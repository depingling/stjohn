package com.americancoders.edi.x12;

/**
 *OBOE - Open Business Objects for EDI
 *<P>java access to EDI
 *<p>Copyright 1998-2007 - American Coders, LTD  - Raleigh NC USA
 *<p>All rights reserved
 *<p>American Coders, Ltd
 *<br>P. O. Box 97462
 *<br>Raleigh, NC  27624  USA
 *<br>1-919-846-2014
 *<br>http://www.americancoders.com
@author Joe McVerry - American Coders, Ltd.
  @version   3.5.3

 * */

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PushbackInputStream;
import java.io.Writer;
import java.util.Vector;

import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.americancoders.edi.DataElement;
import com.americancoders.edi.DocumentErrors;
import com.americancoders.edi.Envelope;
import com.americancoders.edi.FunctionalGroup;
import com.americancoders.edi.OBOEException;
import com.americancoders.edi.Segment;
import com.americancoders.edi.TemplateEnvelope;
import com.americancoders.edi.TemplateSegment;
import com.americancoders.edi.TransactionSet;
import com.americancoders.edi.TransactionSetFactory;
import com.americancoders.util.Util;


/**
 * class for wrapping a X12 EDI transaction set within an EDI Envelope
 *
 */


public class X12Envelope extends Envelope
{


  /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
/** segment constants */
  public static final String  idInterchangeHeader = "ISA";
  public static final String  idGradeofServiceRequest =  "ISB";
  public static final String  idInterchangeAcknowledgment = "TA1";
  public static final String  idDeferredDeliveryRequest = "ISE";
  public static final String  idInterchangeTrailer = "IEA";

  /**
   * instantiates the class from all related OBOE classes
   */

  public X12Envelope()
  {
    super();
    setFormat(Envelope.X12_FORMAT);
    fieldDelimiter = Envelope.X12_FIELD_DELIMITER;
    groupDelimiter = Envelope.X12_GROUP_DELIMITER;
    repeatDelimiter = Envelope.X12_REPEAT_DELIMITER;
    escapeCharacter= Envelope.X12_ESCAPE_CHARACTER;
    
 }


  /**
   * instantiates the class from a TemplateEnvelope,
   * creates mandatory segments ISA and IEA and creates one emtpy functional group
   * @param inTempEnv TemplateEnvelope to build this class with
   * @exception OBOEException missing segment definition in envelope xml.
   */

  public X12Envelope(TemplateEnvelope inTempEnv)
    throws OBOEException
  {
    super();
    setFormat(Envelope.X12_FORMAT);
    
    segmentDelimiter = Envelope.X12_SEGMENT_DELIMITER;
    fieldDelimiter = Envelope.X12_FIELD_DELIMITER;
    groupDelimiter = Envelope.X12_GROUP_DELIMITER;
    repeatDelimiter = Envelope.X12_REPEAT_DELIMITER;
    escapeCharacter= Envelope.X12_ESCAPE_CHARACTER;
    
    myTemplate = inTempEnv;
    myTemplateContainer = myTemplate;



  }


  /* method for parsing well formed edi xml files
  * @param node a DOM node object
  * @throws OBOException...
  */

public void parse(Node node)
   throws OBOEException, FileNotFoundException, IOException
   {
        Node cnode = null;
        NodeList nl = node.getChildNodes();
        
        Segment seg;
        int i;
        for (i = 0; i < nl.getLength(); i++)
        {
           cnode = nl.item(i);
           if (cnode.getNodeType() == Node.ELEMENT_NODE)
              break;
        }


        if (i == nl.getLength())
          throw new OBOEException("No element nodes found");

        if (cnode.getNodeName().compareTo(myTemplate.getTemplateSegment(idInterchangeHeader).getXMLTag()) != 0)
          throw new OBOEException("Expecting " + myTemplate.getTemplateSegment(idInterchangeHeader).getXMLTag());

        seg = new Segment(myTemplate.getTemplateSegment(idInterchangeHeader), this);
        addSegment(seg);
        seg.parse(cnode);
        
        String gd = seg.getDataElement("I15").get();
        if (gd.compareTo(Envelope.X12_GROUP_DELIMITER)!=0)
        {
        	
        	String t = Envelope.X12_SEGMENT_DELIMITER+Envelope.X12_FIELD_DELIMITER+gd+Envelope.X12_REPEAT_DELIMITER+Envelope.X12_ESCAPE_CHARACTER;
        	this.setDelimiters(t);
        }

        for (i++; i < nl.getLength(); i++)
        {
           cnode = nl.item(i);
           if (cnode.getNodeType() == Node.ELEMENT_NODE)
              break;
        }


        if (i == nl.getLength())
          throw new OBOEException("Envelope terminated too soon");

        if (myTemplate.getTemplateSegment(idGradeofServiceRequest) != null && cnode.getNodeName().compareTo(myTemplate.getTemplateSegment(idGradeofServiceRequest).getXMLTag()) == 0)
            {
             seg = new Segment(myTemplate.getTemplateSegment(idGradeofServiceRequest), this);
             addSegment(seg);
             seg.parse(cnode);
             for (i++; i < nl.getLength(); i++)
                {
                    cnode = nl.item(i);
                    if (cnode.getNodeType() == Node.ELEMENT_NODE)
                    break;
                }

             if (i == nl.getLength())
              throw new OBOEException("Envelope terminated too soon");
            }

        if (myTemplate.getTemplateSegment(idDeferredDeliveryRequest)!= null && cnode.getNodeName().compareTo(myTemplate.getTemplateSegment(idGradeofServiceRequest).getXMLTag()) == 0)
            {
             seg = new Segment(myTemplate.getTemplateSegment(idDeferredDeliveryRequest), this);
             addSegment(seg);
             seg.parse(cnode);
             for (i++; i < nl.getLength(); i++)
                {
                    cnode = nl.item(i);
                    if (cnode.getNodeType() == Node.ELEMENT_NODE)
                    break;
                }

             if (i == nl.getLength())
              throw new OBOEException("Envelope terminated too soon");
            }

        if (myTemplate.getTemplateSegment(idInterchangeAcknowledgment)!= null && cnode.getNodeName().compareTo(myTemplate.getTemplateSegment(idInterchangeAcknowledgment).getXMLTag()) == 0)
            {

            do {
                seg  = new Segment(myTemplate.getTemplateSegment(idInterchangeAcknowledgment), this);
                addSegment(seg);
                seg.parse(cnode);
                for (i++; i < nl.getLength(); i++)
                    {
                        cnode = nl.item(i);
                        if (cnode.getNodeType() == Node.ELEMENT_NODE)
                        break;
                    }

                 if (i == nl.getLength())
                  throw new OBOEException("Envelope terminated too soon");

                } while (cnode.getNodeName().compareTo(myTemplate.getTemplateSegment(idInterchangeAcknowledgment).getXMLTag()) == 0);
            }



         while  (myTemplate.getTemplateFunctionalGroup().getTemplateSegment(X12FunctionalGroup.idHeader)!= null &&   cnode.getNodeName().compareTo(myTemplate.getTemplateFunctionalGroup().getTemplateSegment(X12FunctionalGroup.idHeader).getXMLTag()) == 0)
            {
                   FunctionalGroup functionalGroup = new X12FunctionalGroup(myTemplate.getTemplateFunctionalGroup(), this);
                   addFunctionalGroup(functionalGroup);
                   seg = functionalGroup.createSegment(X12FunctionalGroup.idHeader);
                   seg.parse(cnode);
                   functionalGroup.addSegment(seg);
                   for (i++; i < nl.getLength(); i++)
                    {
                        cnode = nl.item(i);
                        if (cnode.getNodeType() == Node.ELEMENT_NODE)
                        break;
                    }

                   if (i == nl.getLength())
                      throw new OBOEException("Envelope terminated too soon");


                   while (myTemplate.getTemplateFunctionalGroup().getTemplateSegment(X12FunctionalGroup.idTrailer) != null
                        &&  cnode.getNodeName().compareTo(myTemplate.getTemplateFunctionalGroup().getTemplateSegment(X12FunctionalGroup.idTrailer).getXMLTag()) != 0)
                    {

                      String tsID = Util.getOBOEProperty(cnode.getNodeName());
                      if (tsID == null)
                        throw new OBOEException(cnode.getNodeName() + " not defined in oboe.properties.");

                      TransactionSet parsedTransactionSet = 
                          TransactionSetFactory.buildTransactionSet(tsID, null,
    					  		  functionalGroup.getSegment(X12FunctionalGroup.idHeader).getDataElement("480").get(),
    							  getSegment(X12Envelope.idInterchangeHeader).getDataElement("I07").get(),
    							  getSegment(X12Envelope.idInterchangeHeader).getDataElement("I06").get(),
    					    	  getSegment(X12Envelope.idInterchangeHeader).getDataElement("I14").get());

                      parsedTransactionSet.setFormat(Envelope.X12_FORMAT);
                      parsedTransactionSet.parse(nl.item(i));
                      functionalGroup.addTransactionSet(parsedTransactionSet);
                      parsedTransactionSet.setParent(functionalGroup);

                      for (i++; i < nl.getLength(); i++)
                       {
                        cnode = nl.item(i);
                        if (cnode.getNodeType() == Node.ELEMENT_NODE)
                        break;
                       }

                      if (i == nl.getLength())
                         throw new OBOEException("Envelope terminated too soon");
                    }

                   seg = functionalGroup.createSegment(X12FunctionalGroup.idTrailer);
                   seg.parse(cnode);
                   functionalGroup.addSegment(seg);
                   for (i++; i < nl.getLength(); i++)
                    {
                        cnode = nl.item(i);
                        if (cnode.getNodeType() == Node.ELEMENT_NODE)
                        break;
                    }

                   if (i == nl.getLength())
                      throw new OBOEException("Envelope terminated too soon");

            }

        if (cnode.getNodeName().compareTo(myTemplate.getTemplateSegment(idInterchangeTrailer).getXMLTag()) != 0)
          throw new OBOEException("Expecting " + myTemplate.getTemplateSegment(idInterchangeTrailer).getXMLTag());


    seg = new Segment(myTemplate.getTemplateSegment(idInterchangeTrailer), this);
    seg.parse(cnode);
    addSegment(seg);


   }

 /* method for parsing fixed format edi files
  * @param DataInputStream
  * @throws OBOException...
  * @throws FileNotFoundException...
  * @throws IOException...
  */

  public boolean parse(PushbackInputStream pis)
      throws OBOEException, FileNotFoundException, IOException
      {
        
        Segment seg;
        int i;

        byte me[] = new byte[3];
        i = pis.read(me);
        if (i != 3)
        	throw new OBOEException("parser fail to read segment id");


        String id = new String(me);

        if (id.compareTo(myTemplate.getTemplateSegment(idInterchangeHeader).getID()) != 0)
          throw new OBOEException("Expecting " + myTemplate.getTemplateSegment(idInterchangeHeader).getID()+ " got " + id);

        seg = new Segment(myTemplate.getTemplateSegment(idInterchangeHeader), this);
        addSegment(seg);
        seg.parse(pis);

        me = new byte[3];
        i = pis.read(me);
        if (i != 3)
        	throw new OBOEException("parser fail to read segment id");
        
        id = Util.rightTrim(new String(me));

        if (myTemplate.getTemplateSegment(idGradeofServiceRequest) != null &&
        id.compareTo(myTemplate.getTemplateSegment(idGradeofServiceRequest).getID()) == 0)
            {
             seg = new Segment(myTemplate.getTemplateSegment(idGradeofServiceRequest), this);
             addSegment(seg);
             seg.parse(pis);
             if (pis.read(me) != 2)
               	throw new OBOEException("parsing failed to read requested data");
             id = Util.rightTrim(new String(me));
            }

        if (myTemplate.getTemplateSegment(idDeferredDeliveryRequest)!= null &&
        id.compareTo(myTemplate.getTemplateSegment(idGradeofServiceRequest).getID()) == 0)
            {
             seg = new Segment(myTemplate.getTemplateSegment(idDeferredDeliveryRequest), this);
             addSegment(seg);
             seg.parse(pis);
             if (pis.read(me) != 2)
               	throw new OBOEException("parsing failed to read requested data");
             id = Util.rightTrim(new String(me));
            }

        if (myTemplate.getTemplateSegment(idInterchangeAcknowledgment)!= null &&
        id.compareTo(myTemplate.getTemplateSegment(idInterchangeAcknowledgment).getID()) == 0)
            {

            do {
                seg  = new Segment(myTemplate.getTemplateSegment(idInterchangeAcknowledgment), this);
                addSegment(seg);
                seg.parse(pis);
                if (pis.read(me) != 2)
                   	throw new OBOEException("parsing failed to read requested data");

                id = Util.rightTrim(new String(me));

                } while (id.compareTo(myTemplate.getTemplateSegment(idInterchangeAcknowledgment).getID()) == 0);
            }

         pis.unread(me);
	  	 me = new byte[2];
         if (pis.read(me) != 2)
           	throw new OBOEException("parsing failed to read requested data");
		 id = Util.rightTrim(new String(me));


         while  (myTemplate.getTemplateFunctionalGroup().getTemplateSegment(X12FunctionalGroup.idHeader)!= null &&
         id.compareTo(myTemplate.getTemplateFunctionalGroup().getTemplateSegment(X12FunctionalGroup.idHeader).getID()) == 0)
            {
                   FunctionalGroup functionalGroup = new X12FunctionalGroup(myTemplate.getTemplateFunctionalGroup(), this);
                   addFunctionalGroup(functionalGroup);
                   seg = functionalGroup.createSegment(X12FunctionalGroup.idHeader);
                   seg.parse(pis);
                   if (pis.read(me) != 2)
                   	throw new OBOEException("parsing failed to read requested data");

                   id = Util.rightTrim(new String(me));
                   functionalGroup.addSegment(seg);

                   while (id.compareTo("ST") == 0)
                    {

                      byte tsme[] = new byte[3];
                      if (pis.read(tsme) != 3)
                       	throw new OBOEException("parsing failed to read requested data");
                      pis.unread(tsme);
                      pis.unread(me);

                      String tsID = Util.rightTrim(new String(tsme));

                      TransactionSet parsedTransactionSet = TransactionSetFactory.buildTransactionSet(tsID);
                      parsedTransactionSet.setFormat(Envelope.X12_FORMAT);
                      parsedTransactionSet.parse(pis);
                      functionalGroup.addTransactionSet(parsedTransactionSet);
                      parsedTransactionSet.setParent(functionalGroup);

                      if (pis.read(me) != 2)
                       	throw new OBOEException("parsing failed to read requested data");
                      
                      id = Util.rightTrim(new String(me));
                    }

                   seg = functionalGroup.createSegment(X12FunctionalGroup.idTrailer);
                   seg.parse(pis);
                   functionalGroup.addSegment(seg);
                   if (pis.read(me) != 2)
                   	throw new OBOEException("parsing failed to read requested data");
                   id = Util.rightTrim(new String(me));

            }
		pis.unread(me);
		me = new byte[3];
        if (pis.read(me) != 3)
           	throw new OBOEException("parsing failed to read requested data");

		id = new String(me);

        if (id.compareTo(myTemplate.getTemplateSegment(idInterchangeTrailer).getID()) != 0)
          throw new OBOEException("Expecting " + myTemplate.getTemplateSegment(idInterchangeTrailer).getID()+ " got " + id);


    seg = new Segment(myTemplate.getTemplateSegment(idInterchangeTrailer), this);
    seg.parse(pis);
    addSegment(seg);

    return true;
}





 

  

    /** creates a basic functionalgroup object
     * @return X12FunctionalGroup
     */
  public FunctionalGroup createFunctionalGroup()
    {
        if (myTemplate != null)
          return new X12FunctionalGroup(myTemplate.getTemplateFunctionalGroup(), this);
        else
          return new X12FunctionalGroup();
    }



  /** returns the Interchange Control Header built for the envelope
   *  @return Segment
   */

public Segment getInterchange_Header() {return getSegment(idInterchangeHeader);}

  /** gets the Grade_of_Service_Request
   * @return Interchange_Control_Header segment
   */
public Segment getGrade_of_Service_Request()  {return getSegment(idGradeofServiceRequest); }

  /** gets the Deferred_Delivery_Request
   * @return Interchange_Control_Header segment
   */
public Segment getDeferred_Delivery_Request()   {return getSegment(idDeferredDeliveryRequest); }

  /** gets the count of Interchange_Acknowledgment in the vector(container)
   *  @return int count
   */

public int getInterchange_AcknowledgmentCount() {return	getSegmentCount(idInterchangeAcknowledgment);}

  /** gets a Interchange_Acknowledgment from the vector(container)
   *  <br>check for runtime array out of bounds exception
   *  @return Interchange_Acknowledgment Segment
   */

public Segment getInterchange_Acknowledgment(int pos)
    {return	getSegment(idInterchangeAcknowledgment,pos);}


 
  /** gets the count of Functional Group object in the vector (container);
   * @return int count
   */
public int getFunctionalGroupCount(){return functionalGroups.size();}

  /** gets a Functional Group object from the vector (container);
   *  <br>check for runtime array out of bounds exception
   * @return a FunctionalGroup object
   */
public FunctionalGroup getFunctionalGroup(int pos){return (FunctionalGroup) functionalGroups.elementAt(pos);}

  /** gets the Vector of Functional Group objects
   * @return a Vector of FunctionalGroup objects
   */
public Vector getFunctionalGroups(){return functionalGroups;}

  /** returns the Interchange Control Trailer built for the envelope
   *  @return Segment
   */

public Segment getInterchange_Trailer() {return getSegment(idInterchangeTrailer);}

  /** creates, sets and returns the Interchange Control Header built for the envelope
   *  @return Segment - can return null if templateenvelope is null or segment not defined in envelope xml rules file
   */

public Segment createInterchange_Header() {
    if (myTemplate == null) return null;
    TemplateSegment tsg = myTemplate.getTemplateSegment(idInterchangeHeader);
    if (tsg == null) return null;
    Segment seg  = new Segment(tsg, this);
    this.addSegment(seg);
    return seg;
    }

  /** creates, sets and returns the Grade_of_Service_Request
   *  @return Segment - can return null if templateenvelope is null or segment not defined in envelope xml rules file
   */
public Segment createGrade_of_Service_Request(){
    if (myTemplate == null) return null;
    TemplateSegment tsg = myTemplate.getTemplateSegment(idGradeofServiceRequest);
    if (tsg == null) return null;
    Segment seg  = new Segment(tsg, this);
    
    return seg;
    }

  /** creates, sets and returns  the Deferred_Delivery_Request
   *  @return Segment - can return null if templateenvelope is null or segment not defined in envelope xml rules file
   */
public Segment createDeferred_Delivery_Request()
    {
    if (myTemplate == null) return null;
    TemplateSegment tsg = myTemplate.getTemplateSegment(idDeferredDeliveryRequest);
    if (tsg == null) return null;
    Segment seg  =  new Segment(tsg, this);
    
    return seg;
    }

  /** creates, adds and returns  a Interchange_Acknowledgment from the vector(container)
   *  <br>check for runtime array out of bounds exception
   *  @return Segment - can return null if templateenvelope is null or segment not defined in envelope xml rules file
   */

public Segment createInterchange_Acknowledgment()
   {
    if (myTemplate == null) return null;
    TemplateSegment tsg = myTemplate.getTemplateSegment(idInterchangeAcknowledgment);
    if (tsg == null) return null;
    Segment seg  = new Segment(tsg, this);
    
    return seg;
    }

  /** creates, sets and returns the Interchange Control Trailer built for the envelope
   *  @return Segment - can return null if templateenvelope is null or segment not defined in envelope xml rules file
   */

public Segment createInterchange_Trailer()
   {
    if (myTemplate == null) return null;
    TemplateSegment tsg = myTemplate.getTemplateSegment(idInterchangeTrailer);
    if (tsg == null) return null;
    Segment seg  =  new Segment(tsg, this);
    this.addSegment(seg);
    
    return seg;
    }


/** sets the Delimter fields in the header */

public void setDelimitersInHeader()
    throws OBOEException
  {

    if (getInterchange_Header() == null)
       throw new OBOEException("header not set yet");

    if (this.repeatDelimiter.length() > 0)
        getInterchange_Header().getDataElement("I10").set(this.repeatDelimiter);

    getInterchange_Header().getDataElement("I15").set(Envelope.X12_GROUP_DELIMITER);

  }


/** sets the functional group count in the trailer.
    also sets the control number from header
 */

public void setFGCountInTrailer()
    throws OBOEException
  {

    if (getInterchange_Trailer() == null)
       throw new OBOEException("trailer not set yet");

    getInterchange_Trailer().getDataElement("I12").set(getInterchange_Header().getDataElement("I12").get());

    getInterchange_Trailer().getDataElement("I16").set(Integer.toString(getFunctionalGroupCount()));
  }

  /**
   * returns the EDI (x12) formatted document in a String
   * @param inFormat int - format type see TransactionSet
   * @return String the formatted document
   * 
   */

public String getFormattedText(int inFormat)
  {

    int format = inFormat;

    StringBuffer sb = new StringBuffer();
    if (format == Envelope.CSV_FORMAT)
      sb.append("Envelope"+com.americancoders.util.Util.lineFeed);
    else
    if (format == Envelope.VALID_XML_FORMAT
	   ||  format == Envelope.VALID_XML_FORMAT_WITH_POSITION
	   || format == Envelope.PIXES_FORMAT) {
            sb.append("<?xml version=\"1.0\" ?>"+com.americancoders.util.Util.lineFeed);
            sb.append("<!-- OBOE release " +
//++$$textRelease            build.not.to.be.released
            "-->"+com.americancoders.util.Util.lineFeed);
            if (format != Envelope.PIXES_FORMAT)
            	sb.append("<!DOCTYPE envelope SYSTEM \"envelope.dtd\">"+com.americancoders.util.Util.lineFeed);
            sb.append("<envelope format=\"X12\">"+com.americancoders.util.Util.lineFeed);
    }
	else
    if  (format == Envelope.XML_FORMAT)
      {
            sb.append("<?xml version=\"1.0\"?>"+com.americancoders.util.Util.lineFeed);
            sb.append("<!-- OBOE release " +
//++$$textRelease            build.not.to.be.released
            "-->"+com.americancoders.util.Util.lineFeed);
            sb.append("<Envelope>"+com.americancoders.util.Util.lineFeed);
      }
    Segment seg = getSegment(idInterchangeHeader);
    sb.append(seg.getFormattedText(format));

    seg = getSegment(idGradeofServiceRequest);
    if (seg != null)// not required
        sb.append(seg.getFormattedText(format));

    seg = getSegment(idDeferredDeliveryRequest);
    if (seg != null)// not required
        sb.append(seg.getFormattedText(format));

    int i;
    for (i=0; i < getInterchange_AcknowledgmentCount(); i++)
      {
       seg = getSegment(idInterchangeAcknowledgment, i);
       sb.append(seg.getFormattedText(format));
      }

    FunctionalGroup fg;
    for (i=0; i < getFunctionalGroupCount(); i++)
      {
       fg = (FunctionalGroup)getFunctionalGroup(i);
       sb.append(fg.getFormattedText(format));
      }
    seg = getSegment(idInterchangeTrailer);
    if (seg == null)
    sb.append(com.americancoders.util.Util.lineFeed+"missing IEA segment"+com.americancoders.util.Util.lineFeed);
    else
    sb.append(seg.getFormattedText(format));
    if  (format == Envelope.XML_FORMAT)
            sb.append("</Envelope>"+com.americancoders.util.Util.lineFeed);
    if (format == Envelope.VALID_XML_FORMAT || format == Envelope.VALID_XML_FORMAT_WITH_POSITION
    		|| format == Envelope.PIXES_FORMAT) {
            sb.append("</envelope>"+com.americancoders.util.Util.lineFeed);
    }
    if (format == Envelope.X12_FORMAT)
      {
      	replaceDelimiters(sb);
      }
    return new String(sb);
  }

/**  replaces delimiters for duplicate delimiters
 * 
 * @param inSB stringbuffer
 * @return string buffer
 */
  private StringBuffer replaceDelimiters(StringBuffer inSB)
  {
   int i;
   if (this.segmentDelimiter.length() == 0 &&
	   this.groupDelimiter.length() == 0 &&
	   this.fieldDelimiter.length() == 0)
	  return inSB;
   for (i = 0; i < inSB.length(); i++)
	 {
	   if (inSB.charAt(i) == Envelope.X12_SEGMENT_DELIMITER.charAt(0))
		 inSB.setCharAt(i,  segmentDelimiter.charAt(0));
	   if (inSB.charAt(i) == Envelope.X12_GROUP_DELIMITER.charAt(0))
		 inSB.setCharAt(i,  groupDelimiter.charAt(0));
	   if (inSB.charAt(i) == Envelope.X12_FIELD_DELIMITER.charAt(0))
		 inSB.setCharAt(i,  fieldDelimiter.charAt(0));
	   if (repeatDelimiter.length()>0 && inSB.charAt(i) == Envelope.X12_REPEAT_DELIMITER.charAt(0))
		 inSB.setCharAt(i,  repeatDelimiter.charAt(0));
	 }
   return inSB;
  }
  /**
   * @see com.americancoders.edi.Envelope#writeFormattedText(Writer, int)
   */

 public void writeFormattedText(Writer inWriter, int inFormat) throws OBOEException, IOException
   {

    Writer writer  = inWriter;
     int format = inFormat;
	 
	 if (format == Envelope.CSV_FORMAT)
	   writer.write("Envelope"+com.americancoders.util.Util.lineFeed);
	 else
	 if (format == Envelope.VALID_XML_FORMAT
		||  format == Envelope.VALID_XML_FORMAT_WITH_POSITION
		|| format == Envelope.PIXES_FORMAT) {
			 writer.write("<?xml version=\"1.0\"?>"+com.americancoders.util.Util.lineFeed);
			 writer.write("<!-- OBOE release " +
//++$$textRelease            build.not.to.be.released
			 "-->"+com.americancoders.util.Util.lineFeed);
			 if  (format != Envelope.PIXES_FORMAT)
			 	writer.write("<!DOCTYPE envelope SYSTEM \"envelope.dtd\">"+com.americancoders.util.Util.lineFeed);
			 writer.write("<envelope format=\"X12\">"+com.americancoders.util.Util.lineFeed);
	 }
	 else
	 if  (format == Envelope.XML_FORMAT)
	   {
			 writer.write("<?xml version=\"1.0\"?>"+com.americancoders.util.Util.lineFeed);
			 writer.write("<!-- OBOE release " +
//++$$textRelease            build.not.to.be.released
			 "-->"+com.americancoders.util.Util.lineFeed);
			 writer.write("<Envelope>"+com.americancoders.util.Util.lineFeed);
	   }
	Segment seg = getSegment(idInterchangeHeader);
 	writer.write(seg.getFormattedText(format));

 	seg = getSegment(idGradeofServiceRequest);
	 if (seg != null)// not required
	  writer.write(seg.getFormattedText(format));

	 seg = getSegment(idDeferredDeliveryRequest);
	 if (seg != null)// not required
	writer.write(seg.getFormattedText(format));

	 int i;
	 
	 for (i=0; i < getInterchange_AcknowledgmentCount(); i++)
	   {
		seg = getSegment(idInterchangeAcknowledgment, i);
		writer.write(seg.getFormattedText(format));
	   }

	 FunctionalGroup fg;
	 for (i=0; i < getFunctionalGroupCount(); i++)
	   {
		fg = (FunctionalGroup)getFunctionalGroup(i);
		fg.writeFormattedText(writer, format);
	   }
	 seg = getSegment(idInterchangeTrailer);
	 if (seg == null)
	 writer.write(com.americancoders.util.Util.lineFeed+"missing IEA segment"+com.americancoders.util.Util.lineFeed);
	 else
	writer.write(seg.getFormattedText(format));
	 if  (format == Envelope.XML_FORMAT)
			 writer.write("</Envelope>"+com.americancoders.util.Util.lineFeed);
	 if (format == Envelope.VALID_XML_FORMAT || format == Envelope.VALID_XML_FORMAT_WITH_POSITION
	 		|| format == Envelope.PIXES_FORMAT) {
			 writer.write("</envelope>"+com.americancoders.util.Util.lineFeed);
	 }
	 
	writer.flush();
	writer.close();
	 
   }



  /**
   * validates
   * @exception OBOEException indicates why envelope is invalid
   */

    public void validate()
    throws OBOEException
    {
    Segment seg, seghdr;
    
    seg = getSegment(idInterchangeHeader);
    if (seg == null)
      throw new OBOEException("Missing ISA Segment");
    else
      seg.validate();
    
    seghdr = seg;

    seg = getSegment(idGradeofServiceRequest);
    if (seg != null)// not required
        seg.validate();

    seg = getSegment(idDeferredDeliveryRequest);
    if (seg != null)// not required
        seg.validate();

    int i;
    
    boolean ta1Found = false;
    for (i=0; i < getInterchange_AcknowledgmentCount(); i++)
      {
       ta1Found = true;
       seg = getSegment(idInterchangeAcknowledgment, i);
       seg.validate();
      }

    FunctionalGroup fg;
    if (getFunctionalGroupCount() == 0 && ta1Found == false)
      throw new OBOEException("No functional groups");
    else
    for (i=0; i < getFunctionalGroupCount(); i++)
      {
       fg = (FunctionalGroup)getFunctionalGroup(i);
       fg.validate();
      }

    seg = getSegment(idInterchangeTrailer);
    if (seg == null)
      throw new OBOEException("Missing IEA Segment");
    else {
      seg.validate();
      if (seghdr != null)
        {
          DataElement de1 = seghdr.getDataElement("I12");
          DataElement de2 = seg.getDataElement("I12");
          // if either is null then it's been reported by previous validate calls
          if (de1 != null && de2 != null)
            {
                if (de1.get().compareTo(de2.get()) != 0)
                  throw new OBOEException("Control number mismatch (I12)");

            }
        }
    }

    }
  /** validate contents of envelope
   * <br> doesn't throw exception but places errors in DocumentErrors object.
   * @param inDErr DocumentErrors object
  */
  public void validate(DocumentErrors inDErr)
    {
    boolean hNoErr = false, tNoErr = false;
    Segment seg, seghdr;
    
    seg = getSegment(idInterchangeHeader);
    if (seg == null)
      inDErr.addError(0, "Envelope", "Missing ISA Segment", this, "1", this, 1);
    else
      hNoErr = seg.validate(inDErr);
    
    seghdr = seg;
    
    seg = getSegment(idGradeofServiceRequest);
    if (seg != null)// not required
        seg.validate(inDErr);

    seg = getSegment(idDeferredDeliveryRequest);
    if (seg != null)// not required
        seg.validate(inDErr);

    int i;

    boolean ta1Found = false;
    for (i=0; i < getInterchange_AcknowledgmentCount(); i++)
    {
     seg = getSegment(idInterchangeAcknowledgment, i);
     seg.validate(inDErr);
     ta1Found = true;
    }

    FunctionalGroup fg;
    if (getFunctionalGroupCount() == 0 && ta1Found == false)
      inDErr.addError(0, "Envelope", "No functional groups", this, "3", this, 1);
    else
    for (i=0; i < getFunctionalGroupCount(); i++)
      {
       fg = (FunctionalGroup)getFunctionalGroup(i);
       fg.validate(inDErr);
      }
    
    seg = getSegment(idInterchangeTrailer);
    if (seg == null)
      inDErr.addError(0, "Envelope", "Missing IEA Segment", this, "3", this, 1);
    else {
      tNoErr = seg.validate(inDErr);
      if (hNoErr == true && tNoErr == true && seghdr != null)
        {
          DataElement de1 = seghdr.getDataElement("I12");
          DataElement de2 = seg.getDataElement("I12");
          // if either is null then it's been reported by previous validate calls
          if (de1 != null && de2 != null)
            {
             if (de1.get() != null && de2.get() != null)

                if (de1.get().compareTo(de2.get()) != 0)
                  inDErr.addError(0, idInterchangeHeader, "Control number mismatch (I12)",  this, "3", seghdr, 3);

            }
        }
    }

    }
  /* (non-Javadoc)
   * @see com.americancoders.edi.IContainedObject#getDelimiter(char)
   */

  	public char getDelimiter(char inOriginal) {
  		
  		 
		 if (inOriginal == Envelope.X12_SEGMENT_DELIMITER.charAt(0))
				return segmentDelimiter.charAt(0);

		 if (inOriginal ==  Envelope.X12_GROUP_DELIMITER.charAt(0))
				 return groupDelimiter.charAt(0);
			     
		 if (inOriginal == Envelope.X12_FIELD_DELIMITER.charAt(0))
				 return fieldDelimiter.charAt(0);
			     
		 if (inOriginal == Envelope.X12_REPEAT_DELIMITER.charAt(0)) {
		   if  (repeatDelimiter.length()>0)
		     return repeatDelimiter.charAt(0);
		   else 
			return inOriginal;
		 }

 		return inOriginal;
	}
  	
  	


}


