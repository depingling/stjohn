package com.americancoders.edi;



import java.io.IOException;
import java.io.Writer;
import java.util.Vector;

import org.apache.log4j.Logger;
import org.w3c.dom.Node;

import com.americancoders.util.Util;


/**
 *class to keep track of errors in EDI documents.
 *<P>OBOE - Open Business Objects for EDI
 *<p>Part of the OBOE Basic Extended Package
 *<br>An EDI and XML Translator Written In Java
 *<br>Copyright 1998-2007 - American Coders, LTD  - Raleigh NC USA
 *<br>All rights reserved
 *<br>American Coders, Ltd
 *<br>P. O. Box 97462
 *<br>Raleigh, NC  27624  USA
 *<br>1-919-846-2014
 *<br>http://www.americancoders.com
@author Joe McVerry - American Coders, Ltd.
  @version   3.5.3
 */

public class XMLErrors
{

	Vector containers = new Vector();
	Vector reportable = new Vector();
	Vector level = new Vector();
	Vector descriptions = new Vector();
	Vector lineNumbers = new Vector();
	Vector nodes = new Vector();
	
	static Logger logr = Logger.getLogger(XMLErrors.class);
	   
	static 	{Util.isLog4JNotConfigured();}

	/** minimum level of error checking
	 * <br>defaults to 2
	 */
	private int errorLevel = 2; 
	
    /** Constructor
     */

     public XMLErrors()
     {
        try {
			String el = Util.getOBOEProperty("errorLevelToReport");
			if (el == null)
				return;
			int iel = Integer.parseInt(el);
			setErrorLevel(iel);
		}
        catch (NumberFormatException e){
			logr.error(e.getMessage(), e);
		} catch (OBOEException e) {
			logr.error(e.getMessage(), e);
		} catch (IOException e) {
			logr.error(e.getMessage(), e);
		}
		
	 }
     
     /**
      * sets the minimim level of compliance checking
      * <br> default value is set to 2
      * <br> minimum value is 1
      * <br> maximum value is 10
      * @param inLvl
      */
     public void setErrorLevel(int inLvl) {
     	if (inLvl < 1 || inLvl > 10){
     		logr.error("setErrorLevel value out of range (1-10).  Value passed"+inLvl);
     		return;
     	}
     	errorLevel = inLvl;
     	}
     
     public int getErrorLevel(int inLvl) {return errorLevel;}

	 /**
	 * @param inDescription
	 * @param inContainer
	 * @param inNode
	 * @param inLevel
	 */
	public void addError(String inDescription, IContainedObject inContainer, Node inNode, int inLevel) {
		if (inLevel > errorLevel) // not reporting these errors.
			return;
			
	    containers.add(inContainer);
	 	reportable.add(null);
	 	level.add(null);
	 	descriptions.add(inDescription);
	 	lineNumbers.add(null);
	 	nodes.add(inNode);
	     
	 }
    
	 /**
	 * @param inLine
	 * @param inDescription
	 * @param inContainer
	 * @param inLevel
	 */
	public void addError(int inLine, String inDescription, IContainedObject inContainer, int inLevel)
	 {
		
		if (inLevel > errorLevel) // not reporting these errors.
			return;
		
	    containers.add(inContainer);
	 	reportable.add(null);
	 	level.add(new Integer(inLevel));
	 	descriptions.add(inDescription);
	 	lineNumbers.add(new Integer(inLine));
	 	nodes.add(null);
	 }

	 /** returns the number of segment errors
	  * @return int
	  */

	 public int getErrorCount() { return descriptions.size(); }


	 /** returns the description of the error
	  * @param inPosition is the position in the vector of errors
	  */
	 public String getErrorDescription(int inPosition)
	  {

		  return (String) descriptions.elementAt(inPosition);
	  }

	 /** returns the container of the segment in error  or the last valid container
	  * @param inPosition is the position in the vector of errors
	  */
	 public IContainedObject getContainer(int inPosition)
	  {

		  return (IContainedObject) containers.elementAt(inPosition);
	  }


	/** returns the boolean indicator if the error is reportable by 997/CONTRL
	 * @param inPosition is the position in the vector of boolean indicator
	 */
	public boolean isReportable(int inPosition) {
		Boolean bool = (Boolean) reportable.elementAt(inPosition);
		return bool.booleanValue();
	}
	
	/** returns the level of error  
	 * @param inPosition is the position in the vector of boolean indicator
	 * @return int
	 */
	
	public int getLevel(int inPosition) {
		return ((Integer) level.elementAt(inPosition)).intValue();
	}
	
	
	public int getLineNumber(int inPosition){
		return ((Integer) lineNumbers.elementAt(inPosition)).intValue();
	}

	 /** returns a string array of the errors found, or null if no errors.
	  * @return String[]
	  */
	 public String[] getError()
	  {
		  if (getErrorCount() == 0) return null;
		  String array[] = new String[getErrorCount()];
		  for (int i = 0; i < getErrorCount(); i++)
		  {
		      if (getContainer(i) == null)
			     array[i] = "Error at: " + getLineNumber(i) +
			             " Description: " + getErrorDescription(i);
		      else
			     array[i] = "Segment position: " + getLineNumber(i) +
			             " Description: " + getErrorDescription(i) +
			             " Container ID: " + getContainer(i).getID();
		  }
		  return array;
	  }
	 
	 /**
	  * logs the document error lines to the log file
	  *
	  */
	 public void logErrors()
	 {
		for (int i = 0; i < getErrorCount(); i++) {

			StringBuffer sb = new StringBuffer(getErrorDescription(i) + " ");
			if (getContainer(i) instanceof Segment) {
				Segment s = (Segment) getContainer(i);
				sb.append("Segment ID:" + s.getID() + " name:" + s.getName());
			} else
				sb.append(getContainer(i));
			
			logr.error(sb.toString());
		}
	 }
	 
	 /**
	  * sends the document error lines to a java.io.Writer object
	  * @param inWrtr Writer
	 * @throws IOException - something wrong with the Writer object?
	  */
	 public void writeErrors(Writer inWrtr) throws IOException 
	 {
		for (int i = 0; i < getErrorCount(); i++) {
            inWrtr.write(getErrorDescription(i) + " ");
			if (getContainer(i) instanceof Segment) {
				Segment s = (Segment) getContainer(i);
				inWrtr.write("Segment ID:" + s.getID() + " name:" + s.getName());
			} else
				inWrtr.write(getContainer(i).toString());
			
			inWrtr.write("\n");
		}
	 }
}


