/**
 * 
 */
package com.americancoders.edi;

/**
 * interface for Indentifying ID fields, used on Composites and DataELements
 *
 *<P>OBOE - Open Business Objects for EDI
 *<p>Part of the OBOE Basic Extended Package
 *<br>An EDI and XML Translator Written In Java
 *<br>Copyright 1998-2007 - American Coders, LTD  - Raleigh NC USA
 *<br>All rights reserved
 *<br>American Coders, Ltd
 *<br>P. O. Box 97462
 *<br>Raleigh, NC  27624  USA
 *<br>1-919-846-2014
 *<br>http://www.americancoders.com
 *@since 3.5.1
@author Joe McVerry - American Coders, Ltd.
  @version   3.5.3
 */

public interface IDelimiterFetcher {
	
	/** returns the objects EDI delimiter 
	 * 
	 * @param inOriginal the one it's primarily known as
	 * @return the new delimiter as defined by the application
	 */
	public char getDelimiter(char inOriginal);

}
