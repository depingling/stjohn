package com.americancoders.edi;

import java.io.ByteArrayInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.io.PushbackInputStream;
import java.net.URL;

import com.americancoders.edi.EDIFact.EDIFactEnvelope;
import com.americancoders.edi.x12.X12Envelope;

/**
 * class builds OBOE objects by parsing input string in xml edi format
 *
 *<P>OBOE - Open Business Objects for EDI
 *<p>Part of the OBOE Basic Extended Package
 *<br>An EDI and XML Translator Written In Java
 *<br>Copyright 1998-2007 - American Coders, LTD  - Raleigh NC USA
 *<br>All rights reserved
 *<br>American Coders, Ltd
 *<br>P. O. Box 97462
 *<br>Raleigh, NC  27624  USA
 *<br>1-919-846-2014
 *<br>http://www.americancoders.com
@author Joe McVerry - American Coders, Ltd.
  @version   3.5.3
 *
 */

public class FixedLengthParser {
	protected URL url = null;
	protected Envelope envelope=null;

	/**
	 * create a transaction set from input string
	 */

	public FixedLengthParser() {
	}

	/**
	 * static main method to test xmlparser class
	 *
	 */
	public static void main(String args[]) {
		try {
			FixedLengthParser xmlp = new FixedLengthParser();
			xmlp.parseFile(args[0]);
			//System.out.println(xmlp.getEnvelope().getFormattedText(1));
			xmlp.getEnvelope().writeFormattedText(new PrintWriter(System.out),1);
		} catch (Exception e1) {
			e1.printStackTrace();
		}
	}

	/**
	 * builds  a transaction set from input string
	 * @param inString the edi document
	 * @exception OBOEException
	 *                      - unknown transaction set, this transaction set is undefined to OBOE
	 */

	public void parse(String inString) {
		ByteArrayInputStream bais =
			new ByteArrayInputStream(inString.getBytes());
		parse(bais);
	}

	/**
	 * builds  a transaction set from input file
	 * @param inString Filename of the edi document file name
	 * @exception FileNotFoundException
	 * @exception IOException
	 */

	public void parseFile(String inString)
		throws FileNotFoundException, IOException {
		FileInputStream fis = new FileInputStream(inString);
		parse(fis);
	}

	/**
	 * builds  a transaction set by reading a URL <i>NOT USED</i>
	 * @param inURL url 
	 * @param text the document String
	 * @exception OBOEException
	 *                - unknown transaction set, this transaction set is undefined to OBOE
	 */

	public void parse(URL inURL, String text) throws OBOEException {
		url = inURL;
		parse(text);
	}

	/**
	 * builds  a transaction set from input stream
	 * <br>all the work is really done here, the other parse methods call this
	 * @param inStream InputStream the edi document in a stream
	 * @exception OBOEException
	 * <br>                 - continues to throw existing exception
	 *                      - unknown transaction set, this transaction set is undefined to OBOE
	 */

	public void parse(InputStream inStream) throws OBOEException {
		PushbackInputStream pis = null;
		try {

			pis = new PushbackInputStream(inStream, 7);

			char id = (char) pis.read();
			pis.unread((byte) id);

			if (id == 'I')
				envelope =
					new X12Envelope(
						EnvelopeFactory.buildEnvelope("x12.envelope","notSetYet"));
			else if (id == 'U')
				envelope =
					new EDIFactEnvelope(
						EnvelopeFactory.buildEnvelope("EDIFact.envelope","notSetYet"));
			else
				throw new OBOEException(
					"Unknown envelope starting segment " + id);

			envelope.parse(pis);

		} catch (Exception e) {
			e.printStackTrace();
			throw new OBOEException(e.getMessage());
		} finally {
			if (pis != null)
				try {
					pis.close();
				} catch (IOException ioe) {
					;
				}
		}

	}

	/**
	 * returns the Envelope that was parsed
	 * @return envelope object either X12Envelope or EDIFactEnvelope
	 */
	public Envelope getEnvelope() {
		return envelope;
	}

}
