package com.americancoders.edi;

import java.io.Externalizable;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInput;
import java.io.ObjectInputStream;
import java.io.ObjectOutput;
import java.lang.reflect.Method;
import java.util.Enumeration;
import java.util.Hashtable;

import org.apache.log4j.Logger;

import com.americancoders.util.Util;


/**
 *class for Template Transaction Sets
 *<p>OBOE - Open Business Objects for EDI
 *<p>Part of the OBOE Basic Extended Package
 *<br>An EDI and XML Translator Written In Java
 *<br>Copyright 1998-2007 - American Coders, LTD  - Raleigh NC USA
 *<br>All rights reserved
 *<br>American Coders, Ltd
 *<br>P. O. Box 97462
 *<br>Raleigh, NC  27624  USA
 *<br>1-919-846-2014
 *<br>http://www.americancoders.com
@author Joe McVerry - American Coders, Ltd.
  @version   3.5.3
 */

public class TemplateTransactionSet
	implements Externalizable, IContainedObject {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
	* Template TransactionSet format
	*/
	int format = -1;
	/**
	 * TransactionSet id (840, ORDER...)
	 */
	String id = "";
	/**
	 * TransactionSet name
	 */
	String name = "";
	/**
	 * TransactionSet revision  (3040, D99A...
	 */
	String revision = "";
	/**
	 * TransactionSet functional group
	 */
	String functionalGroup = "";
	/**
	 * TransactionSet description
	 */
	String shortDescription = "";
	/**
	 * TransactionSet XML tag
	 */
	String xmlTag = "";
	
	/** store idListFile datetime stamp */
	protected Hashtable idListFileList = new Hashtable();

	
	/**
	 * TransactionSet tables three of them.
	 */

	com.americancoders.edi.TemplateTable headerTemplateTable = null,
		detailTemplateTable = null,
		summaryTemplateTable = null;
	/** parent container
	 */
	protected IContainedObject parent = null;
	
	static Logger logr = Logger.getLogger(TemplateTransactionSet.class);
	static 	{Util.isLog4JNotConfigured();}





	/** creates a Template transactionset object
	 */
	public TemplateTransactionSet() {
		
	}

	/** constructs a Template Transaction Set
	 * @param inFormat int format
	 * @param inId String ts id
	 * @param inName String name
	 * @param inRevision String revision or version
	 * @param inFunctionalGroup String functional group
	 * @param inShortDescription String short description
	 * @param inXMLTag String xml tag
	 * @param inParent owning Object
	 */

	public TemplateTransactionSet(
		int inFormat,
		String inId,
		String inName,
		String inRevision,
		String inFunctionalGroup,
		String inShortDescription,
		String inXMLTag,
		IContainedObject inParent) {
		
		setFormat(inFormat);
		setID(inId);
		setName(inName);
		setRevision(inRevision);
		setFunctionalGroup(inFunctionalGroup);
		setShortDescription(inShortDescription);
		setXMLTag(inXMLTag);
		setParent(inParent);
	}

	/** sets format for the Transaction Set
	 * <br> XML_FORMAT = 1;
	 * <br> X12_FORMAT = 2;
	 * <br> EDIFACT_FORMAT = 3;
	 * <br> VALID_XML_FORMAT = 4;
	 * @param inFormat int format
	 */
	public void setFormat(int inFormat) {
		if (inFormat == Envelope.XML_FORMAT
			|| inFormat == Envelope.X12_FORMAT
			|| inFormat == Envelope.EDIFACT_FORMAT
			|| inFormat == Envelope.VALID_XML_FORMAT)
			format = inFormat;
		else
			logr.error(
				"Invalid transaction set format "
					+ inFormat
					+ ".  Value set to -1");
	}

	/** sets id for the Transaction Set
	* @param inId String transation set id
	*/
	public void setID(String inId) {
		id = inId;
	}

	/** sets name for the Transaction Set
	 * @param inName String transaction set name
	 */
	public void setName(String inName) {
		name = inName;
	}

	/** sets Revision for the Transaction Set
	 * @param inRevision String revision or version
	 */
	public void setRevision(String inRevision) {
		revision = inRevision;
	}

	/** sets Function Group for the Transaction Set
	 * @param inFunctionalGroup String functional group
	 */
	public void setFunctionalGroup(String inFunctionalGroup) {
		functionalGroup = inFunctionalGroup;
	}

	/** sets Short Description for the Transaction Set
	 * @param inDesc String description
	 */
	public void setShortDescription(String inDesc) {
		shortDescription = inDesc;
	}

	/** sets header TemplateTable for the Transaction Set
	 * @param inTemplateTable TemplateTable
	 */
	public void setHeaderTemplateTable(TemplateTable inTemplateTable) {
		headerTemplateTable = inTemplateTable;
	}

	/** sets detail TemplateTable for the Transaction Set
	 * @param inTemplateTable TemplateTable
	 */
	public void setDetailTemplateTable(TemplateTable inTemplateTable) {
		detailTemplateTable = inTemplateTable;
	}
	/** sets summary TemplateTable for the Transaction Set
	 * @param inTemplateTable TemplateTable
	 */
	public void setSummaryTemplateTable(TemplateTable inTemplateTable) {
		summaryTemplateTable = inTemplateTable;
	}

	/** returns the Transaction Set format
	 * @return int
	 */

	public int getFormat() {
		return format;
	}

	/** returns the Transaction Set id
	 * @return String
	 */

	public String getID() {
		return id;
	}

	/**
	 * returns name for the Transaction Set
	 * @return String
	 *
	 */

	public String getName() {
		return name;
	}

	/**
	 * returns revision value for the Transaction Set
	 * @return String
	 *
	 */

	public String getRevision() {
		return revision;
	}

	/**
	 * returns functional group string
	 * @return String
	 *
	 */

	public String getFunctionalGroup() {
		return functionalGroup;
	}

	/**
	 * returns the Short Description for the Transaction Set
	 * @return String
	 */
	public String getShortDescription() {
		if (shortDescription == null || shortDescription.length() == 0)
			return id;
		return shortDescription;
	}

	/**
	 * returns header TemplateTable for the Transaction Set
	 * @return TemplateTable
	 *
	 */

	public TemplateTable getHeaderTemplateTable() {
		return headerTemplateTable;
	}

	/**
	 * returns detail TemplateTable for the Transaction Set
	 * @return TemplateTable
	 *
	 */

	public TemplateTable getDetailTemplateTable() {
		return detailTemplateTable;
	}

	/**
	 * returns summary TemplateTable for the Transaction Set
	 * @return TemplateTable
	 *
	 */

	public TemplateTable getSummaryTemplateTable() {
		return summaryTemplateTable;
	}

	/** sets the xml tag field
	 * @param inXMLTag String xml tag id
	 */

	public void setXMLTag(String inXMLTag) {
		xmlTag = inXMLTag;
	}

	/**
	 * returns the xml tag field
	 * @return String tag value
	 */

	public String getXMLTag() {

		return xmlTag;
	}

	/** used by externalize methods
	 * @param in ObjectInput stream
	 * @exception IOException - most likely class changed since written
	 * @exception ClassNotFoundException - only when dummy constructro not found
	 */

	public void readExternal(ObjectInput in)
		throws IOException, ClassNotFoundException {
		format = in.readInt();
		id = in.readUTF();
		name = in.readUTF();
		revision = in.readUTF();
		shortDescription = in.readUTF();
		xmlTag = in.readUTF();
		functionalGroup = in.readUTF();
		
		idListFileList = (Hashtable) in.readObject();

		headerTemplateTable = (TemplateTable) in.readObject();
		detailTemplateTable = (TemplateTable) in.readObject();
		summaryTemplateTable = (TemplateTable) in.readObject();
        }

	/** used by externalize methods
	 * @param out ObjectOutput stream
	 * @exception IOException Java.io error
	 */

	public void writeExternal(ObjectOutput out) throws IOException {
		out.writeInt(format);
		out.writeUTF(id);
		out.writeUTF(name);
		out.writeUTF(revision);
		out.writeUTF(shortDescription);
		out.writeUTF(xmlTag);
		out.writeUTF(functionalGroup);
		out.writeObject(idListFileList);
		out.writeObject(headerTemplateTable);
		out.writeObject(detailTemplateTable);
		out.writeObject(summaryTemplateTable);

	}

	/** sets parent attribute
	 * @param inParent TemplateSegmentContainer
	 */
	public void setParent(IContainedObject inParent) {
		parent = inParent;
	}

	/** gets parent attribute
	 * @return TemplateSegmentContainer
	 */
	public IContainedObject getParent() {
		return parent;
	}


	
	public void addIDListFile(File inFile)
	{
		this.idListFileList.put(inFile.getPath(), new Long(inFile.lastModified()));
	}
	
	public boolean checkIDListFiles()
	{
		int i;
		Enumeration enum = idListFileList.keys();
		for (i = 0 ; i < idListFileList.size(); i++) 
		{
			String pth = (String) enum.nextElement();
			File f = new File(pth);
			if (f == null)
				return false;
			if (f.exists()== false)
			   return false;
			Long l = (Long) idListFileList.get(pth);
			if (l.longValue() != f.lastModified())
				return false;
			
		}
		                                             
		return true;
	}
	
	/* (non-Javadoc)
	 * @see com.americancoders.edi.IContainedObject#getDelimiter(char)
	 */

		public char getDelimiter(char inOriginal) {
			if (parent == null)
				return inOriginal;
			return parent.getDelimiter(inOriginal);
		}

}
