package com.americancoders.util;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;

import javax.activation.DataSource;



/* This class implements a typed DataSource from :
 * 	an InputStream
 *	a byte array
 * 	a String
 *OBOE - Open Business Objects for EDI
 *<p>Copyright 1998-2007 - American Coders, LTD  - Raleigh NC USA
 *<p>All rights reserved
 *<p>American Coders, Ltd
 *<br>P. O. Box 97462
 *<br>Raleigh, NC  27624  USA
 *<br>1-919-846-2014
 *<br>http://www.americancoders.com
@author Joe McVerry - American Coders, Ltd.
  @version   3.5.3
 */
public class ByteArrayDataSource implements DataSource {
  private byte[] data; // data
  private String type; // content-type

  /** Create a datasource from an input stream
   * @param is InputStream
   * @param inType String type (not used)
   */
  public ByteArrayDataSource(InputStream is, String inType) {
    type = inType;
    try {
      ByteArrayOutputStream os = new ByteArrayOutputStream();
      int ch;

      while ((ch = is.read()) != -1)
      // XXX : must be made more efficient by
      // doing buffered reads, rather than one byte reads
      os.write(ch);
      data = os.toByteArray();

  } catch (IOException ioex) { }
  }

  /* Create a datasource from a byte array
   * @param byte[]
   * @param String type
   */
  public ByteArrayDataSource(byte[] inData, String inType) {
    data = (byte[])inData.clone();
    type = inType;
  }

  /* Create a datasource from a String
   * @param InputStream
   * @param String (not used)
   */
public ByteArrayDataSource(String inData, String inType) {
    try {
      // Assumption that the string contains only ascii
      // characters ! Else just pass in a charset into this
      // constructor and use it in getBytes()
      data = inData.getBytes("iso-8859-1");
  } catch (UnsupportedEncodingException uex) { }
    type = inType;
  }

  /**
   * taken from sun's exmaples
   * @return InputStream
   * @exception IOException from sun examples
   */

  public InputStream getInputStream() throws IOException {
    if (data == null)
    throw new IOException("no data");
    return new ByteArrayInputStream(data);
  }


  /**
   * taken from sun's exmaples
   * @return OutputStream
   * @exception IOException from sun examples
   */

  public OutputStream getOutputStream() throws IOException {
    return new ByteArrayOutputStream();
  }

  /**
   * returns data in byte array
   * @return byte[]
   */
  public byte[] getData() {
    return (byte[]) data.clone();
  }

  /**
   * taken from sun's exmaples
   * @return String type
   */
  public String getContentType() {
    return type;
  }

  /**
   * always returns edix12
   * @return String constant "edix12"
   */

  public String getName() {
    return "edix12";
  }

}
