package com.americancoders.edi;


/**
 * interface for DataElement Container
 *
 *<P>OBOE - Open Business Objects for EDI
 *<p>Part of the OBOE Basic Extended Package
 *<br>An EDI and XML Translator Written In Java
 *<br>Copyright 1998-2007 - American Coders, LTD  - Raleigh NC USA
 *<br>All rights reserved
 *<br>American Coders, Ltd
 *<br>P. O. Box 97462
 *<br>Raleigh, NC  27624  USA
 *<br>1-919-846-2014
 *<br>http://www.americancoders.com
@author Joe McVerry - American Coders, Ltd.
  @version   3.5.3
 */

public interface IDataElementContainer
{

  /** returns a DataElement in the Container
     * <br>since more than one dataelement with the same id can be
     * in the container this is not a very effective method for fetching unique datalements.
     * @return DataElement  DataElement object
     * @param ID String ID of datalement to look for
     * @exception OBOEException ID is unknown
     */

  public  DataElement getDataElement(String ID)
  throws OBOEException;

  /** returns a DataElement in the Container
 * @return DataElement  DataElement object
 * @param inSequence int sequence position of dataelement
 * @exception OBOEException ID is unknown
 */

  public  DataElement getDataElement(int inSequence)
  throws OBOEException;



  
  /**
   * returns the number of defined data element
   * @return int DataElement count
   */

  public int  getDataElementSize();
  
  
  /** defines a dataelement by the predefined templateDE array
   * @param pos field to build is identified by its templates position
   * <br><b>position is relative to 1.</b>
   * @return Object always a DataElement, I used Object to keep it consistent with what
   * Segments buildDE returns.
   */

  public Object buildDE(int pos);
}
