/*
 * Copyright (C) 2006-2007 by Joseph McVerry - American Coders, Ltd.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

package org.pixes;

/**
 * @author Joe McVerry - American Coders, Ltd.
 *
 * interface for objects that are continualbe such as loops
 *
 */
public interface IContinuable {

	/**
	 * return the error step
	 * @return int
	 */
	public int getErrorStep();
	/**
	 * return the next step
	 * @return int
	 */
	public int getNextStep();
	/**
	 * return the continue step for looping
	 * @return int
	 */
	public int getContinueStep();
	/**
	 * sets the continue step
	 * @param pos of continue step
	 */
	public void setContinueStep(int pos);

}
