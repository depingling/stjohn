package com.americancoders.samples;
/*
 * <p>EdifactExample.java
 * <p>Copyright 1999 mendelson-e-commerce GmbH Berlin Germany
 * <p>http://www.mendelson.de
 * <p>Created on 5. Januar 2000, 15:27
 * @author Stefan Heller
 */

import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.PrintWriter;

import org.apache.log4j.Logger;

import com.americancoders.edi.Envelope;
import com.americancoders.edi.OBOEException;
import com.americancoders.edi.EDIFact.EDIFactDocumentHandler;
import com.americancoders.util.Util;

/**
 * @version 1.0
 */
public class EdifactExample {

	
	/** log4j object */
	static Logger logr = Logger.getLogger(EdifactExample.class);
	static {Util.isLog4JNotConfigured();}

	
	public EdifactExample(String filein, String fileout) {
		try {
			//receive file contents

			EDIFactDocumentHandler dh =
				new EDIFactDocumentHandler(new FileReader(filein));

			logr.debug("result written to \"" + fileout + "\".");
			dh.getEnvelope().writeFormattedText(new PrintWriter(new FileOutputStream(fileout)), Envelope.VALID_XML_FORMAT);
		}
		catch (OBOEException oe) {
			logr.error(oe.getMessage());
			String de[] = oe.getDocumentErrors().getError();
			for (int j=0; j<de.length; j++)
				System.out.println(de[j]);
		}
		catch (Exception e) {
			logr.error(e.getMessage(), e);
		}

	}


	/**
	* @param args the command line arguments
	*/
	public static void main(String args[]) {
		if (args == null || args.length < 2) {
			System.out.println(
				"usage: java com.americancoders.samples.EdifactExample <edidatafilename> <xmloutfilename>");
			System.exit(-1);
		}
		new EdifactExample(args[0], args[1]);
	}

}
