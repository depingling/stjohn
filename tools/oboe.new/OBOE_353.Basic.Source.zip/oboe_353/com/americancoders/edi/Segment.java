package com.americancoders.edi;

import java.io.IOException;
import java.io.PushbackInputStream;
import java.util.Vector;

import org.apache.log4j.Logger;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.americancoders.util.Util;

/**
 * class for Segments
 *OBOE - Open Business Objects for EDI
 *<P>An EDI and XML Translator Written In Java
 *<p>Copyright 1998-2007 - American Coders, LTD  - Raleigh NC USA
 *<p>All rights reserved
 *<p>American Coders, Ltd
 *<br>P. O. Box 97462
 *<br>Raleigh, NC  27624  USA
 *<br>1-919-846-2014
 *<br>http://www.americancoders.com
@author Joe McVerry - American Coders, Ltd.
  @version   3.5.3
 */

public class Segment  implements IDataElementContainer, ICompositeDEContainer,  IContainedObject, IDelimiterFetcher
{

    /** array of owned datalements
     */
    protected Object deArray[];
    /** TemplateSegment that can build this segment
     */
    protected TemplateSegment myTemplate = null;

    /**
     * position within the X12 or EDIFACT document
     */
    protected int positionInIncomingDocument=-1;
    
    protected int byteOffsetPositionInIncomingDocument=-1;
    
    
	/** log4j object */
	static Logger logr = Logger.getLogger(Segment.class);
	static 	{Util.isLog4JNotConfigured();}

    /** create a Segment based on its template
     * @param inTemplateSegment predefined TemplateSegment
       * @param inParent owning Object
   * @throws OBOEException unknown segment
     */

    public Segment(TemplateSegment inTemplateSegment, IContainedObject inParent)
    throws OBOEException
    {
        super();
        myTemplate = inTemplateSegment;

        deArray = new Object[inTemplateSegment.getTemplateDESize()];
        for (int i = 1;i <= inTemplateSegment.getTemplateDESize(); i++)
         {
			if (myTemplate.isTemplateComposite(i))
				if (myTemplate.getTemplateComposite(i).getRequired()!= 'M')
				continue;
			if (myTemplate.isTemplateDE(i))
				if (myTemplate.getTemplateDE(i).getRequired()!= 'M')
				continue;
			buildDE(i);
         }

        setParent(inParent);
  }



    /** returns the TemplateSegment used to build the Segment
     * @return TemplateSegment
     */
	public TemplateSegment getTemplate(){ return myTemplate; }


    /**
     * gets the segment id
     * @return String id
     */


	public String getID(){return myTemplate.getID();}


    /**
     * gets the segment Name
     * @return String Name
     */


public String getName(){return myTemplate.getName();}


    /**
     * returns the occurs value
     * @return int occurance value
     *
     */

public int getOccurs() {return myTemplate.getOccurs();}


    /**
     * returns the required flag
     * @return char required
     *
     */

public char getRequired() {return myTemplate.getRequired();}

    /**
     * returns the xml tag field
     * @return String tag value
     */

public String getXMLTag() { return myTemplate.getXMLTag(); }

/** 
 * returns the used indicator
 * @return boolean
 */
public boolean isUsed() { return myTemplate.isUsed();

}



    /**
     * gets the segment sequence
     * @return int sequence number
     */
public int getSequence(){ return myTemplate.getSequence(); }

    /** this is here as a stub because of the segment container interface
     * @return Segment
     * @param ID String
     * @throws OBOEException as thrown
     */


    /**
     * returns the Short Description for the Segment
     * @return String
     */
public String getDescription() {return myTemplate.getDescription();}


    /** parses an EDI Document
     * adds to datalement vector
     * and adds to secondary segment vector
     * @param TransactionSetTokenizer tokenizer hold string data
     * @throws OBOEException as thrown, can't process subsegment maybe
     */

public boolean parse(ITokenizer TransactionSetTokenizer)
    throws OBOEException
    {
        int i;
        int elementsToParse;

        DataElement currentDE;
        CompositeDE currentComposite;
       

        setPosition(TransactionSetTokenizer.getSegmentPos());

        TransactionSetTokenizer.getNextDataElement();
        elementsToParse = TransactionSetTokenizer.countDataElements()-1;// skip the id

        if (myTemplate != null
                && elementsToParse > getTemplate().getTemplateDESize()) {
            TransactionSetTokenizer.reportError("Too many data elements "
                    + elementsToParse + " is greater than template count of "
                    + getTemplate().getTemplateDESize());
        } else if (myTemplate == null && elementsToParse > deArray.length) {
            TransactionSetTokenizer.reportError("Too many data elements "
                    + elementsToParse
                    + " is greater than built segment count of "
                    + deArray.length);
            return false;
        }

        for (i=0;
                i < elementsToParse && TransactionSetTokenizer.hasMoreDataElements();
                i++)

            {
                if (myTemplate != null && i >= getTemplate().getTemplateDESize())
                  ;
                else
                {
                if (i >= deArray.length || (deArray[i] == null))
                {
                    buildDE(i+1);
                }

                if (isCompositeDE(i+1))
                {
                    currentComposite = (CompositeDE) deArray[i];
                    if (currentComposite.getOccurs() > 1) {
                    	DataTokenizer dt = new DataTokenizer(TransactionSetTokenizer.getCurrentDataElement(),
                    	                                         TransactionSetTokenizer.getRepeaterCharacter(),
                    	                                         TransactionSetTokenizer.getEscapeCharacters());
                    	for (int dti = 0; dti < dt.countTokens(); dti++){
                    		if (dti > 0)
                    		   currentComposite.createNewGroup();
                    		currentComposite.parse(dt.getTokenAt(dti), TransactionSetTokenizer);
                    	}

					 }
					else {
						if (currentComposite.parse(TransactionSetTokenizer) == false)
						   continue;
					}

                }
                else if (isDataElement(i+1))
                {
                    currentDE = (DataElement) deArray[i];
                    try {
                       if (currentDE.getOccurs() > 1) {
						DataTokenizer dt = new DataTokenizer(TransactionSetTokenizer.getCurrentDataElement(),
																 TransactionSetTokenizer.getRepeaterCharacter(),
																 TransactionSetTokenizer.getEscapeCharacters());
						for (int dti = 0; dti < dt.countTokens(); dti++){
							currentDE.setNext(dt.getTokenAt(dti));
						}
                       }
                       else {
                       currentDE.set(Util.unEscape(TransactionSetTokenizer.getCurrentDataElement(), TransactionSetTokenizer.getEscapeCharacters()));
                       }
                       }
                    catch (Exception exc)
                      {
                        TransactionSetTokenizer.reportError("Parsing Error: "+exc.getMessage());
                      }

                }
                else if(TransactionSetTokenizer.getCurrentDataElement().length()>0)
                      {

                        TransactionSetTokenizer.reportError("Parsing Error: element (\""+TransactionSetTokenizer.getCurrentDataElement()+"\") at position "+(i+1)+" is not used in segment "+getID());
                      }
                }
                TransactionSetTokenizer.getNextDataElement();
            }
        if (TransactionSetTokenizer.getNextSegment((SegmentContainer) getParent()) == null)
           return true;

        TransactionSetTokenizer.getNextDataElement();

        return true;

    }


    /** parses a XML EDI Document
     * adds to datalement vector or compositeDE
     * and adds to secondary segment vector
     * @param node Incoming DOM node
     * @throws OBOEException as thrown
     */

    public int parse(Node node)
    throws OBOEException
    {
        int i=0, n, cn;
  
        boolean multipleNotBuilt = true;

        NodeList nl = node.getChildNodes();
        NodeList cnl;
        DataElement currentDE;
        CompositeDE currentComposite;
        Node currentNode;
        int lastDETested = -1;

        Node cnode;
        nodeLoop: for (n = 0; n < nl.getLength(); n++)
        {
            currentNode = nl.item(n);
            if (currentNode.getNodeType() != Node.ELEMENT_NODE)
                continue nodeLoop;
            cnl = currentNode.getChildNodes();
            if (myTemplate != null)
               i = myTemplate.doYouUseThisXMLElement(currentNode.getNodeName(), lastDETested);
            else
               i = doIUseThisXMLElement(currentNode.getNodeName(), lastDETested);

            if (i >= 0)
            {
                if (myTemplate != null && i > lastDETested && multipleNotBuilt)
                {
                    for (cn = lastDETested+1; cn <= i; cn++)
                    	buildDE(cn+1);
                }
                lastDETested = i;
                if (isCompositeDE(i+1))
                {
                    currentComposite = (CompositeDE) deArray[i];
                    if (currentComposite.getXMLTag().compareTo(currentNode.getNodeName()) == 0)
                    {
                    	if (multipleNotBuilt == false)
                    	   currentComposite.createNewGroup();
                        currentComposite.parse(currentNode);
                    }
					if (currentComposite.getOccurs() > 1)
					{
					  lastDETested--;
					  multipleNotBuilt = false;

					}
				  else
					 multipleNotBuilt = true;
                    continue nodeLoop;
                }
                else // its a data element
                {
                    currentDE = (DataElement) deArray[i];
                    boolean textNodeFound = false;
                    if (currentDE.getXMLTag().compareTo(currentNode.getNodeName()) == 0)
                    {

                        for (int nn = 0; nn < cnl.getLength(); nn++)
                        {
                            cnode = cnl.item(nn);
                            if (cnode.getNodeType() == Node.TEXT_NODE)
                              {
                              	textNodeFound = true;
                                if (currentDE instanceof NumericDE)
                                   ((NumericDE) currentDE).setFormatted(cnode.getNodeValue());
                               else
							   if (currentDE.getOccurs() > 1)
                                   currentDE.setNext(cnode.getNodeValue());
                               else
   								   currentDE.set(cnode.getNodeValue());
                              }
                        }

						if (textNodeFound == false)
						  if (currentDE.getOccurs() > 1)
							currentDE.setNext("");
						  else
							currentDE.set("");  // set fields that have no values

                        if (currentDE.getOccurs() > 1)
                          {
							lastDETested--;
							multipleNotBuilt = false;

                          }
                        else
                           multipleNotBuilt = true;
                        continue nodeLoop;
                    }
                    else
                      if (textNodeFound == false)
 						if (currentDE.getOccurs() > 1)
 						  currentDE.setNext("");
 						else
						  currentDE.set("");  // set fields that have no values
                }
            }
            //virtual else


            throw new OBOEException("Unknown node found " +  currentNode.getNodeName());
        }

        return n;

    }


    /** parses a Fixed Length EDI Document
     * adds to datalement vector or compositeDE
     * and adds to secondary segment vector
     * @param pis PushbackInputStream
     * @throws OBOEException as thrown
     */

    public boolean parse(PushbackInputStream pis)
    throws OBOEException, IOException
      {
        int i=0;

        byte me[] = new byte[getID().length()];
        DataElement currentDE;
        CompositeDE currentComposite;

        for (i=0; i <  myTemplate.getTemplateDESize(); i++)
        {

            if ( myTemplate.isTemplateComposite(i+1))
            {
                buildDE(i+1);
                currentComposite = (CompositeDE) deArray[i];
                currentComposite.parse(pis);

            }
            else if (myTemplate.isTemplateDE(i+1))
            {
                me = new byte[myTemplate.getTemplateDE(i+1).getMaxLength()];
                pis.read(me);
                if (me[0] == 0)
                  continue;
                String s = Util.rightTrim(new String(me));

                currentDE = (DataElement) deArray[i];
                if (currentDE == null)
                  currentDE = (DataElement) this.buildDE(i+1);
                StringBuffer sb = new StringBuffer(s);
                if (currentDE.getRequired()=='M')
                  {
                     for (int j = s.length(); j < currentDE.getMinLength(); j++)
                        sb.append(' ');
                     s=new String(sb);
                  }
                else
                if (s.length() > 0)
                  {
                     for (int j = s.length(); j < currentDE.getMinLength(); j++)
                        sb.append(' ');
                     s=new String(sb);
                  }
                currentDE.set(s);


            }
        }


        return true;
    }




    /** defines a dataelement by the predefined templateDE array
     * @param pos int
     * <br><b>position is relative to 1.</b>
     * @return DataElement or Composite
     */
    public Object buildDE(int pos)
    {


        TemplateDE tde;
        TemplateComposite tComposite;

        if (myTemplate.isTemplateComposite(pos))
        {
            tComposite = myTemplate.getTemplateComposite(pos);
            deArray[pos-1] = new CompositeDE(tComposite, this);
        }
        else if (myTemplate.isTemplateDE(pos))
        {
            tde = myTemplate.getTemplateDE(pos);

            switch (tde.getType().charAt(0))
            {
                case 'A':
                if (tde.getIDList()!= null)
                    deArray[pos-1] = new IDDE(tde, this);
                else
                    deArray[pos-1] = new CharDE(tde, this);
                break;
                case 'B':
                deArray[pos-1] = new BinaryDE(tde, this);
                break;
                case 'C':
                if (tde.getIDList()!= null)
                    deArray[pos-1] = new IDDE(tde, this);
                else
                    deArray[pos-1] = new CharDE(tde, this);
                break;
                case 'I':
                deArray[pos-1] = new IDDE(tde, this);
                break;
                case 'D':
                deArray[pos-1] = new DateDE(tde, this);
                break;
                case 'T':
                deArray[pos-1] = new TimeDE(tde, this);
                break;
                case 'N':
                deArray[pos-1] = new NumericDE(tde, this);
                break;
                case 'R':
                deArray[pos-1] = new RealDE(tde, this);
                break;
                default:
                throw new OBOEException("Unknown dataElement type");
            }
        }
        return deArray[pos-1];
    }



    /**
     * used to verify if the segment is built correctly. 
     * @return boolean true if segment built correctly
     * <br>Basic Edition always returns true
     */
    public boolean validate()
    {
        boolean returnValidation = true;
        int i;
        String response = null;
        if (myTemplate != null)
        {
            DocumentErrors dErr = new DocumentErrors();
            if (isUsed() == false)
            {
              dErr.addError(0, getID(), "Segment Not Used", this.getParent(), "6", this, 2);
            }
          for (i=0; i<myTemplate.getTemplateDESize(); i++)
           {
            if (myTemplate.isTemplateComposite(i+1))
             {
              if (myTemplate.getTemplateComposite(i+1).getRequired()=='M' &&
              		(isCompositeDE(i+1)== false || getCompositeDE(i+1).getDataElementSize()==0) )
                dErr.addError(i, getID()+myTemplate.getTemplateComposite(i+1).getSequence(), "Required CompositeDE missing, see "
                        +myTemplate.getTemplateComposite(i+1).getName() + " at position " + myTemplate.getTemplateComposite(i+1).getSequence(), this, "1",myTemplate.getTemplateComposite(i+1), 1);
              else if (isCompositeDE(i+1))
              {
                getCompositeDE(i+1).validate(dErr);
              }
             }
            else if (myTemplate.isTemplateDE(i+1))
              {
                if (myTemplate.getTemplateDE(i+1).getRequired() == 'M'
                  && ( isDataElement(i+1) == false
                       ||  getDataElement(i+1).getLength() == 0) )
                       dErr.addError(i, getID()+myTemplate.getTemplateDE(i+1).getSequence(), "Required DE missing data, see "
                            +myTemplate.getTemplateDE(i+1).getName() + " at position " + myTemplate.getTemplateDE(i+1).getSequence(), this, "1",myTemplate.getTemplateDE(i+1), 1);

               else if (isDataElement(i+1))
                    getDataElement(i+1).validate(dErr);
              }
           }

         returnValidation &= (dErr.getErrorCount() == 0);
         String errs[] = dErr.getError();
         for (int dei = 0; dei < dErr.getErrorCount(); dei++){
         	logr.error(errs[dei]);
         	
         }
        }

       return returnValidation;

    }

    /** used to verify if the segment is built correctly
     * @return boolean true if segment built correctly
     * @param inDErr DocumentErrorsObject
     */
    public boolean validate(DocumentErrors inDErr)
    {
        boolean returnValidation = true;
        String response = null;
        int i;
        if (myTemplate != null)
         {
            if (isUsed() == false)
            {
              inDErr.addError(0, getID(), "Segment Not Used", this.getParent(), "6", this, 2);
            }
          for (i=0; i<myTemplate.getTemplateDESize(); i++)
           {
            if (myTemplate.isTemplateComposite(i+1))
             {
              if (isCompositeDE(i+1))
              {
                getCompositeDE(i+1).validate(inDErr);
              }
             }
            else
            if (myTemplate.isTemplateDE(i+1))
              {
                if (myTemplate.getTemplateDE(i+1).getRequired() == 'M'
                  && ( isDataElement(i+1) == false
                       || (getDataElement(i+1) == null)
                       || (getDataElement(i+1).getLength() == 0)) )
                     {
                       inDErr.addError(i, Integer.toString(myTemplate.getTemplateDE(i+1).getSequence()), "Required DE missing data, see "
                       		+myTemplate.getTemplateDE(i+1).getName() + " at position " + myTemplate.getTemplateDE(i+1).getSequence(), this, "1",myTemplate.getTemplateDE(i+1), 1);
                            
                       returnValidation = false;
                     }

               else if (isDataElement(i+1))
                    returnValidation &= getDataElement(i+1).validate(inDErr);
              }
           }
        }
        return returnValidation;

    }




    /** returns the formatted text
     * @param formatType int indicating x12, edificact...
     * @return String
     */

    public String getFormattedText(int formatType)
    {

        if (formatType == Envelope.FIXED_LENGTH_FORMAT)
          return getFixedLengthFormattedText();

        int i;
        DataElement currentDE;
        CompositeDE currentComposite;
        
        StringBuffer sbFormattedText = new StringBuffer();

        switch (formatType)
        {
            case Envelope.CSV_FORMAT:
             sbFormattedText.append("Segment,"+getID()+",\""+getName()+"\""+com.americancoders.util.Util.lineFeed);
            break;
            case Envelope.XML_FORMAT:
            sbFormattedText.append('<' +  getXMLTag() + ">"+com.americancoders.util.Util.lineFeed);
            break;
			case Envelope.VALID_XML_FORMAT:
			case Envelope.VALID_XML_FORMAT_WITH_POSITION:
	            sbFormattedText.append("<segment code=\""+getID()+"\"");
				sbFormattedText.append(" name=\"" + getName() + "\"");
				if (formatType == Envelope.VALID_XML_FORMAT_WITH_POSITION)
					sbFormattedText.append(" docPosition=\""+this.getPositionInIncomingDocument() + "\"");
				sbFormattedText.append(">"+com.americancoders.util.Util.lineFeed);
	            break;
			case Envelope.PIXES_FORMAT:
	            sbFormattedText.append("<segment id=\""+getID()+"\"");
				sbFormattedText.append(">"+com.americancoders.util.Util.lineFeed);
	            break;
            case Envelope.X12_FORMAT:
            sbFormattedText.append(getID());
            break;
			case Envelope.EDIFACT_FORMAT:
			sbFormattedText.append(getID());
			break;
			case Envelope.TRADACOMS_FORMAT:
			sbFormattedText.append(getID());
			break;
            default:
                sbFormattedText.append(getID() + ": ");
        }

        for (i=deArray.length-1; i>-1; i--)
        {
          if (deArray[i] == null)
            continue;
          if (deArray[i] instanceof CompositeDE)
            {
              if (getCompositeDE(i+1).getDataElementLength() > 0)
                break;
            }
          else
          if (deArray[i] instanceof DataElement)
          {
            if (getDataElement(i+1).get() != null)
               break;
          }

        }
        int elementsUsed = i;

        if (elementsUsed > -1)
         switch (formatType) {
            case Envelope.X12_FORMAT:
               sbFormattedText.append(getDelimiter(Envelope.X12_FIELD_DELIMITER.charAt(0)));
               break;
			case Envelope.EDIFACT_FORMAT:
			  if (getID().compareTo("UNA") != 0)// don't add it for EDIFactServiceString
			   sbFormattedText.append(getDelimiter(Envelope.EDIFact_FIELD_DELIMITER.charAt(0)));
			  break;
			case Envelope.TRADACOMS_FORMAT:
 				sbFormattedText.append(getDelimiter(Envelope.TRADACOMS_SEGID_DELIMITER.charAt(0)));
			  break;
          }

        for (i=0; i < elementsUsed+1; i++)
        {
            if (deArray[i] == null)
              ;
            else
            if (deArray[i] instanceof CompositeDE)
            {
                currentComposite = (CompositeDE) deArray[i];
                if (currentComposite.getDataElementLength() > 0)
                    sbFormattedText.append(currentComposite.getFormattedText(formatType));
            }
            else
            if (deArray[i] instanceof DataElement)
            {
                currentDE = (DataElement) deArray[i];
                if (currentDE != null && currentDE.get() != null)
                  {
                  if (getID().compareTo("UNA") != 0 || formatType != Envelope.EDIFACT_FORMAT)// do it different for UNA
                    sbFormattedText.append(currentDE.getFormattedText(formatType));
                  else
                    sbFormattedText.append(currentDE.get());
                  }
                else if (currentDE != null) // && currentDE.get() == null)
                  {
                    //if (i < elementsUsed)
                      sbFormattedText.append(currentDE.getFormattedText(formatType));
                  }
            }

           if (i < elementsUsed) {
               switch (formatType) {
                 case Envelope.X12_FORMAT:
                  sbFormattedText.append(getDelimiter(Envelope.X12_FIELD_DELIMITER.charAt(0)));
                  break;
				case Envelope.EDIFACT_FORMAT:
				 sbFormattedText.append(getDelimiter(Envelope.EDIFact_FIELD_DELIMITER.charAt(0)));
				 break;
				case Envelope.TRADACOMS_FORMAT:
					sbFormattedText.append(getDelimiter(Envelope.TRADACOMS_FIELD_DELIMITER.charAt(0)));
				 break;
                  }
              }
        }


        if (elementsUsed > -1)
        switch (formatType)
        {
          case Envelope.X12_FORMAT:
            sbFormattedText.append(getDelimiter(Envelope.X12_SEGMENT_DELIMITER.charAt(0)));
            break;
			case Envelope.EDIFACT_FORMAT:
			  sbFormattedText.append(getDelimiter(Envelope.EDIFact_SEGMENT_DELIMITER.charAt(0)));
			  break;
			case Envelope.TRADACOMS_FORMAT:
			  sbFormattedText.append(getDelimiter(Envelope.TRADACOMS_SEGMENT_DELIMITER.charAt(0)));
			  break;
          default:
            break;
        }
        else return "";


        switch (formatType)
        {
            case Envelope.XML_FORMAT:
              sbFormattedText.append("</" +  getXMLTag() + ">"+com.americancoders.util.Util.lineFeed);
              break;
            case Envelope.VALID_XML_FORMAT:
			case Envelope.VALID_XML_FORMAT_WITH_POSITION:
			case Envelope.PIXES_FORMAT:
              sbFormattedText.append("</segment>"+com.americancoders.util.Util.lineFeed);
              break;
            default:
              break;
        }

        return new String(sbFormattedText);


    }

    /** returns fixed length formatted text
     * @return String
     */


    public String getFixedLengthFormattedText()
    {

        int i;
        StringBuffer sbFormattedText = new StringBuffer(getID());

        for (i=0;  i<myTemplate.getTemplateDESize();  i++)
        {
          if (deArray[i] == null)
            {
              if (getTemplate().isTemplateComposite(i+1))
                {
                    sbFormattedText.append(getTemplate().getTemplateComposite(i+1).getEmptyData());
                }
              else
              if (getTemplate().isTemplateDE(i+1))
                {
                    sbFormattedText.append(getTemplate().getTemplateDE(i+1).getEmptyData());
                }
            }
          else
          if (deArray[i] instanceof CompositeDE)
            {
              if (getCompositeDE(i+1).getDataElementLength() > 0)
                 sbFormattedText.append(getCompositeDE(i+1).getFixedLengthFormattedText());
              else
                 sbFormattedText.append(getTemplate().getTemplateComposite(i+1).getEmptyData());

            }
          else
          if (deArray[i] instanceof DataElement)
          {
            if (getDataElement(i+1).getLength()==0)
               sbFormattedText.append(getTemplate().getTemplateDE(i+1).getEmptyData());
            else
               sbFormattedText.append(getDataElement(i+1).getFixedLengthFormattedText());

          }

        }


        return new String(sbFormattedText);


    }



    /**
     * returns the number of defined data element
     * @return int DataElement count
     */

    public int  getDataElementSize() { return deArray.length; }

    /**
     * returns all the data associated with the Segment
     * <br>dataelements separated by '*'
     * <br>composites separated by '<', note data elements within composites are seperated by ':'
     * @return String for all segments and deArray within the Segment
     */
    public String get()
    {
        StringBuffer sb = new StringBuffer(myTemplate.getID());
        DataElement currentDE;
        CompositeDE currentCDE;
        int i;
        for (i=0; i < deArray.length && deArray[i] != null; i++)
        {

            if (deArray[i] instanceof DataElement)
            {
                currentDE = (DataElement) deArray[i];
                if (currentDE.get() == null)
                    break;

                sb.append('*');
                sb.append(currentDE.get());
            }
            else
            {
                currentCDE = (CompositeDE) deArray[i];
                if (currentCDE.get() == null)
                    break;
                sb.append('<');
                sb.append(currentCDE.get());
            }
        }
        sb.append(com.americancoders.util.Util.lineFeed);


        return new String(sb);
    }


  /** returns the length of the data in the data elements
   * @return int
   */
  public int getDataElementLength()
    {
        int len = 0;
        int i;
        for (i=0; i<getDataElementSize(); i++)
           {
            if (deArray[i] instanceof DataElement)
             {
              DataElement delement = getDataElement(i+1);
              len += delement.getLength();
             }
             else
             if (deArray[i] instanceof CompositeDE)
              {
                CompositeDE cde = getCompositeDE(i+1);
                len += cde.getDataElementLength();
              }
           }
        return len;
    }

    /** returns a data element by its id
     * @return DataElement
     * @param inID ID of dataelement to find
     */

    public DataElement getDataElement(String inID)
    {
        int i;
        DataElement currentDE = null;

        for (i=0; i < deArray.length; i++)
        {
            if (isDataElement(i+1)) {
                currentDE = (DataElement) deArray[i];
                if (currentDE.getID().compareTo(inID) == 0)
                  return  currentDE;
            }
        }
        return null;
    }

    /** returns a data element by its id, from an offset
     * @return DataElement
     * @param inID ID of dataelement to find
     * @param inoffset int
     */

    public DataElement getDataElement(String inID, int inoffset)
    {
        int i;
        DataElement currentDE = null;

        for (i=inoffset+1; i <= deArray.length; i++)
        {
            if (isDataElement(i)) {
                currentDE = (DataElement) deArray[i-1];
                if (currentDE.getID().compareTo(inID) == 0)
                   return currentDE;
            }
        }
        return null;
    }

    /** returns a data element by its id off of an offset
     * @param inName name of dataelement to find
     * @param inoffset int
     * @return DataElement
     */

    public DataElement getDataElementByName(String inName, int inoffset)
    {
        int i;
        DataElement currentDE = null;

        for (i=inoffset+1; i < deArray.length; i++)
        {
            if (isDataElement(i)) {
                currentDE = this.getDataElement(i);
                if (currentDE.getName().compareTo(inName) == 0)
                break;
            }
            else
               currentDE = null;
        }
        return currentDE;
    }

    /** returns a data element by its sequence number, not location within vector
     * @return DataElement
     * @param inSequence int position of dataelement
     * <br><b>position is relative to 1.</b>
     */

    public DataElement getDataElement(int inSequence)
    {
        if (inSequence == 0) return null;
        if (inSequence > deArray.length) return null;
        if (isDataElement(inSequence)) return (DataElement) deArray[inSequence-1];
        return null;
    }

    /** returns a compositeDE by its id
     * @return CompositeDataElement
     * @param inID String id of composite
     */

    public CompositeDE getCompositeDE(String inID)
    {
        int i;
        CompositeDE currentDE = null;

        for (i=0; i < deArray.length; i++)
        {
            if (isCompositeDE(i+1)) {
                currentDE = (CompositeDE) deArray[i];
                if (currentDE.getID().compareTo(inID) == 0)
                return currentDE;
            }
        }
        return null;
    }


    /** returns a compositeDE by its position
     * @return CompositeDataElement
     * @param inSequence int position of CompositeDE
     * <br><b>position is relative to 1.</b>
     */

    public CompositeDE getCompositeDE(int inSequence)
    {
        if (inSequence ==0) return null;
        if (inSequence > deArray.length) return null;
        if (isDataElement(inSequence)) return null;
        return (CompositeDE) deArray[inSequence-1];
    }


    /** returns an objects position in array
     * @return int
     * @param inObject object that may be in the array
     */

    public int getObjectPosition(Object inObject)
    {
        int i;
        for (i = 0; i < deArray.length; i++) {
          if (deArray[i] == inObject)
            return i;
        }
        return -1;
    }


    /** returns a boolean if vector position held by a data element
     * @return boolean
     * @param inSequence is object in the array a dataelement
     * <br><b>position is relative to 1.</b>
     */

    public boolean isDataElement(int inSequence)
    {

        if (inSequence ==0) return false;
        if (inSequence > deArray.length)  return false;
        return (deArray[inSequence-1] instanceof com.americancoders.edi.DataElement);
    }

    /** returns a boolean if vector position held by a composite
     * @return boolean
     * @param inSequence int is object in array at this position a composite
     * <br><b>position is relative to 1.</b>
     */

    public boolean isCompositeDE(int inSequence)
    {
        if (inSequence ==0) return false;
        if (inSequence > deArray.length) return false;
        return  (deArray[inSequence-1] instanceof com.americancoders.edi.CompositeDE);
    }

    /** removes empty trailing data elements and returns the number of used dataelements
     * @return int
     */

    public int trim()
    {
        int i;
        DataElement currentDE = null;
        CompositeDE currentComp = null;

        for (i=deArray.length-1; i > -1; i--)
        {
            if (isDataElement(i+1)) {
              currentDE = (DataElement) deArray[i];
              if (currentDE.getLength() > 0)
                 return i+1;
              deArray[i] = null;
            }
            else if (isCompositeDE(i+1))
            {
              currentComp = (CompositeDE) deArray[i];
              int j = currentComp.trim();
              if (j > 0)
                 return i+1;
              deArray[i] = null;
            }
        }
        return i+1;
    }
    /** routine to ask if it uses a dataelement
     * @return int position of data element
     * @param inTag String id
     * @param startAt prepositioning
     */
    public int doIUseThisXMLElement(String inTag, int startAt)
    {
        DataElement de;
        CompositeDE cde;

        for (int i=startAt+1; i<deArray.length; i++)
         {  if (deArray[i] instanceof DataElement)
            {
                de = (DataElement) deArray[i];
                if ( de.getXMLTag().compareTo(inTag) == 0)
                    return i;
            }
            else
            {
                cde = (CompositeDE) deArray[i];
                if ( cde.getXMLTag().compareTo(inTag) == 0)
                    return i;
            }
         }
        return -1;

    }


/** sets the default value for the data elements
 * <br>Part of Extended Edition Package
 * <br>will create mandatory subsegments.
 * <br>if mandatory subsegment is part of vector (collection) will create the first one
  */
   public void useDefault()
   {
   }

    protected IContainedObject parent=null;
    /** sets parent attribute
     * @param inParent TemplateSegmentContainer
     */
    public void setParent(IContainedObject inParent) {parent = inParent;}

    /** gets parent attribute
     * @return TemplateSegmentContainer
     */
    public IContainedObject  getParent() { return parent;}


    /** returns the data element associated with being
      *  known as making this segment unique
      * @return DataElement
      */

    public DataElement getPrimaryIDDE()
    {
    	DataElement de = null;
		for (int i=0; i<this.getDataElementSize(); i++)
		  {

			if (isCompositeDE(i+1) && getCompositeDE(i+1).getRequired() == 'M')
			  {
				CompositeDE cd = this.getCompositeDE(i+1);
				de = cd.getDataElement(1);
				if (de == null)
				   continue;
				if (de.getRequired()=='M' && de.getType().compareTo("ID") == 0)
				  {
					return de;
				  }
				continue;
			  }
			if (isDataElement(i+1) == false)
			  continue;
			de = getDataElement(i+1);
			if (de.getRequired() != 'M')
			  continue;
			if (de.getType().compareTo("ID") == 0)
			 {

			  return de;
			 }
		  }
		return null;
     }

     /**
      * sets the x12 or edifact position for incoming documnents
      * @param inPos
      */
     public void setPosition(int inPos)
     {
     	positionInIncomingDocument = inPos;
     }


     public int getByteOffsetPositionInIncomingDocument() {
		return byteOffsetPositionInIncomingDocument;
	}



	public void setByteOffsetPositionInIncomingDocument(
			int byteOffsetPositionInIncomingDocument) {
		this.byteOffsetPositionInIncomingDocument = byteOffsetPositionInIncomingDocument;
	}



	/**
      * gets the x12 or edifact position for incoming documnents
      * @return int
      */
     public int getPositionInIncomingDocument()
     {
     	return positionInIncomingDocument;
     }
     /**
      * the toString method
      */
    public String toString()
    {
    	 return "segment id:" + getID() + " name:" + getName() + " seq:" + getSequence();
    	 		
    }
    /* (non-Javadoc)
     * @see com.americancoders.edi.IContainedObject#getDelimiter(char)
     */

    	public char getDelimiter(char inOriginal) {
    		
    		if (parent == null) // for junit tests
    			return inOriginal;
    		return parent.getDelimiter(inOriginal);
    	}


}
