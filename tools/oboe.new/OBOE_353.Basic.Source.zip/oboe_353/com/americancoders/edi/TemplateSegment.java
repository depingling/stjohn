package com.americancoders.edi;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.lang.reflect.Method;
import java.util.Vector;

import org.apache.log4j.Logger;

import com.americancoders.util.Util;

/**
 * TemplateSegment holds preliminary segment structure
 *<p>OBOE - Open Business Objects for EDI
 *<p>Part of the OBOE Basic Extended Package
 *<br>An EDI and XML Translator Written In Java
 *<br>Copyright 1998-2007 - American Coders, LTD  - Raleigh NC USA
 *<br>All rights reserved
 *<br>American Coders, Ltd
 *<br>P. O. Box 97462
 *<br>Raleigh, NC  27624  USA
 *<br>1-919-846-2014
 *<br>http://www.americancoders.com
@author Joe McVerry - American Coders, Ltd.
  @version   3.5.3
 */
public class TemplateSegment implements
                                Externalizable,
                                IContainedObject,
								ITemplateElementContainer
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/** log4j object */
	static Logger logr = Logger.getLogger(TemplateSegment.class);
	static 	{Util.isLog4JNotConfigured();}

    /** segment id
     */
    protected String id;
    /** segment name
     */
    protected String name;
    /** segment sequence within table or parent segment
     */
    protected int sequence = 0;
    /** segment description
     */
    protected String description;
    /** segment XML tag
     */
    protected String xmlTag = "";
    /** segment how many times it can occur
     */
    protected int occurs;
    /** segment required indicator
     */
    protected char required;
    /** segment vector for owned de
     */
    private Vector templateDEVector;

    /** returns used attribute
    * @return boolean
    */
	public boolean isUsed() {
		return used;
	}
    /** sets used attribute
	    * @param used boolean
	    */
	public void setUsed(boolean used) {
		this.used = used;
	}
    protected boolean used = true;


    /**
     * templateSegment constructor used by externalize mehtods
     */
    public TemplateSegment() {}

    /** templateSegment, there are two flavors of segments Templates and regular
     * <P> templates are used to define a segment dynamically
     * <p> and are used to build the static form of segments
     * <p> contains template data elements and secondary segments
     * @param inId String id
     * @param inName String name
     * @param inSequence int sequence within seg or comp
     * @param inDescription String description
     * @param inOccurs int for multiple occurring segments
     * @param inRequired char required indicator
     * @param inXMLTag String XML tag
     * @param inUsed boolean
     * @param inParent owning Object
     */


    public TemplateSegment(String inId, String inName, int inSequence, String inDescription, int inOccurs, char inRequired, String inXMLTag, boolean inUsed, IContainedObject inParent)
    {
        setID(inId);
        setName(inName);
        setSequence(inSequence);
        setDescription(inDescription);
        templateDEVector = new Vector();
        setOccurs(inOccurs);
        setRequired(inRequired);
        setXMLTag(inXMLTag);
        used = inUsed;
        setParent(inParent);
    }




    /** returns the  number of templateDEs
     * @return int
     */
public int getTemplateDESize() { return templateDEVector.size(); }

    /** sets TemplateSegment id
     * @param inID String id
     */
public void setID(String inID) {id = inID; }

    /** sets TemplateSegment name
     * @param inName String name
     */
public void setName(String inName) {name = inName; }

    /** gets TemplateSegment id
     * @return String
     */
public String getID() { return id; }

    /** gets TemplateSegment name
     * @return string name
     */
public String getName() { return name; }

    /** sets sequence id
     * @param inSequence int sequence within table or parent segment
     */
public void setSequence(int inSequence){ sequence = inSequence; }


    /**
     * gets sequence id
     * @return int sequence
     */
public int getSequence(){ return sequence; }

    /** sets Description for the Segmemt
     * @param inDesc String description
     */
public void setDescription(String inDesc) {description = inDesc;}

    /**
     * returns the Description for the Segment
     * @return String
     */
public String getDescription() {return description;}

    /** sets occurance value
     * @param inOccurs int
     */
public void setOccurs(int inOccurs){ occurs = inOccurs; }


    /**
     * gets occurance value
     * @return int occurs
     */
public int getOccurs(){ return occurs; }

    /** sets required value
     * @param inRequired char
     */
public void setRequired(char inRequired){ required = inRequired; }


    /**
     * gets required flag
     * @return char required
     */
    public char getRequired(){ return required; }


    /** sets the xmlTag field
     * @param inXMLTag String XML tag
     */

    public void  setXMLTag(String inXMLTag)
    {
        xmlTag = inXMLTag;
    }

    /**
     * returns the xml tag field
     * @return String tag value
     */


    public String getXMLTag()
    {
        return xmlTag;
    }



    /** adds  TemplateComposite to container
     * <br> checks for duplicate entry at sequence position
     * @param inTemplateComposite TemplateComposite to add
     * @exception OBOEException - Sequence position already filled
     */
    public void addTemplateComposite(TemplateComposite inTemplateComposite)
       throws OBOEException
      { int pos = inTemplateComposite.getSequence()-1;
        if (pos < templateDEVector.size())
          if (isTemplateComposite(pos+1) || isTemplateDE(pos+1))
             throw new OBOEException("Position for Composite with ID="+inTemplateComposite.getID()+" at " + (pos+1) + " already filled  for Segment "+getID()+" "+getName());
        if (pos >= templateDEVector.size())
           templateDEVector.setSize(pos);//cludge for java vector bug
        templateDEVector.insertElementAt(inTemplateComposite, pos);
      }
    /** adds  TemplateDE to container
     * <br> checks for duplicate entry at sequence position
     * @param inTemplateDE TemplateDE to add
     * @exception OBOEException -Sequence position already filled
     */
    public void addTemplateDE(TemplateDE inTemplateDE)
      { int pos = inTemplateDE.getSequence()-1;
        if (pos < templateDEVector.size())
          if (isTemplateComposite(pos+1) || isTemplateDE(pos+1))
             throw new OBOEException("Position for DataElement with ID="+inTemplateDE.getID()+" at " + (pos+1) + " already filled in for Segment "+getID()+" "+getName());
        if (pos > templateDEVector.size())
           templateDEVector.setSize(pos+1);
        templateDEVector.insertElementAt(inTemplateDE, pos);
      }

    /** tests if the element at a position is a TemplateDE
     * @return boolean
     * @param at int position
     * <br><b>position is relative to 1.</b>
     */
    public boolean isTemplateDE(int at)
    {
      if (templateDEVector.elementAt(at-1)==null)    return false;
      return (templateDEVector.elementAt(at-1) instanceof com.americancoders.edi.TemplateDE);
    }

    /** tests if the element at a position is a TemplateComposite
     * @return boolean
     * @param at int position
     * <br><b>position is relative to 1.</b>
     */
    public boolean isTemplateComposite(int at)
    {
        if (templateDEVector.elementAt(at-1)==null)    return false;
        return (templateDEVector.elementAt(at-1) instanceof com.americancoders.edi.TemplateComposite);
    }


    /** gets TemplateComposite from TemplateDE container
     * @return TemplateComposite
     * @param at int position
     * <br><b>position is relative to 1.</b>
     */
    public TemplateComposite getTemplateComposite(int at)
      {return (TemplateComposite) templateDEVector.elementAt(at-1); }


    /** gets TemplateComposite from TemplateDE container
     * @return TemplateComposite
     * @param id String id
     */
    public TemplateComposite getTemplateComposite(String id)
    {
        TemplateComposite tComposite;
        for (int i = 0 ; i < templateDEVector.size(); i++) {
            if (isTemplateComposite(i+1) == false)
            continue;
            tComposite = (TemplateComposite) templateDEVector.elementAt(i);
            if (tComposite.getID().compareTo(id) == 0) return tComposite;
        } /* endif */
        return null;
    }

    /** gets TemplateDE from TemplateDE container
     * @return TemplateDE
     * @param at int position
     * <br><b>position is relative to 1.</b>
     */
    public TemplateDE getTemplateDE(int at)
    {return (TemplateDE) templateDEVector.elementAt(at-1); }

    /** gets TemplateDE from TemplateDE container
     * @return TemplateDE
     * @param id String id
     */
    public TemplateDE getTemplateDE(String id)
    {
        TemplateDE tDE;
        for (int i = 0 ; i < templateDEVector.size(); i++) {
            if (isTemplateComposite(i+1) == true)
            continue;
            tDE = (TemplateDE) templateDEVector.elementAt(i);
            if (tDE.getID().compareTo(id) == 0) return tDE;
        } /* endif */
        return null;
    }


    /** routine to ask if it uses a dataelement
     * @return boolen true the segment id is part of this group
     * @param inID String id
     */
    public int doYouUseThisElement(String inID, int startAt)
    {
        IIdentifier iid;
        for (int i=startAt+1; i<templateDEVector.size(); i++)
        {   iid = (IIdentifier) templateDEVector.elementAt(i);
            if (iid == null)
              continue;
            if ( iid.getID().compareTo(inID) == 0)
                return i;
        }
        return -1;
    }
    /** routine to ask if it uses a dataelement
     * @return boolen true the segment id is part of this group
     * @param inXML String xml tag
     * @param startAt int starting position
     */
    public int doYouUseThisXMLElement(String inXML, int startAt)
    {
        IIdentifier iid;
        for (int i=startAt+1; i<templateDEVector.size(); i++)
        {   iid = (IIdentifier) templateDEVector.elementAt(i);
            if (iid == null)
              continue;
            if ( iid.getXMLTag().compareTo(inXML) == 0)
               return i;
        }
        return -1;
    }
    /** returns entire elementrule vector
     * @return Vector of element rules
     * <br> or null in Basic Edition
     */
    public Vector getElementRules()
 {return null;}

    /** used by externalize methods
     * @param in ObjectInput stream
     * @exception IOException - most likely class changed since written
     * @exception ClassNotFoundException - only when dummy constructro not found
     */

    public void readExternal(ObjectInput in)
    throws IOException, ClassNotFoundException
    {
        id = in.readUTF();
        name = in.readUTF();
        sequence = in.readInt();
        description = in.readUTF();
        xmlTag = in.readUTF();
        occurs = in.readInt();
        required = in.readChar();
        used = in.readBoolean();

        templateDEVector = (Vector) in.readObject();
        for (int i=0; i < getTemplateDESize(); i++)
          {
            if (isTemplateDE(i+1))
             {
              TemplateDE tde = getTemplateDE(i+1);
              tde.setParent(this);
             }
            else
            if (isTemplateComposite(i+1))
             {
              TemplateComposite tc = getTemplateComposite(i+1);
              tc.setParent(this);
             }
          }
    }

    /** used by externalize methods
     * @param out ObjectOutput stream
     * @exception IOException java.io error
     */
    public void writeExternal(ObjectOutput out)
    throws IOException
    {
        out.writeUTF(id);
        out.writeUTF(name);
        out.writeInt(sequence);
        out.writeUTF(description);
        out.writeUTF(xmlTag);
        out.writeInt(occurs);
        out.writeChar(required);
        out.writeBoolean(used);
        out.writeObject(templateDEVector);
    }
    protected IContainedObject parent=null;
    /** sets parent attribute
     * @param inParent TemplateSegmentContainer
     */
    public void setParent(IContainedObject inParent) {parent = inParent;}

    /** gets parent attribute
     * @return TemplateSegmentContainer
     */
    public IContainedObject  getParent() { return parent;}
  /** returns true if the template segment can prevalidate an incoming
        edi transaction segment.  If yes then this incoming segment is the
        segment.
        <br> implemented for HIPAA
        <ul> prevalidation requirement
          <li> at least one mandatory ID field
        </ul>
        @return boolean
        */

     public boolean canYouPrevalidate()
       {
    	if (Util.propertyFileIndicatesDoPrevalidate() == false)
    		return false;
        for (int i=0; i<getTemplateDESize(); i++)
          {
			if (this.isTemplateComposite(i+1) && this.getTemplateComposite(i+1).getRequired() == 'M')
			  {
				TemplateComposite tce = this.getTemplateComposite(i+1);
				TemplateDE tde = tce.getTemplateDE(1);
				if (tde.getRequired()=='M' && tde.getType().compareTo("ID") == 0)
				  {
				  	if (tde.getIDList()==null)
				  	  return false;
					return true;
				  }
				continue;
			  }
            if (isTemplateDE(i+1) == false)
              continue;
            if (getTemplateDE(i+1).getRequired() != 'M')
              continue;
            if (getTemplateDE(i+1).getType().compareTo("ID") == 0)
             {
              if (getTemplateDE(i+1).getIDList()==null)
                  return false;
              return true;
             }
          }
        return false;
        }
    /** returns the idlist that allows for prevalidation
     * used by OBOECodeGenerator
     * @return IDListProcessor
     */ 
    public IDListProcessor getIDListThatPrevalidates()
    {
        for (int i=0; i<getTemplateDESize(); i++)
        {
			if (this.isTemplateComposite(i+1) && this.getTemplateComposite(i+1).getRequired() == 'M')
			  {
				TemplateComposite tce = this.getTemplateComposite(i+1);
				TemplateDE tde = tce.getTemplateDE(1);
				if (tde.getRequired()=='M' && tde.getType().compareTo("ID") == 0)
				  {
				  	if (tde.getIDList()==null)
				  	  return null;
					return tde.getIDList();
				  }
				continue;
			  }
          if (isTemplateDE(i+1) == false)
            continue;
          if (getTemplateDE(i+1).getRequired() != 'M')
            continue;
          if (getTemplateDE(i+1).getType().compareTo("ID") == 0)
           {
            if (getTemplateDE(i+1).getIDList()==null)
                return null;
            return getTemplateDE(i+1).getIDList();
           }
        }
      return null;
    }
	/**
	 * looking into the tokenized string we ask the first
	 * idde field if the data in the same position is one of its codes
	 * @return boolean
	 */

	 public boolean isThisYou(ITokenizer inToken)
	 {
		TemplateDE tde;
		for (int i=0; i<getTemplateDESize() && i < inToken.countDataElements()-1; i++)
		  {
			inToken.getNextDataElement();
			if (this.isTemplateComposite(i+1) && this.getTemplateComposite(i+1).getRequired() == 'M')
			  {
				TemplateComposite tce = this.getTemplateComposite(i+1);
				tde = tce.getTemplateDE(1);
				if (tde.getRequired()=='M' && tde.getType().compareTo("ID") == 0 && inToken.getCurrentDataElement().length() > 0)
				  {
					IDataTokenizer dt = inToken.makeSubfieldTokenizer();
					String s = Util.unEscape(dt.nextToken(),inToken.getEscapeCharacters());
					logr.debug("testing id code "+s+" idlist says "+tde.getIDList().isCodeValid(s));
					inToken.resetSegment();
					return tde.getIDList().isCodeValid(s);
				  }
				continue;
			  }
			if (isTemplateDE(i+1) == false)
			  continue;

			tde =  getTemplateDE(i+1);
			if (tde.getRequired()=='M' && tde.getType().compareTo("ID") == 0)
			  {
				inToken.resetSegment();
				return tde.getIDList().isCodeValid(inToken.getDataElementAt(i+1));
			  }
		  }
		inToken.resetSegment();
		logr.debug("not found in isThisYou");
		return false;
	 }

    /** ask the first idde field if the data in
     * the same position is one of its codes
     * @param primaryIDValue String to search on 
     * @return boolean
     */

     public boolean isThisYou(String primaryIDValue)
     {
        TemplateDE tde;
        for (int i=0; i<getTemplateDESize(); i++)
          {
          	if (this.isTemplateComposite(i+1) && this.getTemplateComposite(i+1).getRequired() == 'M')
          	  {
          	  	TemplateComposite tce = this.getTemplateComposite(i+1);
          	  	tde = tce.getTemplateDE(1);
				if (tde.getRequired()=='M' && tde.getType().compareTo("ID") == 0)
				  {
					return tde.getIDList().isCodeValid(primaryIDValue);
				  }
				continue;
          	  }
            if (isTemplateDE(i+1) == false)
              continue;

            tde =  getTemplateDE(i+1);
            if (tde.getRequired()=='M' && tde.getType().compareTo("ID") == 0)
              {
                return tde.getIDList().isCodeValid(primaryIDValue);
              }
          }
        return false;
     }
    /**
     * asking template what parsing id field it doesn't like so that it would
     * create a prevalidated segment.
     * @return string
     */

     public void whyNotYou(Tokenizer et, SegmentContainer errContainer)
     {
        TemplateDE tde;

        for (int i=0; i<getTemplateDESize() && i < et.countDataElements()-1; i++)
          {
			et.getNextDataElement();
			if (this.isTemplateComposite(i+1) && this.getTemplateComposite(i+1).getRequired() == 'M')
			  {
				TemplateComposite tce = this.getTemplateComposite(i+1);
				tde = tce.getTemplateDE(1);
				if (tde.getRequired()=='M' && tde.getType().compareTo("ID") == 0)
				  {
					IDataTokenizer dt = et.makeSubfieldTokenizer();
					String s = Util.unEscape(dt.nextToken(),et.getEscapeCharacters());
					et.resetSegment();
					et.reportError("ID Field "+this.getID()+" with value of "+s+" is invalid or segment is out of place.", errContainer, "7", this, 1);
				  }
				continue;
			  }
            if (isTemplateDE(i+1) == false)
              continue;
            tde =  getTemplateDE(i+1);
            if (tde.getType().compareTo("ID") == 0)
              {
               et.reportError("ID Field "+this.getID()+" with value of "+et.getDataElementAt(i+1)+" is invalid or segment is out of place.", errContainer, "7", this, 1);
			   et.resetSegment();
               return;
              }
          }
        et.reportError("ID Field "+this.getID()+" value can not be found.", errContainer, "7", this, 1);
		et.resetSegment();
        return;
     }

   
   /* (non-Javadoc)
    * @see com.americancoders.edi.IContainedObject#getDelimiter(char)
    */

   	public char getDelimiter(char inOriginal) {
   		
   		return parent.getDelimiter(inOriginal);
   	}

}
