package com.americancoders.edi;


import java.io.CharArrayWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.util.Hashtable;
import java.util.Stack;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.apache.log4j.Logger;
import org.xml.sax.Attributes;
import org.xml.sax.ContentHandler;
import org.xml.sax.EntityResolver;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import org.xml.sax.ext.LexicalHandler;
import org.xml.sax.helpers.DefaultHandler;

import com.americancoders.util.Util;

/**
 * class for building an Envelope from an edi xml file
 * this is a subclass of the  SAX2 handler
 * <br>Class contains a main method to allow it to be invoked as an application.
 * <br>format: java com.americancoders.edi.EnvelopeFactory xmlfilename,
 * <br>where xmlfilename is a xml file based on envelopeRules.dtd.
 *
 *<br>OBOE - Open Business Objects for EDI
 *<br>An EDI and XML Translator Written In Java
 *<br>Copyright 1998-2007 - American Coders, LTD  - Raleigh NC USA
 *<brp>All rights reserved
 *<br>American Coders, Ltd
 *<br>P. O. Box 97462
 *<br>Raleigh, NC  27624  USA
 *<br>1-919-846-2014
 *<br>http://www.americancoders.com
@author Joe McVerry - American Coders, Ltd.
  @version   3.5.3
 */

public class EnvelopeFactory
	extends DefaultHandler
	implements EntityResolver, LexicalHandler, ContentHandler {
	/** current element number
	 */
	protected int _iElement = 0;
	/** current line number
	 */
	protected int _iLine = 0;
	/** current envelope
	 */
	protected TemplateEnvelope currentEnvelope = null;
	/** current functionalGroup
	 */
	protected TemplateFunctionalGroup currentFG = null;
	/** current container for segments
	 */
	protected TemplateSegmentContainer currentTemplateSegmentContainer = null;
	/** current segment
	 */
	protected TemplateSegment currentTemplateSegment = null;
	/** current composite
	 */
	protected TemplateComposite currentCompositeDE = null;
	/** current element
	 */
	protected TemplateDE currentDataElement = null;
	/** loop id - may not be used in future
	 */
	protected String currentLoopID = "";
	/** current id string
	 */
	protected String currentID = "";

	/**     simple string processor    */
	protected CharArrayWriter contents = new CharArrayWriter();

	/** current idListFile name
	 */
	protected String idListFile = null;

	/**  idList Processor */
	protected IDListProcessor currentIDListProcessor = null;

	protected IDList idlist;

	/** idcode value since idcode appears before idvalue save it
	 */

	protected String idCode = null;

	/** current IDList parser object
	 */
	protected IDListParser idListParser;
	/** list of IDs
	 */
	protected Hashtable idLists;
	/** current list of ids
	 */
	protected IDList currentIDList;
	/** directory path for xml file
	 */
	protected String xmlDirectoryPath = "." + File.separator + ".";

	/** SAX2 parser
	 */
	SAXParser parser;

	/** default name */
	protected String nameOrID = "no set yet";

	/** stack, since segments can be held by table and segments and
	 * datalements by segments and composites we keep track of container depth through a stack
	 */
	protected Stack currentSegContainerStack = new Stack();

	/** file name being parsed */
	protected String knowSystemID = "";

	
    static Logger logr = Logger.getLogger(EnvelopeFactory.class);
	static 	{Util.isLog4JNotConfigured();}

	/** construct the factory with a xml parser
	 * @throws Exception an xml parser exception */

	public EnvelopeFactory() throws Exception {
		SAXParserFactory spf = SAXParserFactory.newInstance();
		spf.setNamespaceAware(TransactionSetFactory.getNamespaceOption() == true);
		spf.setValidating(true);
		spf.setNamespaceAware(true);
		spf.setFeature ("http://apache.org/xml/features/validation/schema",   true);
		parser = spf.newSAXParser();
		parser.getXMLReader().setProperty("http://xml.org/sax/properties/lexical-handler", this);


		currentEnvelope = null;

		idLists = new Hashtable();
		idListParser = new IDListParser();
	//	idListParser.parser.setEntityResolver(this);

	}

	   private Locator locator = null;
	    
	    public void setDocumentLocator(Locator locator) {
	    	this.locator = locator;
	    	}
	    
	    private void reportPosition() {

	    	if (locator != null) {

	    	_iLine=  locator.getLineNumber();
	    	}
	    	 

	    	}

	  

	/**
	 * method to call parser with an InputSource argument
	 * @param is InputSource
	 * @throws Exception an xml parser exception */

	public void parse(InputSource is) throws Exception {
		is.setSystemId("");
		parser.parse(is, this);
	}

	/**
	 * method to call parser with a String argument
	 * @param is String of xml data
	 * @throws Exception an xml parser exception */

	public void parse(String is) throws Exception {
		parser.parse(is, this);
	}

	/** resolves the DTD file name for the xerces parser
	 * @param publicId -  String name of xml public id
	 * @param systemId - String name of xml system id
	 * @return InputSource the dtd
	 */

	public InputSource resolveEntity(
		java.lang.String publicId,
		java.lang.String systemId)
		throws SAXException
	//java.io.IOException
	{

		try {
			if (publicId != null) {
				if (publicId.indexOf("://") < 1) {
					return new InputSource(
						new FileInputStream(
							xmlDirectoryPath + File.separator + publicId));
				}
				File f = new File(publicId);
				if (f.exists())
					return null;
				String sf = f.getName();
				return new InputSource(
					new FileInputStream(
						xmlDirectoryPath + File.separator + sf));
			}
			if (systemId != null) {
				if (systemId.indexOf("://") < 1) {
					return new InputSource(
						new FileInputStream(
							xmlDirectoryPath + File.separator + systemId));
				}
				File f = new File(systemId);
				if (f.exists())
					return null;
				String sf = f.getName();
				return new InputSource(
					new FileInputStream(
						xmlDirectoryPath + File.separator + sf));

			}
		} catch (Exception e) {
			throw new SAXException(e);
		}
		return null;
	}
	/**
	 * method called for each xml element found.
	 * <br> process logic
	 * <ul>
	 * <li> test each name found for edi type: Envelope, table, segment, dataelement
	 * <li> for each type pull appropriate attributes and construct object
	 * <li> for envelopes
	 * <li> for functionalgroups
	 * <li> for segments build a template segment
	 * <li> for data element build a template datalement
	 * </li>
	 *
	 * @param uri URI of incoming file
	 * @param localName String of element's local name
	 * @param rawName String of element's raw name
	 * @param attributes Vector of the elements attributes
	 * @throws SAXException many possible exceptions
	 */
	public void startElement(
		java.lang.String uri,
		java.lang.String localName,
		java.lang.String rawName,
		Attributes attributes)
		throws SAXException {
		reportPosition();

		int i;
		String name = rawName;
		_iElement++;
		contents.reset();

			if (name.compareTo("envelope") == 0) {
				currentEnvelope = new TemplateEnvelope();

				currentEnvelope.setType(attributes.getValue("type"));
				currentEnvelope.setXMLPath(this.xmlDirectoryPath);
				
				currentTemplateSegmentContainer = currentEnvelope;
				currentSegContainerStack.push(currentTemplateSegmentContainer);
				return;
			}
			if (name.compareTo("functionalGroup") == 0) {
				currentFG = new TemplateFunctionalGroup();
				currentTemplateSegmentContainer = currentFG;
				currentSegContainerStack.push(currentTemplateSegmentContainer);
				currentEnvelope.setTemplateFunctionalGroup(currentFG);
				return;
			}
			if (name.compareTo("segment") == 0) {
				String xmlTag = null;
				currentCompositeDE = null;
				int sequence = currentTemplateSegmentContainer.getCount();
				String description = "";
				String currentName = "";
				char required = 'O';
				int occurs = 1;
				for (i = 0; i < attributes.getLength(); i++) {
					if (attributes.getQName(i).compareTo("id") == 0) {
						currentID = attributes.getValue(i);
					}
					if (attributes.getQName(i).compareTo("sequence") == 0)
						sequence = Integer.parseInt(attributes.getValue(i));
					if (attributes.getQName(i).compareTo("description") == 0) {
						description = attributes.getValue(i);
					}
					if (attributes.getQName(i).compareTo("name") == 0)
						currentName = attributes.getValue(i);
					if (attributes.getQName(i).compareTo("xmlTag") == 0)
						xmlTag = attributes.getValue(i);
					if (attributes.getQName(i).compareTo("occurs") == 0) {
						String sOccurs = attributes.getValue(i).trim();
						if (sOccurs.length() > 0)
							// let it numeric parsing exception occur on its own
							occurs = Integer.parseInt(sOccurs);
					}
					if (attributes.getQName(i).compareTo("required") == 0)
						required = attributes.getValue(i).charAt(0);
				}

				if (xmlTag == null)
					xmlTag = currentID;
				currentTemplateSegment =
					new TemplateSegment(
						currentID,
						currentName,
						sequence,
						description,
						occurs,
						required,
						xmlTag,
						true,
						currentTemplateSegmentContainer);
				try {
					currentSegContainerStack.push(
						currentTemplateSegmentContainer);
					currentTemplateSegmentContainer.addTemplateSegment(
						currentTemplateSegment);
				} catch (Exception e1) {
					throw new SAXException(e1.getMessage());
				}
				return;
			}

			if (name.compareTo("compositeDE") == 0) {
				currentCompositeDE = setTemplateComposite(
						currentTemplateSegment.getTemplateDESize(),
						attributes);
				try {
					currentTemplateSegment.addTemplateComposite(
						currentCompositeDE);
				} catch (OBOEException oe) {
					oe.printStackTrace();
					throw new SAXException(oe.getMessage());
				}

				return;
			}
			if (name.compareTo("dataElement") == 0) {
				int pos;
				if (currentCompositeDE != null)
					pos = currentCompositeDE.getTemplateDESize();
				else
					pos = currentTemplateSegment.getTemplateDESize();
				currentDataElement = setDataElement(pos, attributes);
				if (currentCompositeDE != null)
					currentCompositeDE.addTemplateDE(currentDataElement);
				else
					try {
						currentTemplateSegment.addTemplateDE(
							currentDataElement);
					} catch (OBOEException oe) {
						oe.printStackTrace();
						throw new SAXException(oe.getMessage());
					}

				return;
			}

			if (name.compareTo("idListClass") == 0) {
				
				
				if (currentDataElement.getType().compareTo("A")==0 || currentDataElement.getType().compareTo("AN")==0) {
					currentDataElement.setType("ID");
					logr.info("changed dataelement id =\""+currentDataElement.getID()+"\" from type AN to ID because of idListClass node");
				}
				
				if (currentDataElement.getType().compareTo("ID")!=0) {
					logr.error("cannot use idListClass node with dataelement id =\""+currentDataElement.getID()+"\"");
				}


				try {
					currentIDListProcessor =
						(IDListProcessor) Class
							.forName(attributes.getValue("className"))
							.newInstance();
				} catch (java.lang.ClassNotFoundException cfne) {
					cfne.printStackTrace();
					throw new SAXException(
						"Class not found for idListClass="
							+ attributes.getValue("className"));
				} catch (java.lang.InstantiationException ie) {
					ie.printStackTrace();
					throw new SAXException(
						"Instantiation Exception for idListClass="
							+ attributes.getValue("className"));
				} catch (java.lang.IllegalAccessException iae) {
					iae.printStackTrace();
					throw new SAXException(
						"Illegal Access Excpetion for idListClass="
							+ attributes.getValue("className"));
				}
				currentDataElement.setIDList(currentIDListProcessor);
				return;

			}
			if (name.compareTo("idListFile") == 0) {
				if (currentDataElement.getType().compareTo("AN")==0) {
					currentDataElement.setType("ID");
					logr.info("changed dataelement id =\""+currentDataElement.getID()+"\" from type AN to ID because of idListFile node");
				}
				
				if (currentDataElement.getType().compareTo("ID")!=0) {
					logr.error("cannot use idListFile node with dataelement id =\""+currentDataElement.getID()+"\"");
				}

				currentIDList =
					(IDList) idLists.get(
						xmlDirectoryPath + attributes.getValue("fileName"));
				if (currentIDList == null) {

					currentIDList =
						new IDList(
							xmlDirectoryPath + attributes.getValue("fileName"),
							xmlDirectoryPath,
							idListParser);
					idLists.put(
						xmlDirectoryPath + attributes.getValue("fileName"),
						currentIDList);
					currentEnvelope.addIDListFile(new File(attributes.getValue("fileName")));
					//idLists.addElement(currentIDList);
				}
				for (i = 0; i < attributes.getLength(); i++) {
					if (attributes.getQName(i).compareTo("fileName") == 0)
					    continue;
					if (attributes.getQName(i).compareTo("include") == 0)
					{
					    currentIDList=currentIDList.idListWork('i',  attributes.getValue(i));
					    currentIDList.setFilterList("include=\""+attributes.getValue(i)+"\"");
					}
					if (attributes.getQName(i).compareTo("exclude") == 0)
					{
					    currentIDList=currentIDList.idListWork('x', attributes.getValue(i));
					    currentIDList.setFilterList("exclude=\""+attributes.getValue(i)+"\"");
					}
				}	
				currentIDListProcessor = currentIDList;
				currentDataElement.setIDList(currentIDListProcessor);
				return;
			}
			if (name.compareTo("idList") == 0) {
				
				if (currentDataElement.getType().compareTo("AN")==0) {
					currentDataElement.setType("ID");
					logr.info("changed dataelement id =\""+currentDataElement.getID()+"\" from type AN to ID because of idList node");
				}
				
				if (currentDataElement.getType().compareTo("ID")!=0) {
					logr.error("cannot use idList node with dataelement id =\""+currentDataElement.getID()+"\"");
				}


				currentIDList = new IDList();
				currentIDListProcessor = currentIDList;
				currentDataElement.setIDList(currentIDListProcessor);
				return;
			}

			if (rawName.compareTo("idCode") == 0) {
				return;
			}

			if (rawName.compareTo("idValue") == 0) {
				return;
			}

			if (name.compareTo("transactionSet") == 0) {
				return;
			}

			throw new SAXException(
				"logic error: unknown type "
					+ name
					+ ". Last item was "
					+ currentID
					+ " at element # "
					+ _iElement);

	}

	/**
	 * Method called by the SAX parser at the </
	 * @param uri URI of incoming file
	 * @param localName String of element's local name
	 * @param rawName String of element's raw name
	 * @throws SAXException many possible  *
	 */
	public void endElement(
		java.lang.String uri,
		java.lang.String localName,
		java.lang.String rawName)
		throws SAXException {
		reportPosition();

		String name = rawName;
		if (name.compareTo("envelope") == 0) {
			currentSegContainerStack.pop();
			return;
		}
		if (name.compareTo("functionalGroup") == 0) {
			currentSegContainerStack.pop();
			currentTemplateSegmentContainer =
				(TemplateSegmentContainer) currentSegContainerStack.peek();
			return;
		}
		if (name.compareTo("segment") == 0) {
			currentSegContainerStack.pop();
			currentTemplateSegmentContainer =
				(TemplateSegmentContainer) currentSegContainerStack.peek();
			return;
		}
		if (name.compareTo("compositeDE") == 0) {
			currentCompositeDE = null;

			return;
		}
		if (name.compareTo("dataElement") == 0) {
			currentDataElement = null;
			return;
		}

		if (name.compareTo("idListProcess") == 0) {
			return;
		}
		if (name.compareTo("idListFile") == 0) {
			return;
		}
		if (rawName.compareTo("idList") == 0) {
			currentDataElement.setIDList(currentIDList);
			return;
		}

		if (rawName.compareTo("idCode") == 0) {
			idCode = contents.toString(); // code comes before value so save it
			return;
		}

		if (rawName.compareTo("idValue") == 0) {
			currentIDList.add(idCode, contents.toString());
			return;
		}

		//throw new SAXException("logic error: unknown type " + name + " for element: " + _iElement);
	}

	/**
	 * Method handles #PCDATA
	 * @param ch array
	 * @param start position in array where next has been placed
	 * @param length int
	 *
	 *
	 */
	public void characters(char ch[], int start, int length) {
		reportPosition();

		contents.write(ch, start, length);
		for (int i = start; i < start + length; i++)
			if (ch[i] == '\n')
				_iLine++;
	
	}

	/** method to build a template composite
	 * <br>made static in release 2.5.0
	 * @return TemplateComposite template composite
	 * @param pos int position within segment
	 * @param attributes SAX2 attributes
	 * @throws SAXException SAX errors
	 */
	public TemplateComposite setTemplateComposite(
		int pos,
		Attributes attributes)
		throws SAXException {
		int i;
		String id = "", thisName = "", description = "";
		int occurs = 1;
		int sequence = pos + 1;
		String xmlTag = null;
		char required = 'O';
		for (i = 0; i < attributes.getLength(); i++) {
			if (attributes.getQName(i).compareTo("id") == 0)
				id = attributes.getValue(i);
			if (attributes.getQName(i).compareTo("description") == 0) {
				description = attributes.getValue(i);
			}
			if (attributes.getQName(i).compareTo("name") == 0)
				thisName = attributes.getValue(i);
			if (attributes.getQName(i).compareTo("required") == 0)
				required = attributes.getValue(i).charAt(0);
			if (attributes.getQName(i).compareTo("sequence") == 0)
				sequence = Integer.parseInt(attributes.getValue(i));
			if (attributes.getQName(i).compareTo("xmlTag") == 0)
				xmlTag = attributes.getValue(i);
			if (attributes.getQName(i).compareTo("occurs") == 0) {
				String sOccurs = attributes.getValue(i).trim();
				if (sOccurs.length() > 0)
					try {
						occurs = Integer.parseInt(sOccurs);
						if (occurs < 1)
							throw new OBOEException(
								"occurs less than 1. "
									+ " look for occurs=\""
									+ attributes.getValue(i)
									+ "\""
									+ " nodeName: compositeDE"
									+ " name: "
									+ thisName
									+ " id:"
									+ id);
					} catch (NumberFormatException nfe) {
						throw new OBOEException(
							"occurs not numeric. "
								+ " look for occurs=\""
								+ attributes.getValue(i)
								+ "\""
								+ " nodeName: compositeDE"
								+ " name: "
								+ thisName
								+ " id:"
								+ id);
					}
			}

		}
		if (xmlTag == null)
			xmlTag = id;

		TemplateComposite currentTemplateComposite =  new TemplateComposite(
			id,
			thisName,
			required,
			sequence,
			description,
			xmlTag,
			currentTemplateSegment,
			occurs, true);
     return currentTemplateComposite;
	}

	/** method to build a template data element
	 * <br>made static in release 2.5.0
	 * @return TemplateDE template data element
	 * @param pos position within segment or composite
	 * @param attributes SAX2 attributes
	 * @throws SAXException SAX errors
	 */
	public TemplateDE setDataElement(int pos, Attributes attributes)
		throws SAXException {
		int i;

		idListFile = null;

		String id = "", thisName = "", type = "", description = "";
		int minLength = 0, maxLength = 0;
		String xmlTag = null, required = "O";
		int sequence = pos + 1;
		int occurs = 1;
		for (i = 0; i < attributes.getLength(); i++) {
			if (attributes.getQName(i).compareTo("type") == 0)
				type = attributes.getValue(i);
			if (attributes.getQName(i).compareTo("required") == 0)
				required = attributes.getValue(i);
			if (attributes.getQName(i).compareTo("id") == 0)
				id = attributes.getValue(i);
			if (attributes.getQName(i).compareTo("name") == 0)
				thisName = attributes.getValue(i);
			if (attributes.getQName(i).compareTo("description") == 0) {
				description = attributes.getValue(i);
			}
			if (attributes.getQName(i).compareTo("sequence") == 0)
				sequence = Integer.parseInt(attributes.getValue(i));
			if (attributes.getQName(i).compareTo("minLength") == 0)
				minLength = Integer.parseInt(attributes.getValue(i));
			if (attributes.getQName(i).compareTo("maxLength") == 0)
				maxLength = Integer.parseInt(attributes.getValue(i));
			if (attributes.getQName(i).compareTo("xmlTag") == 0) {
				xmlTag = attributes.getValue(i);
			}

			if (attributes.getQName(i).compareTo("idListFile") == 0)
				idListFile = attributes.getValue(i);
			if (attributes.getQName(i).compareTo("occurs") == 0) {
				String sOccurs = attributes.getValue(i).trim();
				if (sOccurs.length() > 0)
					try {
						occurs = Integer.parseInt(sOccurs);
						if (occurs < 1)
							throw new OBOEException(
								"occurs less than 1. "
									+ " look for occurs=\""
									+ attributes.getValue(i)
									+ "\""
									+ " nodeName: dataElement"
									+ " name: "
									+ thisName
									+ " id:"
									+ id);
					} catch (NumberFormatException nfe) {
						throw new OBOEException(
							"occurs not numeric. "
								+ " look for occurs=\""
								+ attributes.getValue(i)
								+ "\""
								+ " nodeName: dataElement"
								+ " name: "
								+ thisName
								+ " id:"
								+ id);
					}
			}
		}

		if (xmlTag == null)
			xmlTag = id;


		TemplateDE currentTemplateDE = new TemplateDE(
			id,
			thisName,
			sequence,
			type,
			required.charAt(0),
			description,
			minLength,
			maxLength,
			xmlTag, null, null,
			occurs, true);

       return currentTemplateDE;
	}

	/** I use this to keep track of line #s
	 * @param ch char array of found whitespaces
	 * @param start int start position in array
	 * @param length int length of what's been found
	 */
	public void ignorableWhitespace(char[] ch, int start, int length) {
		reportPosition();

		for (int i = start; i < start + length; i++)
			if (ch[i] == '\n')
				_iLine++;
	}
	/** catches warning SAXParseExceptions
	 * this code sends exception to stdio and allows public classto continue
	 * @param e SaxException object
	 * @throws SAXException exception
	 */
	public void warning(SAXParseException e) throws SAXException {
		logr.error(
			"Warning at (file "
				+ e.getSystemId()
				+ ", line "
				+ e.getLineNumber()
				+ ", char "
				+ e.getColumnNumber()
				+ "): "
				+ e.getMessage());
	}

	/** catches error SAXParseExceptions
	 * this code causes exception to continue
	 * @param e SaxException object
	 * @throws SAXException thrown
	 */
	public void error(SAXParseException e) throws SAXException {
		throw new SAXException(
			"Error at (file "
				+ e.getPublicId()
				+ ", line "
				+ e.getLineNumber()
				+ ", char "
				+ e.getColumnNumber()
				+ "): "
				+ e.getMessage());
	}

	/** catches fatal SAXParseExceptions
	 * this code causes exception to continue
	 * @param e SAXException object
	 * @throws SAXException thrown
	 */
	public void fatalError(SAXParseException e) throws SAXException {
		throw new SAXException(
			"Fatal Error at (file "
				+ e.getPublicId()
				+ ", line "
				+ e.getLineNumber()
				+ ", char "
				+ e.getColumnNumber()
				+ "): "
				+ e.getMessage());
	}
	
	/* (non-Javadoc)
	 * @see org.xml.sax.ext.LexicalHandler#startDTD(java.lang.String, java.lang.String, java.lang.String)
	 */
	public void startDTD(String arg0, String arg1, String arg2) throws SAXException {
		
		
	}

	/* (non-Javadoc)
	 * @see org.xml.sax.ext.LexicalHandler#endDTD()
	 */
	public void endDTD() throws SAXException {
		
		
	}

	/* (non-Javadoc)
	 * @see org.xml.sax.ext.LexicalHandler#startEntity(java.lang.String)
	 */
	public void startEntity(String arg0) throws SAXException {
		
		
	}

	/* (non-Javadoc)
	 * @see org.xml.sax.ext.LexicalHandler#endEntity(java.lang.String)
	 */
	public void endEntity(String arg0) throws SAXException {
		
		
	}

	/* (non-Javadoc)
	 * @see org.xml.sax.ext.LexicalHandler#startCDATA()
	 */
	public void startCDATA() throws SAXException {
		
		
	}

	/* (non-Javadoc)
	 * @see org.xml.sax.ext.LexicalHandler#endCDATA()
	 */
	public void endCDATA() throws SAXException {
		
		
	}

	/* (non-Javadoc)
	 * @see org.xml.sax.ext.LexicalHandler#comment(char[], int, int)
	 */
	public void comment(char[] chars, int start, int length) throws SAXException {
		reportPosition();

		for (int i = start; i < start+length; i++)
			if (chars[i]=='\n')
				_iLine++;
		
	}

	
	private void setDirectoryPath(String inPath) {
		xmlDirectoryPath = inPath;
	}

	static private Hashtable envBuilt = new Hashtable();

	/** static class method will build a envelope based on input string and OBOE.properties defintion
	 * see OBOE.properties file to define the directory path
	 * @param inFileName String without the path or xml file extension
	 * @return TemplatesEnvelope
	 * @throws OBOEException io error most likely
	 * @deprecated use buildEnvelope(String, String)
	 */
	public static TemplateEnvelope buildEnvelope(String inFileName)
		throws OBOEException {
		return buildEnvelope(inFileName, "");
	}
	
	/** static class method will build a envelope based on input string and OBOE.properties defintion
	 * see OBOE.properties file to define the directory path
	 * @param inFileName String without the path or xml file extension
	 * @param version String specifies subpath to find version specific envelope rules files
	 * @return TemplateEnvelope
	 * @throws OBOEException io error most likely
	 */
		public static TemplateEnvelope buildEnvelope(String inFileName, String version) {
		String xmlPath;
		File xmlFile;
		TemplateEnvelope currentEnvelope;

		TemplateEnvelope gotBuilt =	(TemplateEnvelope) envBuilt.get(version+inFileName);
		if (gotBuilt != null)
		  return gotBuilt;

		try {
			String path = Util.getOBOEProperty("xmlPath");

			xmlPath = path + version+inFileName + ".xml";

			xmlFile = new File(xmlPath);
			
			logr.debug("xml file path is "+xmlFile.getAbsolutePath());
			
			logr.debug("envelope rules xml file test is "+xmlFile.exists());

			if (xmlFile.exists() == false) {
				xmlPath = path + inFileName + ".xml";
				xmlFile = new File(xmlPath);
				logr.debug("envelope rules xml file test is "+xmlFile.exists() +" for "+ xmlFile.getAbsolutePath());
                
            }

			if (xmlFile.exists() == false) {
                throw new OBOEException("Envelope Rules File not found: (" + xmlPath + ")");
            }

 			EnvelopeFactory ef = new EnvelopeFactory();

			ef.setDirectoryPath(path);

			InputSource is = new InputSource(new FileReader(xmlPath));
			ef.parse(is);
			currentEnvelope = ef.currentEnvelope;
			envBuilt.put(version+inFileName, currentEnvelope);
			return currentEnvelope;

		}
		//catch (OBOEException oe) { throw oe; }
		catch (Exception ex) {
			logr.error(ex.getMessage(), ex);
			throw new OBOEException(ex.getMessage());
		}

	}

	/** static main class used for testing
	 * <br>Class contains a main method to allow it to invoked as an application.
	 * <br>format: java com.americancoders.edi.EnvelopeFactory
	 * @param args String array
	 */

	public static void main(String args[]) {
		if (args.length == 0) {
			try {
				buildEnvelope("envelope");

			} catch (Exception ex) {
				logr.error(ex.getMessage(), ex);
			}
		} else {
			System.out.println("java EnvelopeFactory");
			System.exit(0);
		}

	}

}
