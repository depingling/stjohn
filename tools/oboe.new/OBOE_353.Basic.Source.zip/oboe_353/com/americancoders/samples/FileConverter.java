/*
 * Created on Feb 3, 2006
 *
 * 
 */
package com.americancoders.samples;

import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.Writer;

import org.apache.log4j.Logger;
import org.xml.sax.SAXException;

import com.americancoders.edi.DocumentErrors;
import com.americancoders.edi.EDIXMLParser;
import com.americancoders.edi.Envelope;
import com.americancoders.edi.ValidXMLEDIParser;
import com.americancoders.util.Util;

/**
 * @author joe mcverry - americancoders ltd.
 * 
 * program to parse file
 *  
 */
public class FileConverter {

    static Logger logr = Logger.getLogger(FileConverter.class);

    static {
        Util.isLog4JNotConfigured();
    }

    public static void showMainArgs() {
        System.out
                .println("format: com.americancoders.samples.FileConverter inputtype inputfilename outputtype [outputfilename]");
        System.out
                .println("   where inputtype (single character) is x-X12, e-EDIFACT, w-well formed OBOE XML, v-validatable OBOE XML");
        System.out
                .println("         inputfilename is an existing file in format as specified above");
        System.out
                .println("         outputtype (single character) x-X12, e-EDIFACT, w-well formed OBOE XML, v-validatable OBOE XML, r-formatted report ");
        System.out
                .println("         outputfilename (optional) where output is to be written, if not specified file written to System.out");

    }

    /**
     * program to parse incoming file main uses three required arguments and one optional
        1) inputtype (single character) is x-X12, e-EDIFACT, w-well formed OBOE XML, v-validatable OBOE XML
        2) inputfilename is an existing file in format as specified above
        3) outputtype (single character) x-X12, e-EDIFACT, w-well formed OBOE XML, v-validatable OBOE XML, r-formatted report
        4) outputfilename (optional) where output is to be written, if not specified file written to System.out
     */

    public static void main(String[] args) {

        if (args.length != 3 && args.length != 4) {
            showMainArgs();
            System.exit(0);
        }
        try {
            Envelope env = null;
            DocumentErrors de = new DocumentErrors();
            switch (args[0].charAt(0)) {
            case 'x':
                SampleX12DocumentHandler sxdh = new SampleX12DocumentHandler();
                sxdh.parse(args[1]);
                env = sxdh.envelope;
                break;
            case 'e':
                SampleEDIFactDocumentHandler sedh = new SampleEDIFactDocumentHandler();
                sedh.parse(args[1]);
                env = sedh.envelope;
                break;
            case 'w':
                EDIXMLParser xmlp = new EDIXMLParser();
                xmlp.parseFile(args[1]);
                xmlp.getEnvelope().validate(de);
                de.logErrors();
                if (de.getErrorCount() == 0) {
                    logr.info("no errors");
                    env = xmlp.getEnvelope();
                }
                break;
            case 'v':
                ValidXMLEDIParser vxep = new ValidXMLEDIParser();
                vxep.parseFile(args[1]);
                vxep.getEnvelope().validate(de);
                if (de.getErrorCount() == 0) {
                    logr.info("no errors");
                    env = vxep.getEnvelope();
                }
                break;

            default:
                break;
            }

            if (env == null)
                return;

            Writer w;
            if (args.length == 4) {
                logr.info("output written to "+args[3]);
                w = new FileWriter(args[3]);

            } else {
                logr.info("output written to System.out");
                w = new PrintWriter(System.out);
            }

            switch (args[2].charAt(0)) {
            case 'x':
                env.writeFormattedText(w, Envelope.X12_FORMAT);
                break;
            case 'e':
                env.writeFormattedText(w, Envelope.EDIFACT_FORMAT);
                break;
            case 'w':
                env.writeFormattedText(w, Envelope.XML_FORMAT);
                break;
            case 'v':
                env.writeFormattedText(w, Envelope.VALID_XML_FORMAT);
                break;
            case 'r':
                env.writeFormattedText(w, -1);
                break;
            default:
                env.writeFormattedText(w, Envelope.VALID_XML_FORMAT);
                break;
            }

        } catch (FileNotFoundException e) {
            logr.error(e.getMessage(), e);
        } catch (IOException e) {
            logr.error(e.getMessage(), e);
        } catch (SAXException e) {
            logr.error(e.getMessage(), e);
        }

    }
}
