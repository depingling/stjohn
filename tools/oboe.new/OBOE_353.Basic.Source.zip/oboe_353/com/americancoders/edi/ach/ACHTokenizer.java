package com.americancoders.edi.ach;

import java.io.Reader;

import org.apache.log4j.Logger;

import com.americancoders.edi.DocumentErrors;
import com.americancoders.edi.ITokenizer;
import com.americancoders.edi.OBOEException;
import com.americancoders.edi.Tokenizer;
import com.americancoders.util.Util;

/**
 *  class to assist in tokenizing input transaction sets
 *  <br>  x12 field seperator uses 3rd byte of input string
 *  <br>  x12 segment separator uses 16th field + 1 byte field, if it sees a cr character then checks for a lf character and then assumes a \\n character
 *  <br>  EDIFact uses different control positions.  see header segment.
 *<p>OBOE - Open Business Objects for EDI
 *<p>Part of the OBOE Basic Extended Package
 *<br>An EDI and XML Translator Written In Java
 *<br>Copyright 1998-2007 - American Coders, LTD  - Raleigh NC USA
 *<br>All rights reserved
 *<br>American Coders, Ltd
 *<br>P. O. Box 97462
 *<br>Raleigh, NC  27624  USA
 *<br>1-919-846-2014
 *<br>http://www.americancoders.com
@author Joe McVerry - American Coders, Ltd.
  @version   3.5.3
 */

public class ACHTokenizer extends Tokenizer implements ITokenizer{

	/** log4j object */
    static Logger logr = Logger.getLogger(ACHTokenizer.class);
	static 	{Util.isLog4JNotConfigured();}


	/** builds the parsing object for a transaction set
	 * @param inReader what's to be tokenized
	 * @param inType String (X12 | EDIFACT)
	 * @param inDErr DocumentError
	 * @throws OBOEException invalid token most likely
	 */
	public ACHTokenizer(Reader inReader, String inType, DocumentErrors inDErr)
		throws OBOEException {
		
		super(inDErr);

	}

}
