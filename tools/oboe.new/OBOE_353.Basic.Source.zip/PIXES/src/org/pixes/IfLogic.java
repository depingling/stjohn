/*
 * Copyright (C) 2006-2007 by Joseph McVerry - American Coders, Ltd.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

package org.pixes;



import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.xml.sax.Attributes;


/**
 * @author Joe McVerry - American Coders, Ltd.
 *
 * executor object to do if statement processing
 *
 */
public class IfLogic extends Executable{

	
    static {Util.isLog4JNotConfigured();}
    /**
     * who's in charge
     */
    Parser prsr;
    /**
     * debugging level
     */
    Level dbgLvl;
    /**
     * String we are working with
     */
    String test, to;
    /** where to go when staying within the if statement */
    int withinLine;
    /** list of valid operators */
    static String opers[] = {"eq", "ne", "lt", "gt", "le", "ge"};
    /** position of operator in the list */
    int oper;

    /** like a continue step but it's where the else tag is */
    GoTo myElse= null;

	/**
	 * @param line - int xml line number
	 * @param attr - Attributes
	 * @param parser - Parser
	 * @throws PIXESException
	 *
	 */
	public IfLogic(int line, Attributes attr,  Parser parser) throws PIXESException {
    	super(parser);
    	prsr = parser;
    	logr = Logger.getLogger(IfLogic.class);
	    setLogger();
		dbgLvl = prsr.logr.getLevel();
        logr.setLevel(dbgLvl);
		logr.debug("iflogic constructor " + attr + line);
		setMyXMLLine(line);
		test = attr.getValue("test");

		if (parser.getVarStack().testVar(test)== false)
		{
			return;
		}

		String operator = attr.getValue("operator");
		if (operator == null)
		{
			throw new PIXESException("no compareOperator at line "+ line);
		}
		boolean found = false;
		for (oper = 0; oper < opers.length && found == false; oper++)
		{
			found = operator.compareTo(opers[oper])==0;
		}

		if (found == false)
		{
			throw new PIXESException("bad compareOperator "+operator+" at line "+ line);
		}
		oper--;
		to = attr.getValue("to");
		if (parser.getVarStack().testVar(to)== false)
		{
			return;
		}


	}

	
	/**
	 * sets the location of the else tag step
	 * @param withinLine
	 */
	public void setWithinLine(int withinLine) {
		this.withinLine = withinLine;
	}

	/** test and run
	 * @return int
	 */
	public int execute(Executor inExec) {
		exec = inExec;
		exec.logr.setLevel(dbgLvl);    
		logr.setLevel(dbgLvl);
		  FixedDecimalArithmetic fd1=null;
		  FixedDecimalArithmetic fd2=null;
		  logr.debug(" calling execute " + test + " " + opers[oper] + " " + to);
		  boolean bln = false;
		  String first, second;
		  try {
			first = inExec.getVarStack().replaceString(test);
		} catch (Exception e) {
		    logr.error(e.getMessage()+ " line "+this.getMyXMLLine(), e);
			first = test;
		}
		  try {
			second = inExec.getVarStack().replaceString(to);
		} catch (Exception e1) {
		    logr.error(e1.getMessage()+ " line "+this.getMyXMLLine(), e1);
			second = to;
		}
		boolean doFDA = true;
		try {
		   fd1 = new FixedDecimalArithmetic(first) ;
		   fd2 = new FixedDecimalArithmetic(second);
		}
		catch (java.lang.NumberFormatException nfe)
		{
			doFDA = false;
		}
		  logr.debug(" comparing " + first + " " +  opers[oper]  + " " + second);
		  switch (oper) {
		case 0: // equal

			if (doFDA)
				bln = fd1.compare(fd2) == 0;
			else
				bln = first.compareTo(second) == 0;

			break;
		case 1: // not equal
			if (doFDA)
				bln = fd1.compare(fd2) != 0;
			else
				bln = first.compareTo(second) != 0;

			break;
		case 2: // less than
			if (doFDA)
				bln = fd1.compare(fd2) < 0;
			else

			bln = first.compareTo(second) < 0;

			break;
		case 3: // greater than

			if (doFDA)
				bln = fd1.compare(fd2) > 0;
			else
			bln = first.compareTo(second) > 0;

			break;
		case 4: // less than or equal

			if (doFDA)
				bln = fd1.compare(fd2) <= 0;
			else
			bln = first.compareTo(second) <= 0;

			break;
		case 5: // greater than or equal

			if (doFDA)
				bln = fd1.compare(fd2) >= 0;
			else
			bln = first.compareTo(second) >= 0;

			break;

		default:
			logr.fatal("logic error");
			break;
		}

		  if (bln == false)
			  return getNextStep();
	      else
		    return withinLine;
		}


	/** get associated else tag
	 *
	 * @return really a goto object
	 */
	protected GoTo getElse() {
		return myElse;
	}

	/** associate the else tag
	 *
	 * @param inElse really a goto object
	 */
	protected void setElse(GoTo inElse) {
		this.myElse = inElse;
	}
}
