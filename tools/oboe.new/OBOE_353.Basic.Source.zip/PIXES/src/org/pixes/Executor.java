/*
 * Copyright (C) 2006-2007 by Joseph McVerry - American Coders, Ltd.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

package org.pixes;
import java.io.IOException;
import java.io.PipedReader;
import java.io.PrintStream;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

import org.apache.log4j.Appender;
import org.apache.log4j.Logger;
import org.pixes.debugger.DebugListener;
import org.pixes.debugger.Debugger;

/**
 * @author Joe McVerry - American Coders, Ltd.
 */


public class Executor extends Thread
 {


    Logger logr = Logger.getLogger(Executor.class);
    {
        Util.isLog4JNotConfigured();
    }


    int executorCnt = 0;

    /** array of executable objects */
    Executable executorArray[];


    public char methodIdentifier = '@';

    public char arrayStartIdentifier = '[';

    public char arrayEndIdentifier = ']';


    public char startArgList = '(';
    public char endArgList = ')';

    /** default output to System.out unless otherwise told to put it somewhere else */
    private PrintStream processOut = System.out;

    /** list of addons */
    Vector xmlProcessors = new Vector();
    
    
    /** variable stack mechanism */
    
    private VarStack vstack;


    /**
     *
     *
     */
    public Executor(Executable inExecArray[]) throws IOException {
    	vstack = new VarStack();
        executorArray = inExecArray;
    }

    String srcFile = "";
    
    public  Executor(Executable inExecArray[], Executor inExec, String inName) throws IOException {
    	if (inExec.getDebugListener() != null)
    		listeners.add(inExec.getDebugListener());
    	if (inExec.getDebugListener() != null)
    		dbgListener = inExec.getDebugListener();
    	Enumeration e = inExec.getLogger().getAllAppenders();
    	while (e.hasMoreElements())
    		logr.addAppender((Appender)e.nextElement());
    	if (inExec.getDebugListener() != null)
    		dbPipeReaders.put(inExec.getDebugListener(), inExec.dbPipeReaders.get(inExec.getDebugListener()));
    	vstack = inExec.getVarStack();
        executorArray = inExecArray;
        srcFile = inName;
        this.processOut = inExec.processOut;
    	
    }

    
    public VarStack getVarStack() 
    {
    	return vstack;
    }
 
    
    private boolean runSwitch = true;
    
    public void setRunSwitch(boolean inSw) {runSwitch = inSw;    }
    
    
    public void run() {
    	execute();
    }


    /** execute the code
     *
     * @return next step
     */
    public int execute() {


        if (listeners.size() > 0) {
        	notifyExecutionStarted();
        }

           int i;
            for (i=0; i<this.xmlProcessors.size(); i++)
                ((XMLParsexecutor)xmlProcessors.get(i)).setup();
            int executePosition = 0;
            executorCnt = executorArray.length;
            int lastpos = 0;

            while ((runSwitch == true) && 
            		(executePosition < executorCnt) && 
            		(executorArray[executePosition] != null)) {
            	
                logr.debug("calling " + executorArray[executePosition]
                        + " at position " + executePosition);
                lastpos = executePosition;
                if (listeners.size() > 0 && executorArray[executePosition].getMyXMLLine() > 0) {
                	if (notifyLineExecutionStarted(executorArray[executePosition].getMyXMLLine(), executePosition) == Debugger.NOGO)
                			return -2;

                }
                executePosition = executorArray[executePosition].execute(this);

                if (executePosition == -100) {
                    logr.info("execution step indicates exit condition "
                            + executePosition + " " + executorArray[lastpos]);

                    if (listeners.size() > 0) {
                    	this.notifyErrorOccured(new PIXESException("pe"));
                    	this.notifyExecutionStopped();
                    }

                    return -2;
                }
                if (executePosition < 0) {
                    logr.error("execution step indicates error condition "
                            + executePosition + " " + executorArray[lastpos]);

                    if (listeners.size() > 0) {
                    	this.notifyErrorOccured(new PIXESException("pe"));
                    	this.notifyExecutionStopped();
                    }

                    return -3;
                }
                if (listeners.size() > 0 && executorArray[lastpos].getMyXMLLine() > 0)
                	this.notifyLineExecutionStopped(executorArray[lastpos].getMyXMLLine(), executePosition);
                logr.debug("going to " + executePosition);

            }

            if (srcFile.length() == 0 ) {
            for (i=0; i<this.xmlProcessors.size(); i++)
                ((XMLParsexecutor)xmlProcessors.get(i)).shutdown();

            processOut.flush();
            if (processOut != System.out)
            {
            	processOut.close();
            }

            if (listeners.size() > 0)
            	this.notifyExecutionStopped();

            }
          return 0;
    }




 	public char getArrayEndIdentifier() {
        return arrayEndIdentifier;
    }

    public void setArrayEndIdentifier(char inAED) {
        arrayEndIdentifier = inAED;
    }

    public char getArrayStartIdentifier() {
        return arrayStartIdentifier;
    }

    public void setArrayStartIdentifier(char inASI) {
        arrayStartIdentifier = inASI;
    }

    public char getMethodIdentifier() {
        return methodIdentifier;
    }

    public Logger getLogger() {
        return logr;
    }
    public void setLogger(Logger logr) {
        this.logr = logr;
    }
    public int getExecutorCnt() {
        return executorCnt;
    }
    public void setExecutorCnt(int executorCnt) {
        this.executorCnt = executorCnt;
    }

    /* (non-Javadoc)
     * @see org.pixes.XMLParsexecutor#setParsexecutor(org.pixes.Parser)
     */
    public void setParsexecutor(Executor inPx) {
        logr.error("don't use this method with this class");
        System.exit(0);
    }


    /**
     * where is output going
     * @return print stream, could be System.out if it wasn't changed
     */
    public PrintStream getOutProcessFile() {
        return processOut;
    }

	public PrintStream getProcessOutStream() {

		return processOut;
	}
	/* start of debugger add ons */

	/** listners */

	Vector listeners = new Vector();

    DebugListener dbgListener;

    Hashtable dbPipeReaders = new Hashtable();
    
    
	/**
	 * @param debugger
	 * @throws IOException
	 */
	public void registerListeners(DebugListener debugger) throws IOException {

		listeners.add(debugger);

		dbPipeReaders.put(debugger, new PipedReader(debugger.getPipedWriter()));
		dbgListener = debugger;
		logr.addAppender(debugger.getAppender());

	}

	public DebugListener getDebugListener() {
		return dbgListener;
	}



	public void notifyErrorOccured(PIXESException pe){
		for (int i = 0; i < listeners.size(); i++) {
			DebugListener dl = (DebugListener) listeners.elementAt(i);
			dl.errorOccured(pe);
		}

	}

	public void notifyExecutionStarted(){
		for (int i = 0; i < listeners.size(); i++) {
			DebugListener dl = (DebugListener) listeners.elementAt(i);
			dl.executionStarted();
		}

	}

	public int notifyLineExecutionStarted(int inLine, int inPos){

		for (int i = 0; i < listeners.size(); i++) {
			DebugListener dl = (DebugListener) listeners.elementAt(i);
			try {
				dl.lineExecutionStarted(srcFile, inLine, getVarStack());
				PipedReader pr = (PipedReader) dbPipeReaders.get(dl);
				int response = pr.read();
				if (response == Debugger.GO)
					return response;
				else
				{
					System.out.println("told not to go");
					return response;

				}
				}
				catch (IOException ioe) {
					ioe.printStackTrace();
					System.exit(0);
				}

		}

		return Debugger.GO;
	}

	public void notifyLineExecutionStopped(int inLine, int inPos){
		for (int i = 0; i < listeners.size(); i++) {
			DebugListener dl = (DebugListener) listeners.elementAt(i);
			dl.lineExecutionStopped(srcFile, inLine);
		}

	}

	public void notifyExecutionStopped(){
		for (int i = 0; i < listeners.size(); i++) {
			DebugListener dl = (DebugListener) listeners.elementAt(i);
			dl.executionStopped();
		}

	}

	protected Executable[] getExecutorArray() {
		return executorArray;
	}



}
