/*
 * Created on Aug 6, 2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.americancoders.edi;

import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.util.Hashtable;
import java.util.Vector;

import org.apache.log4j.Logger;

import com.americancoders.util.Util;


/**
 * @author Joe McVerry - American Coders, Ltd.
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class IDList103Processor implements IDListProcessor {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	static IDListParser idListParser = null;
	static Hashtable code1 = null;
	static Hashtable code2 = null;
	static Logger logr = Logger.getLogger(IDList103Processor.class.getName());
	static {Util.isLog4JNotConfigured();}


	/**
	 * 
	 */
	public IDList103Processor() throws IOException{
	   if (idListParser != null)
	      return; // done this already;
	   Vector v, c;     
	   try {
		idListParser = new IDListParser();
	} catch (Exception e) {
		logr.error(e.getMessage(), e);
		return;
	}
	   String xmlPath = Util.getOBOEProperty("xmlPath");
	   IDList currentIDList =	new IDList(
					xmlPath
						+ "IDList103Part1.xml",
					xmlPath,
					idListParser);
	   v = currentIDList.getValues();
	   c = currentIDList.getCodes();
	   code1 = new Hashtable(v.size());
	   int i;
	   for (i=0; i < v.size(); i++)
	    {
	    	code1.put(c.elementAt(i),v.elementAt(i));
	    }
	   currentIDList =	new IDList(
					xmlPath
						+ "IDList103Part2.xml",
					xmlPath,
					idListParser);
					
	   v = currentIDList.getValues();				
	   c = currentIDList.getCodes();
	   code2 = new Hashtable(v.size());
	   for (i=0; i < v.size(); i++)
		{
			code2.put(c.elementAt(i),v.elementAt(i));
		}
	   	
	}

	/* (non-Javadoc)
	 * @see com.americancoders.edi.IDListProcessor#add(java.lang.String, java.lang.String)
	 */
	public void add(String inCode, String inDescribe) throws UnsupportedOperationException {
		throw new UnsupportedOperationException("don't do this now");

	}

	/* (non-Javadoc)
	 * @see com.americancoders.edi.IDListProcessor#isCodeValid(java.lang.String)
	 */
	public boolean isCodeValid(String inCode) {
		if (inCode.length() != 5) return false;
		String c1 = inCode.substring(0, 3);
		if (code1.get(c1) == null) return false;
		String c2 = inCode.substring(3, 5);
		if (code2.get(c2) == null) return false;
		return true;
	}

	/* (non-Javadoc)
	 * @see com.americancoders.edi.IDListProcessor#describe(java.lang.String)
	 */
	public String describe(String inCode) {
		// 
		if (inCode.length() != 5) return inCode;
		String c1 = inCode.substring(0, 3);
		if (code1.get(c1) == null) return inCode;
		String c2 = inCode.substring(3, 5);
		if (code2.get(c2) == null) return inCode;
		return (String) code1.get(c1) + " " + (String) code2.get(c2);

	}

	/* (non-Javadoc)
	 * @see com.americancoders.edi.IDListProcessor#getCode(java.lang.String)
	 */
	public String getCode(String inValue) {
		// 
		return inValue;
	}

	/* (non-Javadoc)
	 * @see com.americancoders.edi.IDListProcessor#getCodeByPos(int)
	 */
	public String getCodeByPos(int pos) throws UnsupportedOperationException {
		// 
		return null;
	}

	/* (non-Javadoc)
	 * @see com.americancoders.edi.IDListProcessor#getCodes()
	 */
	public Vector getCodes() {
		// 
		return null;
	}

	/* (non-Javadoc)
	 * @see com.americancoders.edi.IDListProcessor#getValues()
	 */
	public Vector getValues() {
		// 
		return null;
	}

	/* (non-Javadoc)
	 * @see java.io.Externalizable#writeExternal(java.io.ObjectOutput)
	 */
	public void writeExternal(ObjectOutput out) throws IOException {
		// 

	}

	/* (non-Javadoc)
	 * @see java.io.Externalizable#readExternal(java.io.ObjectInput)
	 */
	public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
		// 

	}

	public static void main(String[] args) throws Exception{
		
		IDList103Processor idl103 = new IDList103Processor();
		idl103.hashCode();
	}
}
