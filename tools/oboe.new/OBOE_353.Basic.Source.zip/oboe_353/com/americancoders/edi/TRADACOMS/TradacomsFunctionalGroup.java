package com.americancoders.edi.TRADACOMS;

/**
 *OBOE - Open Business Objects for EDI
 *<p>Copyright 1998-2007 - American Coders, LTD  - Raleigh NC USA
 *<p>All rights reserved
 *<p>American Coders, Ltd
 *<br>P. O. Box 97462
 *<br>Raleigh, NC  27624  USA
 *<br>1-919-846-2014
 *<br>http://www.americancoders.com
@author Joe McVerry - American Coders, Ltd.
  @version   3.5.3
 */
import com.americancoders.edi.FunctionalGroup;
import com.americancoders.edi.IContainedObject;
import com.americancoders.edi.OBOEException;
import com.americancoders.edi.TemplateFunctionalGroup;
import com.americancoders.edi.TemplateSegmentContainer;

/**
 * class for container Functional_Group
 *
 */
public class TradacomsFunctionalGroup
	extends FunctionalGroup
	implements IContainedObject {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/** static segment ids */
	public static final String idHeader = "BAT";
	public static final String idTrailer = "EOB";

	public TradacomsFunctionalGroup() {
		setHeaderId(idHeader);
		setTrailerId(idTrailer);
	}

	/** instantiates a functional group from the definition in an
	 * envelope xml rules file.
	    * @param inParent owning Object
	*/

	public TradacomsFunctionalGroup(
		TemplateFunctionalGroup inTFG,
		IContainedObject inParent) {
		super(inTFG, inParent, idHeader, idTrailer);
	}


	/** set the Transaction Count in the trailer object
	 * @exception DON'T USE THIS METHOD FOR Tradacoms
	 */
	public void setCountInTrailer() throws OBOEException {
		throw new OBOEException("method not functional");
	}
	/** not used
	 */
	public TemplateSegmentContainer getTemplateSegmentContainer() {
		return null;
	}
	/* (non-Javadoc)
	 * @see com.americancoders.edi.IContainedObject#getDelimiter(char)
	 */

		public char getDelimiter(char inOriginal) {
			
			return parent.getDelimiter(inOriginal);
		}

}
