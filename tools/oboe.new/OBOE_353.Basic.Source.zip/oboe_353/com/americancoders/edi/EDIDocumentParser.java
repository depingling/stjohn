package com.americancoders.edi;

/**
 *OBOE - Open Business Objects for EDI
 *<P>java access to EDI
 *<p>Copyright 1998-2007 - American Coders, LTD  - Raleigh NC USA
 *<p>All rights reserved
 *<p>American Coders, Ltd
 *<br>P. O. Box 97462
 *<br>Raleigh, NC  27624  USA
 *<br>1-919-846-2014
 *<br>http://www.americancoders.com
@author Joe McVerry - American Coders, Ltd.
  @version   3.5.3
 */


import java.util.Vector;


/**
 * abstract class defining methods for parsing EDI Documents
 * <br>Document handlers will register with this class to be notified
 * when specific edi objects are created or finished
 * <br>Unlike the old parser these parsers will not contain the
 * objects,  the process of adding objects to owning parents (such as
 * adding functional groups to an envelope) is left up to the document handler.
 */

public abstract class EDIDocumentParser
{

 /** list of registered document handlers */

 private Vector handlers = new Vector();

 protected DocumentErrors dErr = new DocumentErrors();
 
 
 /** method to reset the error level processing
  * 
  * @param i int
  */
 
 public void setErrorLevel(int i) {dErr.setErrorLevel(i);}

 /** method for handlers to register with the parser
  *  @param edh EDIDocumentHandler
  */
 public void registerHandler(EDIDocumentHandler edh)
   {
    synchronized(handlers)
      {
        handlers.add(edh);
      }
   }

  /** abstract method all document parsers must implement
   *  @param s String edi document
   *  @throws OBOEException
   */

  public abstract void parseDocument(String s) throws OBOEException;

  /** abstract method all document parsers must implement
   *  @param r java.io.Reader object containing edi document
   *  @param b boolean if true run validation routine after parsing.
   *  @throws OBOEException
   */

  public abstract void parseDocument(java.io.Reader r, boolean b) throws OBOEException;
 /** method to notifiy handlers when an envelope was just created
  *  @param inEnv Envelope
  */
  public void notifyStartEnvelope(Envelope inEnv)
    {
    synchronized(handlers)
      {
        for (int i = 0; i < handlers.size(); i++)
         {
          EDIDocumentHandler edh = (EDIDocumentHandler) handlers.elementAt(i);
          edh.startEnvelope(inEnv);
         }
      }
    }


 /** method to notifiy handlers when an FunctionalGroup was just created
  *  @param inFG FunctionalGroup
  */
  public void notifyStartFunctionalGroup(FunctionalGroup inFG)
    {
    synchronized(handlers)
      {
        for (int i = 0; i < handlers.size(); i++)
         {
          EDIDocumentHandler edh = (EDIDocumentHandler) handlers.elementAt(i);
          edh.startFunctionalGroup(inFG);
         }
      }
    }


 /** method to notifiy handlers when an TransactionSet was just created
  *  @param inTS TransactionSet
  */
  public void notifyStartTransactionSet(TransactionSet inTS)
    {
    synchronized(handlers)
      {
        for (int i = 0; i < handlers.size(); i++)
         {
          EDIDocumentHandler edh = (EDIDocumentHandler) handlers.elementAt(i);
          edh.startTransactionSet(inTS);
         }
      }
    }

 /** method to notifiy handlers when an Segment was just created
  *  @param inSeg Segment
  */
  public void notifyStartSegment(Segment inSeg)
    {
    synchronized(handlers)
      {
        for (int i = 0; i < handlers.size(); i++)
         {
          EDIDocumentHandler edh = (EDIDocumentHandler) handlers.elementAt(i);
          edh.startSegment(inSeg);
         }
      }
    }

 /** method to notifiy handlers when processing of an envelope is complete
  *  @param inEnv Envelope
  */
  public void notifyEndEnvelope(Envelope inEnv)
    {
    synchronized(handlers)
      {
        for (int i = 0; i < handlers.size(); i++)
         {
          EDIDocumentHandler edh = (EDIDocumentHandler) handlers.elementAt(i);
          edh.endEnvelope(inEnv);
         }
      }
    }

 /** method to notifiy handlers when processing of a functional group is complete
  *  @param inFG FunctionalGroup
  */
  public void notifyEndFunctionalGroup(FunctionalGroup inFG)
    {
    synchronized(handlers)
      {
        for (int i = 0; i < handlers.size(); i++)
         {
          EDIDocumentHandler edh = (EDIDocumentHandler) handlers.elementAt(i);
          edh.endFunctionalGroup(inFG);
         }
      }
    }

 /** method to notifiy handlers when processing of an TransactionSet is complete
  *  @param inTS TransactionSet
  */
  public void notifyEndTransactionSet(TransactionSet inTS)
    {
    synchronized(handlers)
      {
        for (int i = 0; i < handlers.size(); i++)
         {
          EDIDocumentHandler edh = (EDIDocumentHandler) handlers.elementAt(i);
          edh.endTransactionSet(inTS);
         }
      }
    }

 /** method to notifiy handlers when processing of an Segment is complete
  *  @param inSeg Segment
  */
  public void notifyEndSegment(Segment inSeg)
    {
    synchronized(handlers)
      {
        for (int i = 0; i < handlers.size(); i++)
         {
          EDIDocumentHandler edh = (EDIDocumentHandler) handlers.elementAt(i);
          edh.endSegment(inSeg);
         }
      }
    }
  //public abstract CompositeDE notifyEndCompositeDE();
  //public abstract DataElement notifyEndDataElement();

 /** method for handlers to deregister from the parser
  *  @param edh EDIDocumentHandler
  */
 public void deregisterHandler(EDIDocumentHandler edh)
   {
    synchronized(handlers)
      {
        handlers.remove(edh);
      }
   }

 /** gets the DocumentErrors object
  * @return DocumentErrors object
  */

 public DocumentErrors getDocumentErrors()
   {
        return dErr;
   }


}
