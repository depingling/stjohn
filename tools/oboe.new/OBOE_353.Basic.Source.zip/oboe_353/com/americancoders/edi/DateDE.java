package com.americancoders.edi;


import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.apache.log4j.Logger;

import com.americancoders.util.Util;

/**
 * class for Data Elements defined as Date
 *
 *<P>OBOE - Open Business Objects for EDI
 *<p>Part of the OBOE Basic Extended Package
 *<br>An EDI and XML Translator Written In Java
 *<br>Copyright 1998-2007 - American Coders, LTD  - Raleigh NC USA
 *<br>All rights reserved
 *<br>American Coders, Ltd
 *<br>P. O. Box 97462
 *<br>Raleigh, NC  27624  USA
 *<br>1-919-846-2014
 *<br>http://www.americancoders.com
@author Joe McVerry - American Coders, Ltd.
  @version   3.5.3
 */

public class DateDE extends DataElement implements IContainedObject {
	protected String value[];
	protected int cursor = -1;
	private Calendar calendar;
	
	private boolean setLengthIs6 = true;
    static Logger logr = Logger.getLogger(DateDE.class);
	static 	{Util.isLog4JNotConfigured();}

	/** constructs from its template
	 * @param inTDE TemplateDE
	  * @param inParent owning Object
	*/
	public DateDE(TemplateDE inTDE, IContainedObject inParent) {
		super(inTDE, inParent);
		value = new String[inTDE.getOccurs()];
	}

	/**
	 * returns the date stored in YYYYMMDD format  where
	 * <UL>
	 * <LI> YY is year
	 * <LI> MM is month,
	 * <LI> DD is day of month
	 *</UL>

	 * @return String in format YYYYMMDD
	 */
	public String get() {
		return get(0);
	}

	/**
	 * returns the value for the Data Element
	 * @param inPos int position in array
	 * @return String
	 */

	public String get(int inPos) {

		if (value[inPos] == null)
			return null;

		if (value[inPos].length() == 0)
			return value[inPos];

	//	testAndSetValue(inPos);
		return value[inPos];
	}

	private void testAndSetValue(int inPos) {
		if (calendar == null)
			calendar = Calendar.getInstance();

		SimpleDateFormat sdf;
		if ((getMinLength() == 6 && setLengthIs6) || getMaxLength() == 6)
			sdf = new SimpleDateFormat("yyMMdd");
		else
			sdf = new SimpleDateFormat("yyyyMMdd");

		value[inPos] = sdf.format(calendar.getTime());

	}

	/** sets the next field value at first field, cursor set to zero
	* stored  using an input string in the format YYYYMMDD where
	*
	* <UL>
	* <LI> YY is year or YYYY is year.
	* <LI> MM is month,
	* <LI> DD is day of month
	* </UL>
	* @param inDate String date
	*/
	public void set(String inDate) throws OBOEException{
		cursor = -1;
		setNext(inDate);
	}

	/** sets the next field value by moving cursor, cursor will wrap around
	* stored  using an input string in the format YYYYMMDD where
	*
	* <UL>
	* <LI> YY is year or YYYY is year.
	* <LI> MM is month,
	* <LI> DD is day of month
	* </UL>
	* @param inDate String date
	 * @throws ParseException
	*/
	public void setNext(String inDate) throws OBOEException{
		cursor++;
		if (cursor >= getOccurs())
			cursor = 0;

		setLengthIs6 = (inDate.length() == 6);
		if (inDate.length() == 0) {
			value[cursor] = "";
			return;
		}
		
		if (inDate.length() == 10) {
			inDate = inDate.substring(0,4)+inDate.substring(5,7)+inDate.substring(8,10);
			
		}
		testAndSetValue(cursor);
		String vtest = validate(inDate);
		if (vtest != null && vtest.length() > 0) {
		     value[cursor] = inDate;
			 throw new OBOEException(vtest);
		}
		
		if (inDate.length() == 6) {
			if (Integer.parseInt(inDate.substring(0, 2)) < 50) {
				if (getMinLength() == 8)
					logr.error(
						"Date not Y2K compliant '20' will be prepended");
				calendar.set(
					Calendar.YEAR,
					2000 + Integer.parseInt(inDate.substring(0, 2)));
			} else {
				if (getMinLength() == 8)
					logr.error(
						"Date not Y2K compliant '19' will be prepended");
				calendar.set(
					Calendar.YEAR,
					1900 + Integer.parseInt(inDate.substring(0, 2)));
			}
			calendar.set(
				Calendar.MONTH,
				Integer.parseInt(inDate.substring(2, 4)) - 1);
			calendar.set(
				Calendar.DAY_OF_MONTH,
				Integer.parseInt(inDate.substring(4, 6)));
		} else if (inDate.length() == 8) {
			calendar.set(
				Calendar.YEAR,
				Integer.parseInt(inDate.substring(0, 4)));
			calendar.set(
				Calendar.MONTH,
				Integer.parseInt(inDate.substring(4, 6)) - 1);
			calendar.set(
				Calendar.DAY_OF_MONTH,
				Integer.parseInt(inDate.substring(6, 8)));
		}

		testAndSetValue(cursor);


	}

	/** sets the fields contents, not formatted
	 * @param inValue byte array, converted to string and set(String) is called
	 * @exception OBOEException
	 *   inValue contains format characters if field defined with type of N#
	  *
	  */
	public void set(byte inValue[]) throws OBOEException {
		set(new String(inValue));
	}

	/**
	 * gets the current length for the Data Element
	 * @return int retuns length of set value,  can have a null exception if value is not set.
	 *
	 */
	public int getLength() {
		if (value == null)
			return 0;
		int len = 0;
		for (int i = 0; i < getOccurs(); i++) {
			if (value[i] != null)
				len += value[i].length();
		}
		return len;
	}

	/** formats text of data element
	* <br> Short Description of DataElement is defined in the class
	* <br> value is the current value set in the object
	* @param formatType int formatting type
	* @return String formatted content
	*/

	public String getFormattedText(int formatType) {

		SimpleDateFormat sdf = new SimpleDateFormat("MMM dd, yyyy");

		StringBuffer sb = new StringBuffer();
		String got;
		int repeatCnt = -1;
		for (repeatCnt = value.length-1; repeatCnt > -1 && value[repeatCnt] == null; repeatCnt--);
		for (int ii = 0; ii < value.length; ii++) {
			if (value[ii] == null)
				break;
			got = get(ii);
			if (got == null)
				got = "";

			switch (formatType) {
				case Envelope.CSV_FORMAT :
					sb.append("Date DE,"+ getID()	+ ",\""	+ getName()	+ "\",\""	+ sdf.format(calendar.getTime())+ "\""
							+ com.americancoders.util.Util.lineFeed);
					break;
				case Envelope.XML_FORMAT :
					sb.append("<"+ getXMLTag()+ ">"+ Util.normalize(got)+ "</"+ getXMLTag()+ ">"
							+ com.americancoders.util.Util.lineFeed);
					break;
				case Envelope.VALID_XML_FORMAT :
				case Envelope.VALID_XML_FORMAT_WITH_POSITION:
					if (got == null)
						got = "";
					sb.append("<element code=\"" + getID() + "\"");
					sb.append(" name=\"" + getName() + "\"");
					if (formatType == Envelope.VALID_XML_FORMAT_WITH_POSITION)
						sb.append(" docPosition=\""+this.getSequence() + "\"");
					sb.append(">");
						sb.append(" <value>"+ Util.normalize(got)+ "</value></element>"
							+ com.americancoders.util.Util.lineFeed);
					break;
				case Envelope.PIXES_FORMAT:
					if (got == null)
						break;
					sb.append("<set name=\""+parent.getID()+getSequence()+"\">"+Util.normalize(got)+
							"</set>"+com.americancoders.util.Util.lineFeed);
					sb.append("<element position=\"" + this.getSequence() + "\"");
					sb.append(">$");
					sb.append(parent.getID()+getSequence() + "$</element>"+com.americancoders.util.Util.lineFeed);
					break;
				case Envelope.X12_FORMAT :
					if (got == null)
						got = "";
					sb.append(got);
					if (getOccurs() > 1 && ii < repeatCnt)
						sb.append(getDelimiter(Envelope.X12_REPEAT_DELIMITER.charAt(0)));
					break;
				case Envelope.EDIFACT_FORMAT :
					if (got == null)
						got = "";
					sb.append(got);
					if (getOccurs() > 1 && ii < repeatCnt)
						sb.append(getDelimiter(Envelope.EDIFact_REPEAT_DELIMITER.charAt(0)));
					break;
				case Envelope.TRADACOMS_FORMAT :
					if (got == null)
						got = "";
					sb.append(got);
					if (getOccurs() > 1 && ii < repeatCnt)
						sb.append(getDelimiter(Envelope.TRADACOMS_REPEAT_DELIMITER.charAt(0)));
					break;
				default :
				    if (got != null && got.length() > 0)
				       got = sdf.format(calendar.getTime());
					sb.append("\t"+ getName()+ ": "+ got+ com.americancoders.util.Util.lineFeed);
			}
		}
		return new String(sb);
	}

	/** returns error responses of contents
	 * @param inText String text
	 * @return String - null if no error
	 */
	public String validate(String inText) {
		String returnMessage = myTemplate.validate(inText);
		if (returnMessage != null)
			return returnMessage;

		returnMessage = "";

		String dd;

		int i;
		for (i = 0; i < inText.length(); i++)
			if (Character.isDigit(inText.charAt(i)) == false)
				returnMessage = returnMessage + " invalid character at " + i;

		if (returnMessage != null && returnMessage.length() > 0)
			return returnMessage;

		int offset = 2;

		if (inText.length() == 8) {
			dd = inText.substring(0, 4);
			i = Integer.parseInt(dd);
			if (i < 1901 || i > 2099)
				return "invalid year " + dd;
			offset = 4;
		}
		else 
		{
			dd = inText.substring(0,2);
			i = Integer.parseInt(dd);
		}

		dd = inText.substring(offset, offset + 2);
		int m = Integer.parseInt(dd);
		if (m < 1 || m > 12)
			return "invalid month " + dd;

		offset += 2;
		dd = inText.substring(offset, offset + 2);
		int d = Integer.parseInt(dd);
		if (d < 1)
			return "invalid day " + dd;

		if (i % 4 == 0) {
			if (m == 2)
				if (d > 29)
					return "invalid day " + dd;
		} else {
			if (m == 2)
				if (d > 28)
					return "invalid day " + dd;
		}

		if (m == 9 || m == 4 || m == 6 || m == 11) {
			if (d > 30)
				return "invalid day " + dd;
		} else if (d > 31)
			return "invalid day " + dd;

		return null;
	}

	/** sets  error  in DocumentErrors
	 * @param inDErr DocumentErrors object
	 * @return boolean false = error.
	 */
	public boolean validate(DocumentErrors inDErr) {
    	if (isUsed() == false) {
            if (value[0] != null && value[0].length() > 0)
            {
                inDErr.addError(0, getID(), "field is not used, see " +getName() + " at position " + getSequence(),  getParent(), "10", this, 2);
                return false;
               }
            else return true;
    	}

		if (getRequired() == 'M') {
			if (value[0] == null || value[0].length() == 0) {
				inDErr.addError(0, getID(),	"Value Required, see " +getName() + " at position " + getSequence(),	getParent(),
					"1",	this, 1);
				return false;
			}
		} else // not required
			if (value[0] == null || value[0].length() == 0)
				return true;

		if (value[0].length() < getMinLength()) {
			inDErr.addError(getSequence(),	getID(),"Data element value (" + value[0] + ") Too Short, see " +getName() + " at position " + getSequence(),
				getParent(), "4",this, 1);
			return false;
		}

		if (value[0].length() > getMaxLength()) {
			inDErr.addError(getSequence(),getID(),
				"Data element value (" + value[0] + ") Too Long, see " +getName() + " at position " + getSequence(),
				getParent(),"5",this, 1);
			return false;
		}

		return true;
	}


}
