package com.americancoders.edi;

import java.util.Vector;

/**
 * Segment Container
 *
 *<P>OBOE - Open Business Objects for EDI
 *<p>Part of the OBOE Basic Extended Package
 *<br>An EDI and XML Translator Written In Java
 *<br>Copyright 1998-2007 - American Coders, LTD  - Raleigh NC USA
 *<br>All rights reserved
 *<br>American Coders, Ltd
 *<br>P. O. Box 97462
 *<br>Raleigh, NC  27624  USA
 *<br>1-919-846-2014
 *<br>http://www.americancoders.com
@author Joe McVerry - American Coders, Ltd.
  @version   3.5.3
 */

public abstract class SegmentContainer implements IContainedObject, ISegmentContainer, IDelimiterFetcher {

	/** storage for data elements
	 */
	protected Object container[] = null;
	/** get the segment id
	 * @return String segment id
	 */
	abstract public String getID();

	/** this segments template */
	public TemplateSegmentContainer myTemplateContainer;

    /** used by edi parser to test for duplicate segment entries */
      protected boolean dupSegment = false;

	/** parses the segment portion of an EDI Document,
	 * adds to segment vector
	 * @param TransactionTokenizedString incoming tokenized string
	 * @return boolean - true if tts was used
	 * @throws OBOEException as thrown, can't process subsegment maybe
	 */

	public boolean parse(ITokenizer TransactionTokenizedString)
		throws OBOEException {
		int i;

		Segment currentSegment = null;

		boolean inUsed = false;

		i = 0;
		TemplateSegment tseg;

		boolean lookback = false;

		while (i < myTemplateContainer.getCount()) {
			tseg = myTemplateContainer.getTemplateSegment(i);
			
			if (TransactionTokenizedString
				.getCurrentDataElement()
				.compareTo(tseg.getID())
				== 0) {

				if (tseg.canYouPrevalidate()
					&& tseg.isThisYou(TransactionTokenizedString) == false) {
					i++;
					continue;
				}
				if (tseg.getOccurs() == this.getSegmentCount(i)) {
                   if (this.isSegment(i)) {
                   	   this.dupSegment=true;
                       return false;
				   }
				}
				this.dupSegment=false;
                currentSegment = new Segment(tseg, this);
				addSegment(currentSegment, new Integer(i));
				currentSegment.parse(TransactionTokenizedString);
				if (currentSegment.getOccurs() == 1){
					// first test for hipaa equivalent segments
				    if (equivalentSegments(i))
				      i = resetToFirstEquivalentSegment(i);
				    else
					  i++; // don't look back
				}
				else // more than one, still test for equivalence
				if (equivalentSegments(i))
				  i = resetToFirstEquivalentSegment(i);
				inUsed = true;
			} else
				i++; // next
			if (i == myTemplateContainer.getCount() && lookback == true) {
				lookback = false;
				i = 0;
			}
		}

		if (currentSegment == null)
			return false;

		return inUsed;

	}

	/**
	 * @param i position where segment was placed
	 * @return int first position of equivalent segment.
	 */
	protected int resetToFirstEquivalentSegment(int i) {
		if (i == 0)
           return 0;
        int j = i;
		TemplateSegment segAtI = myTemplateContainer.getTemplateSegment(j), otherSeg = null;
        while (j > -1) {
        	if (!myTemplateContainer.isSegment(j))
        	  return j;
			otherSeg = myTemplateContainer.getTemplateSegment(j);
			if (segAtI.getID().compareTo(otherSeg.getID()) != 0)
			    return j;
			if (segAtI.getSequence() != otherSeg.getSequence())
			    return j;
			j--;
        }
		return i;
	}

	/**
	 * @param i position where segment was placed
	 * @return boolean, true if other segments with same id and sequence.
	 */
	protected boolean equivalentSegments(int i) {

		TemplateSegment segAtI = myTemplateContainer.getTemplateSegment(i), otherSeg = null;
		if (i == 0)  // don't test previous, it's not there
		   return false;
		if (!this.myTemplateContainer.isSegment(i-1))
		  return false;
		otherSeg = this.myTemplateContainer.getTemplateSegment(i-1);
		return (segAtI.getID().compareTo(otherSeg.getID()) == 0) &
				  (segAtI.getSequence() == otherSeg.getSequence());
	}

	/** asks the container why it didn't use the current token
	 * @param et Tokenizer incoming tokenized string
	 */


	public void whyNotUsed(Tokenizer et) {
		if (this.dupSegment)
		  {
			et.reportError("Duplicate Segment", "2");
			return;
		  }
		int i;
		i = 0;
		TemplateSegment tseg;

		while (i < myTemplateContainer.getCount()) {
			tseg = myTemplateContainer.getTemplateSegment(i);

			if (et.getCurrentDataElement().compareTo(tseg.getID()) == 0) {
				if (tseg.canYouPrevalidate()) {
					tseg.whyNotYou(et, this);
					return;
				}
			} else
				i++;
		}
		et.reportError("Unknown or out of place segment ("+et.getCurrentDataElement()+") at byte offset ("+et.getInputByteCount()+")", "2");
		return;
	}

	/** returns the size of the segment array
	 * <br> -1 if array is undefined
	 @return int
	 */
	public int getContainerSize() {
		if (container == null)
			return -1;
		return container.length;
	}

	/** simple routine to build the array based on the number of entries in the template segment vector
	 */
	public void defineContainer() {
		TemplateSegment ts;

		container = new Object[myTemplateContainer.getCount()];
		for (int i = 0; i < myTemplateContainer.getCount(); i++) {
			ts = (TemplateSegment) myTemplateContainer.getTemplateSegment(i);
			if (ts.getOccurs() != 1)
				container[i] = new Vector();
		}

	}

	/** add a segment to the array
	 * @param inSegment Segmemt to add to vector
	 * @throws OBOEException segment doesn't belong
	 */
	public void addSegment(Segment inSegment) throws OBOEException {
		int i;
		TemplateSegment tseg = inSegment.getTemplate();
		if (container == null)
			defineContainer();

		String toTest = null;
		if (inSegment.getTemplate().canYouPrevalidate()) {
			TemplateDE tde;
			for (int ii=0; ii<tseg.getTemplateDESize(); ii++)
			   {
				 if (tseg.isTemplateComposite(ii+1) && tseg.getTemplateComposite(ii+1).getRequired() == 'M')
				   {
					 TemplateComposite tce = tseg.getTemplateComposite(ii+1);
					 tde = tce.getTemplateDE(1);
					 if (tde.getRequired()=='M' && tde.getType().compareTo("ID") == 0)
					   {
						 toTest = inSegment.getCompositeDE(ii+1).getDataElement(1).get();
						 break;
					   }
					 continue;
				   }
				 if (tseg.isTemplateDE(ii+1) == false)
				   continue;

				 tde =  tseg.getTemplateDE(ii+1);
				 if (tde.getRequired()=='M' && tde.getType().compareTo("ID") == 0)
				   {
					 toTest = inSegment.getDataElement(ii+1).get();
					 break;
				   }
			   } // if it falls out toTest is a zerolength string and to isThisYou will be false
		}

		for (i = 0; i < myTemplateContainer.getCount(); i++) {
			if (myTemplateContainer.isSegment(i) == false)
				continue;
			tseg =	(TemplateSegment) myTemplateContainer.getTemplateSegment(i);
			if (inSegment.getID().compareTo(tseg.getID()) != 0)
				continue;

			if (tseg.canYouPrevalidate() && toTest != null)
			  {
			  	if (tseg.isThisYou(toTest))	{
			  	  addSegment(inSegment, new Integer(i));
			  	  return;
			  	} else
			  	  continue;
			  }

			if (tseg.getOccurs() == 1)
				container[i] = inSegment;
			else {
				Vector v = (Vector) container[i];
				if (v == null) {
					v = new Vector();
					container[i] = v;
				}
				v.addElement(inSegment);
			}
			return;

		}
		throw new OBOEException(
			"Subsegment " + inSegment.getID() + " not defined in " + getID());
	}

	/** add a segment to the array
	 * @param inSegment Segmemt to add to vector
	 * @throws OBOEException segment doesn't belong
	 */
	protected void addSegment(Segment inSegment, Integer inI)
		throws OBOEException {
		int i = inI.intValue();
		if (container == null)
			defineContainer();

		TemplateSegment tseg =
			(TemplateSegment) myTemplateContainer.getTemplateSegment(i);

		if (tseg.getOccurs() == 1)
			container[i] = inSegment;
		else {
			Vector v = (Vector) container[i];
			if (v == null) {
				v = new Vector();
				container[i] = v;
			}
			v.addElement(inSegment);
		}

	}

	/** adds a Segment to the container by its predefined sequence
	 * @param inSegment Segment to Add
	 * @param inPosition int position to add at
	 * @exception OBOEException Subsegment not defined at sequence
	 *               Subsegment sequence not defined
	 */

	public void addSegment(Segment inSegment, int inPosition)
		throws OBOEException {
		int i;

		if (container == null)
			defineContainer();
		TemplateSegment tempSeg;
		for (i = 0; i < myTemplateContainer.getCount(); i++) {
			tempSeg =
				(TemplateSegment) myTemplateContainer.getTemplateSegment(i);
			if (inSegment.getSequence() == inPosition) {
				if (inSegment.getID().compareTo(tempSeg.getID()) != 0)
					throw new OBOEException(
						"Subsegment "
							+ inSegment.getID()
							+ " not defined at sequence position "
							+ inPosition
							+ " within "
							+ getID());
				if (tempSeg.getOccurs() == 1)
					container[i] = inSegment;
				else {
					Vector v = (Vector) container[i];
					if (v == null) {
						v = new Vector();
						container[i] = v;
					}
					v.addElement(inSegment);
				}
				return;
			}
		}
		throw new OBOEException(
			"Subsegment at position "
				+ inPosition
				+ " not defined in "
				+ getID());
	}

	/** adds a Segment to a vectorized segment in the container at a predefined sequence
	 * @param inSegment Segment
	 * @param inPosition int position
	 * @exception OBOEException segment postion not vectorized
	 */

	public void addSegmentToVector(Segment inSegment, int inPosition)
		throws OBOEException {
		int i;
		TemplateSegment tempSeg;
		if (container == null)
			defineContainer();

		for (i = 0; i < myTemplateContainer.getCount(); i++) {
			tempSeg =
				(TemplateSegment) myTemplateContainer.getTemplateSegment(i);
			if (inSegment.getID().compareTo(tempSeg.getID()) == 0) {
				if (tempSeg.getOccurs() == 1)
					throw new OBOEException("Position not held by Vectorized Subsegment");
				else {
					Vector v = (Vector) container[i];
					if (v == null) {
						v = new Vector();
						container[i] = v;
					}
					v.insertElementAt(inSegment, inPosition);
				}
				return;
			}
		}
		throw new OBOEException(
			"Subsegment " + inSegment.getID() + " not defined in " + getID());
	}

	/** sets a Segment to the container at position in the array,
	 * if the Segment is part of the vectorized segment throw exception
	 * @param inSegment Segment
	 * @param inPosition int position
	 * @exception OBOEException out of range
	 *               Subsegment vectorized
	 *               Subsegment not defined at sequence
	 */

	public void setSegmentAt(Segment inSegment, int inPosition)
		throws OBOEException {
		TemplateSegment tempSeg;

		if (inPosition < 0 || inPosition > myTemplateContainer.getCount())
			throw new OBOEException("Input sequence number out of range for array");

		if (isVector(inPosition))
			throw new OBOEException("Position held by Vectorized Subsegment");

		tempSeg =
			(TemplateSegment) myTemplateContainer.getTemplateSegment(
				inPosition);
		if (tempSeg.getID().compareTo(inSegment.getID()) != 0)
			throw new OBOEException("Segment not defined at position");

		container[inPosition] = inSegment;
	}

	/** sets a Segment to the vector at a position container
	 * @param inSegment Segment
	 * @param inPosition int position in array
	 * @param inVectorPosition int position with vector at inPosition
	 * @exception OBOEException out of range
	 *               Subsegment not vectorized
	 *               Subsegment not defined at sequence
	 */

	public void setSegmentAt(
		Segment inSegment,
		int inPosition,
		int inVectorPosition)
		throws OBOEException {
		TemplateSegment tempSeg;
		if (inPosition < 0 || inPosition > myTemplateContainer.getCount())
			throw new OBOEException("Input sequence number out of range for array");

		if (isSegment(inPosition))
			throw new OBOEException("Position not held by Vectorized Subsegment");

		tempSeg =
			(TemplateSegment) myTemplateContainer.getTemplateSegment(
				inPosition);
		if (tempSeg.getID().compareTo(inSegment.getID()) != 0)
			throw new OBOEException("Segment not defined at position");

		Vector v = (Vector) container[inPosition];
		v.setElementAt(inSegment, inVectorPosition);
	}

	/** removes a Segment from the container by id, does this by setting array entry to null
	 * can be used to remove all segments with same id at a vectorized position
	 * @param inID String id
	 * @exception OBOEException unknown segment id
	 */

	public void removeSegment(String inID) throws OBOEException {
		int i;
		TemplateSegment tempSeg;
		for (i = 0; i < myTemplateContainer.getCount(); i++) {
			tempSeg =
				(TemplateSegment) myTemplateContainer.getTemplateSegment(i);
			if (tempSeg.getID().compareTo(inID) == 0) {
				container[i] = null;
				return;
			}
		}
		throw new OBOEException(
			"Subsegment " + inID + " not defined in " + getID());
	}
	/** removes a Segment from the container by its ID from the subsegment Vector
	 * @param inID String ID
	 * @param inPosition int position in array
	 * @exception OBOEException Subsegment not vectorized
	 *               unknown segment id
	 */

	public void removeSegment(String inID, int inPosition)
		throws OBOEException {
		int i;
		TemplateSegment tempSeg;
		for (i = 0; i < myTemplateContainer.getCount(); i++) {
			tempSeg =
				(TemplateSegment) myTemplateContainer.getTemplateSegment(i);
			if (tempSeg.getID().compareTo(inID) == 0) {
				if (tempSeg.getOccurs() == 1)
					throw new OBOEException("Position not held by Vectorized Subsegment");
				else {
					Vector v = (Vector) container[i];
					v.remove(inPosition);
				}
				return;
			}
		}
		throw new OBOEException(
			"Subsegment " + inID + " not defined in " + getID());
	}

	/** removes a Segment from the container at a particular position
	 * can be used to remove all segments with same id at a vectorized position
	 * @param inPosition int position in array
	 * @exception OBOEException position number out of range
	 */

	public void removeSegment(int inPosition) throws OBOEException {
		if (inPosition < 0 || inPosition > myTemplateContainer.getCount())
			throw new OBOEException("Input sequence number out of range for array");
		container[inPosition] = null;
	}

	/** removes a Segment from the container at a particular position in the subsegment Vector
	 * @param inPosition int position in array
	 * @param inVectorPosition int position in Vector at inPosition in array
	 * @exception OBOEException position number out of range
	 *               Subsegment not vectorized
	 *               Subsegment sequence not defined
	 */

	public void removeSegment(int inPosition, int inVectorPosition)
		throws OBOEException {
		if (inPosition < 0 || inPosition > myTemplateContainer.getCount())
			throw new OBOEException("Input sequence number out of range for array");

		TemplateSegment tempSeg =
			(TemplateSegment) myTemplateContainer.getTemplateSegment(
				inPosition);
		if (tempSeg.getOccurs() == 1)
			throw new OBOEException("Position not held by Vectorized Subsegment");

		Vector v = (Vector) container[inPosition];
		v.remove(inVectorPosition);

	}

	/** returns a Segment by its position
	 * @return Segment objects - will return null if segment  not defined
	 * @param inPosition int  position in array
	 * @exception OBOException "No segment at this position" - it is a Vector of segments
	 */

	public Segment getSegment(int inPosition) throws OBOEException {
		if (container[inPosition] == null)
			return null;
		if (!isSegment(inPosition))
			throw new OBOEException("No segment at this position");
		return (Segment) container[inPosition];
	}

	/** returns the Segment inside the subsegment Vector by its position
	 * @return Vector of Segment objects - null indicates segment not set
	 * @param inPosition int position in array
	 * @param inVectorPosition int position in Vector at inPosition in array
	 * @throws OBOEException bad position specified, position is negative, larger than Vector or
	 * object at position specified by first parameter is a segment.
	 */

	public Segment getSegment(int inPosition, int inVectorPosition)
		throws OBOEException {
		if (isSegment(inPosition))
			throw new OBOEException("Position not held by Vectorized Subsegment");
		if (inVectorPosition >= ((Vector) container[inPosition]).size())
			return null;

		return (Segment) ((Vector) container[inPosition]).elementAt(
			inVectorPosition);
	}
	/** returns a Segment by its ID
	 * @return Segment objects - null indicates segment not set
	 * @param ID String id of segment to get
	 * @throws OBOEException "ID is unknown to segment "
	 */

	public Segment getSegment(String ID) throws OBOEException {
		int i;
		Segment segment;
		for (i = 0; i < getContainerSize(); i++) {
			if (!isSegment(i))
				continue;
			segment = (Segment) container[i];

			if (segment.getID().compareTo(ID) == 0)
				return segment;
		}
		if (myTemplateContainer.getTemplateSegment(ID) == null)
			throw new OBOEException(
				"Segment with ID "
					+ ID
					+ " is unknown to segment container "
					+ getID());
		else
			return null;
	}
	/** returns a Segment by its ID and its position in the vector
	 * <br>You must use this method call to get to floating segments
	 * @return Segment objects - null indicates position of segment not set
	 * @param ID String id of segment to get
	 * @param inVectorPosition int position in Vector at position in array identified by id
	 * @throws OBOEException Segment with ID not within a Vector.
	 */

	public Segment getSegment(String ID, int inVectorPosition)
		throws OBOEException {
		int i;
		Segment segment;
		Vector v;
		for (i = 0; i < getContainerSize(); i++) {
			if (isSegment(i)) {
				segment = (Segment) container[i];
				if (segment.getID().compareTo(ID) == 0)
					throw new OBOEException(
						"Segment with ID " + ID + " not within a Vector.");
				else
					continue;
			}
			if (container[i] instanceof Vector) {
				v = (Vector) container[i];
				if (v.size() == 0)
					continue;
				if (v.elementAt(0) instanceof Segment) {
					segment = (Segment) v.elementAt(0);
					if (segment.getID().compareTo(ID) == 0)
						if (v.size() <= inVectorPosition)
							return null;
						else
							return (Segment) v.elementAt(inVectorPosition);
				}
			}
		}

		return null;
	}
	/** returns a Segment by its ID and its primaryIDValue
	 * <br>Written for the HIPAA package, but you may find it useful
	 * @return Segment objects - null indicates position of segment not set
	 * @param ID String id of segment to get
	 * @param primaryIDValue String - primary IDs are the values in an mandatory
	 * IDDE field value list, any value in the IDList will find this segment
	 * @throws OBOEException Segment with ID not within a Vector.
	 */

	public Segment getSegment(String ID, String primaryIDValue)
		throws OBOEException {
		int i;
		Segment segment;
	 
		for (i = 0; i < getContainerSize(); i++) {
			if (isSegment(i)) {
				segment = (Segment) container[i];
				if (segment.getID().compareTo(ID) == 0)
				  if (segment.getTemplate().canYouPrevalidate()) {
				     if (segment.getTemplate().isThisYou(primaryIDValue))
				        return segment;
				  }
				  else throw new OBOEException("Method does not work with this type of segment, this segment needs a primaryIDField");
			}
			
		}

		return null;
	}
	/** returns one of a multiple set of Segments by its ID, its primaryIDValue and its relative position with relation to its primaryIDValue
	 * <br>Written for the HIPAA package, but you may find it useful
	 * @return Segment objects - null indicates position of segment not set
	 * @param ID String id of segment to get
	 * @param primaryIDValue String - primary IDs are the values in an mandatory
	 * @param inPosition int - relative position of segment with relation to its primaryIDValue
	 * offset by 0 withing 
	 * IDDE field value list, any value in the IDList will find this segment
	 * @throws OBOEException Segment with ID not within a Vector.
	 */

	public Segment getSegment(String ID, String primaryIDValue, int inPosition)
		throws OBOEException {
		int i;
		for (i = 0; i < getContainerSize(); i++) {
			if (myTemplateContainer.isSegment(i) &&  isVector(i)) {
				TemplateSegment ts = myTemplateContainer.getTemplateSegment(i);
				if (ts.getID().compareTo(ID) != 0)
					continue;
				  if (ts.canYouPrevalidate()) {
				     if (ts.isThisYou(primaryIDValue))
				     	return this.getSegment(i, inPosition);
				  }
				  else throw new OBOEException("Method does not work with this type of segment, this segment needs a primaryIDField");
			}
		}

		return null;
	}



	/** returns a Segment by its id and the contents of a data field
	 * <br>Used for segments that repeat, useful with IDDE type fields.
	 * <br>Will NOT work for Composite DE fields.
	 * @return Segment objects - null not found
	 * @param ID String id of loop
	 * @param inSequence int DataElement sequence number relative to 1
	 * @param inValue String value to test
	 * @throws OBOEException Segment with ID not within a Vector.
	 */

	public Segment getSegmentByDataElementValue(
		String ID,
		int inSequence,
		String inValue)
		throws OBOEException {
		int i;
		Segment segment;
		Vector v;
		DataElement de;
		for (i = 0; i < getContainerSize(); i++) {
			if (isSegment(i)) {
				segment = (Segment) container[i];
				if (segment.isCompositeDE(i)) {
					return null;
				}
				if (segment.getID().compareTo(ID) == 0) {
					de = segment.getDataElement(inSequence);
					if (de == null)
						continue;
					if (de.get().compareTo(inValue) == 0)
						return segment;
				}
			}
			if (container[i] instanceof Vector) {
				v = (Vector) container[i];
				if (v.size() == 0)
					continue;
				if (v.elementAt(0) instanceof Segment) {
					segment = (Segment) v.elementAt(0);
					if (segment.isCompositeDE(i)) {
						return null;
					}
					if (segment.getID().compareTo(ID) == 0) {
						de = segment.getDataElement(inSequence);
						if (de == null)
							continue;
						if (de.get().compareTo(inValue) == 0)
							return segment;
					}
				}
			}
		}

		return null;
	}

	/** returns the number of elements in a vector position
	 * @return int a count - zero if position is not held by a vector
	 * @param inPosition int position in array
	 * @throws java.lang.ArrayOutOfBounds is possible.
	 */

	public int getSegmentCount(int inPosition) {
		if (!isVector(inPosition))
			return 0;
		return ((Vector) container[inPosition]).size();
	}

	/** returns the number of elements by id
	 * @return int
	 * @param ID String id  to count
	 * @throws OBOEException ID unknown.
	 */

	public int getSegmentCount(String ID) {
		int i;
		Segment segment;
		for (i = 0; i < getContainerSize(); i++) {
			if (isSegment(i)) {
				segment = (Segment) container[i];
				if (segment.getID().compareTo(ID) == 0)
					return 1;
				else
					continue;
			}
			if (isSegment(i,0)) {
				if (getSegment(i,0).getID().compareTo(ID) == 0)
						return getSegmentCount(i);
			}
		}
		if (myTemplateContainer.getTemplateSegment(ID) == null)
			throw new OBOEException(
				"Segment with ID "
					+ ID
					+ " is unknown to segment container "
					+ getID());
		else
			return 0;

	}


	/** returns true if object in container is a segment at requested position
	 * if false the subsegment is a vector or position specified is outside range of array
	 * @return boolean
	 * @param inPosition int position inarray
	 */
	public boolean isSegment(int inPosition) {
		if (container == null)
			return false;
		if (inPosition < 0 || inPosition >= getContainerSize())
			return false;
		if (container[inPosition] == null)
			return false;
		if (container[inPosition] instanceof Segment)
			return true;
		return false;

	}

	/** returns true if object in container is a Segment at requested position
	* if false the subSegment is a vector or position specified is outside range of array
	* @return boolean
	* @param inPosition int position inarray
	*/
	public boolean isSegment(int inPosition, int inVectorPosition) {
		if (container == null)
			return false;
		if (inPosition < 0 || inPosition >= getContainerSize())
			return false;
		if (container[inPosition] == null)
			return false;
		if (container[inPosition] instanceof Vector) {
			Vector v = (Vector) container[inPosition];
			if (inVectorPosition >= v.size())
			   return false;
			if (v.elementAt(inVectorPosition) instanceof Segment)
				return true;
			else
				return false;
		}
		return false;

	}

	/** returns true if object in container is a vector  at requested position
	 * if true the subsegment is a segment or position specified is outside range of array
	 * @return boolean
	 * @param inPosition int position in array
	 */
	public boolean isVector(int inPosition) {
		if (container == null)
			return false;
		if (inPosition < 0 || inPosition >= getContainerSize())
			return false;
		if (container[inPosition] == null)
			return false;
		if (container[inPosition] instanceof Vector)
			return true;
		return false;

	}

	/** returns true if there is no object in container at requested position
	 * @return boolean
	 * @param inPosition int position in array
	 */
	public boolean isNull(int inPosition) {
		if (container == null)
			return true;
		if (container[inPosition] == null)
			return true;
		return false;

	}
	/** creates a segment by ID
	 * @return Segment based on this Template
	 * @param id String id of subsegment to create
	 * @throws OBOEException unknown id
	 */

	public Segment createSegment(String id) throws OBOEException {
		TemplateSegment tseg = myTemplateContainer.getTemplateSegment(id);
		if (tseg == null)
		  throw new OBOEException("Segment "+id+" unknown to container.");
		Segment seg = new Segment(tseg, this);
		return seg;
	}
	/** creates a segment by ID and its primary id value
	 * <br>Written for the HIPAA package, but you may find it useful
	 * @return Segment based on this Template
	 * @param id String id of subsegment to create
	 * @param primaryIDValue String - primary IDs are the values in an mandatory
	 * IDDE field value list, any value in the IDList will create this segment
	 * @throws OBOEException unknown id
	 * @return Segment
	 */

	public Segment createSegment(String id, String primaryIDValue) throws OBOEException {
		Segment seg =
			new Segment(myTemplateContainer.getTemplateSegment(id, primaryIDValue), this);
		if (seg != null) {
			seg.useDefault();
			seg.getPrimaryIDDE().set(primaryIDValue);
		}
		else
		throw new OBOEException("Segment "+id+" with primaryIDValue of "+primaryIDValue+" unknown to container.");
		return seg;
	}

	/** removes unused Segments and return the number of subsegments in container
	 * @return int
	 */

	public int trim() {
		int i, vi;
		Segment segment;
		Vector v;
		int count = 0;
		for (i = 0; i < getContainerSize(); i++) {
			if (isSegment(i)) {
				segment = (Segment) container[i];
				if (segment.trim() > 0)
					count++;
				else
					container[i] = null;
			}
			if (container[i] instanceof Vector) {
				v = (Vector) container[i];
				if (v.size() == 0)
					continue;
				for (vi = v.size() - 1; vi > -1; vi--) {
					segment = (Segment) v.elementAt(vi);
					if (segment.trim() == 0)
						v.removeElementAt(vi);
				}
				if (v.size() == 0)
					container[i] = null;
				else
					count += v.size();
			}
		}
		return count;

	}

}
