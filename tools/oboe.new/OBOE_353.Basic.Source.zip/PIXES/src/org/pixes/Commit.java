/*
 * Copyright (C) 2006-2007 by Joseph McVerry - American Coders, Ltd.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

package org.pixes;

import java.sql.SQLException;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;


/**
 * @author Joe McVerry - American Coders, Ltd.
 *
 * executor object to do a database commit
 *
 */
public class Commit extends Executable {
	static {Util.isLog4JNotConfigured();}
	Connecter connectObject;

	/**
	 * debuggin level
	 */
	Level dbgLvl;


	/**
	 *
	 * @param line xml file line number
	 * @param dbConnectObject object working with
	 * @param parser who's in charge
	 */
	public Commit(int line, Connecter dbConnectObject, Parser parser) {
    	super(parser);

		logr = Logger.getLogger(Commit.class);
		setLogger();
		dbgLvl = prsr.logr.getLevel();
        logr.setLevel(dbgLvl);
		logr.debug("commit constructor "+line);
		connectObject = dbConnectObject;
		setMyXMLLine(line);
	}


	/**
	 * returns next step
	 * (non-Javadoc)
	 * @see org.pixes.Executable#execute()
	 */
	public int execute(Executor inExec) {
		exec.logr.setLevel(dbgLvl);    logr.setLevel(dbgLvl);
		try {
			connectObject.getConnection().commit();
		} catch (SQLException e) {

			logr.error(e.getMessage(),
					         e);
			return -1;
		}
		return getNextStep();
	}

}
