package com.americancoders.edi.EDIFact;

/**
 *OBOE - Open Business Objects for EDI
 *<P>java access to EDI
 *<p>Copyright 1998-2007 - American Coders, LTD  - Raleigh NC USA
 *<p>All rights reserved
 *<p>American Coders, Ltd
 *<br>P. O. Box 97462
 *<br>Raleigh, NC  27624  USA
 *<br>1-919-846-2014
 *<br>http://www.americancoders.com
@author Joe McVerry - American Coders, Ltd.
  @version   3.5.3
 */

import java.io.Reader;
import java.io.StringReader;

import com.americancoders.edi.DataElement;
import com.americancoders.edi.EDIDocumentParser;
import com.americancoders.edi.Envelope;
import com.americancoders.edi.EnvelopeFactory;
import com.americancoders.edi.FunctionalGroup;
import com.americancoders.edi.OBOEException;
import com.americancoders.edi.Segment;
import com.americancoders.edi.TemplateEnvelope;
import com.americancoders.edi.Tokenizer;
import com.americancoders.edi.TransactionSet;
import com.americancoders.edi.TransactionSetFactory;

/**
 * class defining methods for parsing EDI Documents
 * <br> EDIFact2 dependent
 * <br>Document handlers will register with this class to be notified
 * when specific edi objects are created or finished
 * <br>Unlike the old parser these parsers will not contain the
 * objects,  the process of adding objects to owning parents (such as
 * adding functional groups to an envelope) is left up to the document handler.
 */

public class EDIFactDocumentParser extends EDIDocumentParser {

	/**
	* parses an EDIFact Document and passes results to EDIDocumentHandlers
	*/
	public EDIFactDocumentParser() {
		super();
	}

	/** method that controls the parsing
	 *  @param inString String edi document
	 *  @exception OBOEException - most likely unknown segment
	 */
	public void parseDocument(String inString) throws OBOEException {

		int posStart = inString.indexOf("UNA");
		int posStartUNB = inString.indexOf("UNB");
		if (posStart > -1 && posStart < posStartUNB);
		else {
			posStart = posStartUNB;
			if (posStart < 0)
				throw new OBOEException("UNB (and UNA) segment missing");
		}
		int posStop = inString.indexOf("UNZ");
		if (posStop < 0)
			throw new OBOEException("UNZ segment missing");

		parseDocument(new StringReader(inString), true);
	}

	/** method that controls the parsing
	 *  @param inReader inReader reader object containing edi data
	 *  @exception OBOEException - most likely unknown segment
	 *  @deprecated use parseDocument(Reader, true)
	 */
	public void parseDocument(Reader inReader) throws OBOEException {
		parseDocument(inReader, true);
	}
		/** method that controls the parsing
		 * @param inReader inReader reader object containing edi data
		 * @param inValidate boolean - call validation logic on envelope if true
		 * <br> if false is used then don't forget to call the validation method
		 * on the envelope object pass it the documenterrors object created here
		 * and getable using the getDocumentErrors method.
		 * 
		 *  @exception OBOEException - most likely unknown segment
		 */
		
		public void parseDocument(Reader inReader, boolean inValidate) throws OBOEException {
		TransactionSet parsedTransactionSet = null;
		EDIFactEnvelope envelope = new EDIFactEnvelope();

		try {
			TemplateEnvelope te = EnvelopeFactory.buildEnvelope("EDIFact.envelope","notSetYet");
			envelope = new EDIFactEnvelope(te);
		} catch (OBOEException oe) {
			if (oe.getMessage().startsWith("File not found"))
				envelope = new EDIFactEnvelope();
			else
				throw oe;
		}

		notifyStartEnvelope(envelope);

		Tokenizer et = new EDIFactTokenizer(inReader,  dErr);
		// , posStop-1));
		envelope.setDelimiters(et.getSeparators());

		et.getNextSegment(null);
		String findID = et.getNextDataElement();
		if (findID.startsWith("UNA")) {
			Segment UNA_Service_String = envelope.createService_String();
			UNA_Service_String.setByteOffsetPositionInIncomingDocument(et.getInputByteCount());
			notifyStartSegment(UNA_Service_String);
			UNA_Service_String.getDataElement(1).set(et.getRestOfSegment());
			notifyEndSegment(UNA_Service_String);
			//UNA_Service_String.parse(et);
			et.getNextSegment(null);

			findID = et.getNextDataElement();
		}

		if (findID.compareTo(EDIFactEnvelope.idInterchangeHeader) != 0)
			throw new OBOEException(
				"Segment ID "
					+ findID
					+ " found, was expecting "
					+ EDIFactEnvelope.idInterchangeHeader
					+ ".");
		Segment UNB_Interchange_Header = envelope.createInterchange_Header();
		UNB_Interchange_Header.setByteOffsetPositionInIncomingDocument(et.getInputByteCount());
		notifyStartSegment(UNB_Interchange_Header);
		UNB_Interchange_Header.parse(et);
		notifyEndSegment(UNB_Interchange_Header);

		findID = et.getCurrentDataElement();
		boolean iterateOnce = (findID.compareTo(EDIFactFunctionalGroup.idHeader) != 0);
		if (iterateOnce)
			findID = EDIFactFunctionalGroup.idHeader;

		while (findID != null && findID.compareTo(EDIFactFunctionalGroup.idHeader) == 0) {
			FunctionalGroup fg = envelope.createFunctionalGroup();
			notifyStartFunctionalGroup(fg);
			if (iterateOnce);
			else {
				Segment UNG_Functional_Group_Header =
					fg.createSegment(EDIFactFunctionalGroup.idHeader);
				UNG_Functional_Group_Header.setByteOffsetPositionInIncomingDocument(et.getInputByteCount());
				notifyStartSegment(UNG_Functional_Group_Header);
				UNG_Functional_Group_Header.parse(et);
				notifyEndSegment(UNG_Functional_Group_Header);
			}
			findID = et.getCurrentDataElement();

			while (findID != null && findID.compareTo("UNH") == 0) {
				Segment UNH_Message_Header = Message_Header.getInstance();
				UNH_Message_Header.setByteOffsetPositionInIncomingDocument(et.getInputByteCount());
				UNH_Message_Header.parse(et);

				findID = UNH_Message_Header.getCompositeDE("S009").getDataElement("0065").get();
				
				String testProduction = "";
				DataElement tde =UNB_Interchange_Header.getDataElement("0035");  // do this becuase 0035 is not required
				if (tde != null)
					testProduction = tde.get();

				parsedTransactionSet = TransactionSetFactory.buildTransactionSet(findID, null,
					// use OBOE.properties searchDirective
						UNH_Message_Header.getCompositeDE("S009").getDataElement("0052").get()
						+ UNH_Message_Header.getCompositeDE("S009").getDataElement("0054").get(),	// version
						UNB_Interchange_Header.getCompositeDE("S003").getDataElement("0010").get(),// receiver
						UNB_Interchange_Header.getCompositeDE("S002").getDataElement("0004").get(),// sender
						testProduction); // test/production
				
				UNH_Message_Header.setParent(parsedTransactionSet);

				notifyStartTransactionSet(parsedTransactionSet);
				parsedTransactionSet.setFormat(Envelope.EDIFACT_FORMAT);
				parsedTransactionSet.setParent(fg);

				parsedTransactionSet.getHeaderTable().addSegment(UNH_Message_Header);

				parsedTransactionSet.parse(et);
				findID = et.getCurrentDataElement();

				while (findID != null && findID.compareTo("UNH") == 0) {
					findID = et.getCurrentDataElement();
					if (findID.compareTo("UNH") == 0) {
						notifyEndTransactionSet(parsedTransactionSet);
						break;
					}
					else if (findID.compareTo(EDIFactFunctionalGroup.idHeader) == 0) {
						notifyEndTransactionSet(parsedTransactionSet);
						break;
					} else if (findID.compareTo(EDIFactFunctionalGroup.idTrailer) == 0) {
						notifyEndTransactionSet(parsedTransactionSet);
						if (iterateOnce) // if iterate once then there was no fg header.
							et.reportError(
								EDIFactFunctionalGroup.idHeader
									+ " appears without "
									+ EDIFactFunctionalGroup.idTrailer);
						break;
					} else if (findID.compareTo(EDIFactEnvelope.idInterchangeTrailer) == 0) {
						if (!iterateOnce)
							et.reportError("Should not appear before end of functional group");
						notifyEndTransactionSet(parsedTransactionSet);
						break;
					} else if (findID.length() > 0) {
						et.reportError("Unknown or out of place segment ("+findID+") byte offset ("+et.getInputByteCount()+")", "2");
						// here is where we put logic to try and get back into sync.
						et.getNextSegment(et.getLastSegmentContainer());
						et.getNextDataElement();
						parsedTransactionSet.continueParse(et.getLastSegmentContainer(), et);
					} else {
						et.reportError("Empty Data Line Error", "?");
						// here is where we put logic to try and get back into sync.
						et.getNextSegment(et.getLastSegmentContainer());
						et.getNextDataElement();
						parsedTransactionSet.continueParse(et.getLastSegmentContainer(), et);
					}
				}
			}

			if (iterateOnce)
			{
				notifyEndTransactionSet(parsedTransactionSet);
				notifyEndFunctionalGroup(fg);
			}
			else if (findID.compareTo(EDIFactFunctionalGroup.idTrailer) != 0) {
				dErr.addError(0,EDIFactFunctionalGroup.idTrailer,"More segments to process starting at segment position "
				+ et.getSegmentPos()
				+ ". Problem "
				+ et.getCurrentDataElement()
				+ " is not defined. Expecting "
				+ EDIFactFunctionalGroup.idTrailer,envelope,"0",null,1);
/*
				throw new OBOEException(
					"More segments to process starting at position "
						+ et.getSegmentPos()
						+ ". Problem "
						+ et.getCurrentDataElement()
						+ " is not defined. Expecting "
						+ EDIFactFunctionalGroup.idTrailer); */
			} else {
				Segment UNE_Functional_Group_Trailer =
					fg.createSegment(EDIFactFunctionalGroup.idTrailer);
				UNE_Functional_Group_Trailer.setByteOffsetPositionInIncomingDocument(et.getInputByteCount());
				notifyStartSegment(UNE_Functional_Group_Trailer);

				UNE_Functional_Group_Trailer.parse(et);
				notifyEndSegment(UNE_Functional_Group_Trailer);
				notifyEndFunctionalGroup(fg);
				findID = et.getCurrentDataElement();
			}
			
		}

		if (findID == null) {
			et.reportError("Envelope ended too soon", "2");
		} else

		if (findID.compareTo(EDIFactEnvelope.idInterchangeTrailer) != 0) {
			dErr.addError(0,EDIFactEnvelope.idInterchangeTrailer,"More segments to process starting at segment position "
			+ et.getSegmentPos()
			+ ". Problem "
			+ et.getCurrentDataElement()
			+ " is not defined. Expecting "
			+ EDIFactEnvelope.idInterchangeTrailer,envelope,"0",null,1);
			/*throw new OBOEException(dErr);
			throw new OBOEException(
				"More segments to process starting at segment position "
					+ et.getSegmentPos()
					+ ". Problem "
					+ et.getCurrentDataElement()
					+ " is not defined. Expecting "
					+ EDIFactEnvelope.idInterchangeTrailer);*/
		} else {
			Segment UNZ_Interchange_Trailer = envelope.createInterchange_Trailer();
			UNZ_Interchange_Trailer.setByteOffsetPositionInIncomingDocument(et.getInputByteCount());
			notifyStartSegment(UNZ_Interchange_Trailer);
			UNZ_Interchange_Trailer.parse(et);
			notifyEndSegment(UNZ_Interchange_Trailer);
            notifyEndEnvelope(envelope);

		}

		if (inValidate)
			envelope.validate(dErr);

		if (com.americancoders.util.Util.propertyFileIndicatesThrowParsingException()
			&& dErr.getErrorCount() > 0) {
			dErr.logErrors();
			throw new OBOEException(dErr);
			}

	}

}
