package com.americancoders.edi;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.lang.reflect.Method;

import org.apache.log4j.Logger;

import com.americancoders.util.Util;



/**
 * class for Template Data Elements
 * <br> template de's are dynamic definitions for de's
 *<p>OBOE - Open Business Objects for EDI
 *<p>Part of the OBOE Basic Extended Package
 *<br>An EDI and XML Translator Written In Java
 *<br>Copyright 1998-2007 - American Coders, LTD  - Raleigh NC USA
 *<br>All rights reserved
 *<br>American Coders, Ltd
 *<br>P. O. Box 97462
 *<br>Raleigh, NC  27624  USA
 *<br>1-919-846-2014
 *<br>http://www.americancoders.com
@author Joe McVerry - American Coders, Ltd.
  @version   3.5.3
 *
 */

public class TemplateDE implements
                                Externalizable,
                                IContainedObject
{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/** templatede are not sub classed so store their type here
     */
    protected  String type = "";
    /** sequence within segment or composite
     */
    protected  int sequence;
    /** element id
     */
    protected  String id = "";
    /** element name
     */
    protected  String name = "";
    /** required indictor
     */
    protected  char required = ' ';
    /** referenceid as defined by standard
     */
    protected  String referenceId = "";
    /** minimum and maximum lengths allowed
     */
    protected  int minLength, maxLength;
    /** description
     */
    protected  String description;
    /** xml tag
     */
    protected  String xmlTag;
    /** id list if available
     */
    private IDListProcessor idList=null;

	/**
	   occurs some many times */
	 protected int occurs = 1;

    
    /** returns used attribute
     * @return boolean
     */
 	public boolean isUsed() {
 		return used;
 	}
     /** sets used attribute
 	    * @param used boolean used indicator
 	    */
 	
 	public void setUsed(boolean used) {
		this.used = used;
	}
    protected boolean used = true;

    
    static Logger logr = Logger.getLogger(TemplateDE.class);
	static 	{Util.isLog4JNotConfigured();}

    /**
     * constructs the Data Element type used for serialization
     */

public TemplateDE() {}
    /** constructs the Data Element type
     * @param inID String id
     * @param inName String name
     * @param inSequence int sequence within seg or comp
     * @param inType String de type
     * @param inRequired char required indicator
     * @param inDesc String description
     * @param inMinLength int mimimum length
     * @param inMaxLength int maximum length
     * @param inXMLTag String XML tag
     * @param inIDList IDListProcessor if available
     * @param inParent owning Object
     * @param inOccurs int
     * @param inUsed boolean
     */
    public TemplateDE(String inID, String inName, int inSequence, String inType, char inRequired, String inDesc, int inMinLength, int inMaxLength, String inXMLTag, IDListProcessor inIDList, IContainedObject inParent, int inOccurs, boolean inUsed)
    {
    	
        setID(inID);
        setName(inName);
        setSequence(inSequence);
        setType(inType);
        setRequired(inRequired);
        setDescription(inDesc);
        setMinLength(inMinLength);
        setMaxLength(inMaxLength);
        setXMLTag(inXMLTag);
        setIDList(inIDList);
        setParent(inParent);
        setOccurs(inOccurs);
        setUsed(inUsed);
    }


    /**
     * sets the Data Element type
     * @param inType String
     *
     */
public void setType(String inType) { type = inType; }


    /**
     * gets the Data Element type
     * @return String
     *
     */
public String getType() { return type; }

    /** sets the Data Element required
     * @param inRequired char required indicator
     */
public void setRequired(char inRequired) { required = inRequired; }


    /**
     * gets the Data Element required
     * @return char
     *
     */
public char getRequired() { return required; }

    /** sets the Data Element id
     * @param inID String id
     */
public void setID(String inID) { id = inID; }

    /**
     * gets the Data Element id
     * @return String
     *
     */
public String getID() { return id; }

    /** sets the Data Element name
     * @param inname String name
     */
public void setName(String inname) { name = inname; }


    /**
     * gets the Data Element name
     * @return String
     *
     */
public String getName() { return name; }

    /** sets the Data Element sequence
     * @param inSequence int sequence within seg or comp
     * @exception - invalid sequence - # < 1
     */
public void setSequence(int inSequence)
    throws OBOEException
   {if (inSequence < 1)
      throw new OBOEException("Invalid sequence specified for " + getID());
    sequence = inSequence;
    }

    /**
     * gets the Data Element sequence
     * @return int
     *
     */
public int getSequence()
   { return sequence; }

    /** sets the minimum length for the Data Element
     * @param inMinLength int min length
     */
public void setMinLength(int inMinLength) { minLength = inMinLength; }
    /** sets the maximum length for the Data Element
     * @param inMaxLength int max length
     */
public void setMaxLength(int inMaxLength) { maxLength = inMaxLength;  }
    /**
     * gets the minimum length for the Data Element
     * @return int
     *
     */
public int getMinLength() { return minLength; }


    /**
     * gets the maximum length for the Data Element
     * @return int
     *
     */
public int getMaxLength() { return maxLength;  }


    /** sets Description for the Data Element
     * @param inDesc String description
     */
public void setDescription(String inDesc) {description = inDesc;}

    /**
     * returns the Description for the Data Element
     * @return String
     */
public String getDescription() {return description;}

    /** sets the xml tag field
     * @param inXMLTag String XML Tag
     */

    public void  setXMLTag(String inXMLTag)
    {
        xmlTag = inXMLTag;
    }

    /**
     * returns the xml tag field
     * @return String tag value
     */


    public String getXMLTag()
    {
        if (xmlTag == null) return getID();
        return xmlTag;
    }



    /** sets the idList Object
     * @param inIdList IDListProcessor object
     */

    public void setIDList(IDListProcessor inIdList){ idList=inIdList; }


    /** gets the idListProcessor Object
     *  @return IDListProcessor
     */
    public IDListProcessor getIDList() { return idList; }


    protected IContainedObject  parent;

    /** sets parent attribute
     * @param inParent TemplateSegmentContainer
     */
    public void setParent(IContainedObject inParent) {parent = inParent;}

    /** gets parent attribute
     * @return TemplateSegmentContainer
     */
    public IContainedObject  getParent() { return parent;}
	/**
	 * sets the occurs value
	 * @param inOccurs
	 */
	public void setOccurs(int inOccurs) { occurs = inOccurs; }

	/**
	 * gets the occurs value
	 * @return int
	 */
	public int  getOccurs() { return occurs; }


    /** used by externalize methods
     * @param in ObjectInput stream
     * @exception IOException - most likely class changed since written
     * @exception ClassNotFoundException - only when dummy constructro not found
     */
    public void readExternal(ObjectInput in)
    throws IOException, ClassNotFoundException
    {
        type = in.readUTF();
        sequence = in.readInt();
        id = in.readUTF();
        name = in.readUTF();
        required = in.readChar();
        referenceId = in.readUTF();
        minLength = in.readInt();
        maxLength = in.readInt();
        description = in.readUTF();
        xmlTag = in.readUTF();
        used = in.readBoolean();
        idList = (IDListProcessor) in.readObject();
    }

    /** used by externalize methods
     * @param out ObjectOutput Stream
     * @exception IOException java.io error
     */
    public void writeExternal(ObjectOutput out)
    throws IOException
    {
        out.writeUTF(type);
        out.writeInt(sequence);
        out.writeUTF(id);
        out.writeUTF(name);
        out.writeChar(required);
        out.writeUTF(referenceId);
        out.writeInt(minLength);
        out.writeInt(maxLength);
        out.writeUTF(description);
        out.writeUTF(xmlTag);
        out.writeBoolean(used);
        out.writeObject(idList);
     }


    /** returns error responses of contents
     * @param inText String text
     * @return String
     */
    public String validate(String inText)
    {
       String testText="";

        if (inText != null)
            testText = inText;//;.trim();

        if (isUsed() == false)
        {
        	if (inText != null || testText.length() > 0)
        		return "field at position "+getSequence()+" id="+getID() + " data element is not used.";
        }

        if (getRequired() == 'M'){
            if (inText == null || testText.length() == 0)
            return "field at position "+getSequence()+" id="+getID() + " value required.";
        }
        else // not required
        if (inText == null || testText.length() == 0)
            return null;

        if (inText.length() < getMinLength())
          return "field at position "+getSequence()+" id="+getID() + " field value too short.";
        
        if (getType().compareTo("DT") == 0
        &&  getMaxLength() == 6 
		&&  testText.length() == 8)
        	; // let's not do this here       
        else
        if (testText.length() > getMaxLength())
          return "field at position "+getSequence()+" id="+getID() + " field value too long.";

        for (int i = 0; i < testText.length(); i++)
         {char ch = testText.charAt(i);
          if ( (ch >= 'A' && ch <= 'Z') ||
             (ch >= '0' && ch <= '9') ||
              ch == '!' ||
              ch =='"' ||
              ch == '&' ||
              ch == '\'' ||
              ch == '(' ||
              ch == ')' ||
              ch == '*' ||
              ch == '+' ||
              ch == '�' ||
              ch == '-' ||
              ch == '.' ||
              ch == '/' ||
              ch == ':' ||
              ch == ';' ||
              ch == '?' ||
              ch == '=' ||
              ch == ' ' ||
             (ch >= 'a' && ch <= 'z') ||
              ch == '%' ||
              ch == '~' ||
              ch == '@' ||
              ch == '[' ||
              ch == ']' ||
              ch == '_' ||
              ch == '{' ||
              ch == '}' ||
              ch == '\\' ||
              ch == '|' ||
              ch == '<' ||
              ch == '>' ||
              ch == '#' ||
              ch == '$')
            ;
         else
           return "field at position "+getSequence()+" id="+getID() + " invalid character.";
         }

        return null;
     }



/**
 * gets the default value for a data element
 * <br>not part of Basic edition
  @return String value as ste
  */
    public String getDefault()
      {
        return null;
      }

    public String getEmptyData()
     {
        char cArray[] = new char[getMaxLength()];
        for (int i = 0; i < getMaxLength(); i++)
          cArray[i] = '\0';
        return new String(cArray);
     }

   
   /* (non-Javadoc)
    * @see com.americancoders.edi.IContainedObject#getDelimiter(char)
    */

   	public char getDelimiter(char inOriginal) {
   		
   		return parent.getDelimiter(inOriginal);
   	}

}

