/*
 * Copyright (C) 2006-2007 by Joseph McVerry - American Coders, Ltd.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

package org.pixes;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;

/*
 * Created on Apr 28, 2005
 *
 * Logic for atend processing - used by looping tags
 * <br> tracks some looping tag, logic asks that 
 * tag if it's at the end of its process.  if it is then this process
 * skips to the appropriate place in the processing steps.
 *
 */

public class AtEndLogic extends Executable {

/** debug level */
    Level dbgLvl;
/** object to work with */
    IContinuable testObject;
/** step out line */
    int outsideStep;

    /**
     * @param line - int line number
     * @param parser - Parser
     * @param inTestObject - IEndTestable
     *
     */
    public AtEndLogic(int line, Parser parser, IContinuable inTestObject) {
    	super(parser);
 	    logr = Logger.getLogger(AtEndLogic.class);
 	    setLogger(); 	   
        dbgLvl = prsr.logr.getLevel();
        logr.setLevel(dbgLvl);
        logr.debug("atEnd constructor " +line);
        setMyXMLLine(line);

        testObject = inTestObject;

    }

    /**
     * sets line number to step out.
     * @param inStep the line(step) number to step out at.
     */
    public void setOutsideStep(int inStep) {
        outsideStep = inStep;
    }

    public int execute(Executor inExec) {
        prsr.logr.setLevel(dbgLvl);
        logr.setLevel(dbgLvl);

         return outsideStep;

    }

 }
