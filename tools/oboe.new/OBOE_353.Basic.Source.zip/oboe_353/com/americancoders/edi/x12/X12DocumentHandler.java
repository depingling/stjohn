package com.americancoders.edi.x12;

/**
 *OBOE - Open Business Objects for EDI
 *<P>java access to EDI
 *<p>Copyright 1998-2007 - American Coders, LTD  - Raleigh NC USA
 *<p>All rights reserved
 *<p>American Coders, Ltd
 *<br>P. O. Box 97462
 *<br>Raleigh, NC  27624  USA
 *<br>1-919-846-2014
 *<br>http://www.americancoders.com
@author Joe McVerry - American Coders, Ltd.
  @version   3.5.3
 */


import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.PrintWriter;
import java.io.Reader;

import org.apache.log4j.Logger;

import com.americancoders.edi.DocumentErrors;
import com.americancoders.edi.EDIDocumentHandler;
import com.americancoders.edi.Envelope;
import com.americancoders.edi.FunctionalGroup;
import com.americancoders.edi.IContainedObject;
import com.americancoders.edi.OBOEException;
import com.americancoders.edi.Segment;
import com.americancoders.edi.TransactionSet;
import com.americancoders.util.Util;

/**
 * class to parse input string for all defined OBOE Transaction Sets
 * <br> x12 dependent
 *
 */

public class X12DocumentHandler implements EDIDocumentHandler {
	X12DocumentParser parser;
	X12Envelope envelope = null;
	FunctionalGroup functionalGroup = null;

	static Logger logr = Logger.getLogger(X12DocumentHandler.class);
	static 	{		Util.isLog4JNotConfigured();	}


	/**
	 * create a parser for transaction set and parser what is coming from Reader object
	 */

	public X12DocumentHandler() {
		parser = new X12DocumentParser();
		parser.registerHandler(this);
	}

	/**
	 * create a parser for transaction set and parser what is coming from Reader object
	 * <br>if you use this constructor and there are document errors the method
	 * will not make the envelope object available
	 * @param inReader the edi document in a java io reader object
	 * @exception OBOEException
	 *                      - unknown transaction set, this transaction set is undefined to OBOE
	 *                      - parsing erros
	 */

	public X12DocumentHandler(Reader inReader) throws OBOEException {
		parser = new X12DocumentParser();
		parser.registerHandler(this);
		parser.parseDocument(inReader, false);
		envelope.validate(parser.getDocumentErrors());
	}
	/**
	 * create a parser for transaction set and parser what is coming from Reader object
	 * <br>if you use this constructor and there are document errors the method
	 * will not make the envelope object available
	 * @param inString filename to parse
	 * @exception OBOEException
	 *                      - unknown transaction set, this transaction set is undefined to OBOE
	 *                      - parsing erros
	 */

	public X12DocumentHandler(String inString) throws OBOEException {
		try {
		    
		    parser = new X12DocumentParser();
		    
		    parser.registerHandler(this);
		    
		    startParsing(new FileReader(inString));
		    
		    envelope.validate(parser.getDocumentErrors());
        } catch (OBOEException e) {
            
            logr.error(e.getMessage(), e);
        } catch (FileNotFoundException e) {
            //  catch block Sep 9, 2005
            logr.error(e.getMessage(), e);
        }
	}

	/** starts the parser with the passed Reader object
	 *
	 * @param inReader the edi document in a java io reader object
	 * @exception OBOEException
	 *                      - unknown transaction set, this transaction set is undefined to OBOE
	 *                      - parsing erros
	 */

	public void startParsing(Reader inReader) throws OBOEException {
	    
		parser.parseDocument(inReader, false);
	    
		envelope.validate(parser.getDocumentErrors());
	}

	/** called when an Envelope object is created
	 * @param inEnv Envelope found
	 */
	public void startEnvelope(Envelope inEnv) {
		envelope = (X12Envelope) inEnv;
	}

	/** called when an FunctionalGroup object is created
	 * @param inFG FunctionalGroup found
	 */
	public void startFunctionalGroup(FunctionalGroup inFG) {
		functionalGroup = inFG;
		envelope.addFunctionalGroup(inFG);
	}

	/** called when an TransactionSet object is created
	 * @param inTS TransactionSet found
	 */
	public void startTransactionSet(TransactionSet inTS) {
		functionalGroup.addTransactionSet(inTS);
	}

	/** called when an Segment object is created
	 * <br>only called for segments at the Envelope and functionalGroup level
	 * does not get called for segments within TransactionSet
	 * @param inSeg  Segment found
	 */
	public void startSegment(Segment inSeg) {

		
		
		if (inSeg.getID().compareTo(X12Envelope.idInterchangeHeader) == 0)
			envelope.addSegment(inSeg);
		else if (
			inSeg.getID().compareTo(X12Envelope.idInterchangeTrailer) == 0)
			envelope.addSegment(inSeg);
		else if (
			inSeg.getID().compareTo(X12Envelope.idGradeofServiceRequest) == 0)
			envelope.addSegment(inSeg);
		else if (
			inSeg.getID().compareTo(X12Envelope.idDeferredDeliveryRequest)
				== 0)
			envelope.addSegment(inSeg);
		else if (
			inSeg.getID().compareTo(X12Envelope.idInterchangeAcknowledgment)
				== 0)
			envelope.addSegment(inSeg);
		else if (inSeg.getID().compareTo(X12FunctionalGroup.idHeader) == 0)
			functionalGroup.addSegment(inSeg);
		else if (inSeg.getID().compareTo(X12FunctionalGroup.idTrailer) == 0)
			functionalGroup.addSegment(inSeg);

	}

	/** called when an Evelope is finished
	 * @param inEnv envelope found
	 */
	public void endEnvelope(Envelope inEnv) {
		envelope = (X12Envelope) inEnv;
	}

	/** called when an FunctionalGroup object is finished
	 * @param inFG FunctionalGroup found
	 */
	public void endFunctionalGroup(FunctionalGroup inFG) {
		;
	}

	/** called when an TransactionSet object is finished
	 * @param inTS TransactionSet found
	 */
	public void endTransactionSet(TransactionSet inTS) {
		;
	}

	/** called when an Segment object is finished
	 * <br>only called for segments at the Envelope and functionalGroup level
	 * does not get called for segments within TransactionSet
	 * @param inSeg  Segment found
	 */
	public void endSegment(Segment inSeg) {
		;
	}

	/**
	 * returns the envelope that was parsed
	 * @return Envelope - the envelope when object was built.
	 */
	public Envelope getEnvelope() {
		return envelope;
	}

	/**
	 * main to test in application mode
	 * args[0] String - an input file name - contains an X12 message
	 * args[1] String - optional integer value for output format 
	 * 	 XML_FORMAT = 1;
	 * 	 X12_FORMAT = 2;
	 * 	 EDIFACT_FORMAT = 3 not logical
	 * 	 VALID_XML_FORMAT = 4;
	 * 	 CSV_FORMAT = 5;
	 * 	 FIXED_LENGTH_FORMAT = 6;
	 * 	 TRADACOMS_FORMAT = 7 not logical
	 * 	 VALID_XML_FORMAT_WITH_POSITION = 8;
	 * 	 ACH_FORMAT = 9 not logical
	 * 	 ACH_FORMAT_FOR_CBR_PBR = 10 not logical
	 * 	 PIXES_FORMAT = 11
	 * file must contain an x12 edi document
	 */

	public static void main(String args[]) {
		
		
		
		try {
			FileReader fr = new FileReader(args[0]);
			X12DocumentHandler dh = new X12DocumentHandler();
			dh.startParsing(fr);

			fr.close();
			Envelope env = dh.getEnvelope();
			//TransactionSet ts = env.getFunctionalGroup(0).getTransactionSet(0);
			
			env.writeFormattedText(new PrintWriter(System.out), Envelope.VALID_XML_FORMAT);

		} catch (OBOEException oe1) {
			if (oe1.getDocumentErrors() == null)
				oe1.printStackTrace();
			else 
				oe1.getDocumentErrors().logErrors();
						
		} catch (Exception e1) {
			e1.printStackTrace();
		}
	}



static void goUp(IContainedObject inICO, StringBuffer inSB)
{
	inSB.append(" in " + inICO.getID());
	if (inICO.getParent() != null)
		goUp(inICO.getParent(), inSB);
	
}

public DocumentErrors getDocumentErrors() {
	
	return parser.getDocumentErrors();
}

public X12DocumentParser getParser() {
	return parser;
}


}
