/**
 * Created on 18 dec. 2005
 * @author p.mouawad@ubik-ingenierie.com
 * Copyright Ubik-Ingenierie 2005
 * Duplication is subject to law suites
 * suggest.js
 */
Salto.suggestNext = function(src, node) 
{
	try
	{
		src.updateChoices(node.firstChild.data);
	}
	catch(e)
	{
		alert('suggest.js:Salto.suggestNext():Error '+e.toString());
		throw e;
	}
}

/**
 * Autocomplete integrated with the framework
 */
Salto.Autocompleter = Class.create();
Object.extend(Object.extend(Salto.Autocompleter.prototype, Autocompleter.Base.prototype), {
	initialize: function(element, update, url, options) 
	{
		this.baseInitialize(element, update, options);
		this.options.asynchronous  = true;
		this.options.onComplete    = this.onComplete.bind(this);
		this.options.defaultParams = this.options.parameters || null;
		this.url                   = url;
	},
	getUpdatedChoices: function() 
	{
  		entry = encodeURIComponent(this.options.paramName) + '=' + 
  			encodeURIComponent(this.getToken());
  		this.options.parameters = this.options.callback ?
  			this.options.callback(this.element, entry) : entry;
		if(this.options.defaultParams) 
		{
			this.options.parameters += '&' + this.options.defaultParams;
		}
		AjaxCall(this.url, this, this.options.parameters,true);    
	},
	onComplete: function(request) {
  		;
	}
});

