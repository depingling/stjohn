package com.americancoders.edi.x12;

import java.io.IOException;
import java.io.PushbackReader;
import java.io.Reader;

import org.apache.log4j.Logger;


import com.americancoders.edi.DocumentErrors;
import com.americancoders.edi.ITokenizer;
import com.americancoders.edi.OBOEException;
import com.americancoders.edi.ReaderTokenizer;
import com.americancoders.edi.Tokenizer;
import com.americancoders.util.Util;

/**
 *  class to assist in tokenizing input transaction sets
 *  <br>  x12 field seperator uses 3rd byte of input string
 *  <br>  x12 segment separator uses 16th field + 1 byte field, if it sees a cr character then checks for a lf character and then assumes a \\n character
 *  <br>  EDIFact uses different control positions.  see header segment.
 *<p>OBOE - Open Business Objects for EDI
 *<p>Part of the OBOE Basic Extended Package
 *<br>An EDI and XML Translator Written In Java
 *<br>Copyright 1998-2007 - American Coders, LTD  - Raleigh NC USA
 *<br>All rights reserved
 *<br>American Coders, Ltd
 *<br>P. O. Box 97462
 *<br>Raleigh, NC  27624  USA
 *<br>1-919-846-2014
 *<br>http://www.americancoders.com
@author Joe McVerry - American Coders, Ltd.
  @version   3.5.3
 */

public class X12Tokenizer extends Tokenizer implements ITokenizer {

	/** log4j object */
    static Logger logr = Logger.getLogger(X12Tokenizer.class);
	static 	{Util.isLog4JNotConfigured();}

	/** builds the parsing object for a transaction set
	 * @param inReader what's to be tokenized
	 * @param inDErr DocumentError
	 * @throws OBOEException invalid token most likely
	 */
	public X12Tokenizer(Reader inReader,  DocumentErrors inDErr)
		throws OBOEException {
		
		super(inDErr);
		
		int i;
		StringBuffer versionBuffer = new StringBuffer();
		
			PushbackReader pbr = new PushbackReader(inReader, 107);
			char firstSeg[] = new char[107];
			try {
				if (pbr.read(firstSeg, 0, 107) != 107)
					throw new OBOEException("expected data not read");
				pbr.unread(firstSeg);
			} catch (IOException ioe) {
				ioe.printStackTrace();
				throw new OBOEException(ioe.getMessage());
			}

			int tokencnt = 0;
			boolean saveVersion = false;

			for (i = 0; i < 107; i++) {
				if (firstSeg[i] == firstSeg[3]) {
					tokencnt++;
					if (tokencnt == 11){
						if (firstSeg[i+1] != 'U') // hmmmm.... maybe it indicates the repeater separater for post 4010
						  {
						   repeatChar = firstSeg[i+1];
						   //System.err.println("Found repeating character " + repeatChar);
						  }
					}
					if (tokencnt == 12)	{
						saveVersion = true;
						continue;
					}
					
					if (tokencnt == 13)  saveVersion=false;
					if (tokencnt == 16) {
						if (i > 103) {
							if (inDErr != null)
								inDErr.addError(0,"Envelope",
									"ISA segment too long, unable to continue",
									null,	"E", null, 1);
							logr.error("ISA segment too long, unable to to continue");
							throw new OBOEException("ISA segment too long, unable to to continue");
						}
						if (i < 103) {
							if (inDErr != null)
								inDErr.addError(0,"Envelope","ISA segment too short, attempting to continue",
									null, "E",	null, 1);
							logr.error("ISA segment too short, attempting to continue");
						}

						if ((firstSeg[i + 1] == 10)
							|| (firstSeg[i + 1] == 13)
							|| (firstSeg[i + 1] == '\n'))
							if (inDErr != null)
								inDErr.addError(0,"Envelope","ISA segment in error, missing component element separator",
									null,	"E",  null, 1);
							else
								throw new OBOEException("ISA segment in error, missing component element separator");

						tokenGroups[0] = firstSeg[i + 1];
						tokenSeperatorCharacter = firstSeg[i + 2] + "";

						if (((firstSeg[i + 2] == 10) && (firstSeg[i + 3] == 13))
							|| ((firstSeg[i + 2] == 13) && (firstSeg[i + 3] == 10)))
							tokenSeperatorCharacter = "\n";

						separators.append(tokenSeperatorCharacter);
						separators.append(firstSeg[3]);
						separators.append(tokenGroups[0]);
						if (repeatChar != 0)
							separators.append(repeatChar);

						break;
					}

				}
				if (saveVersion == true)
					versionBuffer.append(firstSeg[i]);
			}

			if (tokencnt != 16)
				throw new OBOEException("ISA Segment incorrect format, cannot continue");

			/*
			tokenGroups[0] = firstSeg[104];
			tokenSeperatorCharacter = firstSeg[105]+"";
			*/

			//transactionSetTokenizer = new DataTokenizer(str, tokenSeperatorCharacter, escapeCharacters);
			transactionSetTokenizer =
				new ReaderTokenizer(pbr, tokenSeperatorCharacter, escapeCharacters);

			tokenSeperatorCharacter = firstSeg[3] + "";

			if (((firstSeg[i + 2] == 10) && (firstSeg[i + 3] == 13))
				|| ((firstSeg[i + 2] == 13) && (firstSeg[i + 3] == 10)))
				 ((ReaderTokenizer) transactionSetTokenizer).setSkipChar(firstSeg[i + 2]);

			dataElementReady = false;
	}
}
