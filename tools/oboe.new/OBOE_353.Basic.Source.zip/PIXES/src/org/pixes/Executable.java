/*
 * Copyright (C) 2006-2007 by Joseph McVerry - American Coders, Ltd.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

package org.pixes;

import org.apache.log4j.Logger;
import org.pixes.debugger.DebugListener;


/**
 * @author Joe McVerry - American Coders, Ltd.
 *
 * abstract class for all executor objects
 *
 */
public abstract class Executable implements IExecutable {

    Logger logr;


	/**
	 * the xml file line number for this tag
	 *
	 */
	private int myXMLLine = -1;
	/**
	 * the next step to execute
	 */
	private int nextStep = -1;

	/**
	 * go somewhere else if there is an error
	 */
	private int errorStep = -1;


	/** parser */
    Parser prsr;
	/** executeor */
    Executor exec;

    public void setExecutor(Executor inExec) 
    {
    	exec = inExec;
    }
    public Executable(Parser inParser)
    {
      prsr = inParser;

    }

    public void setLogger() {
    	if (getDebugListener() != null)
    		logr.addAppender(getDebugListener().getAppender());
    }

	/**
	 * return the line number
	 * @return int line number
	 */
	public int getMyXMLLine() {
		return myXMLLine;
	}

	/**
	 * sets the line number
	 * @param myXMLLine the xml file line number
	 */
	public void setMyXMLLine(int myXMLLine) {
		this.myXMLLine = myXMLLine;
	}



	/** (non-Javadoc)
	 * @see org.pixes.edi.IExecutor#execute()
	 */
	public int execute(Executor inExec) {

		logr.error("execute method not written ");
		return -1;
	}

/**
 * return the error step number
 * @return error step number
 */
	public int getErrorStep() {
		return errorStep;
	}
	/**
	 * sets the error step number
	 * @param errorStep
	 */
	public void setErrorStep(int errorStep) {

		this.errorStep = errorStep;
	}
	/**
	 * get the next step to go to
	 * @return next step
	 */
	public int getNextStep() {
		return nextStep;
	}

	/**
	 * sets the next step to go to
	 * @param nextStep
	 */
	public void setNextStep(int nextStep) {

		this.nextStep = nextStep;
	}

	/**
	 * make a more informative toString method
	 */
	public String toString()
	{
		return "executor object "+ getClass().getName()+" at line " + myXMLLine + " in xml process file";
	}


	public DebugListener getDebugListener() {
		if (exec != null)
			return exec.getDebugListener();
		return null;
		}
}
