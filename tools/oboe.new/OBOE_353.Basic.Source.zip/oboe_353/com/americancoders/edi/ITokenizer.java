package com.americancoders.edi;

/**
 * interface for Tokenizers
 *
 *<P>OBOE - Open Business Objects for EDI
 *<p>Part of the OBOE Basic Extended Package
 *<br>An EDI and XML Translator Written In Java
 *<br>Copyright 1998-2007 - American Coders, LTD  - Raleigh NC USA
 *<br>All rights reserved
 *<br>American Coders, Ltd
 *<br>P. O. Box 97462
 *<br>Raleigh, NC  27624  USA
 *<br>1-919-846-2014
 *<br>http://www.americancoders.com
@author Joe McVerry - American Coders, Ltd.
  @version   3.5.3
 */

public interface ITokenizer {
	/** number of dataelements in token string
	 * @return int
	 */
	public int countDataElements();
	/** get the contents for the current data element
	 * @return String
	 */
	public String getCurrentDataElement();
	/** gets the position within segment or composite of the current data element
	 * @return int
	 */
	public int getDataElementPos();
	/** look ahead to the next data element
	 * @return String
	 */
	public String getNextDataElement();
	/** returns data element at preparsed position
	 * @param pos int position
	 * @return String may return null
	 */
	public String getDataElementAt(int pos);
	/** gets the next DataTokenizer object
	 * @param inSegContainer SegmentContainer requesting the next segment.
	 * Used for error handling and recovery.
	 * @return IDataTokenizer
	 */
	public IDataTokenizer getNextSegment(SegmentContainer inSegContainer);
	/** gets the current segment position within tokenized object
	 * @return int
	 */
	public int getSegmentPos();
	/** determine if there are more data elements to parse in token
	 * @return true or false
	 */
	public boolean hasMoreDataElements();
	/** determine if there are more segments to parse
	 * @return true or false
	 */
	public boolean hasMoreSegments();
	/** is there a data element to parse or a segment
	 * @return true - data element
	 * false - segment
	 */
	public boolean isThereADataElement();
	/** reset for look ahead
	 * @return IDataTokenizer
	 */
	public IDataTokenizer resetSegment();
	/** turn the current tokenizer into a subfield tokenizer
	 * @return IDataTokenizer
	 */

	public IDataTokenizer makeSubfieldTokenizer();
	/** adds an error description to the OBOEParserErrors object
	 * @param inDescription description of the error,
	 */

	public void reportError(String inDescription);

	/** adds an error description to the OBOEParserErrors object
	 * @param inDescription description of the error,
	 * @param inRequestingContainer segment, table...
	 * @param inCode 720 code
	 * @param inObject object reporting erro
	 * @param inInt level of error
	 */

	public void reportError(
		String inDescription,
		SegmentContainer inRequestingContainer,
		String inCode,
		Object inObject,
		int inInt);

	/** returns the escape character string
	* @return String
	*/
	public 	String getEscapeCharacters();

	/** returns the repeater delimiter
	 * @return String
     */
	public String getRepeaterCharacter();

	/** returns the element delimiter
	 * @return String
	 */
	public String getElementSeparator();

    public String toString();
    
    /** returns the byte positin in the input stream of the current token 
     * 
     * @return int
     */
	public int getInputByteCount() ;
}
