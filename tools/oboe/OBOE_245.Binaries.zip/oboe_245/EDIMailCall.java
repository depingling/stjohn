package com.americancoders.samples;


import java.awt.*;
import java.awt.event.*;
import java.util.Vector;
import javax.swing.*;
import javax.swing.JTable;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.TableColumn;
import com.americancoders.edi.*;
import com.americancoders.edi.x12.*;
import com.americancoders.mail.*;

import javax.swing.*;


/** this is a sample program to show a java app. could pull data from a server
 * <br>Class contains a main method to allow it to invoked as an application.
 * <br>format: java com.americancoders.edi.EDIMailCall hostid userid password mailServerProtocol
 * <br>where hostid is the name of your incoming mail server
 * <br>      userid mailid to get mail
 * <br>      password
 * <br>      mailServerProtocol - imap | pop3
 *<P>OBOE - Open Business Objects for EDI
 *<br>An EDI and XML Translator Written In Java
 *<br>Copyright 1998-2001 - American Coders, LTD  - Raleigh NC USA
 *<br>All rights reserved
 *<br>American Coders, Ltd
 *<br>P. O. Box 97462
 *<br>Raleigh, NC  27624  USA
 *<br>1-919-846-2014
 *<br>http://www.americancoders.com
@author Joe McVerry, American Coders Ltd.
@version buildNotToBeReleased
 */


public class EDIMailCall extends JFrame implements ActionListener, WindowListener, ComponentListener
{

  Container container;
  OBOETable dt;
  Vector emailData;
  Vector deleteVector = new Vector();

  javax.swing.JScrollPane scrollPane;
  javax.swing.JTable mailTable;
  javax.swing.JMenuBar menuBar;
  javax.swing.JMenu controlMenu;
  javax.swing.JMenuItem getMailList, getMailText, closeScreenItem;
  javax.swing.JMenu responseMenu;
  javax.swing.JMenuItem acknowledgeMail, rejectMail;
  IncomingEDIMail iem;

  boolean	frameSizeAdjusted = true;

  String from, toHost;

  /** constructs to object with 4 parameters ,  a Swing Frame classes, requires JAVA 2 swingset.
 * @param host String defining the mail server
 * @param password String
 * @param protocol String imap or pop3
 * @param userid String user id on server
 * @param senderId String id of mail to send rsp to.
 */

  public EDIMailCall(String host, String userid, String password, String senderId, String protocol)
  {
    setTitle("OBOE - EDI Mail");
    setSize(600, 400);

    emailData = new Vector();
    iem = new IncomingEDIMail(host, userid, password, protocol, false);
    iem.vectorizeEDIDocument(emailData);

    dt = new OBOETable();
    mailTable = new javax.swing.JTable(dt);
    dt.setInitialWidths();
    scrollPane = new javax.swing.JScrollPane(mailTable);

    container = getContentPane();
    container.add(scrollPane, BorderLayout.CENTER);

    menuBar = new javax.swing.JMenuBar();
    setJMenuBar(menuBar);

    controlMenu = new javax.swing.JMenu("Controls");
    menuBar.add(controlMenu);

    getMailList = new javax.swing.JMenuItem("Refresh Mail List");
    controlMenu.add(getMailList);

    getMailText = new javax.swing.JMenuItem("Get Mail Text");
    controlMenu.add(getMailText);

    closeScreenItem = new javax.swing.JMenuItem("Close");
    controlMenu.add(closeScreenItem);

    responseMenu = new javax.swing.JMenu("Response");
    menuBar.add(responseMenu);

    acknowledgeMail = new javax.swing.JMenuItem("Positive Acknowledgement");
    responseMenu.add(acknowledgeMail);

    rejectMail = new javax.swing.JMenuItem("Reject Mail");
    responseMenu.add(rejectMail);

    controlMenu.add(getMailText);
    addWindowListener(this);
    getMailList.addActionListener(this);
    getMailText.addActionListener(this);
    acknowledgeMail.addActionListener(this);
    rejectMail.addActionListener(this);
    closeScreenItem.addActionListener(this);
    addComponentListener(this);

    setVisible(true);
    toHost = host;
    from = senderId;

  }


  /** allows testing of the class,  as an application
 * <br>format: java com.americancoders.edi.EDIMailCall hostid userid password mailServerProtocol
 * <br>where hostid is the name of your incoming mail server
 * <br>      userid mailid to get mail
 * <br>      password
 * <br>      mailServerProtocol - imap | pop3
 * @param args String array
 */

  static public void main(String args[])
  {
    if (args.length != 5)
    {System.out.println("format: java EDIMailCall host userid password sendUserid protocol");
      System.exit(1);
    }
    try {
      (new EDIMailCall(args[0], args[1], args[2], args[3], args[4])).setVisible(true);
    }
    catch (Throwable t) {
      t.printStackTrace();
      System.exit(1);
    }
  }

  public void windowClosing(WindowEvent event) {
    deleteMail();
    setVisible(false);
    dispose();
  System.exit(0);     }


  public void windowClosed(WindowEvent event) {
  }

  public void windowDeiconified(WindowEvent event) {
  }

  public void windowIconified(WindowEvent event) {
  }

  public void windowActivated(WindowEvent event) {
  }

  public void windowDeactivated(WindowEvent event) {
  }

  public void windowOpened(WindowEvent event) {
  }

public void componentHidden(ComponentEvent Event) {}

public void componentMoved(ComponentEvent Event) {}

public void componentShown(ComponentEvent Event) {}

public void componentResized(ComponentEvent Event) {}

  public void actionPerformed(ActionEvent event) {

    if (event.getSource() == getMailList) {

      deleteMail();
      emailData = new Vector();

      iem.vectorizeEDIDocument(emailData);

      mailTable.revalidate();
      mailTable.repaint();
    }
    if (event.getSource() == getMailText) {
      int r = mailTable.getSelectedRow();
      if (r < 0) return;
      testAndSendMDN(r, true);
      new viewsamples((String) ((Vector) emailData.elementAt(r)).elementAt(7), ' ');
    }
    if (event.getSource() == closeScreenItem) {
      deleteMail();
      dispose();
      System.exit(0);
    }

    if (event.getSource() == acknowledgeMail)
    {
      int r = mailTable.getSelectedRow();
      if (r<0) return;
      try {

        Parser p = new Parser((String) ((Vector) emailData.elementAt(r)).elementAt(7));
        X12Envelope env = (X12Envelope) p.getEnvelope();

        TransactionSet inTS = env.getFunctionalGroup(0).getTransactionSet(0);
        TransactionSet responseTS = Functional_Acknowledgment.PostiveAcknowledgment(inTS,
            env.getFunctionalGroup(0).getHeader());

        env = new com.americancoders.edi.x12.X12Envelope();
        env.setInterchange_Header(Interchange_Control_Header.getInstance());
        X12FunctionalGroup fg = new X12FunctionalGroup();
        fg.setHeader(Functional_Group_Header.getInstance());
        fg.addTransactionSet(responseTS);
        fg.setTrailer(Functional_Group_Trailer.getInstance());
        env.setInterchange_Trailer(Interchange_Control_Trailer.getInstance());
        OutgoingEDIMail oem = new OutgoingEDIMail(toHost, from);
        oem.sendEDIDocument(env.getFormattedText(Envelope.X12_FORMAT), (String) mailTable.getValueAt(r, 1), true);
      }
      catch (Exception e)
      {
        System.out.println(e.getMessage());
        e.printStackTrace();
        return;
      }
    }
  }

  /**
   * method that goes through list to find what mail has been marked for deletion and calls
   * a method in IncomingEDIMail class to actually delete the selected mail items
   */

  public void deleteMail()
  {

    int row;
    Boolean b;
    deleteVector = new Vector();
    for (row = emailData.size(); row > 0; row--)
    {
      b = (Boolean) dt.getValueAt(row-1, 3);
      if (b.booleanValue())
      {
        testAndSendMDN(row-1, false);
        Vector columnVector = (Vector) emailData.elementAt(row-1);
        deleteVector.addElement(columnVector.elementAt(6));
      }
    }

    iem.deleteEDIMail(deleteVector);
  }

  void testAndSendMDN(int row, boolean lookedAt)
  {
    Boolean b = (Boolean) dt.getValueAt(row, 5);
    if (b.booleanValue())
    {
      OutgoingEDIMail oem = new OutgoingEDIMail(toHost, from);
      oem.sendMDNResponse(dt.getResponseToMDN(row), lookedAt);
    }
    dt.setValueAt(null, row, 5);
  }


  /**
   * This is how SWING allows you to define your very own table
   * see Swing documentation for more information
   * <br> our column vector has more rows than what is dispplayed.  columns not displayed are: msgNo which
   * is used by the delete method above.
   */

  class OBOETable extends AbstractTableModel {
  String[] columnNames = {"Date Rcvd.", "From", "Subject", "Delete?", "Content Type", "Receipt Request"};

    public void setInitialWidths() {

      mailTable.getColumnModel().getColumn(0).setPreferredWidth(50);
      mailTable.getColumnModel().getColumn(1).setPreferredWidth(100);
      mailTable.getColumnModel().getColumn(2).setPreferredWidth(100);
      mailTable.getColumnModel().getColumn(3).setPreferredWidth(10);
      mailTable.getColumnModel().getColumn(4).setPreferredWidth(10);
      mailTable.getColumnModel().getColumn(5).setPreferredWidth(10);

    }

  public String getColumnName(int col) { return columnNames[col]; }

  public int getRowCount() { return emailData.size(); }

  public int getColumnCount()  { return columnNames.length; }


    public Object getValueAt(int row, int col) {
      Vector columnVector = (Vector) emailData.elementAt(row);
      if (col == 5)
      if (columnVector.elementAt(col) == null)
      return new Boolean(false);
      else
      return new Boolean(true);
      return columnVector.elementAt(col);
    }

    public String getResponseToMDN(int row) {
      Vector columnVector = (Vector) emailData.elementAt(row);
      return (String) columnVector.elementAt(5);
    }

  public boolean isCellEditable(int row, int col) { return (col == 3); } // only column 3 is editable

    public void setValueAt(Object value, int row, int col)
    {
      Vector columnVector = (Vector) emailData.elementAt(row);
      columnVector.setElementAt(value,col);
      fireTableCellUpdated(row, col);
    }

  public Class getColumnClass(int c) { return getValueAt(0,c).getClass();}

  }



}
