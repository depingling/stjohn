/*
 * Created on Sep 17, 2004
 *
 * 
 * 
 */
package com.americancoders.samples;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;

 
import com.americancoders.edi.Envelope;
import com.americancoders.edi.OBOEException;
/**
 * @author Joe McVerry - American Coders, Ltd.
 *
 * 
 */
public class ParseEnvelope {

	public static void main(String[] args){
		Envelope env = null;
		try {
		FileInputStream fis = new FileInputStream(args[0]);
		env = Envelope.processEDIEnvelope(fis);
		OutputStreamWriter osw = new OutputStreamWriter(System.out);
		env.writeFormattedText(osw, Envelope.VALID_XML_FORMAT);
		}
		catch (IOException ioe)
		{
			ioe.printStackTrace();
			System.exit(0);
		}
		catch (OBOEException oe)
		{
			  oe.getDocumentErrors();
			
		}
		
	}
}
