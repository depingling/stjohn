#!/bin/bash
export CLASSPATH=$JAVA_HOME/lib/tools.jar:./lib/ant.jar:./lib/optional.jar:./lib/junit.jar
$JAVA_HOME/bin/java org.apache.tools.ant.Main $@
