package com.americancoders.edi;


import java.util.Vector;

/**
 * Template Segment Container
 *
 *<P>OBOE - Open Business Objects for EDI
 *<p>Part of the OBOE Basic Extended Package
 *<br>An EDI and XML Translator Written In Java
 *<br>Copyright 1998-2007 - American Coders, LTD  - Raleigh NC USA
 *<br>All rights reserved
 *<br>American Coders, Ltd
 *<br>P. O. Box 97462
 *<br>Raleigh, NC  27624  USA
 *<br>1-919-846-2014
 *<br>http://www.americancoders.com
@author Joe McVerry - American Coders, Ltd.
  @version   3.5.3
 */

public abstract class TemplateSegmentContainer implements ITemplateSegmentContainer, IContainedObject
{

    /** storage for segments
     */
    protected Vector templateContainer = new Vector();


    /** adds a templatesegment to the vector
     * @param inTemplateSegment TemplateSegment to add
     */

    public void addTemplateSegment(TemplateSegment inTemplateSegment)
        {
            templateContainer.addElement(inTemplateSegment);
        }

    /**
     *returns the number of template segments
     * @return int
     */

    public int getCount() { return templateContainer.size(); }


    /** gets a templatesegment from the vector
     * @return TemplateSegment
     * @param inPosition int position in array
     */

    public TemplateSegment getTemplateSegment(int inPosition)
    {
        return (TemplateSegment) templateContainer.elementAt(inPosition);
    }

    /** gets a templatesegment from the vector
     * @return TemplateSegment
     * @param inID String template id
     */

    public TemplateSegment getTemplateSegment(String inID)
    {
        int i;
        for (i=0; i < templateContainer.size(); i++)
           {
            if (isSegment(i) == false)
              continue;
			TemplateSegment gotTS = getTemplateSegment(i);
			if (inID.compareTo(gotTS.getID()) == 0)
              return gotTS;
           }

        return null;
    }
	/** gets a templatesegment from the vector by its id and primary id value
	 * <b>This method only works if the OBOE.properties property
	 * prevalidate is set to true</b>
	  * @return TemplateSegment
	  * @param inID String template id
	  * @param primaryIDValue String id value
	  */

	 public TemplateSegment getTemplateSegment(String inID, String primaryIDValue)
	 {
		 int i;
		 for (i=0; i < templateContainer.size(); i++)
			{
			 if (isSegment(i) == false)
			   continue;
			 TemplateSegment gotTS = getTemplateSegment(i);
			 if (inID.compareTo(gotTS.getID()) == 0)
			   {
			   if (gotTS.canYouPrevalidate() && gotTS.isThisYou(primaryIDValue))
			      return gotTS;
			   }
			}

		 return null;
	 }

   public boolean isSegment(int i)
    {
        if (templateContainer == null) return false;
        if (i < 0 || i >= templateContainer.size()) return false;
        return (templateContainer.elementAt(i) instanceof TemplateSegment);
    }

	/** returns the number of elements with the same id
	 * @return int
	 * @param ID String id  to count
	 * @throws OBOEException ID unknown.
	 */

	public int getCount(String ID) {
		int i;
		int cnt = 0;
		TemplateSegment segment;
		for (i = 0; i < templateContainer.size(); i++) {
			if (isSegment(i)) {
				segment = (TemplateSegment) templateContainer.elementAt(i);
				if (segment.getID().compareTo(ID) == 0)
					cnt++;
			}
		}
		return cnt;

	}

}
