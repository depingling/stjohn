package com.americancoders.samples;
import java.io.*;

import java.applet.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;
import java.net.*;

/** sample applet routine used at americancoders web page
*<br>OBOE - Open Business Objects for EDI
 *<br>An EDI and XML Translator Written In Java
 *<br>Copyright 1998-2001 - American Coders, LTD  - Raleigh NC USA
 *<brp>All rights reserved
 *<br>American Coders, Ltd
 *<br>P. O. Box 97462
 *<br>Raleigh, NC  27624  USA
 *<br>1-919-846-2014
 *<br>http://www.americancoders.com
 @author Joe McVerry, American Coders Ltd.
 @version buildNotToBeReleased
 */

public class viewsample extends Applet

{

viewsamples vs;


  public viewsample()
  {
  }
  public void start()
  {
    vs = new viewsamples(getCodeBase(), getParameter("type").charAt(0));
    vs.show();
  }

}

