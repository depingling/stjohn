package com.americancoders.edi;

import java.io.IOException;
import java.io.Writer;
import java.util.Vector;

/**
 * class for Loops
 *OBOE - Open Business Objects for EDI
 *<P>An EDI and XML Translator Written In Java
 *<p>Copyright 1998-2007 - American Coders, LTD  - Raleigh NC USA
 *<p>All rights reserved
 *<p>American Coders, Ltd
 *<br>P. O. Box 97462
 *<br>Raleigh, NC  27624  USA
 *<br>1-919-846-2014
 *<br>http://www.americancoders.com
@author Joe McVerry - American Coders, Ltd.
  @version   3.5.3
 */

public class Loop extends LoopAndSegmentContainer {

	/** TemplateSegment that can build this Segment
	 */
	protected TemplateLoop myTemplate = null;

	/**
	  owning object
	  */

	protected IContainedObject parent = null;

	/** create a Loop based on its template
	 * @param inTemplateLoop predefined Templatoop
     * @param inParent owning Object
	 * @throws OBOEException unknown Segment
	 */

	public Loop(TemplateLoop inTemplateLoop, IContainedObject inParent)
		throws OBOEException {
		super();
		myTemplate = inTemplateLoop;
		myTemplateContainer = myTemplate;
		setTemplateLoopContainer( myTemplate );
		container = new Object[inTemplateLoop.getContainerSize()];
		setParent(inParent);
	}

	/** returns the TemplateSegment used to build the Segment
	 * @return TemplateSegment
	 */
	public TemplateLoop getTemplate() {
		return myTemplate;
	}

	/**
	 * gets the Segment id
	 * @return String id
	 */

	public String getID() {
		return myTemplate.getID();
	}

	/**
	 * gets the Segment Name
	 * @return String Name
	 */

	public String getName() {
		return myTemplate.getName();
	}

	/**
	 * returns the occurs value
	 * @return int occurance value
	 *
	 */

	public int getOccurs() {
		return myTemplate.getOccurs();
	}

	/**
	 * gets required flag
	 * @return char required
	 */
	public char getRequired() {
		return myTemplate.getRequired();
	}

	/**
	 * returns the xml tag field
	 * @return String tag value
	 */

	public String getXMLTag() {
		return myTemplate.getXMLTag();
	}

    /** 
     * returns the used indicator
     * @return boolean
     */
    public boolean isUsed() { return myTemplate.isUsed();
    
    }

	
	/** this is here as a stub because of the Segment container interface
	    * @return Segment
	    * @param ID String
	    * @throws OBOEException as thrown
	    */

	public Segment createSegment(String ID) throws OBOEException {
		Segment seg = myTemplate.createSegment(ID);
		seg.setParent(this);
		return seg;
	}

	/**returns the number of Segments within this Segment
	 * @return int subSegment count
	 */

	public int getSegmentSize() {
		return getSegmentCount() - 1;
	}

	/** returns the formatted text
	 * @param formatType int indicating x12, edificact...
	 * @return String
	 */

	public String getFormattedText(int formatType) {

		if (formatType == Envelope.FIXED_LENGTH_FORMAT)
			return getFixedLengthFormattedText();

		int i;
		Segment currentSegment;
		Loop currentLoop;
		StringBuffer sbFormattedText = new StringBuffer();

		switch (formatType) {
			case Envelope.CSV_FORMAT :
				sbFormattedText.append(
					"Loop,"
						+ getID()
						+ ",\""
						+ getName()
						+ "\""
						+ com.americancoders.util.Util.lineFeed);
				break;
			case Envelope.XML_FORMAT :
				sbFormattedText.append(
					'<'
						+ getXMLTag()
						+ ">"
						+ com.americancoders.util.Util.lineFeed);
				break;
			case Envelope.VALID_XML_FORMAT :
			case Envelope.VALID_XML_FORMAT_WITH_POSITION :
				sbFormattedText.append("<loop code=\"" + getID() + "\"");
				sbFormattedText.append(
					" name=\""
						+ getName()
						+ "\">"
						+ com.americancoders.util.Util.lineFeed);
				break;
			case Envelope.PIXES_FORMAT :
				sbFormattedText.append("<loop id=\"" + getID() + "\">"
						+ com.americancoders.util.Util.lineFeed);
				break;
			case Envelope.X12_FORMAT :
				break;
			case Envelope.EDIFACT_FORMAT :
				break;
			case Envelope.TRADACOMS_FORMAT :
				break;
			default :
				sbFormattedText.append(
					"Loop: " + getID() + com.americancoders.util.Util.lineFeed);
		}

		for (i = 0; container != null && i < getContainerSize(); i++) {
			if (container[i] == null)
				continue;
			if (isSegment(i)) {
				currentSegment = getSegment(i);
				sbFormattedText.append(
					currentSegment.getFormattedText(formatType));
			} else if (isLoop(i)) {
				currentLoop = getLoop(i);
				sbFormattedText.append(
					currentLoop.getFormattedText(formatType));
			} else {
				Vector v = (Vector) container[i];
				for (int j = 0; j < v.size(); j++) {
					if (isLoop(i, j)) {
						currentLoop = getLoop(i, j);
						sbFormattedText.append(
							currentLoop.getFormattedText(formatType));
					} else {
						currentSegment = getSegment(i, j);
						sbFormattedText.append(
							currentSegment.getFormattedText(formatType));
					}
				}
			}
		}

		switch (formatType) {
			case Envelope.CSV_FORMAT :
				break;
			case Envelope.XML_FORMAT :
				sbFormattedText.append(
					"</"
						+ getXMLTag()
						+ ">"
						+ com.americancoders.util.Util.lineFeed);
				break;
			case Envelope.VALID_XML_FORMAT :
			case Envelope.VALID_XML_FORMAT_WITH_POSITION :
			case Envelope.PIXES_FORMAT :
				sbFormattedText.append(
					"</loop>" + com.americancoders.util.Util.lineFeed);
				break;
			case Envelope.X12_FORMAT :
				break;
			case Envelope.EDIFACT_FORMAT :
				break;
			case Envelope.TRADACOMS_FORMAT :
				break;
			default :
				}

		return new String(sbFormattedText);

	}

	/** returns fixed length formatted text
	 * @return String
	 */

	public String getFixedLengthFormattedText() {

		int i;
		Segment currentSegment;
		Loop currentLoop;
		StringBuffer sbFormattedText = new StringBuffer();
		for (i = 0; container != null && i < getContainerSize(); i++) {
			if (container[i] == null)
				continue;
			if (isSegment(i)) {
				currentSegment = (Segment) container[i];
				sbFormattedText.append(
					currentSegment.getFixedLengthFormattedText());
			} else if (isLoop(i)) {
				currentLoop = (Loop) container[i];
				sbFormattedText.append(
					currentLoop.getFixedLengthFormattedText());
			} else {
				Vector v = (Vector) container[i];
				for (int j = 0; j < v.size(); j++) {
					if (isLoop(i, j)) {
						currentLoop = getLoop(i, j);
						sbFormattedText.append(
							currentLoop.getFixedLengthFormattedText());
					} else {
						currentSegment = getSegment(i, j);
						sbFormattedText.append(
							currentSegment.getFixedLengthFormattedText());
					}
				}
			}
		}

		return new String(sbFormattedText);

	}

	/** writes a  formatted text
	 * @param inWriter writer object
	 * @param formatType int indicating x12, edificact...
	 * @throws IOException
	 */

	public void writeFormattedText(Writer inWriter, int formatType) throws IOException {

		if (formatType == Envelope.FIXED_LENGTH_FORMAT) {
			writeFixedLengthFormattedText(inWriter);
			return;
		}

		int i;
		Segment currentSegment;
		Loop currentLoop;
		
		switch (formatType) {
			case Envelope.CSV_FORMAT :
				inWriter.write(
					"Loop,"
						+ getID()
						+ ",\""
						+ getName()
						+ "\""
						+ com.americancoders.util.Util.lineFeed);
				break;
			case Envelope.XML_FORMAT :
				inWriter.write(
					'<'
						+ getXMLTag()
						+ ">"
						+ com.americancoders.util.Util.lineFeed);
				break;
			case Envelope.VALID_XML_FORMAT :
			case Envelope.VALID_XML_FORMAT_WITH_POSITION :
				inWriter.write("<loop code=\"" + getID() + "\"");
				inWriter.write(
					" name=\""
						+ getName()
						+ "\">"
						+ com.americancoders.util.Util.lineFeed);
				break;
			case Envelope.PIXES_FORMAT :
				inWriter.write("<loop id=\"" + getID() + "\">"
						+ com.americancoders.util.Util.lineFeed);
				break;
			case Envelope.X12_FORMAT :
				break;
			case Envelope.EDIFACT_FORMAT :
				break;
			case Envelope.TRADACOMS_FORMAT :
				break;
			default :
				inWriter.write(
					"Loop: " + getID() + com.americancoders.util.Util.lineFeed);
		}

		for (i = 0; container != null && i < getContainerSize(); i++) {
			if (container[i] == null)
				continue;
			if (isSegment(i)) {
				currentSegment = getSegment(i);
					inWriter.write(currentSegment.getFormattedText( formatType));
			} else if (isLoop(i)) {
				currentLoop = getLoop(i);
				currentLoop.writeFormattedText(inWriter, formatType);
			} else {
				Vector v = (Vector) container[i];
				for (int j = 0; j < v.size(); j++) {
					if (isLoop(i, j)) {
						currentLoop = getLoop(i, j);
						currentLoop.writeFormattedText(inWriter, formatType);
					} else {
						currentSegment = getSegment(i, j);
						inWriter.write(currentSegment.getFormattedText( formatType));
					}
				}
			}
		}

		switch (formatType) {
			case Envelope.CSV_FORMAT :
				break;
			case Envelope.XML_FORMAT :
				inWriter.write(
					"</"
						+ getXMLTag()
						+ ">"
						+ com.americancoders.util.Util.lineFeed);
				break;
			case Envelope.VALID_XML_FORMAT :
			case Envelope.VALID_XML_FORMAT_WITH_POSITION :
			case Envelope.PIXES_FORMAT :
				inWriter.write(
					"</loop>" + com.americancoders.util.Util.lineFeed);
				break;
			case Envelope.X12_FORMAT :
				break;
			case Envelope.EDIFACT_FORMAT :
				break;
			case Envelope.TRADACOMS_FORMAT :
				break;
			default :
				}

		inWriter.flush();

	}

	/** returns fixed length formatted text
	 * @return String
	 * @throws IOException
	 */

	public void writeFixedLengthFormattedText(Writer inWriter) throws IOException {

		int i;
		Segment currentSegment;
		Loop currentLoop;
		
		for (i = 0; container != null && i < getContainerSize(); i++) {
			if (container[i] == null)
				continue;
			if (isSegment(i)) {
				currentSegment = (Segment) container[i];
				inWriter.write(currentSegment.getFixedLengthFormattedText());
			} else if (isLoop(i)) {
				currentLoop = (Loop) container[i];
				currentLoop.writeFixedLengthFormattedText(inWriter);
			} else {
				Vector v = (Vector) container[i];
				for (int j = 0; j < v.size(); j++) {
					if (isLoop(i, j)) {
						currentLoop = getLoop(i, j);
						currentLoop.writeFixedLengthFormattedText(inWriter);
					} else {
						currentSegment = getSegment(i, j);
						inWriter.write(currentSegment.getFixedLengthFormattedText());
					}
				}
			}
		}


	}

	/**
	 * returns all the data associated with the Segment
	 * <br>dataelements separated by '*'
	 * <br>composites separated by '<', note data elements within composites are seperated by ':'
	 * @return String for all Segments and deArray within the Segment
	 */
	public String get() {
		StringBuffer sb = new StringBuffer();
		Segment currentSegment;
		int i;

		for (i = 0; container != null && i < getContainerSize(); i++) {
			if (isSegment(i)) {
				currentSegment = getSegment(i);
				sb.append(currentSegment.get());
			} else if (isVector(i)) {
				for (int j = 0; j < getSegmentCount(i); j++) {
					currentSegment = getSegment(i, j);
					sb.append(currentSegment.get());
				}
			}

		}

		return new String(sb);
	}

	/** sets parent attribute
	 * @param inParent TemplateSegmentContainer
	 */
	public void setParent(IContainedObject inParent) {
		parent = inParent;
	}

	/** sets the default value for the data elements
	 * <br>part of Extended Edition package
	 * <br>will create mandatory subsegments.
	 * <br>if mandatory subsegment is part of vector (collection) will create the first one
	  */
	public void useDefault() {
	}

	public boolean validate(DocumentErrors inDErr) {
		boolean b = super.validate(inDErr);

		return b;
	}

	/** gets parent attribute
	 * @return TemplateSegmentContainer
	 */
	public IContainedObject getParent() {
		return parent;
	}
    /**
     * the toString method
     */
   public String toString()
   {
   	 return "loop  id:" + getID() + " name:" + getName(); 
   	 		
   }

	/* (non-Javadoc)
	 * @see com.americancoders.edi.ISegmentContainer#getTemplateSegmentContainer()
	 */
	public TemplateSegmentContainer getTemplateSegmentContainer() {
		
		return this.myTemplateContainer;
	}

	/* (non-Javadoc)
	 * @see com.americancoders.edi.IContainedObject#getDelimiter(char)
	 */

		public char getDelimiter(char inOriginal) {
			
			return parent.getDelimiter(inOriginal);
		}

}
