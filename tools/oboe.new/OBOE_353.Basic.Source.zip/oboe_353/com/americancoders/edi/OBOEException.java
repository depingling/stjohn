package com.americancoders.edi;

/**
 *package's Exception class
 *<P>OBOE - Open Business Objects for EDI
 *<p>Part of the OBOE Basic Extended Package
 *<br>An EDI and XML Translator Written In Java
 *<br>Copyright 1998-2007 - American Coders, LTD  - Raleigh NC USA
 *<br>All rights reserved
 *<br>American Coders, Ltd
 *<br>P. O. Box 97462
 *<br>Raleigh, NC  27624  USA
 *<br>1-919-846-2014
 *<br>http://www.americancoders.com
@author Joe McVerry - American Coders, Ltd.
  @version   3.5.3
 */

public class OBOEException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	DocumentErrors dErr = null;
	/** Constructor
	 */
	public OBOEException() {
		super();
	}
	/** Constructor with a message
	 * @param s String message
	 */
	public OBOEException(String s) {
		super(s);
	}

	/** Used by parsers for errors
	 * @param inDErr DocumentError object
	 */
	public OBOEException(DocumentErrors inDErr) {
		super("Parsing Errors.");
		dErr = inDErr;
	}

	/** returns the DocumentErrors object passed by the Parser
	 * @return DocumentErrors
	 */

	public DocumentErrors getDocumentErrors() {
		return dErr;
	}
}
