/*
 * Copyright (C) 2006-2007 by Joseph McVerry - American Coders, Ltd.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

package org.pixes;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.xml.sax.Attributes;



/**
 * @author Joe McVerry - American Coders, Ltd.
 *
 * executor object to do database connections
 *
 */
public class Connecter extends Executable {

/**
 * jdbc driver class
 */
    String driverClass;

    /**
     * jdbc connector
     */
    String connectionCall;

    private Connection connection;

	/**
	 * debugging level
	 */
	Level dbgLvl;

	/**
	 *
	 * @param line xml file line number
	 * @param attr xml attributes
	 * @param parser who's in charge
	 *
	 */
	public Connecter(int line, Attributes attr, Parser parser) {

    	super(parser);
        logr = Logger.getLogger(Connecter.class);
        setLogger();
		dbgLvl = prsr.logr.getLevel();
        logr.setLevel(dbgLvl);
		logr.debug("connecter constructor " + attr + " " + line);
		setMyXMLLine(line);

		this.driverClass = attr.getValue("driverClass");
		this.connectionCall = attr.getValue("dbConnection");

	}



	/**
	 * executes and returns next step
	 * @return next step
	 */
	public int execute(Executor inExec)
	{
		exec = inExec;
		exec.logr.setLevel(dbgLvl);
		logr.setLevel(dbgLvl);
   		logr.debug("execute call");
			try {
				Class.forName(driverClass).newInstance();
			} catch (InstantiationException e) {

				logr.error(e.getMessage(),
						         e);
				return -1;
			} catch (IllegalAccessException e) {

				logr.error(e.getMessage(),
						         e);
				return -1;
			} catch (ClassNotFoundException e) {

				logr.error(e.getMessage(),
						         e);
				return -1;
			}
			try {
				connection = DriverManager.getConnection(connectionCall);
				try {
			        DatabaseMetaData dmd = connection.getMetaData();
			        if (dmd.supportsResultSetType(ResultSet.TYPE_SCROLL_INSENSITIVE)) {
			            logr.debug("scroll insensitive");
			        }
			        if (dmd.supportsResultSetType(ResultSet.TYPE_SCROLL_SENSITIVE)) {
			            logr.debug("scroll sensitive");
			        }
			        if (!dmd.supportsResultSetType(ResultSet.TYPE_SCROLL_INSENSITIVE)
			            && !dmd.supportsResultSetType(ResultSet.TYPE_SCROLL_SENSITIVE)) {
			            logr.debug("don't know about scrolling");
			        }
			    } catch (SQLException e) {
			    }
			} catch (SQLException e1) {

				logr.error(e1.getMessage(),
						         e1);
				return -1;
			}

		return getNextStep();

	}


	/**
	 *
	 * @return jdbc Connection
	 */
	public Connection getConnection() {
		return connection;
	}
}
