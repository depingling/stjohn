package com.americancoders.edi;

import java.io.IOException;
import java.io.Writer;
import java.util.Vector;

/**
 * class for Tables
 * a general class for the transaction set's heading detail and summary.
 *
 *<p>OBOE - Open Business Objects for EDI
 *<p>Part of the OBOE Basic Extended Package
 *<br>An EDI and XML Translator Written In Java
 *<br>Copyright 1998-2007 - American Coders, LTD  - Raleigh NC USA
 *<br>All rights reserved
 *<br>American Coders, Ltd
 *<br>P. O. Box 97462
 *<br>Raleigh, NC  27624  USA
 *<br>1-919-846-2014
 *<br>http://www.americancoders.com
@author Joe McVerry - American Coders, Ltd.
  @version   3.5.3
 */
public class Table
	extends LoopAndSegmentContainer
	implements IContainedObject {
	/** String XML tag
	 */
	protected String xmlTag = "";

	/** reference to its template table
	 */
	TemplateTable myTemplate = null;

	/** constructor
	 *  @param inTemplateTable
	    * @param inParent owning Object
	*/
	public Table(TemplateTable inTemplateTable, IContainedObject inParent) {
		myTemplate = inTemplateTable;
		myTemplateContainer = inTemplateTable;
		setTemplateLoopContainer(inTemplateTable);
		setXMLTag(inTemplateTable.getXMLTag());
		defineContainer();
		setParent(inParent);
	}

	/** return the tables template
	 */
	public TemplateTable getTemplateTable() {
		return myTemplate;
	}

	/** returns a preformatted string
	 * @return String  formatted text
	 * @param formatType int - x12, edifact...
	 */

	public String getFormattedText(int formatType) {
		int i;
		StringBuffer sbFormattedText = new StringBuffer();
		Segment currentSegment;
		Loop currentLoop;
		if (formatType == Envelope.CSV_FORMAT)
			sbFormattedText.append(
				"Table," + getXMLTag() + com.americancoders.util.Util.lineFeed);
		if (formatType == Envelope.XML_FORMAT)
			sbFormattedText.append(
				"<"
					+ getXMLTag()
					+ ">"
					+ com.americancoders.util.Util.lineFeed);
		if (formatType == Envelope.VALID_XML_FORMAT
		  || formatType == Envelope.VALID_XML_FORMAT_WITH_POSITION
		  || formatType == Envelope.PIXES_FORMAT)
			sbFormattedText.append(
				"<table section=\""
					+ getXMLTag()
					+ "\">"
					+ com.americancoders.util.Util.lineFeed);

		for (i = 0; container != null && i < getContainerSize(); i++) {
			if (container[i] == null)
				continue;
			if (isSegment(i)) {
				currentSegment = getSegment(i);
				sbFormattedText.append(
					currentSegment.getFormattedText(formatType));
			} else if (isLoop(i)) {
				currentLoop = getLoop(i);
				sbFormattedText.append(
					currentLoop.getFormattedText(formatType));
			} else {
				Vector v = (Vector) container[i];
				for (int j = 0; j < v.size(); j++) {
					if (isLoop(i, j)) {
						currentLoop = getLoop(i, j);
						sbFormattedText.append(
							currentLoop.getFormattedText(formatType));
					} else {
						currentSegment = getSegment(i, j);
						sbFormattedText.append(
							currentSegment.getFormattedText(formatType));
					}
				}
			}
		}

		if (formatType == Envelope.XML_FORMAT)
			sbFormattedText.append(
				"</"
					+ getXMLTag()
					+ ">"
					+ com.americancoders.util.Util.lineFeed);
		if (formatType == Envelope.VALID_XML_FORMAT
		  || formatType == Envelope.VALID_XML_FORMAT_WITH_POSITION
		  || formatType == Envelope.PIXES_FORMAT)
			sbFormattedText.append(
				"</table>" + com.americancoders.util.Util.lineFeed);

		return new String(sbFormattedText);

	}
	/** writes a preformatted string
	 * @param inWriter writer object
	 * @param formatType int - x12, edifact...
	 */

	public void writeFormattedText(Writer inWriter, int formatType) throws IOException
	  {
		int i;
		
		Segment currentSegment;
		Loop currentLoop;
		if (formatType == Envelope.CSV_FORMAT)
			inWriter.write(
				"Table," + getXMLTag() + com.americancoders.util.Util.lineFeed);
		if (formatType == Envelope.XML_FORMAT)
			inWriter.write(
				"<"
					+ getXMLTag()
					+ ">"
					+ com.americancoders.util.Util.lineFeed);
		if (formatType == Envelope.VALID_XML_FORMAT
		  || formatType == Envelope.VALID_XML_FORMAT_WITH_POSITION
		  || formatType == Envelope.PIXES_FORMAT)
			inWriter.write(
				"<table section=\""
					+ getXMLTag()
					+ "\">"
					+ com.americancoders.util.Util.lineFeed);

		for (i = 0; container != null && i < getContainerSize(); i++) {
			if (container[i] == null)
				continue;
			if (isSegment(i)) {
				currentSegment = getSegment(i);
				inWriter.write(currentSegment.getFormattedText( formatType));
			} else if (isLoop(i)) {
				currentLoop = getLoop(i);
				currentLoop.writeFormattedText(inWriter, formatType);
			} else {
				Vector v = (Vector) container[i];
				for (int j = 0; j < v.size(); j++) {
					if (isLoop(i, j)) {
						currentLoop = getLoop(i, j);
						currentLoop.writeFormattedText(inWriter, formatType);
					} else {
						currentSegment = getSegment(i, j);
						inWriter.write(currentSegment.getFormattedText( formatType));
					}
				}
			}
		}

		if (formatType == Envelope.XML_FORMAT)
			inWriter.write(
				"</"
					+ getXMLTag()
					+ ">"
					+ com.americancoders.util.Util.lineFeed);
		if (formatType == Envelope.VALID_XML_FORMAT
		  || formatType == Envelope.VALID_XML_FORMAT_WITH_POSITION
		  || formatType == Envelope.PIXES_FORMAT)
			inWriter.write(
				"</table>" + com.americancoders.util.Util.lineFeed);

	   inWriter.flush();	

	}

	/** returns the table id, since there are no table ids method returns a zero-length string
	 * @return String
	 */
	public String getID() {
		return getXMLTag();
	}

	/** sets the xml tag field
	 * @param inXMLTag String tag
	 */

	public void setXMLTag(String inXMLTag) {
		xmlTag = inXMLTag;
	}

	/**
	 * returns the xml tag field
	 * @return String tag value
	 */

	public String getXMLTag() {
		return xmlTag;
	}

	/** return the Template
	 */
	public TemplateSegmentContainer getTemplateSegmentContainer() {
		return myTemplate;
	}

	/** sets the default value for the data elements
	 * <br>part of Extended Edition package
	 * <br>will create mandatory subsegments.
	 * <br>if mandatory subsegment is part of vector (collection) will create the first one
	  */
	public void useDefault() {
	}

	public boolean validate(DocumentErrors inDErr) {
		boolean b = super.validate(inDErr);

		return b;
	}

	protected IContainedObject parent = null;
	/** sets parent attribute
	 * @param inParent TemplateSegmentContainer
	 */
	public void setParent(IContainedObject inParent) {
		parent = inParent;
	}

	/** gets parent attribute
	 * @return TemplateSegmentContainer
	 */
	public IContainedObject getParent() {
		return parent;
	}
	/* (non-Javadoc)
	 * @see com.americancoders.edi.IContainedObject#getDelimiter(char)
	 */

		public char getDelimiter(char inOriginal) {
			
			return parent.getDelimiter(inOriginal);
		}

}
