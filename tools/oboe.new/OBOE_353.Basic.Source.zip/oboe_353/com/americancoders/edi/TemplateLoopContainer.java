package com.americancoders.edi;

/**
 * Template Segment Container
 *
 *<P>OBOE - Open Business Objects for EDI
 *<p>Part of the OBOE Basic Extended Package
 *<br>An EDI and XML Translator Written In Java
 *<br>Copyright 1998-2007 - American Coders, LTD  - Raleigh NC USA
 *<br>All rights reserved
 *<br>American Coders, Ltd
 *<br>P. O. Box 97462
 *<br>Raleigh, NC  27624  USA
 *<br>1-919-846-2014
 *<br>http://www.americancoders.com
@author Joe McVerry - American Coders, Ltd.
  @version   3.5.3
 */

public abstract class TemplateLoopContainer extends TemplateSegmentContainer {

	/** creates a subsegment
	 * @return Segment based on this Template
	 * @param id String id of subsegment to create
	 * @throws OBOEException unknown id
	 */

	public Segment createSegment(String id) throws OBOEException {
		int i;
		for (i = 0; i < templateContainer.size(); i++) {
			if (isLoop(i))
				continue;
			if (((TemplateSegment) templateContainer.elementAt(i))
				.getID()
				.compareTo(id)
				== 0)
				return new Segment(
					(TemplateSegment) templateContainer.elementAt(i),
					this);
		}

		throw new OBOEException(
			"Segment " + id + " is not defined in this container");
	}

	/** adds a TemplateLoop to the vector
	 * @param inTemplateLoop TemplateLoop to add
	 */

	public void addTemplateLoop(TemplateLoop inTemplateLoop) {
		templateContainer.addElement(inTemplateLoop);
	}

	/**
	 *returns the number of template segments
	 * @return int
	 */

	public int getContainerSize() {
		return templateContainer.size();
	}

	/** gets a TemplateLoop from the vector
	 * @return TemplateLoop
	 * @param inPosition int position in array
	 */

	public TemplateLoop getTemplateLoop(int inPosition) {
		return (TemplateLoop) templateContainer.elementAt(inPosition);
	}

	/** gets a TemplateLoop from the vector
	 * @return TemplateLoop
	 * @param inID String template's loop id
	 */

	public TemplateLoop getTemplateLoop(String inID) {
		int i;
		for (i = 0; i < templateContainer.size(); i++) {
			if (isLoop(i) == false)
				continue;
			if (inID.compareTo(((TemplateLoop) templateContainer.elementAt(i)).getID()) == 0)
				return (TemplateLoop) templateContainer.elementAt(i);
		}

		return null;
	}

	public boolean isLoop(int i) {
		if (templateContainer == null)
			return false;
		if (i < 0 || i >= templateContainer.size())
			return false;
		return (templateContainer.elementAt(i) instanceof TemplateLoop);
	}

}
