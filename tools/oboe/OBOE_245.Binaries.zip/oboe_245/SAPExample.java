/*
 * <p>SAPExample.java
 * <p>Example creates a classic EDI file from XML EDI input.
 * <p>I think there will still problems occure if you don't define
 * <p> the PurchaseOrderMessage property in the OBOE properties file.
 * <p>Copyright 1999 mendelson-e-commerce GmbH Berlin Germany
 * <p>Created on 5. Januar 2000, 15:27
 * @author Stefan Heller
 */
package com.americancoders.samples;

import com.americancoders.edi.*;
import com.americancoders.edi.fixformat.FixformatTokenizer;
import java.io.*;
import java.util.*;
import org.w3c.dom.*;
import org.xml.sax.*;

public class SAPExample{


	/**Constructor, just calls edi2XML
	* @param inFile input file, format is XML, must be EDIFACT style
	* @param outFile Filename for created XML EDI output file
	* @param rulesFile Filename of the XML OBOE rules file
	*/
    public SAPExample( String inFile, String outFile, String rulesFile ) {
        //this.ediToXML( "purchaseordermessage.xml", "orders31g", "orders31g" );
		this.ediToXML( inFile, outFile, rulesFile );
    }

    /**Creates XML EDI data using a classic EDI file
    * @author S.Heller
    * @param inputFilename Classic EDI data file in EDIFACT style (e.g. orders, edifact )
    * @param outputFilename Filename for created XML EDI output file (also printed to stdout)
    * @param rulesFilename Filename of the XML OBOE rules file
    */
    protected void ediToXML( String inputFilename, String outputFilename,
                              String rulesFilename ){
	try{
	    //receive XML input file contents
	    String contents = this.getContents( new File( inputFilename ) );

	    //build up Transaction Set
	    TransactionSet transactionSet
			= TransactionSetFactory.buildTransactionSet( rulesFilename );
        transactionSet.setFormat(Envelope.EDIFACT_FORMAT);
	    FixformatTokenizer tokenizer
              = new FixformatTokenizer( contents, "\n", transactionSet, 10 );
	    //parse message against TransactionSet
		transactionSet.parse( tokenizer );

	    String outXMLEDI
			= transactionSet.getFormattedText( Envelope.XML_FORMAT );

		//Save outXMLEDI in a file called <outFilename>
		FileOutputStream fos = new FileOutputStream( new File( outputFilename ));
                byte[] buffer = outXMLEDI.getBytes();
                fos.write( buffer );
		fos.flush();
		fos.close();
	}
	catch( Exception e ){
	    System.out.println( e.getMessage() );
	    e.printStackTrace();
	}

    }


    /**Reads the contents of a file and returns it as String - warning: there may occure
     * problems because a byte buffer is used instead of a char buffer.
     *@author S.Heller
     *@param inFile File to read
     *@param return String that contains the file contents
     */
    public String getContents( File inFile ) throws IOException{
		byte buffer[] = new byte[(int)inFile.length()];
		FileInputStream fis = new FileInputStream(inFile);
		fis.read(buffer);
		return( new String( buffer ));
    }

     /**
     * @param args the command line arguments
     */
    public static void main (String args[]) {
		if( args == null || args.length < 3 ){
			System.out.println( "usage: java SAPExample "
				+ "<inFileXML> <outFileClassicEDI> <OBOERulesFile>" );
			System.exit( -1 );
		}
		new SAPExample( args[0], args[1], args[2] );
    }

}
