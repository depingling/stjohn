/*
 * Copyright (C) 2006-2007 by Joseph McVerry - American Coders, Ltd.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

package org.pixes;


import java.util.Vector;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.xml.sax.Attributes;


/**
 * @author Joe McVerry - American Coders, Ltd.
 *
 * executor object to do a database select
 *
 */
public class Reader  extends Executable implements IContinuable {

    static {Util.isLog4JNotConfigured();}
    /**
     * how input is layed out, for parsing the input
     */
    String readLayout;
    /**
     * debugging level
     */
    Level dbgLvl;
    /**
     * my file
     */
	BufferedFile f;
	/**
	 * xml file line number
	 */
	int line;

	VarStack vstack;


	/** tokens to parse the input string */
	Vector tokens=new Vector();
	/** types of tokens */
	Vector types = new Vector();

	/**
	 * @param line - int xml line number
	 * @param attr - Attributes
	 * @param parser - Parser
	 * @throws PIXESException
	 */
	public Reader(int line, Attributes attr, Parser parser)
			throws PIXESException {
	    super(parser);
        logr = Logger.getLogger(Reader.class);
	    setLogger();
		this.line = line;

		dbgLvl = prsr.logr.getLevel();
        logr.setLevel(dbgLvl);
		logr.debug("Reader constructor "+line);
		setMyXMLLine(line);
		String refid = attr.getValue("refid");
	    f = parser.getFile(refid);
		if (f == null)
			logr.debug("cannot find associated file with id=\""+refid+"\"  see line "+line);

		readLayout = attr.getValue("readLayout");
		if (readLayout == null) {
			throw new PIXESException("missing readLayout attribute for read tag.  see line "+line);

		}
		vstack = parser.getVarStack();
		detokenString(readLayout);

	}


	/** end of file indicator */
	boolean eof = false;

	public int execute(Executor inExec) {
		exec = inExec;
		exec.logr.setLevel(dbgLvl);
		vstack = exec.getVarStack();
		logr.setLevel(dbgLvl);
		logr.debug("executing");

		try {

				String in =   f.br.readLine();
				if (in == null) {
					eof = true;
					return getContinueStep();
				}
				logr.info(in);
				int start = 0;
				int inpos = 0;
				while(inpos < in.length() && start < tokens.size()) {
				boolean fieldType = ((Boolean) types.get(start)).booleanValue();
				if (fieldType)  // get field and assign
				{
					String field = (String) tokens.get(start);
					start++;
					char stop = 0xFF;
					boolean readToEnd = false;
					if (start >= tokens.size()) {
						readToEnd = true;
					}
					else {
					stop = ((String) tokens.get(start)).charAt(0);
					if (inpos >= in.length()) {
						logr.debug("ran out of tokens to read, see line "+line);
						break;
					}
					}
					StringBuffer sb = new StringBuffer();
					sb.append(in.charAt(inpos));
					inpos++;
					if (readToEnd)
						while (inpos < in.length())
						{
							sb.append(in.charAt(inpos));
							inpos++;
						}
					else
					while (inpos < in.length() && (in.charAt(inpos) != stop))
					{
						sb.append(in.charAt(inpos));
						inpos++;
					}
					vstack.getVariables().put(field, sb.toString());
					if (readToEnd)
						break;
					start++;
					inpos++;
					continue;
				}
				else {
					char stop = ((String) tokens.get(start)).charAt(0);
					if (stop != in.charAt(inpos))
					{
						logr.debug("delimiter mismatch dropping rest of read line, see line"+line);
						break;
					}
                    inpos++;
                    start++;
				}
				}

		} catch (Exception e) {

			logr.error(e.getMessage());
			return -1;
		}

		return getNextStep();

	}



	/** shred and rebuild the incoming data
	 *
	 * @param st incoming
	 * @throws PIXESException
	 */
	  public void detokenString(String st) throws PIXESException {
	        if (st == null)
	            return;
	        StringBuffer sb = new StringBuffer(st.length());
	        int i;
	        boolean lastAField = false;

	        for (i = 0; i < st.length(); i++) {
	            if (st.charAt(i) == vstack.varStartIdentifier) {
	                boolean found = false;
	                if (lastAField)
	                	throw new PIXESException("two fields in a row is not logical for readLayout.  see line "+line);
	                lastAField = true;
	                StringBuffer sb2 = new StringBuffer();
	                i++;
	                if (i >= st.length()) {
	                    sb.append(st.charAt(i));
	                    continue;
	                }
	                if (st.charAt(i) != vstack.varContinueIdentifier) {
	                    sb.append(st.charAt(i));
	                    continue;
	                }
	                for (i++; i < st.length() && found == false; i++) {
	                    if (st.charAt(i) == vstack.varEndIdentifier)
	                        found = true;
	                    else if (st.charAt(i) == vstack.arrayStartIdentifier) {
	                        sb2.append(st.charAt(i));
	                        boolean found2 = false;
	                        StringBuffer sb3 = new StringBuffer();
	                        for (i++; i < st.length() && found2 == false; i++) {
	                            if (st.charAt(i) == vstack.arrayEndIdentifier) {
	                                found2 = true;
	                                String s = vstack.replaceString(sb3.toString());
	                                sb2.append(s);
	                                i--;

	                            } else
	                                sb3.append(st.charAt(i));
	                        }
	                        sb2.append(vstack.arrayEndIdentifier);
	                    } else
	                        sb2.append(st.charAt(i));
	                }
	                if (found == false) {
	                    throw new PIXESException("missing closing variable identifier "
	                            + vstack.varEndIdentifier + " in string " + st+ " see line "+line);
	                }
                    types.add(Boolean.valueOf(true));
	                tokens.add(sb2.toString());
	                i--;
	            } else {
	            	lastAField = false;
                    types.add(Boolean.valueOf(false));
	                tokens.add(st.charAt(i)+"");

	            }
	        }


	    }

    int continueStep=-1;

	/* (non-Javadoc)
	 * @see org.pixes.IContinuable#getContinueStep()
	 */
	public int getContinueStep() {
		return continueStep;
	}



	/* (non-Javadoc)
	 * @see org.pixes.IContinuable#setContinueStep(int)
	 */
	public void setContinueStep(int pos) {
		if (continueStep == -1)
			continueStep = pos;

	}



	/* (non-Javadoc)
	 * @see org.pixes.IEndTestable#atEnd()
	 */
	public boolean atEnd() {

		return this.eof;
	}





}