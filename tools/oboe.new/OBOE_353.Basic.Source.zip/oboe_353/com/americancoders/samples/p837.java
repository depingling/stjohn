//$$allSkip
package com.americancoders.samples;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;

import com.americancoders.edi.CompositeDE;
import com.americancoders.edi.DataElement;
import com.americancoders.edi.FunctionalGroup;
import com.americancoders.edi.Loop;
import com.americancoders.edi.OBOEException;
import com.americancoders.edi.Segment;
import com.americancoders.edi.Table;
import com.americancoders.edi.TransactionSet;
import com.americancoders.edi.x12.X12DocumentHandler;
import com.americancoders.edi.x12.X12Envelope;

/** code template to parse
*<br>class 004010X098/837 Health Care Claim
*<br>
* This Draft Standard for Trial Use contains the format and establishes
* the data contents of the Health Care Claim Transaction Set (837)
* for use within the context of an Electronic Data Interchange
* (EDI) environment. This transaction set can be used to submit
* health care claim billing information, encounter information,
* or both, from providers of health care services to payers, either
* directly or via intermediary billers and claims clearinghouses.
* It can also be used to transmit health care claims and billing
* payment information between payers with different payment responsibilities
* where coordination of benefits is required or between payers
* and regulatory agencies to monitor the rendering, billing, and/or
* payment of health care services within a specific health care/insurance
* industry segment. For purposes of this standard, providers of
* health care products or services may include entities such as
* physicians, hospitals and other medical facilities or suppliers,
* dentists, and pharmacies, and entities providing medical information
* to meet regulatory requirements. The payer refers to a third
* party entity that pays claims or administers the insurance product
* or benefit or both. For example, a payer may be an insurance
* company, health maintenance organization (HMO), preferred provider
* organization (PPO), government agency (Medicare, Medicaid, Civilian
* Health and Medical Program of the Uniformed Services (CHAMPUS),
* etc.) or an entity such as a third party administrator (TPA)
* or third party organization (TPO) that may be contracted by one
* of those groups. A regulatory agency is an entity responsible,
* by law or rule, for administering and monitoring a statutory
* benefits program or a specific health care/insurance industry
* segment.
*@author OBOECodeGenerator
*/
public class p837
{
/** constructor for class p837
*@param inFileName - String filename to be parsed
*@throws OBOEException - most likely transactionset not found
*@throws IOException - most likely input file not found
*/
public p837(String inFileName)
  throws OBOEException, IOException
{
  File fileToParse = new File(inFileName);
  if (fileToParse.exists() == false)
     throw new OBOEException("File: "+ inFileName + " does not exist.");
  X12DocumentHandler dh = new X12DocumentHandler();
  dh.startParsing(new FileReader(fileToParse));
  X12Envelope env = (X12Envelope) dh.getEnvelope();

  Table table;
  FunctionalGroup fg;
  TransactionSet ts;
  int fgCount = env.getFunctionalGroupCount();
  int tsCount = -1;
  for (int fgPosition = 0; fgPosition < fgCount; fgPosition++)
     {
        fg = env.getFunctionalGroup(fgPosition);
        tsCount = fg.getTransactionSetCount();
        for (int tsPosition = 0; tsPosition < tsCount; tsPosition++)
           {
             ts = fg.getTransactionSet(tsPosition);
             table = ts.getHeaderTable();
             if (table != null)
               {
                 extractSegmentTransactionSetHeaderfromTableHeader(table);
                 extractSegmentBeginningofHierarchicalTransactionfromTableHeader(table);
                 extractSegmentTransmissionTypeIdentificationfromTableHeader(table);
                 extractLoop1000AfromTableHeader(table);
                 extractLoop1000BfromTableHeader(table);

              }
             table = ts.getDetailTable();
             if (table != null)
               {
                 extractLoop2000AfromTableDetail(table);
                 extractSegmentTransactionSetTrailerfromTableDetail(table);

              }
           }
     }

}

/** extract data from segment ST that is part of the TableHeader
*<br>Transaction Set Header used 
*<br>To indicate the start of a transaction set and to assign a control number
* @param inTable Table containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentTransactionSetHeaderfromTableHeader(Table inTable)
  throws OBOEException
{
  Segment segment = inTable.getSegment("ST");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 143 Transaction Set Identifier Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 329 Transaction Set Control Number
  if (de != null)
    de.get();
  }

/** extract data from segment BHT that is part of the TableHeader
*<br>Beginning of Hierarchical Transaction used 
*<br>To define the business hierarchical structure of the transaction set and identify the business application purpose and reference data, i.e., number, date, and time
* @param inTable Table containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentBeginningofHierarchicalTransactionfromTableHeader(Table inTable)
  throws OBOEException
{
  Segment segment = inTable.getSegment("BHT");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 1005 Hierarchical Structure Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 353 Transaction Set Purpose Code
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 127 Originator Application Transaction Identifier
  if (de != null)
    de.get();
  de = segment.getDataElement(4);  // 373 Transaction Set Creation Date
  if (de != null)
    de.get();
  de = segment.getDataElement(5);  // 337 Transaction Set Creation Time
  if (de != null)
    de.get();
  de = segment.getDataElement(6);  // 640 Claim or Encounter Identifier
  if (de != null)
    de.get();
  }

/** extract data from segment REF that is part of the TableHeader
*<br>Transmission Type Identification used 
*<br>To specify identifying information
* @param inTable Table containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentTransmissionTypeIdentificationfromTableHeader(Table inTable)
  throws OBOEException
{
  Segment segment = inTable.getSegment("REF");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 128 Reference Identification Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 127 Transmission Type Code
  if (de != null)
    de.get();
  }

/** extract data from loop 1000A that is part of TableHeader
*<br>Submitter Name used 
* @param inTable table containing this loop
*@throws OBOEException - most likely loop not found
*/
public void extractLoop1000AfromTableHeader(Table inTable)
  throws OBOEException
{
  Loop loop = inTable.getLoop("1000A");
    if (loop == null) return;
  extractSegmentSubmitterNamefromLoop1000A(loop);
  extractSegmentAdditionalSubmitterNameInformationfromLoop1000A(loop);
  extractSegmentSubmitterEDIContactInformationfromLoop1000A(loop);
  }

/** extract data from segment NM1 that is part of the Loop1000A
*<br>Submitter Name used 
*<br>To supply the full name of an individual or organizational entity
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentSubmitterNamefromLoop1000A(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("NM1");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 98 Entity Identifier Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1065 Entity Type Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1035 Submitter Last or Organization Name
  if (de != null)
    de.get();
  de = segment.getDataElement(4);  // 1036 Submitter First Name
  if (de != null)
    de.get();
  de = segment.getDataElement(5);  // 1037 Submitter Middle Name
  if (de != null)
    de.get();
  de = segment.getDataElement(8);  // 66 Identification Code Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(9);  // 67 Submitter Identifier
  if (de != null)
    de.get();
  }

/** extract data from segment N2 that is part of the Loop1000A
*<br>Additional Submitter Name Information used 
*<br>To specify additional names or those longer than 35 characters in length
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentAdditionalSubmitterNameInformationfromLoop1000A(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("N2");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 93 Additional Submitter Name
  if (de != null)
    de.get();
  }

/** extract data from segment PER that is part of the Loop1000A
*<br>Submitter EDI Contact Information used 
*<br>To identify a person or office to whom administrative communications should be directed
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentSubmitterEDIContactInformationfromLoop1000A(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("PER");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("PER", i);
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 366 Contact Function Code
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 93 Submitter Contact Name
       if (de != null)
         de.get();
       de = segment.getDataElement(3);       // 365 Communication Number Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(4);       // 364 Communication Number
       if (de != null)
         de.get();
       de = segment.getDataElement(5);       // 365 Communication Number Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(6);       // 364 Communication Number
       if (de != null)
         de.get();
       de = segment.getDataElement(7);       // 365 Communication Number Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(8);       // 364 Communication Number
       if (de != null)
         de.get();
    }
  }

/** extract data from loop 1000B that is part of TableHeader
*<br>Receiver Name used 
* @param inTable table containing this loop
*@throws OBOEException - most likely loop not found
*/
public void extractLoop1000BfromTableHeader(Table inTable)
  throws OBOEException
{
  Loop loop = inTable.getLoop("1000B");
    if (loop == null) return;
  extractSegmentReceiverNamefromLoop1000B(loop);
  extractSegmentReceiverAdditionalNameInformationfromLoop1000B(loop);
  }

/** extract data from segment NM1 that is part of the Loop1000B
*<br>Receiver Name used 
*<br>To supply the full name of an individual or organizational entity
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentReceiverNamefromLoop1000B(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("NM1");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 98 Entity Identifier Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1065 Entity Type Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1035 Receiver Name
  if (de != null)
    de.get();
  de = segment.getDataElement(8);  // 66 Identification Code Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(9);  // 67 Receiver Primary Identifier
  if (de != null)
    de.get();
  }

/** extract data from segment N2 that is part of the Loop1000B
*<br>Receiver Additional Name Information used 
*<br>To specify additional names or those longer than 35 characters in length
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentReceiverAdditionalNameInformationfromLoop1000B(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("N2");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 93 Receiver Additional Name
  if (de != null)
    de.get();
  }

/** extract data from loop 2000A that is part of TableDetail
*<br>Billing/Pay-to Provider Hierarchical Level used 
* @param inTable table containing this loop
*@throws OBOEException - most likely loop not found
*/
public void extractLoop2000AfromTableDetail(Table inTable)
  throws OBOEException
{
  Loop loop;
  int numberInVector = inTable.getCount("2000A");
  for (int i = 0; i <  numberInVector; i++)
   {
     loop = inTable.getLoop("2000A", i);
     if (loop == null) return;
     extractSegmentBillingPaytoProviderHierarchicalLevelfromLoop2000A(loop);
     extractSegmentBillingPaytoProviderSpecialtyInformationfromLoop2000A(loop);
     extractSegmentForeignCurrencyInformationfromLoop2000A(loop);
     extractLoop2010AAfromLoop2000A(loop);
     extractLoop2010ABfromLoop2000A(loop);
     extractLoop2000BfromLoop2000A(loop);
    }
  }

/** extract data from segment HL that is part of the Loop2000A
*<br>Billing/Pay-to Provider Hierarchical Level used 
*<br>To identify dependencies among and the content of hierarchically related groups of data segments
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentBillingPaytoProviderHierarchicalLevelfromLoop2000A(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("HL");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 628 Hierarchical ID Number
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 735 Hierarchical Level Code
  if (de != null)
    de.get();
  de = segment.getDataElement(4);  // 736 Hierarchical Child Code
  if (de != null)
    de.get();
  }

/** extract data from segment PRV that is part of the Loop2000A
*<br>Billing/Pay-to Provider Specialty Information used 
*<br>To specify the identifying characteristics of a provider
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentBillingPaytoProviderSpecialtyInformationfromLoop2000A(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("PRV");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 1221 Provider Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 128 Reference Identification Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 127 Provider Taxonomy Code
  if (de != null)
    de.get();
  }

/** extract data from segment CUR that is part of the Loop2000A
*<br>Foreign Currency Information used 
*<br>To specify the currency (dollars, pounds, francs, etc.) used in a transaction
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentForeignCurrencyInformationfromLoop2000A(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("CUR");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 98 Entity Identifier Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 100 Currency Code
  if (de != null)
    de.get();
  }

/** extract data from loop 2010AA that is part of Loop2000A
*<br>Billing Provider Name used 
* @param inLoop loop containing this loop
*@throws OBOEException - most likely loop not found
*/
public void extractLoop2010AAfromLoop2000A(Loop inLoop)  throws OBOEException
{
  Loop loop = inLoop.getLoop("2010AA");
  if (loop == null) return;
  extractSegmentBillingProviderNamefromLoop2010AA(loop);
  extractSegmentAdditionalBillingProviderNameInformationfromLoop2010AA(loop);
  extractSegmentBillingProviderAddressfromLoop2010AA(loop);
  extractSegmentBillingProviderCityStateZIPCodefromLoop2010AA(loop);
  extractSegmentBillingProviderSecondaryIdentificationfromLoop2010AA(loop);
  extractSegmentCreditDebitCardBillingInformationfromLoop2010AA(loop);
  extractSegmentBillingProviderContactInformationfromLoop2010AA(loop);
  }

/** extract data from segment NM1 that is part of the Loop2010AA
*<br>Billing Provider Name used 
*<br>To supply the full name of an individual or organizational entity
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentBillingProviderNamefromLoop2010AA(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("NM1");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 98 Entity Identifier Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1065 Entity Type Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1035 Billing Provider Last or Organizational Name
  if (de != null)
    de.get();
  de = segment.getDataElement(4);  // 1036 Billing Provider First Name
  if (de != null)
    de.get();
  de = segment.getDataElement(5);  // 1037 Billing Provider Middle Name
  if (de != null)
    de.get();
  de = segment.getDataElement(7);  // 1039 Billing Provider Name Suffix
  if (de != null)
    de.get();
  de = segment.getDataElement(8);  // 66 Identification Code Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(9);  // 67 Billing Provider Identifier
  if (de != null)
    de.get();
  }

/** extract data from segment N2 that is part of the Loop2010AA
*<br>Additional Billing Provider Name Information used 
*<br>To specify additional names or those longer than 35 characters in length
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentAdditionalBillingProviderNameInformationfromLoop2010AA(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("N2");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 93 Billing Provider Additional Name
  if (de != null)
    de.get();
  }

/** extract data from segment N3 that is part of the Loop2010AA
*<br>Billing Provider Address used 
*<br>To specify the location of the named party
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentBillingProviderAddressfromLoop2010AA(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("N3");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 166 Billing Provider Address Line
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 166 Billing Provider Address Line
  if (de != null)
    de.get();
  }

/** extract data from segment N4 that is part of the Loop2010AA
*<br>Billing Provider City/State/ZIP Code used 
*<br>To specify the geographic place of the named party
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentBillingProviderCityStateZIPCodefromLoop2010AA(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("N4");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 19 Billing Provider City Name
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 156 Billing Provider State or Province Code
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 116 Billing Provider Postal Zone or ZIP Code
  if (de != null)
    de.get();
  de = segment.getDataElement(4);  // 26 Country Code
  if (de != null)
    de.get();
  }

/** extract data from segment REF that is part of the Loop2010AA
*<br>Billing Provider Secondary Identification used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentBillingProviderSecondaryIdentificationfromLoop2010AA(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("REF");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("REF", "0B", i);
 // other key values: "1A" "1B" "1C" "1D" "1G" "1H" "1J" "B3" "BQ" "EI" "FH" "G2" "G5" "LU" "SY" "U3" "X5" 
   // there can be 8 of these segments.
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 128 Reference Identification Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 127 Billing Provider Additional Identifier
       if (de != null)
         de.get();
    }
  }

/** extract data from segment REF that is part of the Loop2010AA
*<br>Credit/Debit Card Billing Information used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentCreditDebitCardBillingInformationfromLoop2010AA(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("REF");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("REF", "06", i);
 // other key values: "8U" "EM" "IJ" "LU" "RB" "ST" "TT" 
   // there can be 8 of these segments.
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 128 Reference Identification Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 127 Billing Provider Credit Card Identifier
       if (de != null)
         de.get();
    }
  }

/** extract data from segment PER that is part of the Loop2010AA
*<br>Billing Provider Contact Information used 
*<br>To identify a person or office to whom administrative communications should be directed
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentBillingProviderContactInformationfromLoop2010AA(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("PER");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("PER", i);
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 366 Contact Function Code
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 93 Billing Provider Contact Name
       if (de != null)
         de.get();
       de = segment.getDataElement(3);       // 365 Communication Number Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(4);       // 364 Communication Number
       if (de != null)
         de.get();
       de = segment.getDataElement(5);       // 365 Communication Number Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(6);       // 364 Communication Number
       if (de != null)
         de.get();
       de = segment.getDataElement(7);       // 365 Communication Number Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(8);       // 364 Communication Number
       if (de != null)
         de.get();
    }
  }

/** extract data from loop 2010AB that is part of Loop2000A
*<br>Pay-to Provider Name used 
* @param inLoop loop containing this loop
*@throws OBOEException - most likely loop not found
*/
public void extractLoop2010ABfromLoop2000A(Loop inLoop)  throws OBOEException
{
  Loop loop = inLoop.getLoop("2010AB");
  if (loop == null) return;
  extractSegmentPaytoProviderNamefromLoop2010AB(loop);
  extractSegmentAdditionalPaytoProviderNameInformationfromLoop2010AB(loop);
  extractSegmentPaytoProviderAddressfromLoop2010AB(loop);
  extractSegmentPaytoProviderCityStateZIPCodefromLoop2010AB(loop);
  extractSegmentPaytoProviderSecondaryIdentificationfromLoop2010AB(loop);
  }

/** extract data from segment NM1 that is part of the Loop2010AB
*<br>Pay-to Provider Name used 
*<br>To supply the full name of an individual or organizational entity
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentPaytoProviderNamefromLoop2010AB(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("NM1");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 98 Entity Identifier Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1065 Entity Type Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1035 Pay-to Provider Last or Organizational Name
  if (de != null)
    de.get();
  de = segment.getDataElement(4);  // 1036 Pay-to Provider First Name
  if (de != null)
    de.get();
  de = segment.getDataElement(5);  // 1037 Pay-to Provider Middle Name
  if (de != null)
    de.get();
  de = segment.getDataElement(7);  // 1039 Pay-to Provider Name Suffix
  if (de != null)
    de.get();
  de = segment.getDataElement(8);  // 66 Identification Code Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(9);  // 67 Pay-to Provider Identifier
  if (de != null)
    de.get();
  }

/** extract data from segment N2 that is part of the Loop2010AB
*<br>Additional Pay-to Provider Name Information used 
*<br>To specify additional names or those longer than 35 characters in length
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentAdditionalPaytoProviderNameInformationfromLoop2010AB(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("N2");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 93 Pay-to Provider Additional Name
  if (de != null)
    de.get();
  }

/** extract data from segment N3 that is part of the Loop2010AB
*<br>Pay-to Provider Address used 
*<br>To specify the location of the named party
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentPaytoProviderAddressfromLoop2010AB(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("N3");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 166 Pay-to Provider Address Line
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 166 Pay-to Provider Address Line
  if (de != null)
    de.get();
  }

/** extract data from segment N4 that is part of the Loop2010AB
*<br>Pay-to Provider City/State/ZIP Code used 
*<br>To specify the geographic place of the named party
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentPaytoProviderCityStateZIPCodefromLoop2010AB(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("N4");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 19 Pay-to Provider City Name
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 156 Pay-to Provider State Code
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 116 Pay-to Provider Postal Zone or ZIP Code
  if (de != null)
    de.get();
  de = segment.getDataElement(4);  // 26 Country Code
  if (de != null)
    de.get();
  }

/** extract data from segment REF that is part of the Loop2010AB
*<br>Pay-to-Provider Secondary Identification used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentPaytoProviderSecondaryIdentificationfromLoop2010AB(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("REF");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("REF", i);
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 128 Reference Identification Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 127 Pay-to Provider Identifier
       if (de != null)
         de.get();
    }
  }

/** extract data from loop 2000B that is part of Loop2000A
*<br>Subscriber Hierarchical Level used 
* @param inLoop loop containing this loop
*@throws OBOEException - most likely loop not found
*/
public void extractLoop2000BfromLoop2000A(Loop inLoop)  throws OBOEException
{
  Loop loop;
  int numberInVector = inLoop.getCount("2000B");
  for (int i = 0; i <  numberInVector; i++)
   {
   loop = inLoop.getLoop("2000B", i);
   if (loop == null) return;
      extractSegmentSubscriberHierarchicalLevelfromLoop2000B(loop);
      extractSegmentSubscriberInformationfromLoop2000B(loop);
      extractSegmentPatientInformationfromLoop2000B(loop);
      extractLoop2010BAfromLoop2000B(loop);
      extractLoop2010BBfromLoop2000B(loop);
      extractLoop2010BCfromLoop2000B(loop);
      extractLoop2010BDfromLoop2000B(loop);
      extractLoop2300fromLoop2000B(loop);
      extractLoop2000CfromLoop2000B(loop);
    }
  }

/** extract data from segment HL that is part of the Loop2000B
*<br>Subscriber Hierarchical Level used 
*<br>To identify dependencies among and the content of hierarchically related groups of data segments
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentSubscriberHierarchicalLevelfromLoop2000B(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("HL");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 628 Hierarchical ID Number
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 734 Hierarchical Parent ID Number
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 735 Hierarchical Level Code
  if (de != null)
    de.get();
  de = segment.getDataElement(4);  // 736 Hierarchical Child Code
  if (de != null)
    de.get();
  }

/** extract data from segment SBR that is part of the Loop2000B
*<br>Subscriber Information used 
*<br>To record information specific to the primary insured and the insurance carrier for that insured
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentSubscriberInformationfromLoop2000B(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("SBR");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 1138 Payer Responsibility Sequence Number Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1069 Individual Relationship Code
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 127 Insured Group or Policy Number
  if (de != null)
    de.get();
  de = segment.getDataElement(4);  // 93 Insured Group Name
  if (de != null)
    de.get();
  de = segment.getDataElement(5);  // 1336 Insurance Type Code
  if (de != null)
    de.get();
  de = segment.getDataElement(9);  // 1032 Claim Filing Indicator Code
  if (de != null)
    de.get();
  }

/** extract data from segment PAT that is part of the Loop2000B
*<br>Patient Information used 
*<br>To supply patient information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentPatientInformationfromLoop2000B(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("PAT");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(5);  // 1250 Date Time Period Format Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(6);  // 1251 Insured Individual Death Date
  if (de != null)
    de.get();
  de = segment.getDataElement(7);  // 355 Unit or Basis for Measurement Code
  if (de != null)
    de.get();
  de = segment.getDataElement(8);  // 81 Patient Weight
  if (de != null)
    de.get();
  de = segment.getDataElement(9);  // 1073 Pregnancy Indicator
  if (de != null)
    de.get();
  }

/** extract data from loop 2010BA that is part of Loop2000B
*<br>Subscriber Name used 
* @param inLoop loop containing this loop
*@throws OBOEException - most likely loop not found
*/
public void extractLoop2010BAfromLoop2000B(Loop inLoop)  throws OBOEException
{
  Loop loop = inLoop.getLoop("2010BA");
  if (loop == null) return;
  extractSegmentSubscriberNamefromLoop2010BA(loop);
  extractSegmentAdditionalSubscriberNameInformationfromLoop2010BA(loop);
  extractSegmentSubscriberAddressfromLoop2010BA(loop);
  extractSegmentSubscriberCityStateZIPCodefromLoop2010BA(loop);
  extractSegmentSubscriberDemographicInformationfromLoop2010BA(loop);
  extractSegmentSubscriberSecondaryIdentificationfromLoop2010BA(loop);
  extractSegmentPropertyandCasualtyClaimNumberfromLoop2010BA(loop);
  }

/** extract data from segment NM1 that is part of the Loop2010BA
*<br>Subscriber Name used 
*<br>To supply the full name of an individual or organizational entity
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentSubscriberNamefromLoop2010BA(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("NM1");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 98 Entity Identifier Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1065 Entity Type Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1035 Subscriber Last Name
  if (de != null)
    de.get();
  de = segment.getDataElement(4);  // 1036 Subscriber First Name
  if (de != null)
    de.get();
  de = segment.getDataElement(5);  // 1037 Subscriber Middle Name
  if (de != null)
    de.get();
  de = segment.getDataElement(7);  // 1039 Subscriber Name Suffix
  if (de != null)
    de.get();
  de = segment.getDataElement(8);  // 66 Identification Code Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(9);  // 67 Subscriber Primary Identifier
  if (de != null)
    de.get();
  }

/** extract data from segment N2 that is part of the Loop2010BA
*<br>Additional Subscriber Name Information used 
*<br>To specify additional names or those longer than 35 characters in length
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentAdditionalSubscriberNameInformationfromLoop2010BA(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("N2");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 93 Subscriber Supplemental Description
  if (de != null)
    de.get();
  }

/** extract data from segment N3 that is part of the Loop2010BA
*<br>Subscriber Address used 
*<br>To specify the location of the named party
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentSubscriberAddressfromLoop2010BA(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("N3");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 166 Subscriber Address Line
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 166 Subscriber Address Line
  if (de != null)
    de.get();
  }

/** extract data from segment N4 that is part of the Loop2010BA
*<br>Subscriber City/State/ZIP Code used 
*<br>To specify the geographic place of the named party
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentSubscriberCityStateZIPCodefromLoop2010BA(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("N4");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 19 Subscriber City Name
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 156 Subscriber State Code
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 116 Subscriber Postal Zone or ZIP Code
  if (de != null)
    de.get();
  de = segment.getDataElement(4);  // 26 Country Code
  if (de != null)
    de.get();
  }

/** extract data from segment DMG that is part of the Loop2010BA
*<br>Subscriber Demographic Information used 
*<br>To supply demographic information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentSubscriberDemographicInformationfromLoop2010BA(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("DMG");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 1250 Date Time Period Format Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1251 Subscriber Birth Date
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1068 Subscriber Gender Code
  if (de != null)
    de.get();
  }

/** extract data from segment REF that is part of the Loop2010BA
*<br>Subscriber Secondary Identification used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentSubscriberSecondaryIdentificationfromLoop2010BA(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("REF");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("REF", "1W", i);
 // other key values: "23" "IG" "SY" 
   // there can be 4 of these segments.
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 128 Reference Identification Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 127 Subscriber Supplemental Identifier
       if (de != null)
         de.get();
    }
  }

/** extract data from segment REF that is part of the Loop2010BA
*<br>Property and Casualty Claim Number used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentPropertyandCasualtyClaimNumberfromLoop2010BA(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("REF", "Y4");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 128 Reference Identification Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 127 Property Casualty Claim Number
  if (de != null)
    de.get();
  }

/** extract data from loop 2010BB that is part of Loop2000B
*<br>Payer Name used 
* @param inLoop loop containing this loop
*@throws OBOEException - most likely loop not found
*/
public void extractLoop2010BBfromLoop2000B(Loop inLoop)  throws OBOEException
{
  Loop loop = inLoop.getLoop("2010BB");
  if (loop == null) return;
  extractSegmentPayerNamefromLoop2010BB(loop);
  extractSegmentAdditionalPayerNameInformationfromLoop2010BB(loop);
  extractSegmentPayerAddressfromLoop2010BB(loop);
  extractSegmentPayerCityStateZIPCodefromLoop2010BB(loop);
  extractSegmentPayerSecondaryIdentificationfromLoop2010BB(loop);
  }

/** extract data from segment NM1 that is part of the Loop2010BB
*<br>Payer Name used 
*<br>To supply the full name of an individual or organizational entity
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentPayerNamefromLoop2010BB(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("NM1");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 98 Entity Identifier Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1065 Entity Type Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1035 Payer Name
  if (de != null)
    de.get();
  de = segment.getDataElement(8);  // 66 Identification Code Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(9);  // 67 Payer Identifier
  if (de != null)
    de.get();
  }

/** extract data from segment N2 that is part of the Loop2010BB
*<br>Additional Payer Name Information used 
*<br>To specify additional names or those longer than 35 characters in length
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentAdditionalPayerNameInformationfromLoop2010BB(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("N2");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 93 Payer Additional Name
  if (de != null)
    de.get();
  }

/** extract data from segment N3 that is part of the Loop2010BB
*<br>Payer Address used 
*<br>To specify the location of the named party
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentPayerAddressfromLoop2010BB(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("N3");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 166 Payer Address Line
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 166 Payer Address Line
  if (de != null)
    de.get();
  }

/** extract data from segment N4 that is part of the Loop2010BB
*<br>Payer City/State/ZIP Code used 
*<br>To specify the geographic place of the named party
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentPayerCityStateZIPCodefromLoop2010BB(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("N4");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 19 Payer City Name
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 156 Payer State Code
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 116 Payer Postal Zone or ZIP Code
  if (de != null)
    de.get();
  de = segment.getDataElement(4);  // 26 Country Code
  if (de != null)
    de.get();
  }

/** extract data from segment REF that is part of the Loop2010BB
*<br>Payer Secondary Identification used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentPayerSecondaryIdentificationfromLoop2010BB(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("REF");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("REF", i);
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 128 Reference Identification Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 127 Payer Additional Identifier
       if (de != null)
         de.get();
    }
  }

/** extract data from loop 2010BC that is part of Loop2000B
*<br>Responsible Party Name used 
* @param inLoop loop containing this loop
*@throws OBOEException - most likely loop not found
*/
public void extractLoop2010BCfromLoop2000B(Loop inLoop)  throws OBOEException
{
  Loop loop = inLoop.getLoop("2010BC");
  if (loop == null) return;
  extractSegmentResponsiblePartyNamefromLoop2010BC(loop);
  extractSegmentAdditionalResponsiblePartyNameInformationfromLoop2010BC(loop);
  extractSegmentResponsiblePartyAddressfromLoop2010BC(loop);
  extractSegmentResponsiblePartyCityStateZIPCodefromLoop2010BC(loop);
  }

/** extract data from segment NM1 that is part of the Loop2010BC
*<br>Responsible Party Name used 
*<br>To supply the full name of an individual or organizational entity
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentResponsiblePartyNamefromLoop2010BC(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("NM1");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 98 Entity Identifier Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1065 Entity Type Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1035 Responsible Party Last or Organization Name
  if (de != null)
    de.get();
  de = segment.getDataElement(4);  // 1036 Responsible Party First Name
  if (de != null)
    de.get();
  de = segment.getDataElement(5);  // 1037 Responsible Party Middle Name
  if (de != null)
    de.get();
  de = segment.getDataElement(7);  // 1039 Responsible Party Suffix Name
  if (de != null)
    de.get();
  }

/** extract data from segment N2 that is part of the Loop2010BC
*<br>Additional Responsible Party Name Information used 
*<br>To specify additional names or those longer than 35 characters in length
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentAdditionalResponsiblePartyNameInformationfromLoop2010BC(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("N2");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 93 Responsible Party Additional Name
  if (de != null)
    de.get();
  }

/** extract data from segment N3 that is part of the Loop2010BC
*<br>Responsible Party Address used 
*<br>To specify the location of the named party
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentResponsiblePartyAddressfromLoop2010BC(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("N3");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 166 Responsible Party Address Line
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 166 Responsible Party Address Line
  if (de != null)
    de.get();
  }

/** extract data from segment N4 that is part of the Loop2010BC
*<br>Responsible Party City/State/ZIP Code used 
*<br>To specify the geographic place of the named party
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentResponsiblePartyCityStateZIPCodefromLoop2010BC(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("N4");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 19 Responsible Party City Name
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 156 Responsible Party State Code
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 116 Responsible Party Postal Zone or ZIP Code
  if (de != null)
    de.get();
  de = segment.getDataElement(4);  // 26 Country Code
  if (de != null)
    de.get();
  }

/** extract data from loop 2010BD that is part of Loop2000B
*<br>Credit/Debit Card Holder Name used 
* @param inLoop loop containing this loop
*@throws OBOEException - most likely loop not found
*/
public void extractLoop2010BDfromLoop2000B(Loop inLoop)  throws OBOEException
{
  Loop loop = inLoop.getLoop("2010BD");
  if (loop == null) return;
  extractSegmentCreditDebitCardHolderNamefromLoop2010BD(loop);
  extractSegmentAdditionalCreditDebitCardHolderNameInformationfromLoop2010BD(loop);
  extractSegmentCreditDebitCardInformationfromLoop2010BD(loop);
  }

/** extract data from segment NM1 that is part of the Loop2010BD
*<br>Credit/Debit Card Holder Name used 
*<br>To supply the full name of an individual or organizational entity
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentCreditDebitCardHolderNamefromLoop2010BD(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("NM1");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 98 Entity Identifier Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1065 Entity Type Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1035 Credit or Debit Card Holder Last or Organizational Name
  if (de != null)
    de.get();
  de = segment.getDataElement(4);  // 1036 Credit or Debit Card Holder First Name
  if (de != null)
    de.get();
  de = segment.getDataElement(5);  // 1037 Credit or Debit Card Holder Middle Name
  if (de != null)
    de.get();
  de = segment.getDataElement(7);  // 1039 Credit or Debit Card Holder Name Suffix
  if (de != null)
    de.get();
  de = segment.getDataElement(8);  // 66 Identification Code Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(9);  // 67 Credit or Debit Card Number
  if (de != null)
    de.get();
  }

/** extract data from segment N2 that is part of the Loop2010BD
*<br>Additional Credit/Debit Card Holder Name Information used 
*<br>To specify additional names or those longer than 35 characters in length
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentAdditionalCreditDebitCardHolderNameInformationfromLoop2010BD(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("N2");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 93 Credit or Debit Card Holder Additional Name
  if (de != null)
    de.get();
  }

/** extract data from segment REF that is part of the Loop2010BD
*<br>Credit/Debit Card Information used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentCreditDebitCardInformationfromLoop2010BD(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("REF");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("REF", i);
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 128 Reference Identification Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 127 Credit or Debit Card Authorization Number
       if (de != null)
         de.get();
    }
  }

/** extract data from loop 2300 that is part of Loop2000B
*<br>Claim Information used 
* @param inLoop loop containing this loop
*@throws OBOEException - most likely loop not found
*/
public void extractLoop2300fromLoop2000B(Loop inLoop)  throws OBOEException
{
  Loop loop;
  int numberInVector = inLoop.getCount("2300");
  for (int i = 0; i <  numberInVector; i++)
   {
   loop = inLoop.getLoop("2300", i);
   if (loop == null) return;
      extractSegmentClaimInformationfromLoop2300(loop);
      extractSegmentDateOrderDatefromLoop2300(loop);
      extractSegmentDateInitialTreatmentfromLoop2300(loop);
      extractSegmentDateReferralDatefromLoop2300(loop);
      extractSegmentDateDateLastSeenfromLoop2300(loop);
      extractSegmentDateOnsetofCurrentIllnessSymptomfromLoop2300(loop);
      extractSegmentDateAcuteManifestationfromLoop2300(loop);
      extractSegmentDateSimilarIllnessSymptomOnsetfromLoop2300(loop);
      extractSegmentDateAccidentfromLoop2300(loop);
      extractSegmentDateLastMenstrualPeriodfromLoop2300(loop);
      extractSegmentDateLastXrayfromLoop2300(loop);
      extractSegmentDateEstimatedDateofBirthfromLoop2300(loop);
      extractSegmentDateHearingandVisionPrescriptionDatefromLoop2300(loop);
      extractSegmentDateDisabilityBeginfromLoop2300(loop);
      extractSegmentDateDisabilityEndfromLoop2300(loop);
      extractSegmentDateLastWorkedfromLoop2300(loop);
      extractSegmentDateAuthorizedReturntoWorkfromLoop2300(loop);
      extractSegmentDateAdmissionfromLoop2300(loop);
      extractSegmentDateDischargefromLoop2300(loop);
      extractSegmentDateAssumedandRelinquishedCareDatesfromLoop2300(loop);
      extractSegmentClaimSupplementalInformationfromLoop2300(loop);
      extractSegmentContractInformationfromLoop2300(loop);
      extractSegmentCreditDebitCardMaximumAmountfromLoop2300(loop);
      extractSegmentPatientAmountPaidfromLoop2300(loop);
      extractSegmentTotalPurchasedServiceAmountfromLoop2300(loop);
      extractSegmentServiceAuthorizationExceptionCodefromLoop2300(loop);
      extractSegmentMandatoryMedicareSection4081CrossoverIndicatorfromLoop2300(loop);
      extractSegmentMammographyCertificationNumberfromLoop2300(loop);
      extractSegmentPriorAuthorizationorReferralNumberfromLoop2300(loop);
      extractSegmentOriginalReferenceNumberICNDCNfromLoop2300(loop);
      extractSegmentClinicalLaboratoryImprovementAmendmentCLIANumberfromLoop2300(loop);
      extractSegmentRepricedClaimNumberfromLoop2300(loop);
      extractSegmentAdjustedRepricedClaimNumberfromLoop2300(loop);
      extractSegmentInvestigationalDeviceExemptionNumberfromLoop2300(loop);
      extractSegmentClaimIdentificationNumberforClearingHousesandOtherTransmissionIntermediariesfromLoop2300(loop);
      extractSegmentAmbulatoryPatientGroupAPGfromLoop2300(loop);
      extractSegmentMedicalRecordNumberfromLoop2300(loop);
      extractSegmentDemonstrationProjectIdentifierfromLoop2300(loop);
      extractSegmentFileInformationfromLoop2300(loop);
      extractSegmentClaimNotefromLoop2300(loop);
      extractSegmentAmbulanceTransportInformationfromLoop2300(loop);
      extractSegmentSpinalManipulationServiceInformationfromLoop2300(loop);
      extractSegmentAmbulanceCertificationfromLoop2300(loop);
      extractSegmentPatientConditionInformationVisionfromLoop2300(loop);
      extractSegmentHomeboundIndicatorfromLoop2300(loop);
      extractSegmentHealthCareDiagnosisCodefromLoop2300(loop);
      extractSegmentClaimPricingRepricingInformationfromLoop2300(loop);
      extractLoop2305fromLoop2300(loop);
      extractLoop2310AfromLoop2300(loop);
      extractLoop2310BfromLoop2300(loop);
      extractLoop2310CfromLoop2300(loop);
      extractLoop2310DfromLoop2300(loop);
      extractLoop2310EfromLoop2300(loop);
      extractLoop2320fromLoop2300(loop);
      extractLoop2400fromLoop2300(loop);
    }
  }

/** extract data from segment CLM that is part of the Loop2300
*<br>Claim Information used 
*<br>To specify basic data about the claim
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentClaimInformationfromLoop2300(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("CLM");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 1028 Patient Account Number
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 782 Total Claim Charge Amount
  if (de != null)
    de.get();
    CompositeDE  composite = (CompositeDE) segment.getCompositeDE(5);  // C023 Health Care Service
  if (composite == null)
    return;
  de = composite.getDataElement(1);  // composite element 1331 Facility Type Code
  if (de != null)
    de.get();
  de = composite.getDataElement(3);  // composite element 1325 Claim Frequency Code
  if (de != null)
    de.get();
  de = segment.getDataElement(6);  // 1073 Provider or Supplier Signature Indicator
  if (de != null)
    de.get();
  de = segment.getDataElement(7);  // 1359 Medicare Assignment Code
  if (de != null)
    de.get();
  de = segment.getDataElement(8);  // 1073 Benefits Assignment Certification Indicator
  if (de != null)
    de.get();
  de = segment.getDataElement(9);  // 1363 Release of Information Code
  if (de != null)
    de.get();
  de = segment.getDataElement(10);  // 1351 Patient Signature Source Code
  if (de != null)
    de.get();
  composite = (CompositeDE) segment.getCompositeDE(11);  // C024 Related
  if (composite == null)
    return;
  de = composite.getDataElement(1);  // composite element 1362 Related Causes Code
  if (de != null)
    de.get();
  de = composite.getDataElement(2);  // composite element 1362 Related Causes Code
  if (de != null)
    de.get();
  de = composite.getDataElement(3);  // composite element 1362 Related Causes Code
  if (de != null)
    de.get();
  de = composite.getDataElement(4);  // composite element 156 Auto Accident State or Province Code
  if (de != null)
    de.get();
  de = composite.getDataElement(5);  // composite element 26 Country Code
  if (de != null)
    de.get();
  de = segment.getDataElement(12);  // 1366 Special Program Indicator
  if (de != null)
    de.get();
  de = segment.getDataElement(16);  // 1360 Participation Agreement
  if (de != null)
    de.get();
  de = segment.getDataElement(20);  // 1514 Delay Reason Code
  if (de != null)
    de.get();
  }

/** extract data from segment DTP that is part of the Loop2300
*<br>Date - Order Date used 
*<br>To specify any or all of a date, a time, or a time period
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentDateOrderDatefromLoop2300(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("DTP", "938");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 374 Date Time Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1250 Date Time Period Format Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1251 Order Date
  if (de != null)
    de.get();
  }

/** extract data from segment DTP that is part of the Loop2300
*<br>Date - Initial Treatment used 
*<br>To specify any or all of a date, a time, or a time period
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentDateInitialTreatmentfromLoop2300(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("DTP", "454");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 374 Date Time Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1250 Date Time Period Format Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1251 Initial Treatment Date
  if (de != null)
    de.get();
  }

/** extract data from segment DTP that is part of the Loop2300
*<br>Date - Referral Date used 
*<br>To specify any or all of a date, a time, or a time period
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentDateReferralDatefromLoop2300(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("DTP", "330");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 374 Date Time Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1250 Date Time Period Format Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1251 Referral Date
  if (de != null)
    de.get();
  }

/** extract data from segment DTP that is part of the Loop2300
*<br>Date - Date Last Seen used 
*<br>To specify any or all of a date, a time, or a time period
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentDateDateLastSeenfromLoop2300(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("DTP", "304");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 374 Date Time Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1250 Date Time Period Format Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1251 Last Seen Date
  if (de != null)
    de.get();
  }

/** extract data from segment DTP that is part of the Loop2300
*<br>Date - Onset of Current Illness/Symptom used 
*<br>To specify any or all of a date, a time, or a time period
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentDateOnsetofCurrentIllnessSymptomfromLoop2300(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("DTP", "431");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 374 Date Time Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1250 Date Time Period Format Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1251 Onset of Current Illness or Injury Date
  if (de != null)
    de.get();
  }

/** extract data from segment DTP that is part of the Loop2300
*<br>Date - Acute Manifestation used 
*<br>To specify any or all of a date, a time, or a time period
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentDateAcuteManifestationfromLoop2300(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("DTP");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("DTP", "453", i);
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 374 Date Time Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 1250 Date Time Period Format Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(3);       // 1251 Acute Manifestation Date
       if (de != null)
         de.get();
    }
  }

/** extract data from segment DTP that is part of the Loop2300
*<br>Date - Similar Illness/Symptom Onset used 
*<br>To specify any or all of a date, a time, or a time period
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentDateSimilarIllnessSymptomOnsetfromLoop2300(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("DTP");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("DTP", "438", i);
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 374 Date Time Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 1250 Date Time Period Format Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(3);       // 1251 Similar Illness or Symptom Date
       if (de != null)
         de.get();
    }
  }

/** extract data from segment DTP that is part of the Loop2300
*<br>Date - Accident used 
*<br>To specify any or all of a date, a time, or a time period
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentDateAccidentfromLoop2300(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("DTP");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("DTP", "439", i);
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 374 Date Time Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 1250 Date Time Period Format Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(3);       // 1251 Accident Date
       if (de != null)
         de.get();
    }
  }

/** extract data from segment DTP that is part of the Loop2300
*<br>Date - Last Menstrual Period used 
*<br>To specify any or all of a date, a time, or a time period
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentDateLastMenstrualPeriodfromLoop2300(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("DTP", "484");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 374 Date Time Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1250 Date Time Period Format Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1251 Last Menstrual Period Date
  if (de != null)
    de.get();
  }

/** extract data from segment DTP that is part of the Loop2300
*<br>Date - Last X-ray used 
*<br>To specify any or all of a date, a time, or a time period
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentDateLastXrayfromLoop2300(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("DTP", "455");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 374 Date Time Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1250 Date Time Period Format Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1251 Last X-Ray Date
  if (de != null)
    de.get();
  }

/** extract data from segment DTP that is part of the Loop2300
*<br>Date - Estimated Date of Birth used 
*<br>To specify any or all of a date, a time, or a time period
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentDateEstimatedDateofBirthfromLoop2300(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("DTP", "ABC");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 374 Date Time Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1250 Date Time Period Format Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1251 Estimated Birth Date
  if (de != null)
    de.get();
  }

/** extract data from segment DTP that is part of the Loop2300
*<br>Date - Hearing and Vision Prescription Date used 
*<br>To specify any or all of a date, a time, or a time period
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentDateHearingandVisionPrescriptionDatefromLoop2300(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("DTP", "471");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 374 Date Time Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1250 Date Time Period Format Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1251 Prescription Date
  if (de != null)
    de.get();
  }

/** extract data from segment DTP that is part of the Loop2300
*<br>Date - Disability Begin used 
*<br>To specify any or all of a date, a time, or a time period
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentDateDisabilityBeginfromLoop2300(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("DTP");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("DTP", "360", i);
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 374 Date Time Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 1250 Date Time Period Format Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(3);       // 1251 Disability From Date
       if (de != null)
         de.get();
    }
  }

/** extract data from segment DTP that is part of the Loop2300
*<br>Date - Disability End used 
*<br>To specify any or all of a date, a time, or a time period
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentDateDisabilityEndfromLoop2300(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("DTP");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("DTP", "361", i);
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 374 Date Time Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 1250 Date Time Period Format Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(3);       // 1251 Disability To Date
       if (de != null)
         de.get();
    }
  }

/** extract data from segment DTP that is part of the Loop2300
*<br>Date - Last Worked used 
*<br>To specify any or all of a date, a time, or a time period
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentDateLastWorkedfromLoop2300(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("DTP", "297");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 374 Date Time Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1250 Date Time Period Format Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1251 Last Worked Date
  if (de != null)
    de.get();
  }

/** extract data from segment DTP that is part of the Loop2300
*<br>Date - Authorized Return to Work used 
*<br>To specify any or all of a date, a time, or a time period
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentDateAuthorizedReturntoWorkfromLoop2300(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("DTP", "296");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 374 Date Time Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1250 Date Time Period Format Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1251 Work Return Date
  if (de != null)
    de.get();
  }

/** extract data from segment DTP that is part of the Loop2300
*<br>Date - Admission used 
*<br>To specify any or all of a date, a time, or a time period
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentDateAdmissionfromLoop2300(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("DTP", "435");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 374 Date Time Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1250 Date Time Period Format Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1251 Related Hospitalization Admission Date
  if (de != null)
    de.get();
  }

/** extract data from segment DTP that is part of the Loop2300
*<br>Date - Discharge used 
*<br>To specify any or all of a date, a time, or a time period
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentDateDischargefromLoop2300(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("DTP", "096");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 374 Date Time Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1250 Date Time Period Format Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1251 Related Hospitalization Discharge Date
  if (de != null)
    de.get();
  }

/** extract data from segment DTP that is part of the Loop2300
*<br>Date - Assumed and Relinquished Care Dates used 
*<br>To specify any or all of a date, a time, or a time period
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentDateAssumedandRelinquishedCareDatesfromLoop2300(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("DTP");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("DTP", "090", i);
 // other key values: "091" 
   // there can be 2 of these segments.
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 374 Date Time Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 1250 Date Time Period Format Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(3);       // 1251 Assumed or Relinquished Care Date
       if (de != null)
         de.get();
    }
  }

/** extract data from segment PWK that is part of the Loop2300
*<br>Claim Supplemental Information used 
*<br>To identify the type or transmission or both of paperwork or supporting information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentClaimSupplementalInformationfromLoop2300(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("PWK");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("PWK", i);
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 755 Attachment Report Type Code
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 756 Attachment Transmission Code
       if (de != null)
         de.get();
       de = segment.getDataElement(5);       // 66 Identification Code Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(6);       // 67 Attachment Control Number
       if (de != null)
         de.get();
    }
  }

/** extract data from segment CN1 that is part of the Loop2300
*<br>Contract Information used 
*<br>To specify basic data about the contract or contract line item
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentContractInformationfromLoop2300(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("CN1");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 1166 Contract Type Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 782 Contract Amount
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 332 Contract Percentage
  if (de != null)
    de.get();
  de = segment.getDataElement(4);  // 127 Contract Code
  if (de != null)
    de.get();
  de = segment.getDataElement(5);  // 338 Terms Discount Percentage
  if (de != null)
    de.get();
  de = segment.getDataElement(6);  // 799 Contract Version Identifier
  if (de != null)
    de.get();
  }

/** extract data from segment AMT that is part of the Loop2300
*<br>Credit/Debit Card Maximum Amount used 
*<br>To indicate the total monetary amount
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentCreditDebitCardMaximumAmountfromLoop2300(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("AMT", "MA");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 522 Amount Qualifier Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 782 Credit or Debit Card Maximum Amount
  if (de != null)
    de.get();
  }

/** extract data from segment AMT that is part of the Loop2300
*<br>Patient Amount Paid used 
*<br>To indicate the total monetary amount
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentPatientAmountPaidfromLoop2300(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("AMT", "F5");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 522 Amount Qualifier Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 782 Patient Amount Paid
  if (de != null)
    de.get();
  }

/** extract data from segment AMT that is part of the Loop2300
*<br>Total Purchased Service Amount used 
*<br>To indicate the total monetary amount
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentTotalPurchasedServiceAmountfromLoop2300(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("AMT", "NE");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 522 Amount Qualifier Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 782 Total Purchased Service Amount
  if (de != null)
    de.get();
  }

/** extract data from segment REF that is part of the Loop2300
*<br>Service Authorization Exception Code used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentServiceAuthorizationExceptionCodefromLoop2300(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("REF", "4N");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 128 Reference Identification Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 127 Service Authorization Exception Code
  if (de != null)
    de.get();
  }

/** extract data from segment REF that is part of the Loop2300
*<br>Mandatory Medicare (Section 4081) Crossover Indicator used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentMandatoryMedicareSection4081CrossoverIndicatorfromLoop2300(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("REF", "F5");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 128 Reference Identification Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 127 Medicare Section 4081 Indicator
  if (de != null)
    de.get();
  }

/** extract data from segment REF that is part of the Loop2300
*<br>Mammography Certification Number used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentMammographyCertificationNumberfromLoop2300(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("REF", "EW");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 128 Reference Identification Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 127 Mammography Certification Number
  if (de != null)
    de.get();
  }

/** extract data from segment REF that is part of the Loop2300
*<br>Prior Authorization or Referral Number used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentPriorAuthorizationorReferralNumberfromLoop2300(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("REF");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("REF", "9F", i);
 // other key values: "G1" 
   // there can be 2 of these segments.
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 128 Reference Identification Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 127 Prior Authorization or Referral Number
       if (de != null)
         de.get();
    }
  }

/** extract data from segment REF that is part of the Loop2300
*<br>Original Reference Number (ICN/DCN) used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentOriginalReferenceNumberICNDCNfromLoop2300(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("REF", "F8");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 128 Reference Identification Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 127 Claim Original Reference Number
  if (de != null)
    de.get();
  }

/** extract data from segment REF that is part of the Loop2300
*<br>Clinical Laboratory Improvement Amendment (CLIA) Number used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentClinicalLaboratoryImprovementAmendmentCLIANumberfromLoop2300(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("REF");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("REF", "X4", i);
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 128 Reference Identification Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 127 Clinical Laboratory Improvement Amendment Number
       if (de != null)
         de.get();
    }
  }

/** extract data from segment REF that is part of the Loop2300
*<br>Repriced Claim Number used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentRepricedClaimNumberfromLoop2300(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("REF", "9A");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 128 Reference Identification Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 127 Repriced Claim Reference Number
  if (de != null)
    de.get();
  }

/** extract data from segment REF that is part of the Loop2300
*<br>Adjusted Repriced Claim Number used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentAdjustedRepricedClaimNumberfromLoop2300(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("REF", "9C");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 128 Reference Identification Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 127 Adjusted Repriced Claim Reference Number
  if (de != null)
    de.get();
  }

/** extract data from segment REF that is part of the Loop2300
*<br>Investigational Device Exemption Number used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentInvestigationalDeviceExemptionNumberfromLoop2300(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("REF", "LX");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 128 Reference Identification Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 127 Investigational Device Exemption Identifier
  if (de != null)
    de.get();
  }

/** extract data from segment REF that is part of the Loop2300
*<br>Claim Identification Number for Clearing Houses and Other Transmission Intermediaries used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentClaimIdentificationNumberforClearingHousesandOtherTransmissionIntermediariesfromLoop2300(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("REF", "D9");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 128 Reference Identification Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 127 Clearinghouse Trace Number
  if (de != null)
    de.get();
  }

/** extract data from segment REF that is part of the Loop2300
*<br>Ambulatory Patient Group (APG) used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentAmbulatoryPatientGroupAPGfromLoop2300(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("REF");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("REF", "1S", i);
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 128 Reference Identification Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 127 Ambulatory Patient Group Number
       if (de != null)
         de.get();
    }
  }

/** extract data from segment REF that is part of the Loop2300
*<br>Medical Record Number used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentMedicalRecordNumberfromLoop2300(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("REF", "EA");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 128 Reference Identification Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 127 Medical Record Number
  if (de != null)
    de.get();
  }

/** extract data from segment REF that is part of the Loop2300
*<br>Demonstration Project Identifier used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentDemonstrationProjectIdentifierfromLoop2300(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("REF", "P4");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 128 Reference Identification Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 127 Demonstration Project Identifier
  if (de != null)
    de.get();
  }

/** extract data from segment K3 that is part of the Loop2300
*<br>File Information used 
*<br>To transmit a fixed-format record or matrix contents
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentFileInformationfromLoop2300(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("K3");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("K3", i);
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 449 Fixed Format Information
       if (de != null)
         de.get();
    }
  }

/** extract data from segment NTE that is part of the Loop2300
*<br>Claim Note used 
*<br>To transmit information in a free-form format, if necessary, for comment or special instruction
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentClaimNotefromLoop2300(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("NTE");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 363 Note Reference Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 352 Claim Note Text
  if (de != null)
    de.get();
  }

/** extract data from segment CR1 that is part of the Loop2300
*<br>Ambulance Transport Information used 
*<br>To supply information related to the ambulance service rendered to a patient
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentAmbulanceTransportInformationfromLoop2300(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("CR1");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 355 Unit or Basis for Measurement Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 81 Patient Weight
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1316 Ambulance Transport Code
  if (de != null)
    de.get();
  de = segment.getDataElement(4);  // 1317 Ambulance Transport Reason Code
  if (de != null)
    de.get();
  de = segment.getDataElement(5);  // 355 Unit or Basis for Measurement Code
  if (de != null)
    de.get();
  de = segment.getDataElement(6);  // 380 Transport Distance
  if (de != null)
    de.get();
  de = segment.getDataElement(9);  // 352 Round Trip Purpose Description
  if (de != null)
    de.get();
  de = segment.getDataElement(10);  // 352 Stretcher Purpose Description
  if (de != null)
    de.get();
  }

/** extract data from segment CR2 that is part of the Loop2300
*<br>Spinal Manipulation Service Information used 
*<br>To supply information related to the chiropractic service rendered to a patient
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentSpinalManipulationServiceInformationfromLoop2300(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("CR2");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 609 Treatment Series Number
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 380 Treatment Count
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1367 Subluxation Level Code
  if (de != null)
    de.get();
  de = segment.getDataElement(4);  // 1367 Subluxation Level Code
  if (de != null)
    de.get();
  de = segment.getDataElement(5);  // 355 Unit or Basis for Measurement Code
  if (de != null)
    de.get();
  de = segment.getDataElement(6);  // 380 Treatment Period Count
  if (de != null)
    de.get();
  de = segment.getDataElement(7);  // 380 Monthly Treatment Count
  if (de != null)
    de.get();
  de = segment.getDataElement(8);  // 1342 Patient Condition Code
  if (de != null)
    de.get();
  de = segment.getDataElement(9);  // 1073 Complication Indicator
  if (de != null)
    de.get();
  de = segment.getDataElement(10);  // 352 Patient Condition Description
  if (de != null)
    de.get();
  de = segment.getDataElement(11);  // 352 Patient Condition Description
  if (de != null)
    de.get();
  de = segment.getDataElement(12);  // 1073 X-ray Availability Indicator
  if (de != null)
    de.get();
  }

/** extract data from segment CRC that is part of the Loop2300
*<br>Ambulance Certification used 
*<br>To supply information on conditions
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentAmbulanceCertificationfromLoop2300(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("CRC");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("CRC", "07", i);
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 1136 Code Category
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 1073 Certification Condition Indicator
       if (de != null)
         de.get();
       de = segment.getDataElement(3);       // 1321 Condition Code
       if (de != null)
         de.get();
       de = segment.getDataElement(4);       // 1321 Condition Code
       if (de != null)
         de.get();
       de = segment.getDataElement(5);       // 1321 Condition Code
       if (de != null)
         de.get();
       de = segment.getDataElement(6);       // 1321 Condition Code
       if (de != null)
         de.get();
       de = segment.getDataElement(7);       // 1321 Condition Code
       if (de != null)
         de.get();
    }
  }

/** extract data from segment CRC that is part of the Loop2300
*<br>Patient Condition Information: Vision used 
*<br>To supply information on conditions
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentPatientConditionInformationVisionfromLoop2300(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("CRC");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("CRC", "E1", i);
 // other key values: "E2" "E3" 
   // there can be 3 of these segments.
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 1136 Code Category
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 1073 Certification Condition Indicator
       if (de != null)
         de.get();
       de = segment.getDataElement(3);       // 1321 Condition Code
       if (de != null)
         de.get();
       de = segment.getDataElement(4);       // 1321 Condition Code
       if (de != null)
         de.get();
       de = segment.getDataElement(5);       // 1321 Condition Code
       if (de != null)
         de.get();
       de = segment.getDataElement(6);       // 1321 Condition Code
       if (de != null)
         de.get();
       de = segment.getDataElement(7);       // 1321 Condition Code
       if (de != null)
         de.get();
    }
  }

/** extract data from segment CRC that is part of the Loop2300
*<br>Homebound Indicator used 
*<br>To supply information on conditions
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentHomeboundIndicatorfromLoop2300(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("CRC", "75");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 1136 Code Category
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1073 Certification Condition Indicator
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1321 Homebound Indicator
  if (de != null)
    de.get();
  }

/** extract data from segment HI that is part of the Loop2300
*<br>Health Care Diagnosis Code used 
*<br>To supply information related to the delivery of health care
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentHealthCareDiagnosisCodefromLoop2300(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("HI");
  if (segment == null)
    return;
  DataElement de;
    CompositeDE  composite = (CompositeDE) segment.getCompositeDE(1);  // C022 Health Care
  if (composite == null)
    return;
  de = composite.getDataElement(1);  // composite element 1270 Diagnosis Type Code
  if (de != null)
    de.get();
  de = composite.getDataElement(2);  // composite element 1271 Diagnosis Code
  if (de != null)
    de.get();
  composite = (CompositeDE) segment.getCompositeDE(2);  // C022 Health Care
  if (composite == null)
    return;
  de = composite.getDataElement(1);  // composite element 1270 Diagnosis Type Code
  if (de != null)
    de.get();
  de = composite.getDataElement(2);  // composite element 1271 Diagnosis Code
  if (de != null)
    de.get();
  composite = (CompositeDE) segment.getCompositeDE(3);  // C022 Health Care
  if (composite == null)
    return;
  de = composite.getDataElement(1);  // composite element 1270 Diagnosis Type Code
  if (de != null)
    de.get();
  de = composite.getDataElement(2);  // composite element 1271 Diagnosis Code
  if (de != null)
    de.get();
  composite = (CompositeDE) segment.getCompositeDE(4);  // C022 Health Care
  if (composite == null)
    return;
  de = composite.getDataElement(1);  // composite element 1270 Diagnosis Type Code
  if (de != null)
    de.get();
  de = composite.getDataElement(2);  // composite element 1271 Diagnosis Code
  if (de != null)
    de.get();
  composite = (CompositeDE) segment.getCompositeDE(5);  // C022 Health Care
  if (composite == null)
    return;
  de = composite.getDataElement(1);  // composite element 1270 Diagnosis Type Code
  if (de != null)
    de.get();
  de = composite.getDataElement(2);  // composite element 1271 Diagnosis Code
  if (de != null)
    de.get();
  composite = (CompositeDE) segment.getCompositeDE(6);  // C022 Health Care
  if (composite == null)
    return;
  de = composite.getDataElement(1);  // composite element 1270 Diagnosis Type Code
  if (de != null)
    de.get();
  de = composite.getDataElement(2);  // composite element 1271 Diagnosis Code
  if (de != null)
    de.get();
  composite = (CompositeDE) segment.getCompositeDE(7);  // C022 Health Care
  if (composite == null)
    return;
  de = composite.getDataElement(1);  // composite element 1270 Diagnosis Type Code
  if (de != null)
    de.get();
  de = composite.getDataElement(2);  // composite element 1271 Diagnosis Code
  if (de != null)
    de.get();
  composite = (CompositeDE) segment.getCompositeDE(8);  // C022 Health Care
  if (composite == null)
    return;
  de = composite.getDataElement(1);  // composite element 1270 Diagnosis Type Code
  if (de != null)
    de.get();
  de = composite.getDataElement(2);  // composite element 1271 Diagnosis Code
  if (de != null)
    de.get();
  }

/** extract data from segment HCP that is part of the Loop2300
*<br>Claim Pricing/Repricing Information used 
*<br>To specify pricing or repricing information about a health care claim or line item
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentClaimPricingRepricingInformationfromLoop2300(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("HCP");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 1473 Pricing Methodology
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 782 Repriced Allowed Amount
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 782 Repriced Saving Amount
  if (de != null)
    de.get();
  de = segment.getDataElement(4);  // 127 Repricing Organization Identifier
  if (de != null)
    de.get();
  de = segment.getDataElement(5);  // 118 Repricing Per Diem or Flat Rate Amount
  if (de != null)
    de.get();
  de = segment.getDataElement(6);  // 127 Repriced Approved Ambulatory Patient Group Code
  if (de != null)
    de.get();
  de = segment.getDataElement(7);  // 782 Repriced Approved Ambulatory Patient Group Amount
  if (de != null)
    de.get();
  de = segment.getDataElement(13);  // 901 Reject Reason Code
  if (de != null)
    de.get();
  de = segment.getDataElement(14);  // 1526 Policy Compliance Code
  if (de != null)
    de.get();
  de = segment.getDataElement(15);  // 1527 Exception Code
  if (de != null)
    de.get();
  }

/** extract data from loop 2305 that is part of Loop2300
*<br>Home Health Care Plan Information used 
* @param inLoop loop containing this loop
*@throws OBOEException - most likely loop not found
*/
public void extractLoop2305fromLoop2300(Loop inLoop)  throws OBOEException
{
  Loop loop;
  int numberInVector = inLoop.getCount("2305");
  for (int i = 0; i <  numberInVector; i++)
   {
   loop = inLoop.getLoop("2305", i);
   if (loop == null) return;
      extractSegmentHomeHealthCarePlanInformationfromLoop2305(loop);
      extractSegmentHealthCareServicesDeliveryfromLoop2305(loop);
    }
  }

/** extract data from segment CR7 that is part of the Loop2305
*<br>Home Health Care Plan Information used 
*<br>To supply information related to the home health care plan of treatment and services
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentHomeHealthCarePlanInformationfromLoop2305(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("CR7");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 921 Discipline Type Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1470 Total Visits Rendered Count
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1470 Certification Period Projected Visit Count
  if (de != null)
    de.get();
  }

/** extract data from segment HSD that is part of the Loop2305
*<br>Health Care Services Delivery used 
*<br>To specify the delivery pattern of health care services
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentHealthCareServicesDeliveryfromLoop2305(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("HSD");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("HSD", i);
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 673 Visits
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 380 Number of Visits
       if (de != null)
         de.get();
       de = segment.getDataElement(3);       // 355 Frequency Period
       if (de != null)
         de.get();
       de = segment.getDataElement(4);       // 1167 Frequency Count
       if (de != null)
         de.get();
       de = segment.getDataElement(5);       // 615 Duration of Visits Units
       if (de != null)
         de.get();
       de = segment.getDataElement(6);       // 616 Duration of Visits, Number of Units
       if (de != null)
         de.get();
       de = segment.getDataElement(7);       // 678 Ship, Delivery or Calendar Pattern Code
       if (de != null)
         de.get();
       de = segment.getDataElement(8);       // 679 Delivery Pattern Time Code
       if (de != null)
         de.get();
    }
  }

/** extract data from loop 2310A that is part of Loop2300
*<br>Referring Provider Name used 
* @param inLoop loop containing this loop
*@throws OBOEException - most likely loop not found
*/
public void extractLoop2310AfromLoop2300(Loop inLoop)  throws OBOEException
{
  Loop loop;
  int numberInVector = inLoop.getCount("2310A");
  for (int i = 0; i <  numberInVector; i++)
   {
   loop = inLoop.getLoop("2310A", i);
   if (loop == null) return;
      extractSegmentReferringProviderNamefromLoop2310A(loop);
      extractSegmentReferringProviderSpecialtyInformationfromLoop2310A(loop);
      extractSegmentAdditionalReferringProviderNameInformationfromLoop2310A(loop);
      extractSegmentReferringProviderSecondaryIdentificationfromLoop2310A(loop);
    }
  }

/** extract data from segment NM1 that is part of the Loop2310A
*<br>Referring Provider Name used 
*<br>To supply the full name of an individual or organizational entity
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentReferringProviderNamefromLoop2310A(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("NM1");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 98 Entity Identifier Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1065 Entity Type Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1035 Referring Provider Last Name
  if (de != null)
    de.get();
  de = segment.getDataElement(4);  // 1036 Referring Provider First Name
  if (de != null)
    de.get();
  de = segment.getDataElement(5);  // 1037 Referring Provider Middle Name
  if (de != null)
    de.get();
  de = segment.getDataElement(7);  // 1039 Referring Provider Name Suffix
  if (de != null)
    de.get();
  de = segment.getDataElement(8);  // 66 Identification Code Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(9);  // 67 Referring Provider Identifier
  if (de != null)
    de.get();
  }

/** extract data from segment PRV that is part of the Loop2310A
*<br>Referring Provider Specialty Information used 
*<br>To specify the identifying characteristics of a provider
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentReferringProviderSpecialtyInformationfromLoop2310A(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("PRV");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 1221 Provider Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 128 Reference Identification Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 127 Provider Taxonomy Code
  if (de != null)
    de.get();
  }

/** extract data from segment N2 that is part of the Loop2310A
*<br>Additional Referring Provider Name Information used 
*<br>To specify additional names or those longer than 35 characters in length
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentAdditionalReferringProviderNameInformationfromLoop2310A(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("N2");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 93 Referring Provider Name Additional Text
  if (de != null)
    de.get();
  }

/** extract data from segment REF that is part of the Loop2310A
*<br>Referring Provider Secondary Identification used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentReferringProviderSecondaryIdentificationfromLoop2310A(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("REF");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("REF", i);
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 128 Reference Identification Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 127 Referring Provider Secondary Identifier
       if (de != null)
         de.get();
    }
  }

/** extract data from loop 2310B that is part of Loop2300
*<br>Rendering Provider Name used 
* @param inLoop loop containing this loop
*@throws OBOEException - most likely loop not found
*/
public void extractLoop2310BfromLoop2300(Loop inLoop)  throws OBOEException
{
  Loop loop = inLoop.getLoop("2310B");
  if (loop == null) return;
  extractSegmentRenderingProviderNamefromLoop2310B(loop);
  extractSegmentRenderingProviderSpecialtyInformationfromLoop2310B(loop);
  extractSegmentAdditionalRenderingProviderNameInformationfromLoop2310B(loop);
  extractSegmentRenderingProviderSecondaryIdentificationfromLoop2310B(loop);
  }

/** extract data from segment NM1 that is part of the Loop2310B
*<br>Rendering Provider Name used 
*<br>To supply the full name of an individual or organizational entity
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentRenderingProviderNamefromLoop2310B(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("NM1");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 98 Entity Identifier Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1065 Entity Type Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1035 Rendering Provider Last or Organization Name
  if (de != null)
    de.get();
  de = segment.getDataElement(4);  // 1036 Rendering Provider First Name
  if (de != null)
    de.get();
  de = segment.getDataElement(5);  // 1037 Rendering Provider Middle Name
  if (de != null)
    de.get();
  de = segment.getDataElement(7);  // 1039 Rendering Provider Name Suffix
  if (de != null)
    de.get();
  de = segment.getDataElement(8);  // 66 Identification Code Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(9);  // 67 Rendering Provider Identifier
  if (de != null)
    de.get();
  }

/** extract data from segment PRV that is part of the Loop2310B
*<br>Rendering Provider Specialty Information used 
*<br>To specify the identifying characteristics of a provider
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentRenderingProviderSpecialtyInformationfromLoop2310B(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("PRV");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 1221 Provider Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 128 Reference Identification Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 127 Provider Taxonomy Code
  if (de != null)
    de.get();
  }

/** extract data from segment N2 that is part of the Loop2310B
*<br>Additional Rendering Provider Name Information used 
*<br>To specify additional names or those longer than 35 characters in length
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentAdditionalRenderingProviderNameInformationfromLoop2310B(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("N2");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 93 Rendering Provider Name Additional Text
  if (de != null)
    de.get();
  }

/** extract data from segment REF that is part of the Loop2310B
*<br>Rendering Provider Secondary Identification used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentRenderingProviderSecondaryIdentificationfromLoop2310B(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("REF");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("REF", i);
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 128 Reference Identification Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 127 Rendering Provider Secondary Identifier
       if (de != null)
         de.get();
    }
  }

/** extract data from loop 2310C that is part of Loop2300
*<br>Purchased Service Provider Name used 
* @param inLoop loop containing this loop
*@throws OBOEException - most likely loop not found
*/
public void extractLoop2310CfromLoop2300(Loop inLoop)  throws OBOEException
{
  Loop loop = inLoop.getLoop("2310C");
  if (loop == null) return;
  extractSegmentPurchasedServiceProviderNamefromLoop2310C(loop);
  extractSegmentPurchasedServiceProviderSecondaryIdentificationfromLoop2310C(loop);
  }

/** extract data from segment NM1 that is part of the Loop2310C
*<br>Purchased Service Provider Name used 
*<br>To supply the full name of an individual or organizational entity
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentPurchasedServiceProviderNamefromLoop2310C(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("NM1");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 98 Entity Identifier Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1065 Entity Type Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(8);  // 66 Identification Code Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(9);  // 67 Purchased Service Provider Identifier
  if (de != null)
    de.get();
  }

/** extract data from segment REF that is part of the Loop2310C
*<br>Purchased Service Provider Secondary Identification used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentPurchasedServiceProviderSecondaryIdentificationfromLoop2310C(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("REF");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("REF", i);
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 128 Reference Identification Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 127 Purchased Service Provider Secondary Identifier
       if (de != null)
         de.get();
    }
  }

/** extract data from loop 2310D that is part of Loop2300
*<br>Service Facility Location used 
* @param inLoop loop containing this loop
*@throws OBOEException - most likely loop not found
*/
public void extractLoop2310DfromLoop2300(Loop inLoop)  throws OBOEException
{
  Loop loop = inLoop.getLoop("2310D");
  if (loop == null) return;
  extractSegmentServiceFacilityLocationfromLoop2310D(loop);
  extractSegmentAdditionalServiceFacilityLocationNameInformationfromLoop2310D(loop);
  extractSegmentServiceFacilityLocationAddressfromLoop2310D(loop);
  extractSegmentServiceFacilityLocationCityStateZIPfromLoop2310D(loop);
  extractSegmentServiceFacilityLocationSecondaryIdentificationfromLoop2310D(loop);
  }

/** extract data from segment NM1 that is part of the Loop2310D
*<br>Service Facility Location used 
*<br>To supply the full name of an individual or organizational entity
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentServiceFacilityLocationfromLoop2310D(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("NM1");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 98 Entity Identifier Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1065 Entity Type Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1035 Laboratory or Facility Name
  if (de != null)
    de.get();
  de = segment.getDataElement(8);  // 66 Identification Code Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(9);  // 67 Laboratory or Facility Primary Identifier
  if (de != null)
    de.get();
  }

/** extract data from segment N2 that is part of the Loop2310D
*<br>Additional Service Facility Location Name Information used 
*<br>To specify additional names or those longer than 35 characters in length
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentAdditionalServiceFacilityLocationNameInformationfromLoop2310D(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("N2");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 93 Laboratory or Facility Name Additional Text
  if (de != null)
    de.get();
  }

/** extract data from segment N3 that is part of the Loop2310D
*<br>Service Facility Location Address used 
*<br>To specify the location of the named party
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentServiceFacilityLocationAddressfromLoop2310D(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("N3");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 166 Laboratory or Facility Address Line
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 166 Laboratory or Facility Address Line
  if (de != null)
    de.get();
  }

/** extract data from segment N4 that is part of the Loop2310D
*<br>Service Facility Location City/State/ZIP used 
*<br>To specify the geographic place of the named party
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentServiceFacilityLocationCityStateZIPfromLoop2310D(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("N4");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 19 Laboratory or Facility City Name
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 156 Laboratory or Facility State or Province Code
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 116 Laboratory or Facility Postal Zone or ZIP Code
  if (de != null)
    de.get();
  de = segment.getDataElement(4);  // 26 Country Code
  if (de != null)
    de.get();
  }

/** extract data from segment REF that is part of the Loop2310D
*<br>Service Facility Location Secondary Identification used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentServiceFacilityLocationSecondaryIdentificationfromLoop2310D(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("REF");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("REF", i);
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 128 Reference Identification Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 127 Laboratory or Facility Secondary Identifier
       if (de != null)
         de.get();
    }
  }

/** extract data from loop 2310E that is part of Loop2300
*<br>Supervising Provider Name used 
* @param inLoop loop containing this loop
*@throws OBOEException - most likely loop not found
*/
public void extractLoop2310EfromLoop2300(Loop inLoop)  throws OBOEException
{
  Loop loop = inLoop.getLoop("2310E");
  if (loop == null) return;
  extractSegmentSupervisingProviderNamefromLoop2310E(loop);
  extractSegmentAdditionalSupervisingProviderNameInformationfromLoop2310E(loop);
  extractSegmentSupervisingProviderSecondaryIdentificationfromLoop2310E(loop);
  }

/** extract data from segment NM1 that is part of the Loop2310E
*<br>Supervising Provider Name used 
*<br>To supply the full name of an individual or organizational entity
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentSupervisingProviderNamefromLoop2310E(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("NM1");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 98 Entity Identifier Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1065 Entity Type Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1035 Supervising Provider Last Name
  if (de != null)
    de.get();
  de = segment.getDataElement(4);  // 1036 Supervising Provider First Name
  if (de != null)
    de.get();
  de = segment.getDataElement(5);  // 1037 Supervising Provider Middle Name
  if (de != null)
    de.get();
  de = segment.getDataElement(7);  // 1039 Supervising Provider Name Suffix
  if (de != null)
    de.get();
  de = segment.getDataElement(8);  // 66 Identification Code Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(9);  // 67 Supervising Provider Identifier
  if (de != null)
    de.get();
  }

/** extract data from segment N2 that is part of the Loop2310E
*<br>Additional Supervising Provider Name Information used 
*<br>To specify additional names or those longer than 35 characters in length
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentAdditionalSupervisingProviderNameInformationfromLoop2310E(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("N2");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 93 Supervising Provider Name Additional Text
  if (de != null)
    de.get();
  }

/** extract data from segment REF that is part of the Loop2310E
*<br>Supervising Provider Secondary Identification used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentSupervisingProviderSecondaryIdentificationfromLoop2310E(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("REF");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("REF", i);
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 128 Reference Identification Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 127 Supervising Provider Secondary Identifier
       if (de != null)
         de.get();
    }
  }

/** extract data from loop 2320 that is part of Loop2300
*<br>Other Subscriber Information used 
* @param inLoop loop containing this loop
*@throws OBOEException - most likely loop not found
*/
public void extractLoop2320fromLoop2300(Loop inLoop)  throws OBOEException
{
  Loop loop;
  int numberInVector = inLoop.getCount("2320");
  for (int i = 0; i <  numberInVector; i++)
   {
   loop = inLoop.getLoop("2320", i);
   if (loop == null) return;
      extractSegmentOtherSubscriberInformationfromLoop2320(loop);
      extractSegmentClaimLevelAdjustmentsfromLoop2320(loop);
      extractSegmentCoordinationofBenefitsCOBPayerPaidAmountfromLoop2320(loop);
      extractSegmentCoordinationofBenefitsCOBApprovedAmountfromLoop2320(loop);
      extractSegmentCoordinationofBenefitsCOBAllowedAmountfromLoop2320(loop);
      extractSegmentCoordinationofBenefitsCOBPatientResponsibilityAmountfromLoop2320(loop);
      extractSegmentCoordinationofBenefitsCOBCoveredAmountfromLoop2320(loop);
      extractSegmentCoordinationofBenefitsCOBDiscountAmountfromLoop2320(loop);
      extractSegmentCoordinationofBenefitsCOBPerDayLimitAmountfromLoop2320(loop);
      extractSegmentCoordinationofBenefitsCOBPatientPaidAmountfromLoop2320(loop);
      extractSegmentCoordinationofBenefitsCOBTaxAmountfromLoop2320(loop);
      extractSegmentCoordinationofBenefitsCOBTotalClaimBeforeTaxesAmountfromLoop2320(loop);
      extractSegmentSubscriberDemographicInformationfromLoop2320(loop);
      extractSegmentOtherInsuranceCoverageInformationfromLoop2320(loop);
      extractSegmentMedicareOutpatientAdjudicationInformationfromLoop2320(loop);
      extractLoop2330AfromLoop2320(loop);
      extractLoop2330BfromLoop2320(loop);
      extractLoop2330CfromLoop2320(loop);
      extractLoop2330DfromLoop2320(loop);
      extractLoop2330EfromLoop2320(loop);
      extractLoop2330FfromLoop2320(loop);
      extractLoop2330GfromLoop2320(loop);
      extractLoop2330HfromLoop2320(loop);
    }
  }

/** extract data from segment SBR that is part of the Loop2320
*<br>Other Subscriber Information used 
*<br>To record information specific to the primary insured and the insurance carrier for that insured
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentOtherSubscriberInformationfromLoop2320(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("SBR");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 1138 Payer Responsibility Sequence Number Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1069 Individual Relationship Code
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 127 Insured Group or Policy Number
  if (de != null)
    de.get();
  de = segment.getDataElement(4);  // 93 Other Insured Group Name
  if (de != null)
    de.get();
  de = segment.getDataElement(5);  // 1336 Insurance Type Code
  if (de != null)
    de.get();
  de = segment.getDataElement(9);  // 1032 Claim Filing Indicator Code
  if (de != null)
    de.get();
  }

/** extract data from segment CAS that is part of the Loop2320
*<br>Claim Level Adjustments used 
*<br>To supply adjustment reason codes and amounts as needed for an entire claim or for a particular service within the claim being paid
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentClaimLevelAdjustmentsfromLoop2320(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("CAS");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("CAS", i);
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 1033 Claim Adjustment Group Code
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 1034 Adjustment Reason Code
       if (de != null)
         de.get();
       de = segment.getDataElement(3);       // 782 Adjustment Amount
       if (de != null)
         de.get();
       de = segment.getDataElement(4);       // 380 Adjustment Quantity
       if (de != null)
         de.get();
       de = segment.getDataElement(5);       // 1034 Adjustment Reason Code
       if (de != null)
         de.get();
       de = segment.getDataElement(6);       // 782 Adjustment Amount
       if (de != null)
         de.get();
       de = segment.getDataElement(7);       // 380 Adjustment Quantity
       if (de != null)
         de.get();
       de = segment.getDataElement(8);       // 1034 Adjustment Reason Code
       if (de != null)
         de.get();
       de = segment.getDataElement(9);       // 782 Adjustment Amount
       if (de != null)
         de.get();
       de = segment.getDataElement(10);       // 380 Adjustment Quantity
       if (de != null)
         de.get();
       de = segment.getDataElement(11);       // 1034 Adjustment Reason Code
       if (de != null)
         de.get();
       de = segment.getDataElement(12);       // 782 Adjustment Amount
       if (de != null)
         de.get();
       de = segment.getDataElement(13);       // 380 Adjustment Quantity
       if (de != null)
         de.get();
       de = segment.getDataElement(14);       // 1034 Adjustment Reason Code
       if (de != null)
         de.get();
       de = segment.getDataElement(15);       // 782 Adjustment Amount
       if (de != null)
         de.get();
       de = segment.getDataElement(16);       // 380 Adjustment Quantity
       if (de != null)
         de.get();
       de = segment.getDataElement(17);       // 1034 Adjustment Reason Code
       if (de != null)
         de.get();
       de = segment.getDataElement(18);       // 782 Adjustment Amount
       if (de != null)
         de.get();
       de = segment.getDataElement(19);       // 380 Adjustment Quantity
       if (de != null)
         de.get();
    }
  }

/** extract data from segment AMT that is part of the Loop2320
*<br>Coordination of Benefits (COB) Payer Paid Amount used 
*<br>To indicate the total monetary amount
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentCoordinationofBenefitsCOBPayerPaidAmountfromLoop2320(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("AMT", "D");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 522 Amount Qualifier Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 782 Payer Paid Amount
  if (de != null)
    de.get();
  }

/** extract data from segment AMT that is part of the Loop2320
*<br>Coordination of Benefits (COB) Approved Amount used 
*<br>To indicate the total monetary amount
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentCoordinationofBenefitsCOBApprovedAmountfromLoop2320(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("AMT", "AAE");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 522 Amount Qualifier Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 782 Approved Amount
  if (de != null)
    de.get();
  }

/** extract data from segment AMT that is part of the Loop2320
*<br>Coordination of Benefits (COB) Allowed Amount used 
*<br>To indicate the total monetary amount
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentCoordinationofBenefitsCOBAllowedAmountfromLoop2320(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("AMT", "B6");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 522 Amount Qualifier Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 782 Allowed Amount
  if (de != null)
    de.get();
  }

/** extract data from segment AMT that is part of the Loop2320
*<br>Coordination of Benefits (COB) Patient Responsibility Amount used 
*<br>To indicate the total monetary amount
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentCoordinationofBenefitsCOBPatientResponsibilityAmountfromLoop2320(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("AMT", "F2");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 522 Amount Qualifier Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 782 Other Payer Patient Responsibility Amount
  if (de != null)
    de.get();
  }

/** extract data from segment AMT that is part of the Loop2320
*<br>Coordination of Benefits (COB) Covered Amount used 
*<br>To indicate the total monetary amount
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentCoordinationofBenefitsCOBCoveredAmountfromLoop2320(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("AMT", "AU");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 522 Amount Qualifier Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 782 Other Payer Covered Amount
  if (de != null)
    de.get();
  }

/** extract data from segment AMT that is part of the Loop2320
*<br>Coordination of Benefits (COB) Discount Amount used 
*<br>To indicate the total monetary amount
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentCoordinationofBenefitsCOBDiscountAmountfromLoop2320(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("AMT", "D8");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 522 Amount Qualifier Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 782 Other Payer Discount Amount
  if (de != null)
    de.get();
  }

/** extract data from segment AMT that is part of the Loop2320
*<br>Coordination of Benefits (COB) Per Day Limit Amount used 
*<br>To indicate the total monetary amount
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentCoordinationofBenefitsCOBPerDayLimitAmountfromLoop2320(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("AMT", "DY");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 522 Amount Qualifier Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 782 Other Payer Per Day Limit Amount
  if (de != null)
    de.get();
  }

/** extract data from segment AMT that is part of the Loop2320
*<br>Coordination of Benefits (COB) Patient Paid Amount used 
*<br>To indicate the total monetary amount
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentCoordinationofBenefitsCOBPatientPaidAmountfromLoop2320(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("AMT", "F5");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 522 Amount Qualifier Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 782 Other Payer Patient Paid Amount
  if (de != null)
    de.get();
  }

/** extract data from segment AMT that is part of the Loop2320
*<br>Coordination of Benefits (COB) Tax Amount used 
*<br>To indicate the total monetary amount
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentCoordinationofBenefitsCOBTaxAmountfromLoop2320(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("AMT", "T");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 522 Amount Qualifier Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 782 Other Payer Tax Amount
  if (de != null)
    de.get();
  }

/** extract data from segment AMT that is part of the Loop2320
*<br>Coordination of Benefits (COB) Total Claim Before Taxes Amount used 
*<br>To indicate the total monetary amount
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentCoordinationofBenefitsCOBTotalClaimBeforeTaxesAmountfromLoop2320(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("AMT", "T2");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 522 Amount Qualifier Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 782 Other Payer Pre-Tax Claim Total Amount
  if (de != null)
    de.get();
  }

/** extract data from segment DMG that is part of the Loop2320
*<br>Subscriber Demographic Information used 
*<br>To supply demographic information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentSubscriberDemographicInformationfromLoop2320(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("DMG");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 1250 Date Time Period Format Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1251 Other Insured Birth Date
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1068 Other Insured Gender Code
  if (de != null)
    de.get();
  }

/** extract data from segment OI that is part of the Loop2320
*<br>Other Insurance Coverage Information used 
*<br>To specify information associated with other health insurance coverage
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentOtherInsuranceCoverageInformationfromLoop2320(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("OI");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(3);  // 1073 Benefits Assignment Certification Indicator
  if (de != null)
    de.get();
  de = segment.getDataElement(4);  // 1351 Patient Signature Source Code
  if (de != null)
    de.get();
  de = segment.getDataElement(6);  // 1363 Release of Information Code
  if (de != null)
    de.get();
  }

/** extract data from segment MOA that is part of the Loop2320
*<br>Medicare Outpatient Adjudication Information used 
*<br>To convey claim-level data related to the adjudication of Medicare claims not related to an inpatient setting
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentMedicareOutpatientAdjudicationInformationfromLoop2320(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("MOA");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 954 Reimbursement Rate
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 782 HCPCS Payable Amount
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 127 Remark Code
  if (de != null)
    de.get();
  de = segment.getDataElement(4);  // 127 Remark Code
  if (de != null)
    de.get();
  de = segment.getDataElement(5);  // 127 Remark Code
  if (de != null)
    de.get();
  de = segment.getDataElement(6);  // 127 Remark Code
  if (de != null)
    de.get();
  de = segment.getDataElement(7);  // 127 Remark Code
  if (de != null)
    de.get();
  de = segment.getDataElement(8);  // 782 End Stage Renal Disease Payment Amount
  if (de != null)
    de.get();
  de = segment.getDataElement(9);  // 782 Non-Payable Professional Component Billed Amount
  if (de != null)
    de.get();
  }

/** extract data from loop 2330A that is part of Loop2320
*<br>Other Subscriber Name used 
* @param inLoop loop containing this loop
*@throws OBOEException - most likely loop not found
*/
public void extractLoop2330AfromLoop2320(Loop inLoop)  throws OBOEException
{
  Loop loop = inLoop.getLoop("2330A");
  if (loop == null) return;
  extractSegmentOtherSubscriberNamefromLoop2330A(loop);
  extractSegmentAdditionalOtherSubscriberNameInformationfromLoop2330A(loop);
  extractSegmentOtherSubscriberAddressfromLoop2330A(loop);
  extractSegmentOtherSubscriberCityStateZIPCodefromLoop2330A(loop);
  extractSegmentOtherSubscriberSecondaryIdentificationfromLoop2330A(loop);
  }

/** extract data from segment NM1 that is part of the Loop2330A
*<br>Other Subscriber Name used 
*<br>To supply the full name of an individual or organizational entity
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentOtherSubscriberNamefromLoop2330A(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("NM1");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 98 Entity Identifier Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1065 Entity Type Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1035 Other Insured Last Name
  if (de != null)
    de.get();
  de = segment.getDataElement(4);  // 1036 Other Insured First Name
  if (de != null)
    de.get();
  de = segment.getDataElement(5);  // 1037 Other Insured Middle Name
  if (de != null)
    de.get();
  de = segment.getDataElement(7);  // 1039 Other Insured Name Suffix
  if (de != null)
    de.get();
  de = segment.getDataElement(8);  // 66 Identification Code Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(9);  // 67 Other Insured Identifier
  if (de != null)
    de.get();
  }

/** extract data from segment N2 that is part of the Loop2330A
*<br>Additional Other Subscriber Name Information used 
*<br>To specify additional names or those longer than 35 characters in length
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentAdditionalOtherSubscriberNameInformationfromLoop2330A(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("N2");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 93 Other Insured Additional Name
  if (de != null)
    de.get();
  }

/** extract data from segment N3 that is part of the Loop2330A
*<br>Other Subscriber Address used 
*<br>To specify the location of the named party
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentOtherSubscriberAddressfromLoop2330A(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("N3");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 166 Other Insured Address Line
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 166 Other Insured Address Line
  if (de != null)
    de.get();
  }

/** extract data from segment N4 that is part of the Loop2330A
*<br>Other Subscriber City/State/ZIP Code used 
*<br>To specify the geographic place of the named party
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentOtherSubscriberCityStateZIPCodefromLoop2330A(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("N4");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 19 Other Insured City Name
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 156 Other Insured State Code
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 116 Other Insured Postal Zone or ZIP Code
  if (de != null)
    de.get();
  de = segment.getDataElement(4);  // 26 Country Code
  if (de != null)
    de.get();
  }

/** extract data from segment REF that is part of the Loop2330A
*<br>Other Subscriber Secondary Identification used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentOtherSubscriberSecondaryIdentificationfromLoop2330A(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("REF");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("REF", i);
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 128 Reference Identification Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 127 Other Insured Additional Identifier
       if (de != null)
         de.get();
    }
  }

/** extract data from loop 2330B that is part of Loop2320
*<br>Other Payer Name used 
* @param inLoop loop containing this loop
*@throws OBOEException - most likely loop not found
*/
public void extractLoop2330BfromLoop2320(Loop inLoop)  throws OBOEException
{
  Loop loop = inLoop.getLoop("2330B");
  if (loop == null) return;
  extractSegmentOtherPayerNamefromLoop2330B(loop);
  extractSegmentAdditionalOtherPayerNameInformationfromLoop2330B(loop);
  extractSegmentOtherPayerContactInformationfromLoop2330B(loop);
  extractSegmentClaimAdjudicationDatefromLoop2330B(loop);
  extractSegmentOtherPayerSecondaryIdentifierfromLoop2330B(loop);
  extractSegmentOtherPayerPriorAuthorizationorReferralNumberfromLoop2330B(loop);
  extractSegmentOtherPayerClaimAdjustmentIndicatorfromLoop2330B(loop);
  }

/** extract data from segment NM1 that is part of the Loop2330B
*<br>Other Payer Name used 
*<br>To supply the full name of an individual or organizational entity
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentOtherPayerNamefromLoop2330B(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("NM1");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 98 Entity Identifier Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1065 Entity Type Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1035 Other Payer Last or Organization Name
  if (de != null)
    de.get();
  de = segment.getDataElement(8);  // 66 Identification Code Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(9);  // 67 Other Payer Primary Identifier
  if (de != null)
    de.get();
  }

/** extract data from segment N2 that is part of the Loop2330B
*<br>Additional Other Payer Name Information used 
*<br>To specify additional names or those longer than 35 characters in length
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentAdditionalOtherPayerNameInformationfromLoop2330B(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("N2");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 93 Other Payer Additional Name Text
  if (de != null)
    de.get();
  }

/** extract data from segment PER that is part of the Loop2330B
*<br>Other Payer Contact Information used 
*<br>To identify a person or office to whom administrative communications should be directed
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentOtherPayerContactInformationfromLoop2330B(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("PER");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("PER", i);
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 366 Contact Function Code
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 93 Other Payer Contact Name
       if (de != null)
         de.get();
       de = segment.getDataElement(3);       // 365 Communication Number Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(4);       // 364 Communication Number
       if (de != null)
         de.get();
       de = segment.getDataElement(5);       // 365 Communication Number Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(6);       // 364 Communication Number
       if (de != null)
         de.get();
       de = segment.getDataElement(7);       // 365 Communication Number Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(8);       // 364 Communication Number
       if (de != null)
         de.get();
    }
  }

/** extract data from segment DTP that is part of the Loop2330B
*<br>Claim Adjudication Date used 
*<br>To specify any or all of a date, a time, or a time period
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentClaimAdjudicationDatefromLoop2330B(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("DTP");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 374 Date Time Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1250 Date Time Period Format Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1251 Adjudication or Payment Date
  if (de != null)
    de.get();
  }

/** extract data from segment REF that is part of the Loop2330B
*<br>Other Payer Secondary Identifier used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentOtherPayerSecondaryIdentifierfromLoop2330B(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("REF");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("REF", "2U", i);
 // other key values: "F8" "FY" "NF" "TJ" 
   // there can be 2 of these segments.
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 128 Reference Identification Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 127 Other Payer Secondary Identifier
       if (de != null)
         de.get();
    }
  }

/** extract data from segment REF that is part of the Loop2330B
*<br>Other Payer Prior Authorization or Referral Number used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentOtherPayerPriorAuthorizationorReferralNumberfromLoop2330B(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("REF");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("REF", "9F", i);
 // other key values: "G1" 
   // there can be 2 of these segments.
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 128 Reference Identification Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 127 Other Payer Prior Authorization or Referral Number
       if (de != null)
         de.get();
    }
  }

/** extract data from segment REF that is part of the Loop2330B
*<br>Other Payer Claim Adjustment Indicator used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentOtherPayerClaimAdjustmentIndicatorfromLoop2330B(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("REF");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("REF", "T4", i);
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 128 Reference Identification Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 127 Other Payer Claim Adjustment Indicator
       if (de != null)
         de.get();
    }
  }

/** extract data from loop 2330C that is part of Loop2320
*<br>Other Payer Patient Information used 
* @param inLoop loop containing this loop
*@throws OBOEException - most likely loop not found
*/
public void extractLoop2330CfromLoop2320(Loop inLoop)  throws OBOEException
{
  Loop loop = inLoop.getLoop("2330C");
  if (loop == null) return;
  extractSegmentOtherPayerPatientInformationfromLoop2330C(loop);
  extractSegmentOtherPayerPatientIdentificationfromLoop2330C(loop);
  }

/** extract data from segment NM1 that is part of the Loop2330C
*<br>Other Payer Patient Information used 
*<br>To supply the full name of an individual or organizational entity
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentOtherPayerPatientInformationfromLoop2330C(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("NM1");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 98 Entity Identifier Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1065 Entity Type Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1035 Patient Last Name
  if (de != null)
    de.get();
  de = segment.getDataElement(8);  // 66 Identification Code Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(9);  // 67 Other Payer Patient Primary Identifier
  if (de != null)
    de.get();
  }

/** extract data from segment REF that is part of the Loop2330C
*<br>Other Payer Patient Identification used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentOtherPayerPatientIdentificationfromLoop2330C(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("REF");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("REF", i);
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 128 Reference Identification Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 127 Other Payer Patient Secondary Identifier
       if (de != null)
         de.get();
    }
  }

/** extract data from loop 2330D that is part of Loop2320
*<br>Other Payer Referring Provider used 
* @param inLoop loop containing this loop
*@throws OBOEException - most likely loop not found
*/
public void extractLoop2330DfromLoop2320(Loop inLoop)  throws OBOEException
{
  Loop loop;
  int numberInVector = inLoop.getCount("2330D");
  for (int i = 0; i <  numberInVector; i++)
   {
   loop = inLoop.getLoop("2330D", i);
   if (loop == null) return;
      extractSegmentOtherPayerReferringProviderfromLoop2330D(loop);
      extractSegmentOtherPayerReferringProviderIdentificationfromLoop2330D(loop);
    }
  }

/** extract data from segment NM1 that is part of the Loop2330D
*<br>Other Payer Referring Provider used 
*<br>To supply the full name of an individual or organizational entity
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentOtherPayerReferringProviderfromLoop2330D(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("NM1");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 98 Entity Identifier Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1065 Entity Type Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1035 Referring Provider Last Name
  if (de != null)
    de.get();
  }

/** extract data from segment REF that is part of the Loop2330D
*<br>Other Payer Referring Provider Identification used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentOtherPayerReferringProviderIdentificationfromLoop2330D(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("REF");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("REF", i);
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 128 Reference Identification Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 127 Other Payer Referring Provider Identifier
       if (de != null)
         de.get();
    }
  }

/** extract data from loop 2330E that is part of Loop2320
*<br>Other Payer Rendering Provider used 
* @param inLoop loop containing this loop
*@throws OBOEException - most likely loop not found
*/
public void extractLoop2330EfromLoop2320(Loop inLoop)  throws OBOEException
{
  Loop loop = inLoop.getLoop("2330E");
  if (loop == null) return;
  extractSegmentOtherPayerRenderingProviderfromLoop2330E(loop);
  extractSegmentOtherPayerRenderingProviderSecondaryIdentificationfromLoop2330E(loop);
  }

/** extract data from segment NM1 that is part of the Loop2330E
*<br>Other Payer Rendering Provider used 
*<br>To supply the full name of an individual or organizational entity
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentOtherPayerRenderingProviderfromLoop2330E(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("NM1");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 98 Entity Identifier Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1065 Entity Type Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1035 Rendering Provider Last or Organization Name
  if (de != null)
    de.get();
  }

/** extract data from segment REF that is part of the Loop2330E
*<br>Other Payer Rendering Provider Secondary Identification used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentOtherPayerRenderingProviderSecondaryIdentificationfromLoop2330E(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("REF");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("REF", i);
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 128 Reference Identification Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 127 Other Payer Rendering Provider Secondary Identifier
       if (de != null)
         de.get();
    }
  }

/** extract data from loop 2330F that is part of Loop2320
*<br>Other Payer Purchased Service Provider used 
* @param inLoop loop containing this loop
*@throws OBOEException - most likely loop not found
*/
public void extractLoop2330FfromLoop2320(Loop inLoop)  throws OBOEException
{
  Loop loop = inLoop.getLoop("2330F");
  if (loop == null) return;
  extractSegmentOtherPayerPurchasedServiceProviderfromLoop2330F(loop);
  extractSegmentOtherPayerPurchasedServiceProviderIdentificationfromLoop2330F(loop);
  }

/** extract data from segment NM1 that is part of the Loop2330F
*<br>Other Payer Purchased Service Provider used 
*<br>To supply the full name of an individual or organizational entity
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentOtherPayerPurchasedServiceProviderfromLoop2330F(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("NM1");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 98 Entity Identifier Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1065 Entity Type Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1035 Purchased Service Provider Name
  if (de != null)
    de.get();
  }

/** extract data from segment REF that is part of the Loop2330F
*<br>Other Payer Purchased Service Provider Identification used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentOtherPayerPurchasedServiceProviderIdentificationfromLoop2330F(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("REF");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("REF", i);
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 128 Reference Identification Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 127 Other Payer Purchased Service Provider Identifier
       if (de != null)
         de.get();
    }
  }

/** extract data from loop 2330G that is part of Loop2320
*<br>Other Payer Service Facility Location used 
* @param inLoop loop containing this loop
*@throws OBOEException - most likely loop not found
*/
public void extractLoop2330GfromLoop2320(Loop inLoop)  throws OBOEException
{
  Loop loop = inLoop.getLoop("2330G");
  if (loop == null) return;
  extractSegmentOtherPayerServiceFacilityLocationfromLoop2330G(loop);
  extractSegmentOtherPayerServiceFacilityLocationIdentificationfromLoop2330G(loop);
  }

/** extract data from segment NM1 that is part of the Loop2330G
*<br>Other Payer Service Facility Location used 
*<br>To supply the full name of an individual or organizational entity
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentOtherPayerServiceFacilityLocationfromLoop2330G(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("NM1");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 98 Entity Identifier Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1065 Entity Type Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1035 Service Facility Name
  if (de != null)
    de.get();
  }

/** extract data from segment REF that is part of the Loop2330G
*<br>Other Payer Service Facility Location Identification used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentOtherPayerServiceFacilityLocationIdentificationfromLoop2330G(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("REF");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("REF", i);
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 128 Reference Identification Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 127 Other Payer Service Facility Location Identifier
       if (de != null)
         de.get();
    }
  }

/** extract data from loop 2330H that is part of Loop2320
*<br>Other Payer Supervising Provider used 
* @param inLoop loop containing this loop
*@throws OBOEException - most likely loop not found
*/
public void extractLoop2330HfromLoop2320(Loop inLoop)  throws OBOEException
{
  Loop loop = inLoop.getLoop("2330H");
  if (loop == null) return;
  extractSegmentOtherPayerSupervisingProviderfromLoop2330H(loop);
  extractSegmentOtherPayerSupervisingProviderIdentificationfromLoop2330H(loop);
  }

/** extract data from segment NM1 that is part of the Loop2330H
*<br>Other Payer Supervising Provider used 
*<br>To supply the full name of an individual or organizational entity
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentOtherPayerSupervisingProviderfromLoop2330H(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("NM1");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 98 Entity Identifier Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1065 Entity Type Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1035 Supervising Provider Last Name
  if (de != null)
    de.get();
  }

/** extract data from segment REF that is part of the Loop2330H
*<br>Other Payer Supervising Provider Identification used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentOtherPayerSupervisingProviderIdentificationfromLoop2330H(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("REF");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("REF", i);
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 128 Reference Identification Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 127 Other Payer Supervising Provider Identifier
       if (de != null)
         de.get();
    }
  }

/** extract data from loop 2400 that is part of Loop2300
*<br>Service Line used 
* @param inLoop loop containing this loop
*@throws OBOEException - most likely loop not found
*/
public void extractLoop2400fromLoop2300(Loop inLoop)  throws OBOEException
{
  Loop loop;
  int numberInVector = inLoop.getCount("2400");
  for (int i = 0; i <  numberInVector; i++)
   {
   loop = inLoop.getLoop("2400", i);
   if (loop == null) return;
      extractSegmentServiceLinefromLoop2400(loop);
      extractSegmentProfessionalServicefromLoop2400(loop);
      extractSegmentPrescriptionNumberfromLoop2400(loop);
      extractSegmentDMERCCMNIndicatorfromLoop2400(loop);
      extractSegmentAmbulanceTransportInformationfromLoop2400(loop);
      extractSegmentSpinalManipulationServiceInformationfromLoop2400(loop);
      extractSegmentDurableMedicalEquipmentCertificationfromLoop2400(loop);
      extractSegmentHomeOxygenTherapyInformationfromLoop2400(loop);
      extractSegmentAmbulanceCertificationfromLoop2400(loop);
      extractSegmentHospiceEmployeeIndicatorfromLoop2400(loop);
      extractSegmentDMERCConditionIndicatorfromLoop2400(loop);
      extractSegmentDateServiceDatefromLoop2400(loop);
      extractSegmentDateCertificationRevisionDatefromLoop2400(loop);
      extractSegmentDateReferralDatefromLoop2400(loop);
      extractSegmentDateBeginTherapyDatefromLoop2400(loop);
      extractSegmentDateLastCertificationDatefromLoop2400(loop);
      extractSegmentDateOrderDatefromLoop2400(loop);
      extractSegmentDateDateLastSeenfromLoop2400(loop);
      extractSegmentDateTestfromLoop2400(loop);
      extractSegmentDateOxygenSaturationArterialBloodGasTestfromLoop2400(loop);
      extractSegmentDateShippedfromLoop2400(loop);
      extractSegmentDateOnsetofCurrentSymptomIllnessfromLoop2400(loop);
      extractSegmentDateLastXrayfromLoop2400(loop);
      extractSegmentDateAcuteManifestationfromLoop2400(loop);
      extractSegmentDateInitialTreatmentfromLoop2400(loop);
      extractSegmentDateSimilarIllnessSymptomOnsetfromLoop2400(loop);
      extractSegmentAnesthesiaModifyingUnitsfromLoop2400(loop);
      extractSegmentTestResultfromLoop2400(loop);
      extractSegmentContractInformationfromLoop2400(loop);
      extractSegmentRepricedLineItemReferenceNumberfromLoop2400(loop);
      extractSegmentAdjustedRepricedLineItemReferenceNumberfromLoop2400(loop);
      extractSegmentPriorAuthorizationorReferralNumberfromLoop2400(loop);
      extractSegmentLineItemControlNumberfromLoop2400(loop);
      extractSegmentMammographyCertificationNumberfromLoop2400(loop);
      extractSegmentClinicalLaboratoryImprovementAmendmentCLIAIdentificationfromLoop2400(loop);
      extractSegmentReferringClinicalLaboratoryImprovementAmendmentCLIAFacilityIdentificationfromLoop2400(loop);
      extractSegmentImmunizationBatchNumberfromLoop2400(loop);
      extractSegmentAmbulatoryPatientGroupAPGfromLoop2400(loop);
      extractSegmentOxygenFlowRatefromLoop2400(loop);
      extractSegmentUniversalProductNumberUPNfromLoop2400(loop);
      extractSegmentSalesTaxAmountfromLoop2400(loop);
      extractSegmentApprovedAmountfromLoop2400(loop);
      extractSegmentPostageClaimedAmountfromLoop2400(loop);
      extractSegmentFileInformationfromLoop2400(loop);
      extractSegmentLineNotefromLoop2400(loop);
      extractSegmentPurchasedServiceInformationfromLoop2400(loop);
      extractSegmentHealthCareServicesDeliveryfromLoop2400(loop);
      extractSegmentLinePricingRepricingInformationfromLoop2400(loop);
      extractLoop2420AfromLoop2400(loop);
      extractLoop2420BfromLoop2400(loop);
      extractLoop2420CfromLoop2400(loop);
      extractLoop2420DfromLoop2400(loop);
      extractLoop2420EfromLoop2400(loop);
      extractLoop2420FfromLoop2400(loop);
      extractLoop2420GfromLoop2400(loop);
      extractLoop2430fromLoop2400(loop);
      extractLoop2440fromLoop2400(loop);
    }
  }

/** extract data from segment LX that is part of the Loop2400
*<br>Service Line used 
*<br>To reference a line number in a transaction set
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentServiceLinefromLoop2400(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("LX");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 554 Assigned Number
  if (de != null)
    de.get();
  }

/** extract data from segment SV1 that is part of the Loop2400
*<br>Professional Service used 
*<br>To specify the claim service detail for a Health Care professional
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentProfessionalServicefromLoop2400(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("SV1");
  if (segment == null)
    return;
  DataElement de;
    CompositeDE  composite = (CompositeDE) segment.getCompositeDE(1);  // C003 Composite Medical
  if (composite == null)
    return;
  de = composite.getDataElement(1);  // composite element 235 Product or Service ID Qualifier
  if (de != null)
    de.get();
  de = composite.getDataElement(2);  // composite element 234 Procedure Code
  if (de != null)
    de.get();
  de = composite.getDataElement(3);  // composite element 1339 Procedure Modifier
  if (de != null)
    de.get();
  de = composite.getDataElement(4);  // composite element 1339 Procedure Modifier
  if (de != null)
    de.get();
  de = composite.getDataElement(5);  // composite element 1339 Procedure Modifier
  if (de != null)
    de.get();
  de = composite.getDataElement(6);  // composite element 1339 Procedure Modifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 782 Line Item Charge Amount
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 355 Unit or Basis for Measurement Code
  if (de != null)
    de.get();
  de = segment.getDataElement(4);  // 380 Service Unit Count
  if (de != null)
    de.get();
  de = segment.getDataElement(5);  // 1331 Place of Service Code
  if (de != null)
    de.get();
  composite = (CompositeDE) segment.getCompositeDE(7);  // C004 Composite Diagnosis
  if (composite == null)
    return;
  de = composite.getDataElement(1);  // composite element 1328 Diagnosis Code Pointer
  if (de != null)
    de.get();
  de = composite.getDataElement(2);  // composite element 1328 Diagnosis Code Pointer
  if (de != null)
    de.get();
  de = composite.getDataElement(3);  // composite element 1328 Diagnosis Code Pointer
  if (de != null)
    de.get();
  de = composite.getDataElement(4);  // composite element 1328 Diagnosis Code Pointer
  if (de != null)
    de.get();
  de = segment.getDataElement(9);  // 1073 Emergency Indicator
  if (de != null)
    de.get();
  de = segment.getDataElement(11);  // 1073 EPSDT Indicator
  if (de != null)
    de.get();
  de = segment.getDataElement(12);  // 1073 Family Planning Indicator
  if (de != null)
    de.get();
  de = segment.getDataElement(15);  // 1327 Co-Pay Status Code
  if (de != null)
    de.get();
  }

/** extract data from segment SV4 that is part of the Loop2400
*<br>Prescription Number used 
*<br>To specify the claim service detail for prescription drugs
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentPrescriptionNumberfromLoop2400(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("SV4");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 127 Prescription Number
  if (de != null)
    de.get();
  }

/** extract data from segment PWK that is part of the Loop2400
*<br>DMERC CMN Indicator used 
*<br>To identify the type or transmission or both of paperwork or supporting information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentDMERCCMNIndicatorfromLoop2400(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("PWK");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 755 Attachment Report Type Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 756 Attachment Transmission Code
  if (de != null)
    de.get();
  }

/** extract data from segment CR1 that is part of the Loop2400
*<br>Ambulance Transport Information used 
*<br>To supply information related to the ambulance service rendered to a patient
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentAmbulanceTransportInformationfromLoop2400(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("CR1");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 355 Unit or Basis for Measurement Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 81 Patient Weight
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1316 Ambulance Transport Code
  if (de != null)
    de.get();
  de = segment.getDataElement(4);  // 1317 Ambulance Transport Reason Code
  if (de != null)
    de.get();
  de = segment.getDataElement(5);  // 355 Unit or Basis for Measurement Code
  if (de != null)
    de.get();
  de = segment.getDataElement(6);  // 380 Transport Distance
  if (de != null)
    de.get();
  de = segment.getDataElement(9);  // 352 Round Trip Purpose Description
  if (de != null)
    de.get();
  de = segment.getDataElement(10);  // 352 Stretcher Purpose Description
  if (de != null)
    de.get();
  }

/** extract data from segment CR2 that is part of the Loop2400
*<br>Spinal Manipulation Service Information used 
*<br>To supply information related to the chiropractic service rendered to a patient
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentSpinalManipulationServiceInformationfromLoop2400(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("CR2");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("CR2", i);
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 609 Treatment Series Number
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 380 Treatment Count
       if (de != null)
         de.get();
       de = segment.getDataElement(3);       // 1367 Subluxation Level Code
       if (de != null)
         de.get();
       de = segment.getDataElement(4);       // 1367 Subluxation Level Code
       if (de != null)
         de.get();
       de = segment.getDataElement(5);       // 355 Unit or Basis for Measurement Code
       if (de != null)
         de.get();
       de = segment.getDataElement(6);       // 380 Treatment Period Count
       if (de != null)
         de.get();
       de = segment.getDataElement(7);       // 380 Monthly Treatment Count
       if (de != null)
         de.get();
       de = segment.getDataElement(8);       // 1342 Patient Condition Code
       if (de != null)
         de.get();
       de = segment.getDataElement(9);       // 1073 Complication Indicator
       if (de != null)
         de.get();
       de = segment.getDataElement(10);       // 352 Patient Condition Description
       if (de != null)
         de.get();
       de = segment.getDataElement(11);       // 352 Patient Condition Description
       if (de != null)
         de.get();
       de = segment.getDataElement(12);       // 1073 X-ray Availability Indicator
       if (de != null)
         de.get();
    }
  }

/** extract data from segment CR3 that is part of the Loop2400
*<br>Durable Medical Equipment Certification used 
*<br>To supply information regarding a physician's certification for durable medical equipment
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentDurableMedicalEquipmentCertificationfromLoop2400(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("CR3");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 1322 Certification Type Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 355 Unit or Basis for Measurement Code
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 380 Durable Medical Equipment Duration
  if (de != null)
    de.get();
  }

/** extract data from segment CR5 that is part of the Loop2400
*<br>Home Oxygen Therapy Information used 
*<br>To supply information regarding certification of medical necessity for home oxygen therapy
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentHomeOxygenTherapyInformationfromLoop2400(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("CR5");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 1322 Certification Type Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 380 Treatment Period Count
  if (de != null)
    de.get();
  de = segment.getDataElement(10);  // 380 Arterial Blood Gas Quantity
  if (de != null)
    de.get();
  de = segment.getDataElement(11);  // 380 Oxygen Saturation Quantity
  if (de != null)
    de.get();
  de = segment.getDataElement(12);  // 1349 Oxygen Test Condition Code
  if (de != null)
    de.get();
  de = segment.getDataElement(13);  // 1350 Oxygen Test Findings Code
  if (de != null)
    de.get();
  de = segment.getDataElement(14);  // 1350 Oxygen Test Findings Code
  if (de != null)
    de.get();
  de = segment.getDataElement(15);  // 1350 Oxygen Test Findings Code
  if (de != null)
    de.get();
  }

/** extract data from segment CRC that is part of the Loop2400
*<br>Ambulance Certification used 
*<br>To supply information on conditions
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentAmbulanceCertificationfromLoop2400(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("CRC");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("CRC", "07", i);
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 1136 Code Category
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 1073 Certification Condition Indicator
       if (de != null)
         de.get();
       de = segment.getDataElement(3);       // 1321 Condition Code
       if (de != null)
         de.get();
       de = segment.getDataElement(4);       // 1321 Condition Code
       if (de != null)
         de.get();
       de = segment.getDataElement(5);       // 1321 Condition Code
       if (de != null)
         de.get();
       de = segment.getDataElement(6);       // 1321 Condition Code
       if (de != null)
         de.get();
       de = segment.getDataElement(7);       // 1321 Condition Code
       if (de != null)
         de.get();
    }
  }

/** extract data from segment CRC that is part of the Loop2400
*<br>Hospice Employee Indicator used 
*<br>To supply information on conditions
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentHospiceEmployeeIndicatorfromLoop2400(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("CRC", "70");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 1136 Code Category
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1073 Hospice Employed Provider Indicator
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1321 Condition Indicator
  if (de != null)
    de.get();
  }

/** extract data from segment CRC that is part of the Loop2400
*<br>DMERC Condition Indicator used 
*<br>To supply information on conditions
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentDMERCConditionIndicatorfromLoop2400(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("CRC");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("CRC", "09", i);
 // other key values: "11" 
   // there can be 2 of these segments.
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 1136 Code Category
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 1073 Certification Condition Indicator
       if (de != null)
         de.get();
       de = segment.getDataElement(3);       // 1321 Condition Indicator
       if (de != null)
         de.get();
       de = segment.getDataElement(4);       // 1321 Condition Indicator
       if (de != null)
         de.get();
       de = segment.getDataElement(5);       // 1321 Condition Indicator
       if (de != null)
         de.get();
       de = segment.getDataElement(6);       // 1321 Condition Indicator
       if (de != null)
         de.get();
       de = segment.getDataElement(7);       // 1321 Condition Indicator
       if (de != null)
         de.get();
    }
  }

/** extract data from segment DTP that is part of the Loop2400
*<br>Date - Service Date used 
*<br>To specify any or all of a date, a time, or a time period
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentDateServiceDatefromLoop2400(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("DTP", "472");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 374 Date Time Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1250 Date Time Period Format Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1251 Service Date
  if (de != null)
    de.get();
  }

/** extract data from segment DTP that is part of the Loop2400
*<br>Date - Certification Revision Date used 
*<br>To specify any or all of a date, a time, or a time period
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentDateCertificationRevisionDatefromLoop2400(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("DTP", "607");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 374 Date Time Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1250 Date Time Period Format Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1251 Certification Revision Date
  if (de != null)
    de.get();
  }

/** extract data from segment DTP that is part of the Loop2400
*<br>Date - Referral Date used 
*<br>To specify any or all of a date, a time, or a time period
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentDateReferralDatefromLoop2400(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("DTP", "330");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 374 Date Time Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1250 Date Time Period Format Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1251 Referral Date
  if (de != null)
    de.get();
  }

/** extract data from segment DTP that is part of the Loop2400
*<br>Date - Begin Therapy Date used 
*<br>To specify any or all of a date, a time, or a time period
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentDateBeginTherapyDatefromLoop2400(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("DTP", "463");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 374 Date Time Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1250 Date Time Period Format Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1251 Begin Therapy Date
  if (de != null)
    de.get();
  }

/** extract data from segment DTP that is part of the Loop2400
*<br>Date - Last Certification Date used 
*<br>To specify any or all of a date, a time, or a time period
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentDateLastCertificationDatefromLoop2400(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("DTP", "461");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 374 Date Time Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1250 Date Time Period Format Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1251 Last Certification Date
  if (de != null)
    de.get();
  }

/** extract data from segment DTP that is part of the Loop2400
*<br>Date - Order Date used 
*<br>To specify any or all of a date, a time, or a time period
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentDateOrderDatefromLoop2400(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("DTP", "938");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 374 Date Time Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1250 Date Time Period Format Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1251 Order Date
  if (de != null)
    de.get();
  }

/** extract data from segment DTP that is part of the Loop2400
*<br>Date - Date Last Seen used 
*<br>To specify any or all of a date, a time, or a time period
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentDateDateLastSeenfromLoop2400(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("DTP", "304");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 374 Date Time Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1250 Date Time Period Format Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1251 Last Seen Date
  if (de != null)
    de.get();
  }

/** extract data from segment DTP that is part of the Loop2400
*<br>Date - Test used 
*<br>To specify any or all of a date, a time, or a time period
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentDateTestfromLoop2400(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("DTP");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("DTP", "738", i);
 // other key values: "739" 
   // there can be 2 of these segments.
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 374 Date Time Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 1250 Date Time Period Format Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(3);       // 1251 Test Performed Date
       if (de != null)
         de.get();
    }
  }

/** extract data from segment DTP that is part of the Loop2400
*<br>Date - Oxygen Saturation/Arterial Blood Gas Test used 
*<br>To specify any or all of a date, a time, or a time period
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentDateOxygenSaturationArterialBloodGasTestfromLoop2400(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("DTP");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("DTP", "119", i);
 // other key values: "GRA" "480" "481" 
   // there can be 3 of these segments.
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 374 Date Time Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 1250 Date Time Period Format Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(3);       // 1251 Oxygen Saturation Test Date
       if (de != null)
         de.get();
    }
  }

/** extract data from segment DTP that is part of the Loop2400
*<br>Date - Shipped used 
*<br>To specify any or all of a date, a time, or a time period
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentDateShippedfromLoop2400(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("DTP", "011");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 374 Date Time Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1250 Date Time Period Format Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1251 Shipped Date
  if (de != null)
    de.get();
  }

/** extract data from segment DTP that is part of the Loop2400
*<br>Date - Onset of Current Symptom/Illness used 
*<br>To specify any or all of a date, a time, or a time period
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentDateOnsetofCurrentSymptomIllnessfromLoop2400(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("DTP", "431");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 374 Date Time Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1250 Date Time Period Format Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1251 Onset Date
  if (de != null)
    de.get();
  }

/** extract data from segment DTP that is part of the Loop2400
*<br>Date - Last X-ray used 
*<br>To specify any or all of a date, a time, or a time period
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentDateLastXrayfromLoop2400(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("DTP", "455");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 374 Date Time Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1250 Date Time Period Format Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1251 Last X-Ray Date
  if (de != null)
    de.get();
  }

/** extract data from segment DTP that is part of the Loop2400
*<br>Date - Acute Manifestation used 
*<br>To specify any or all of a date, a time, or a time period
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentDateAcuteManifestationfromLoop2400(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("DTP", "453");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 374 Date Time Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1250 Date Time Period Format Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1251 Acute Manifestation Date
  if (de != null)
    de.get();
  }

/** extract data from segment DTP that is part of the Loop2400
*<br>Date - Initial Treatment used 
*<br>To specify any or all of a date, a time, or a time period
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentDateInitialTreatmentfromLoop2400(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("DTP", "454");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 374 Date Time Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1250 Date Time Period Format Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1251 Initial Treatment Date
  if (de != null)
    de.get();
  }

/** extract data from segment DTP that is part of the Loop2400
*<br>Date - Similar Illness/Symptom Onset used 
*<br>To specify any or all of a date, a time, or a time period
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentDateSimilarIllnessSymptomOnsetfromLoop2400(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("DTP", "438");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 374 Date Time Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1250 Date Time Period Format Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1251 Similar Illness or Symptom Date
  if (de != null)
    de.get();
  }

/** extract data from segment QTY that is part of the Loop2400
*<br>Anesthesia Modifying Units used 
*<br>To specify quantity information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentAnesthesiaModifyingUnitsfromLoop2400(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("QTY");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("QTY", i);
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 673 Quantity Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 380 Anesthesia Modifying Units
       if (de != null)
         de.get();
    }
  }

/** extract data from segment MEA that is part of the Loop2400
*<br>Test Result used 
*<br>To specify physical measurements or counts, including dimensions, tolerances, variances, and weights
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentTestResultfromLoop2400(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("MEA");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("MEA", i);
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 737 Measurement Reference Identification Code
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 738 Measurement Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(3);       // 739 Test Results
       if (de != null)
         de.get();
    }
  }

/** extract data from segment CN1 that is part of the Loop2400
*<br>Contract Information used 
*<br>To specify basic data about the contract or contract line item
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentContractInformationfromLoop2400(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("CN1");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 1166 Contract Type Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 782 Contract Amount
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 332 Contract Percentage
  if (de != null)
    de.get();
  de = segment.getDataElement(4);  // 127 Contract Code
  if (de != null)
    de.get();
  de = segment.getDataElement(5);  // 338 Terms Discount Percentage
  if (de != null)
    de.get();
  de = segment.getDataElement(6);  // 799 Contract Version Identifier
  if (de != null)
    de.get();
  }

/** extract data from segment REF that is part of the Loop2400
*<br>Repriced Line Item Reference Number used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentRepricedLineItemReferenceNumberfromLoop2400(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("REF", "9B");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 128 Reference Identification Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 127 Repriced Line Item Reference Number
  if (de != null)
    de.get();
  }

/** extract data from segment REF that is part of the Loop2400
*<br>Adjusted Repriced Line Item Reference Number used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentAdjustedRepricedLineItemReferenceNumberfromLoop2400(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("REF", "9D");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 128 Reference Identification Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 127 Adjusted Repriced Line Item Reference Number
  if (de != null)
    de.get();
  }

/** extract data from segment REF that is part of the Loop2400
*<br>Prior Authorization or Referral Number used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentPriorAuthorizationorReferralNumberfromLoop2400(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("REF");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("REF", "9F", i);
 // other key values: "G1" 
   // there can be 2 of these segments.
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 128 Reference Identification Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 127 Prior Authorization or Referral Number
       if (de != null)
         de.get();
    }
  }

/** extract data from segment REF that is part of the Loop2400
*<br>Line Item Control Number used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentLineItemControlNumberfromLoop2400(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("REF", "6R");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 128 Reference Identification Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 127 Line Item Control Number
  if (de != null)
    de.get();
  }

/** extract data from segment REF that is part of the Loop2400
*<br>Mammography Certification Number used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentMammographyCertificationNumberfromLoop2400(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("REF", "EW");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 128 Reference Identification Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 127 Mammography Certification Number
  if (de != null)
    de.get();
  }

/** extract data from segment REF that is part of the Loop2400
*<br>Clinical Laboratory Improvement Amendment (CLIA) Identification used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentClinicalLaboratoryImprovementAmendmentCLIAIdentificationfromLoop2400(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("REF", "X4");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 128 Reference Identification Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 127 Clinical Laboratory Improvement Amendment Number
  if (de != null)
    de.get();
  }

/** extract data from segment REF that is part of the Loop2400
*<br>Referring Clinical Laboratory Improvement Amendment (CLIA) Facility Identification used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentReferringClinicalLaboratoryImprovementAmendmentCLIAFacilityIdentificationfromLoop2400(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("REF", "F4");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 128 Reference Identification Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 127 Referring CLIA Number
  if (de != null)
    de.get();
  }

/** extract data from segment REF that is part of the Loop2400
*<br>Immunization Batch Number used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentImmunizationBatchNumberfromLoop2400(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("REF", "BT");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 128 Reference Identification Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 127 Immunization Batch Number
  if (de != null)
    de.get();
  }

/** extract data from segment REF that is part of the Loop2400
*<br>Ambulatory Patient Group (APG) used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentAmbulatoryPatientGroupAPGfromLoop2400(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("REF");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("REF", "1S", i);
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 128 Reference Identification Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 127 Ambulatory Patient Group Number
       if (de != null)
         de.get();
    }
  }

/** extract data from segment REF that is part of the Loop2400
*<br>Oxygen Flow Rate used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentOxygenFlowRatefromLoop2400(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("REF", "TP");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 128 Reference Identification Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 127 Oxygen Flow Rate
  if (de != null)
    de.get();
  }

/** extract data from segment REF that is part of the Loop2400
*<br>Universal Product Number (UPN) used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentUniversalProductNumberUPNfromLoop2400(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("REF", "OZ");
 // other key values: "VP" 
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 128 Reference Identification Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 127 Universal Product Number
  if (de != null)
    de.get();
  }

/** extract data from segment AMT that is part of the Loop2400
*<br>Sales Tax Amount used 
*<br>To indicate the total monetary amount
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentSalesTaxAmountfromLoop2400(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("AMT", "T");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 522 Amount Qualifier Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 782 Sales Tax Amount
  if (de != null)
    de.get();
  }

/** extract data from segment AMT that is part of the Loop2400
*<br>Approved Amount used 
*<br>To indicate the total monetary amount
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentApprovedAmountfromLoop2400(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("AMT", "AAE");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 522 Amount Qualifier Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 782 Approved Amount
  if (de != null)
    de.get();
  }

/** extract data from segment AMT that is part of the Loop2400
*<br>Postage Claimed Amount used 
*<br>To indicate the total monetary amount
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentPostageClaimedAmountfromLoop2400(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("AMT", "F4");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 522 Amount Qualifier Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 782 Postage Claimed Amount
  if (de != null)
    de.get();
  }

/** extract data from segment K3 that is part of the Loop2400
*<br>File Information used 
*<br>To transmit a fixed-format record or matrix contents
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentFileInformationfromLoop2400(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("K3");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("K3", i);
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 449 Fixed Format Information
       if (de != null)
         de.get();
    }
  }

/** extract data from segment NTE that is part of the Loop2400
*<br>Line Note used 
*<br>To transmit information in a free-form format, if necessary, for comment or special instruction
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentLineNotefromLoop2400(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("NTE");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 363 Note Reference Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 352 Line Note Text
  if (de != null)
    de.get();
  }

/** extract data from segment PS1 that is part of the Loop2400
*<br>Purchased Service Information used 
*<br>To specify the information about services that are purchased
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentPurchasedServiceInformationfromLoop2400(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("PS1");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 127 Purchased Service Provider Identifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 782 Purchased Service Charge Amount
  if (de != null)
    de.get();
  }

/** extract data from segment HSD that is part of the Loop2400
*<br>Health Care Services Delivery used 
*<br>To specify the delivery pattern of health care services
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentHealthCareServicesDeliveryfromLoop2400(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("HSD");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 673 Visits
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 380 Number of Visits
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 355 Frequency Period
  if (de != null)
    de.get();
  de = segment.getDataElement(4);  // 1167 Frequency Count
  if (de != null)
    de.get();
  de = segment.getDataElement(5);  // 615 Duration of Visits Units
  if (de != null)
    de.get();
  de = segment.getDataElement(6);  // 616 Duration of Visits, Number of Units
  if (de != null)
    de.get();
  de = segment.getDataElement(7);  // 678 Ship, Delivery or Calendar Pattern Code
  if (de != null)
    de.get();
  de = segment.getDataElement(8);  // 679 Delivery Pattern Time Code
  if (de != null)
    de.get();
  }

/** extract data from segment HCP that is part of the Loop2400
*<br>Line Pricing/Repricing Information used 
*<br>To specify pricing or repricing information about a health care claim or line item
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentLinePricingRepricingInformationfromLoop2400(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("HCP");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 1473 Pricing Methodology
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 782 Repriced Allowed Amount
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 782 Repriced Saving Amount
  if (de != null)
    de.get();
  de = segment.getDataElement(4);  // 127 Repricing Organization Identifier
  if (de != null)
    de.get();
  de = segment.getDataElement(5);  // 118 Repricing Per Diem or Flat Rate Amount
  if (de != null)
    de.get();
  de = segment.getDataElement(6);  // 127 Repriced Approved Ambulatory Patient Group Code
  if (de != null)
    de.get();
  de = segment.getDataElement(7);  // 782 Repriced Approved Ambulatory Patient Group Amount
  if (de != null)
    de.get();
  de = segment.getDataElement(9);  // 235 Product or Service ID Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(10);  // 234 Procedure Code
  if (de != null)
    de.get();
  de = segment.getDataElement(11);  // 355 Unit or Basis for Measurement Code
  if (de != null)
    de.get();
  de = segment.getDataElement(12);  // 380 Repriced Approved Service Unit Count
  if (de != null)
    de.get();
  de = segment.getDataElement(13);  // 901 Reject Reason Code
  if (de != null)
    de.get();
  de = segment.getDataElement(14);  // 1526 Policy Compliance Code
  if (de != null)
    de.get();
  de = segment.getDataElement(15);  // 1527 Exception Code
  if (de != null)
    de.get();
  }

/** extract data from loop 2420A that is part of Loop2400
*<br>Rendering Provider Name used 
* @param inLoop loop containing this loop
*@throws OBOEException - most likely loop not found
*/
public void extractLoop2420AfromLoop2400(Loop inLoop)  throws OBOEException
{
  Loop loop = inLoop.getLoop("2420A");
  if (loop == null) return;
  extractSegmentRenderingProviderNamefromLoop2420A(loop);
  extractSegmentRenderingProviderSpecialtyInformationfromLoop2420A(loop);
  extractSegmentAdditionalRenderingProviderNameInformationfromLoop2420A(loop);
  extractSegmentRenderingProviderSecondaryIdentificationfromLoop2420A(loop);
  }

/** extract data from segment NM1 that is part of the Loop2420A
*<br>Rendering Provider Name used 
*<br>To supply the full name of an individual or organizational entity
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentRenderingProviderNamefromLoop2420A(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("NM1");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 98 Entity Identifier Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1065 Entity Type Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1035 Rendering Provider Last or Organization Name
  if (de != null)
    de.get();
  de = segment.getDataElement(4);  // 1036 Rendering Provider First Name
  if (de != null)
    de.get();
  de = segment.getDataElement(5);  // 1037 Rendering Provider Middle Name
  if (de != null)
    de.get();
  de = segment.getDataElement(7);  // 1039 Rendering Provider Name Suffix
  if (de != null)
    de.get();
  de = segment.getDataElement(8);  // 66 Identification Code Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(9);  // 67 Rendering Provider Identifier
  if (de != null)
    de.get();
  }

/** extract data from segment PRV that is part of the Loop2420A
*<br>Rendering Provider Specialty Information used 
*<br>To specify the identifying characteristics of a provider
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentRenderingProviderSpecialtyInformationfromLoop2420A(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("PRV");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 1221 Provider Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 128 Reference Identification Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 127 Provider Taxonomy Code
  if (de != null)
    de.get();
  }

/** extract data from segment N2 that is part of the Loop2420A
*<br>Additional Rendering Provider Name Information used 
*<br>To specify additional names or those longer than 35 characters in length
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentAdditionalRenderingProviderNameInformationfromLoop2420A(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("N2");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 93 Rendering Provider Name Additional Text
  if (de != null)
    de.get();
  }

/** extract data from segment REF that is part of the Loop2420A
*<br>Rendering Provider Secondary Identification used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentRenderingProviderSecondaryIdentificationfromLoop2420A(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("REF");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("REF", i);
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 128 Reference Identification Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 127 Rendering Provider Secondary Identifier
       if (de != null)
         de.get();
    }
  }

/** extract data from loop 2420B that is part of Loop2400
*<br>Purchased Service Provider Name used 
* @param inLoop loop containing this loop
*@throws OBOEException - most likely loop not found
*/
public void extractLoop2420BfromLoop2400(Loop inLoop)  throws OBOEException
{
  Loop loop = inLoop.getLoop("2420B");
  if (loop == null) return;
  extractSegmentPurchasedServiceProviderNamefromLoop2420B(loop);
  extractSegmentPurchasedServiceProviderSecondaryIdentificationfromLoop2420B(loop);
  }

/** extract data from segment NM1 that is part of the Loop2420B
*<br>Purchased Service Provider Name used 
*<br>To supply the full name of an individual or organizational entity
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentPurchasedServiceProviderNamefromLoop2420B(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("NM1");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 98 Entity Identifier Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1065 Entity Type Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(8);  // 66 Identification Code Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(9);  // 67 Purchased Service Provider Identifier
  if (de != null)
    de.get();
  }

/** extract data from segment REF that is part of the Loop2420B
*<br>Purchased Service Provider Secondary Identification used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentPurchasedServiceProviderSecondaryIdentificationfromLoop2420B(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("REF");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("REF", i);
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 128 Reference Identification Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 127 Purchased Service Provider Secondary Identifier
       if (de != null)
         de.get();
    }
  }

/** extract data from loop 2420C that is part of Loop2400
*<br>Service Facility Location used 
* @param inLoop loop containing this loop
*@throws OBOEException - most likely loop not found
*/
public void extractLoop2420CfromLoop2400(Loop inLoop)  throws OBOEException
{
  Loop loop = inLoop.getLoop("2420C");
  if (loop == null) return;
  extractSegmentServiceFacilityLocationfromLoop2420C(loop);
  extractSegmentAdditionalServiceFacilityLocationNameInformationfromLoop2420C(loop);
  extractSegmentServiceFacilityLocationAddressfromLoop2420C(loop);
  extractSegmentServiceFacilityLocationCityStateZIPfromLoop2420C(loop);
  extractSegmentServiceFacilityLocationSecondaryIdentificationfromLoop2420C(loop);
  }

/** extract data from segment NM1 that is part of the Loop2420C
*<br>Service Facility Location used 
*<br>To supply the full name of an individual or organizational entity
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentServiceFacilityLocationfromLoop2420C(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("NM1");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 98 Entity Identifier Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1065 Entity Type Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1035 Laboratory or Facility Name
  if (de != null)
    de.get();
  de = segment.getDataElement(8);  // 66 Identification Code Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(9);  // 67 Laboratory or Facility Primary Identifier
  if (de != null)
    de.get();
  }

/** extract data from segment N2 that is part of the Loop2420C
*<br>Additional Service Facility Location Name Information used 
*<br>To specify additional names or those longer than 35 characters in length
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentAdditionalServiceFacilityLocationNameInformationfromLoop2420C(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("N2");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 93 Laboratory or Facility Name Additional Text
  if (de != null)
    de.get();
  }

/** extract data from segment N3 that is part of the Loop2420C
*<br>Service Facility Location Address used 
*<br>To specify the location of the named party
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentServiceFacilityLocationAddressfromLoop2420C(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("N3");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 166 Laboratory or Facility Address Line
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 166 Laboratory or Facility Address Line
  if (de != null)
    de.get();
  }

/** extract data from segment N4 that is part of the Loop2420C
*<br>Service Facility Location City/State/ZIP used 
*<br>To specify the geographic place of the named party
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentServiceFacilityLocationCityStateZIPfromLoop2420C(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("N4");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 19 Laboratory or Facility City Name
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 156 Laboratory or Facility State or Province Code
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 116 Laboratory or Facility Postal Zone or ZIP Code
  if (de != null)
    de.get();
  de = segment.getDataElement(4);  // 26 Country Code
  if (de != null)
    de.get();
  }

/** extract data from segment REF that is part of the Loop2420C
*<br>Service Facility Location Secondary Identification used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentServiceFacilityLocationSecondaryIdentificationfromLoop2420C(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("REF");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("REF", i);
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 128 Reference Identification Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 127 Service Facility Location Secondary Identifier
       if (de != null)
         de.get();
    }
  }

/** extract data from loop 2420D that is part of Loop2400
*<br>Supervising Provider Name used 
* @param inLoop loop containing this loop
*@throws OBOEException - most likely loop not found
*/
public void extractLoop2420DfromLoop2400(Loop inLoop)  throws OBOEException
{
  Loop loop = inLoop.getLoop("2420D");
  if (loop == null) return;
  extractSegmentSupervisingProviderNamefromLoop2420D(loop);
  extractSegmentAdditionalSupervisingProviderNameInformationfromLoop2420D(loop);
  extractSegmentSupervisingProviderSecondaryIdentificationfromLoop2420D(loop);
  }

/** extract data from segment NM1 that is part of the Loop2420D
*<br>Supervising Provider Name used 
*<br>To supply the full name of an individual or organizational entity
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentSupervisingProviderNamefromLoop2420D(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("NM1");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 98 Entity Identifier Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1065 Entity Type Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1035 Supervising Provider Last Name
  if (de != null)
    de.get();
  de = segment.getDataElement(4);  // 1036 Supervising Provider First Name
  if (de != null)
    de.get();
  de = segment.getDataElement(5);  // 1037 Supervising Provider Middle Name
  if (de != null)
    de.get();
  de = segment.getDataElement(7);  // 1039 Supervising Provider Name Suffix
  if (de != null)
    de.get();
  de = segment.getDataElement(8);  // 66 Identification Code Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(9);  // 67 Supervising Provider Identifier
  if (de != null)
    de.get();
  }

/** extract data from segment N2 that is part of the Loop2420D
*<br>Additional Supervising Provider Name Information used 
*<br>To specify additional names or those longer than 35 characters in length
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentAdditionalSupervisingProviderNameInformationfromLoop2420D(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("N2");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 93 Supervising Provider Name Additional Text
  if (de != null)
    de.get();
  }

/** extract data from segment REF that is part of the Loop2420D
*<br>Supervising Provider Secondary Identification used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentSupervisingProviderSecondaryIdentificationfromLoop2420D(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("REF");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("REF", i);
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 128 Reference Identification Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 127 Supervising Provider Secondary Identifier
       if (de != null)
         de.get();
    }
  }

/** extract data from loop 2420E that is part of Loop2400
*<br>Ordering Provider Name used 
* @param inLoop loop containing this loop
*@throws OBOEException - most likely loop not found
*/
public void extractLoop2420EfromLoop2400(Loop inLoop)  throws OBOEException
{
  Loop loop = inLoop.getLoop("2420E");
  if (loop == null) return;
  extractSegmentOrderingProviderNamefromLoop2420E(loop);
  extractSegmentAdditionalOrderingProviderNameInformationfromLoop2420E(loop);
  extractSegmentOrderingProviderAddressfromLoop2420E(loop);
  extractSegmentOrderingProviderCityStateZIPCodefromLoop2420E(loop);
  extractSegmentOrderingProviderSecondaryIdentificationfromLoop2420E(loop);
  extractSegmentOrderingProviderContactInformationfromLoop2420E(loop);
  }

/** extract data from segment NM1 that is part of the Loop2420E
*<br>Ordering Provider Name used 
*<br>To supply the full name of an individual or organizational entity
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentOrderingProviderNamefromLoop2420E(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("NM1");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 98 Entity Identifier Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1065 Entity Type Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1035 Ordering Provider Last Name
  if (de != null)
    de.get();
  de = segment.getDataElement(4);  // 1036 Ordering Provider First Name
  if (de != null)
    de.get();
  de = segment.getDataElement(5);  // 1037 Ordering Provider Middle Name
  if (de != null)
    de.get();
  de = segment.getDataElement(7);  // 1039 Ordering Provider Name Suffix
  if (de != null)
    de.get();
  de = segment.getDataElement(8);  // 66 Identification Code Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(9);  // 67 Ordering Provider Identifier
  if (de != null)
    de.get();
  }

/** extract data from segment N2 that is part of the Loop2420E
*<br>Additional Ordering Provider Name Information used 
*<br>To specify additional names or those longer than 35 characters in length
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentAdditionalOrderingProviderNameInformationfromLoop2420E(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("N2");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 93 Ordering Provider Name Additional Text
  if (de != null)
    de.get();
  }

/** extract data from segment N3 that is part of the Loop2420E
*<br>Ordering Provider Address used 
*<br>To specify the location of the named party
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentOrderingProviderAddressfromLoop2420E(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("N3");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 166 Ordering Provider Address Line
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 166 Ordering Provider Address Line
  if (de != null)
    de.get();
  }

/** extract data from segment N4 that is part of the Loop2420E
*<br>Ordering Provider City/State/ZIP Code used 
*<br>To specify the geographic place of the named party
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentOrderingProviderCityStateZIPCodefromLoop2420E(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("N4");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 19 Ordering Provider City Name
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 156 Ordering Provider State Code
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 116 Ordering Provider Postal Zone or ZIP Code
  if (de != null)
    de.get();
  de = segment.getDataElement(4);  // 26 Country Code
  if (de != null)
    de.get();
  }

/** extract data from segment REF that is part of the Loop2420E
*<br>Ordering Provider Secondary Identification used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentOrderingProviderSecondaryIdentificationfromLoop2420E(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("REF");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("REF", i);
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 128 Reference Identification Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 127 Ordering Provider Secondary Identifier
       if (de != null)
         de.get();
    }
  }

/** extract data from segment PER that is part of the Loop2420E
*<br>Ordering Provider Contact Information used 
*<br>To identify a person or office to whom administrative communications should be directed
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentOrderingProviderContactInformationfromLoop2420E(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("PER");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 366 Contact Function Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 93 Ordering Provider Contact Name
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 365 Communication Number Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(4);  // 364 Communication Number
  if (de != null)
    de.get();
  de = segment.getDataElement(5);  // 365 Communication Number Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(6);  // 364 Communication Number
  if (de != null)
    de.get();
  de = segment.getDataElement(7);  // 365 Communication Number Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(8);  // 364 Communication Number
  if (de != null)
    de.get();
  }

/** extract data from loop 2420F that is part of Loop2400
*<br>Referring Provider Name used 
* @param inLoop loop containing this loop
*@throws OBOEException - most likely loop not found
*/
public void extractLoop2420FfromLoop2400(Loop inLoop)  throws OBOEException
{
  Loop loop;
  int numberInVector = inLoop.getCount("2420F");
  for (int i = 0; i <  numberInVector; i++)
   {
   loop = inLoop.getLoop("2420F", i);
   if (loop == null) return;
      extractSegmentReferringProviderNamefromLoop2420F(loop);
      extractSegmentReferringProviderSpecialtyInformationfromLoop2420F(loop);
      extractSegmentAdditionalReferringProviderNameInformationfromLoop2420F(loop);
      extractSegmentReferringProviderSecondaryIdentificationfromLoop2420F(loop);
    }
  }

/** extract data from segment NM1 that is part of the Loop2420F
*<br>Referring Provider Name used 
*<br>To supply the full name of an individual or organizational entity
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentReferringProviderNamefromLoop2420F(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("NM1");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 98 Entity Identifier Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1065 Entity Type Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1035 Referring Provider Last Name
  if (de != null)
    de.get();
  de = segment.getDataElement(4);  // 1036 Referring Provider First Name
  if (de != null)
    de.get();
  de = segment.getDataElement(5);  // 1037 Referring Provider Middle Name
  if (de != null)
    de.get();
  de = segment.getDataElement(7);  // 1039 Referring Provider Name Suffix
  if (de != null)
    de.get();
  de = segment.getDataElement(8);  // 66 Identification Code Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(9);  // 67 Referring Provider Identifier
  if (de != null)
    de.get();
  }

/** extract data from segment PRV that is part of the Loop2420F
*<br>Referring Provider Specialty Information used 
*<br>To specify the identifying characteristics of a provider
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentReferringProviderSpecialtyInformationfromLoop2420F(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("PRV");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 1221 Provider Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 128 Reference Identification Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 127 Provider Taxonomy Code
  if (de != null)
    de.get();
  }

/** extract data from segment N2 that is part of the Loop2420F
*<br>Additional Referring Provider Name Information used 
*<br>To specify additional names or those longer than 35 characters in length
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentAdditionalReferringProviderNameInformationfromLoop2420F(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("N2");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 93 Referring Provider Name Additional Text
  if (de != null)
    de.get();
  }

/** extract data from segment REF that is part of the Loop2420F
*<br>Referring Provider Secondary Identification used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentReferringProviderSecondaryIdentificationfromLoop2420F(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("REF");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("REF", i);
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 128 Reference Identification Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 127 Referring Provider Secondary Identifier
       if (de != null)
         de.get();
    }
  }

/** extract data from loop 2420G that is part of Loop2400
*<br>Other Payer Prior Authorization or Referral Number used 
* @param inLoop loop containing this loop
*@throws OBOEException - most likely loop not found
*/
public void extractLoop2420GfromLoop2400(Loop inLoop)  throws OBOEException
{
  Loop loop;
  int numberInVector = inLoop.getCount("2420G");
  for (int i = 0; i <  numberInVector; i++)
   {
   loop = inLoop.getLoop("2420G", i);
   if (loop == null) return;
      extractSegmentOtherPayerPriorAuthorizationorReferralNumberfromLoop2420G(loop);
      extractSegmentOtherPayerPriorAuthorizationorReferralNumber_2fromLoop2420G(loop);
    }
  }

/** extract data from segment NM1 that is part of the Loop2420G
*<br>Other Payer Prior Authorization or Referral Number used 
*<br>To supply the full name of an individual or organizational entity
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentOtherPayerPriorAuthorizationorReferralNumberfromLoop2420G(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("NM1");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 98 Entity Identifier Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1065 Entity Type Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1035 Payer Name
  if (de != null)
    de.get();
  de = segment.getDataElement(8);  // 66 Identification Code Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(9);  // 67 Other Payer Identification Number
  if (de != null)
    de.get();
  }

/** extract data from segment REF that is part of the Loop2420G
*<br>Other Payer Prior Authorization or Referral Number used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentOtherPayerPriorAuthorizationorReferralNumber_2fromLoop2420G(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("REF");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("REF", i);
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 128 Reference Identification Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 127 Other Payer Prior Authorization or Referral Number
       if (de != null)
         de.get();
    }
  }

/** extract data from loop 2430 that is part of Loop2400
*<br>Line Adjudication Information used 
* @param inLoop loop containing this loop
*@throws OBOEException - most likely loop not found
*/
public void extractLoop2430fromLoop2400(Loop inLoop)  throws OBOEException
{
  Loop loop;
  int numberInVector = inLoop.getCount("2430");
  for (int i = 0; i <  numberInVector; i++)
   {
   loop = inLoop.getLoop("2430", i);
   if (loop == null) return;
      extractSegmentLineAdjudicationInformationfromLoop2430(loop);
      extractSegmentLineAdjustmentfromLoop2430(loop);
      extractSegmentLineAdjudicationDatefromLoop2430(loop);
    }
  }

/** extract data from segment SVD that is part of the Loop2430
*<br>Line Adjudication Information used 
*<br>To convey service line adjudication information for coordination of benefits between the initial payers of a health care claim and all subsequent payers
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentLineAdjudicationInformationfromLoop2430(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("SVD");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 67 Other Payer Primary Identifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 782 Service Line Paid Amount
  if (de != null)
    de.get();
    CompositeDE  composite = (CompositeDE) segment.getCompositeDE(3);  // C003 Composite Medical
  if (composite == null)
    return;
  de = composite.getDataElement(1);  // composite element 235 Product or Service ID Qualifier
  if (de != null)
    de.get();
  de = composite.getDataElement(2);  // composite element 234 Procedure Code
  if (de != null)
    de.get();
  de = composite.getDataElement(3);  // composite element 1339 Procedure Modifier
  if (de != null)
    de.get();
  de = composite.getDataElement(4);  // composite element 1339 Procedure Modifier
  if (de != null)
    de.get();
  de = composite.getDataElement(5);  // composite element 1339 Procedure Modifier
  if (de != null)
    de.get();
  de = composite.getDataElement(6);  // composite element 1339 Procedure Modifier
  if (de != null)
    de.get();
  de = composite.getDataElement(7);  // composite element 352 Procedure Code Description
  if (de != null)
    de.get();
  de = segment.getDataElement(5);  // 380 Paid Service Unit Count
  if (de != null)
    de.get();
  de = segment.getDataElement(6);  // 554 Bundled or Unbundled Line Number
  if (de != null)
    de.get();
  }

/** extract data from segment CAS that is part of the Loop2430
*<br>Line Adjustment used 
*<br>To supply adjustment reason codes and amounts as needed for an entire claim or for a particular service within the claim being paid
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentLineAdjustmentfromLoop2430(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("CAS");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("CAS", i);
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 1033 Claim Adjustment Group Code
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 1034 Adjustment Reason Code
       if (de != null)
         de.get();
       de = segment.getDataElement(3);       // 782 Adjustment Amount
       if (de != null)
         de.get();
       de = segment.getDataElement(4);       // 380 Adjustment Quantity
       if (de != null)
         de.get();
       de = segment.getDataElement(5);       // 1034 Adjustment Reason Code
       if (de != null)
         de.get();
       de = segment.getDataElement(6);       // 782 Adjustment Amount
       if (de != null)
         de.get();
       de = segment.getDataElement(7);       // 380 Adjustment Quantity
       if (de != null)
         de.get();
       de = segment.getDataElement(8);       // 1034 Adjustment Reason Code
       if (de != null)
         de.get();
       de = segment.getDataElement(9);       // 782 Adjustment Amount
       if (de != null)
         de.get();
       de = segment.getDataElement(10);       // 380 Adjustment Quantity
       if (de != null)
         de.get();
       de = segment.getDataElement(11);       // 1034 Adjustment Reason Code
       if (de != null)
         de.get();
       de = segment.getDataElement(12);       // 782 Adjustment Amount
       if (de != null)
         de.get();
       de = segment.getDataElement(13);       // 380 Adjustment Quantity
       if (de != null)
         de.get();
       de = segment.getDataElement(14);       // 1034 Adjustment Reason Code
       if (de != null)
         de.get();
       de = segment.getDataElement(15);       // 782 Adjustment Amount
       if (de != null)
         de.get();
       de = segment.getDataElement(16);       // 380 Adjustment Quantity
       if (de != null)
         de.get();
       de = segment.getDataElement(17);       // 1034 Adjustment Reason Code
       if (de != null)
         de.get();
       de = segment.getDataElement(18);       // 782 Adjustment Amount
       if (de != null)
         de.get();
       de = segment.getDataElement(19);       // 380 Adjustment Quantity
       if (de != null)
         de.get();
    }
  }

/** extract data from segment DTP that is part of the Loop2430
*<br>Line Adjudication Date used 
*<br>To specify any or all of a date, a time, or a time period
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentLineAdjudicationDatefromLoop2430(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("DTP");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 374 Date Time Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1250 Date Time Period Format Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1251 Adjudication or Payment Date
  if (de != null)
    de.get();
  }

/** extract data from loop 2440 that is part of Loop2400
*<br>Form Identification Code used 
* @param inLoop loop containing this loop
*@throws OBOEException - most likely loop not found
*/
public void extractLoop2440fromLoop2400(Loop inLoop)  throws OBOEException
{
  Loop loop;
  int numberInVector = inLoop.getCount("2440");
  for (int i = 0; i <  numberInVector; i++)
   {
   loop = inLoop.getLoop("2440", i);
   if (loop == null) return;
      extractSegmentFormIdentificationCodefromLoop2440(loop);
      extractSegmentSupportingDocumentationfromLoop2440(loop);
    }
  }

/** extract data from segment LQ that is part of the Loop2440
*<br>Form Identification Code used 
*<br>Code to transmit standard industry codes
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentFormIdentificationCodefromLoop2440(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("LQ");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 1270 Code List Qualifier Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1271 Form Identifier
  if (de != null)
    de.get();
  }

/** extract data from segment FRM that is part of the Loop2440
*<br>Supporting Documentation used 
*<br>To specify information in response to a codified questionnaire document.
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentSupportingDocumentationfromLoop2440(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("FRM");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("FRM", i);
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 350 Question Number/Letter
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 1073 Question Response
       if (de != null)
         de.get();
       de = segment.getDataElement(3);       // 127 Question Response
       if (de != null)
         de.get();
       de = segment.getDataElement(4);       // 373 Question Response
       if (de != null)
         de.get();
       de = segment.getDataElement(5);       // 332 Question Response
       if (de != null)
         de.get();
    }
  }

/** extract data from loop 2000C that is part of Loop2000B
*<br>Patient Hierarchical Level used 
* @param inLoop loop containing this loop
*@throws OBOEException - most likely loop not found
*/
public void extractLoop2000CfromLoop2000B(Loop inLoop)  throws OBOEException
{
  Loop loop;
  int numberInVector = inLoop.getCount("2000C");
  for (int i = 0; i <  numberInVector; i++)
   {
   loop = inLoop.getLoop("2000C", i);
   if (loop == null) return;
      extractSegmentPatientHierarchicalLevelfromLoop2000C(loop);
      extractSegmentPatientInformationfromLoop2000C(loop);
      extractLoop2010CAfromLoop2000C(loop);
      extractLoop2300fromLoop2000C(loop);
    }
  }

/** extract data from segment HL that is part of the Loop2000C
*<br>Patient Hierarchical Level used 
*<br>To identify dependencies among and the content of hierarchically related groups of data segments
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentPatientHierarchicalLevelfromLoop2000C(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("HL");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 628 Hierarchical ID Number
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 734 Hierarchical Parent ID Number
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 735 Hierarchical Level Code
  if (de != null)
    de.get();
  de = segment.getDataElement(4);  // 736 Hierarchical Child Code
  if (de != null)
    de.get();
  }

/** extract data from segment PAT that is part of the Loop2000C
*<br>Patient Information used 
*<br>To supply patient information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentPatientInformationfromLoop2000C(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("PAT");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 1069 Individual Relationship Code
  if (de != null)
    de.get();
  de = segment.getDataElement(5);  // 1250 Date Time Period Format Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(6);  // 1251 Patient Death Date
  if (de != null)
    de.get();
  de = segment.getDataElement(7);  // 355 Unit or Basis for Measurement Code
  if (de != null)
    de.get();
  de = segment.getDataElement(8);  // 81 Patient Weight
  if (de != null)
    de.get();
  de = segment.getDataElement(9);  // 1073 Pregnancy Indicator
  if (de != null)
    de.get();
  }

/** extract data from loop 2010CA that is part of Loop2000C
*<br>Patient Name used 
* @param inLoop loop containing this loop
*@throws OBOEException - most likely loop not found
*/
public void extractLoop2010CAfromLoop2000C(Loop inLoop)  throws OBOEException
{
  Loop loop = inLoop.getLoop("2010CA");
  if (loop == null) return;
  extractSegmentPatientNamefromLoop2010CA(loop);
  extractSegmentAdditionalPatientNameInformationfromLoop2010CA(loop);
  extractSegmentPatientAddressfromLoop2010CA(loop);
  extractSegmentPatientCityStateZIPCodefromLoop2010CA(loop);
  extractSegmentPatientDemographicInformationfromLoop2010CA(loop);
  extractSegmentPatientSecondaryIdentificationfromLoop2010CA(loop);
  extractSegmentPropertyandCasualtyClaimNumberfromLoop2010CA(loop);
  }

/** extract data from segment NM1 that is part of the Loop2010CA
*<br>Patient Name used 
*<br>To supply the full name of an individual or organizational entity
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentPatientNamefromLoop2010CA(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("NM1");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 98 Entity Identifier Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1065 Entity Type Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1035 Patient Last Name
  if (de != null)
    de.get();
  de = segment.getDataElement(4);  // 1036 Patient First Name
  if (de != null)
    de.get();
  de = segment.getDataElement(5);  // 1037 Patient Middle Name
  if (de != null)
    de.get();
  de = segment.getDataElement(7);  // 1039 Patient Name Suffix
  if (de != null)
    de.get();
  de = segment.getDataElement(8);  // 66 Identification Code Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(9);  // 67 Patient Primary Identifier
  if (de != null)
    de.get();
  }

/** extract data from segment N2 that is part of the Loop2010CA
*<br>Additional Patient Name Information used 
*<br>To specify additional names or those longer than 35 characters in length
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentAdditionalPatientNameInformationfromLoop2010CA(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("N2");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 93 Patient Additional Name
  if (de != null)
    de.get();
  }

/** extract data from segment N3 that is part of the Loop2010CA
*<br>Patient Address used 
*<br>To specify the location of the named party
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentPatientAddressfromLoop2010CA(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("N3");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 166 Patient Address Line
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 166 Patient Address Line
  if (de != null)
    de.get();
  }

/** extract data from segment N4 that is part of the Loop2010CA
*<br>Patient City/State/ZIP Code used 
*<br>To specify the geographic place of the named party
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentPatientCityStateZIPCodefromLoop2010CA(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("N4");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 19 Patient City Name
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 156 Patient State Code
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 116 Patient Postal Zone or ZIP Code
  if (de != null)
    de.get();
  de = segment.getDataElement(4);  // 26 Country Code
  if (de != null)
    de.get();
  }

/** extract data from segment DMG that is part of the Loop2010CA
*<br>Patient Demographic Information used 
*<br>To supply demographic information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentPatientDemographicInformationfromLoop2010CA(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("DMG");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 1250 Date Time Period Format Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1251 Patient Birth Date
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1068 Patient Gender Code
  if (de != null)
    de.get();
  }

/** extract data from segment REF that is part of the Loop2010CA
*<br>Patient Secondary Identification used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentPatientSecondaryIdentificationfromLoop2010CA(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("REF");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("REF", "1W", i);
 // other key values: "23" "IG" "SY" 
   // there can be 5 of these segments.
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 128 Reference Identification Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 127 Patient Secondary Identifier
       if (de != null)
         de.get();
    }
  }

/** extract data from segment REF that is part of the Loop2010CA
*<br>Property and Casualty Claim Number used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentPropertyandCasualtyClaimNumberfromLoop2010CA(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("REF", "Y4");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 128 Reference Identification Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 127 Property Casualty Claim Number
  if (de != null)
    de.get();
  }

/** extract data from loop 2300 that is part of Loop2000C
*<br>Claim Information used 
* @param inLoop loop containing this loop
*@throws OBOEException - most likely loop not found
*/
public void extractLoop2300fromLoop2000C(Loop inLoop)  throws OBOEException
{
  Loop loop;
  int numberInVector = inLoop.getCount("2300");
  for (int i = 0; i <  numberInVector; i++)
   {
   loop = inLoop.getLoop("2300", i);
   if (loop == null) return;
      extractSegmentClaimInformation_2fromLoop2300(loop);
      extractSegmentDateOrderDate_2fromLoop2300(loop);
      extractSegmentDateInitialTreatment_2fromLoop2300(loop);
      extractSegmentDateReferralDate_2fromLoop2300(loop);
      extractSegmentDateDateLastSeen_2fromLoop2300(loop);
      extractSegmentDateOnsetofCurrentIllnessSymptom_2fromLoop2300(loop);
      extractSegmentDateAcuteManifestation_2fromLoop2300(loop);
      extractSegmentDateSimilarIllnessSymptomOnset_2fromLoop2300(loop);
      extractSegmentDateAccident_2fromLoop2300(loop);
      extractSegmentDateLastMenstrualPeriod_2fromLoop2300(loop);
      extractSegmentDateLastXray_2fromLoop2300(loop);
      extractSegmentDateEstimatedDateofBirth_2fromLoop2300(loop);
      extractSegmentDateHearingandVisionPrescriptionDate_2fromLoop2300(loop);
      extractSegmentDateDisabilityBegin_2fromLoop2300(loop);
      extractSegmentDateDisabilityEnd_2fromLoop2300(loop);
      extractSegmentDateLastWorked_2fromLoop2300(loop);
      extractSegmentDateAuthorizedReturntoWork_2fromLoop2300(loop);
      extractSegmentDateAdmission_2fromLoop2300(loop);
      extractSegmentDateDischarge_2fromLoop2300(loop);
      extractSegmentDateAssumedandRelinquishedCareDates_2fromLoop2300(loop);
      extractSegmentClaimSupplementalInformation_2fromLoop2300(loop);
      extractSegmentContractInformation_2fromLoop2300(loop);
      extractSegmentCreditDebitCardMaximumAmount_2fromLoop2300(loop);
      extractSegmentPatientAmountPaid_2fromLoop2300(loop);
      extractSegmentTotalPurchasedServiceAmount_2fromLoop2300(loop);
      extractSegmentServiceAuthorizationExceptionCode_2fromLoop2300(loop);
      extractSegmentMandatoryMedicareSection4081CrossoverIndicator_2fromLoop2300(loop);
      extractSegmentMammographyCertificationNumber_2fromLoop2300(loop);
      extractSegmentPriorAuthorizationorReferralNumber_2fromLoop2300(loop);
      extractSegmentOriginalReferenceNumberICNDCN_2fromLoop2300(loop);
      extractSegmentClinicalLaboratoryImprovementAmendmentCLIANumber_2fromLoop2300(loop);
      extractSegmentRepricedClaimNumber_2fromLoop2300(loop);
      extractSegmentAdjustedRepricedClaimNumber_2fromLoop2300(loop);
      extractSegmentInvestigationalDeviceExemptionNumber_2fromLoop2300(loop);
      extractSegmentClaimIdentificationNumberforClearingHousesandOtherTransmissionIntermediaries_2fromLoop2300(loop);
      extractSegmentAmbulatoryPatientGroupAPG_2fromLoop2300(loop);
      extractSegmentMedicalRecordNumber_2fromLoop2300(loop);
      extractSegmentDemonstrationProjectIdentifier_2fromLoop2300(loop);
      extractSegmentFileInformation_2fromLoop2300(loop);
      extractSegmentClaimNote_2fromLoop2300(loop);
      extractSegmentAmbulanceTransportInformation_2fromLoop2300(loop);
      extractSegmentSpinalManipulationServiceInformation_2fromLoop2300(loop);
      extractSegmentAmbulanceCertification_2fromLoop2300(loop);
      extractSegmentPatientConditionInformationVision_2fromLoop2300(loop);
      extractSegmentHomeboundIndicator_2fromLoop2300(loop);
      extractSegmentHealthCareDiagnosisCode_2fromLoop2300(loop);
      extractSegmentClaimPricingRepricingInformation_2fromLoop2300(loop);
      extractLoop2305_2fromLoop2300(loop);
      extractLoop2310A_2fromLoop2300(loop);
      extractLoop2310B_2fromLoop2300(loop);
      extractLoop2310C_2fromLoop2300(loop);
      extractLoop2310D_2fromLoop2300(loop);
      extractLoop2310E_2fromLoop2300(loop);
      extractLoop2320_2fromLoop2300(loop);
      extractLoop2400_2fromLoop2300(loop);
    }
  }

/** extract data from segment CLM that is part of the Loop2300
*<br>Claim Information used 
*<br>To specify basic data about the claim
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentClaimInformation_2fromLoop2300(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("CLM");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 1028 Patient Account Number
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 782 Total Claim Charge Amount
  if (de != null)
    de.get();
    CompositeDE  composite = (CompositeDE) segment.getCompositeDE(5);  // C023 Health Care Service
  if (composite == null)
    return;
  de = composite.getDataElement(1);  // composite element 1331 Facility Type Code
  if (de != null)
    de.get();
  de = composite.getDataElement(3);  // composite element 1325 Claim Frequency Code
  if (de != null)
    de.get();
  de = segment.getDataElement(6);  // 1073 Provider or Supplier Signature Indicator
  if (de != null)
    de.get();
  de = segment.getDataElement(7);  // 1359 Medicare Assignment Code
  if (de != null)
    de.get();
  de = segment.getDataElement(8);  // 1073 Benefits Assignment Certification Indicator
  if (de != null)
    de.get();
  de = segment.getDataElement(9);  // 1363 Release of Information Code
  if (de != null)
    de.get();
  de = segment.getDataElement(10);  // 1351 Patient Signature Source Code
  if (de != null)
    de.get();
  composite = (CompositeDE) segment.getCompositeDE(11);  // C024 Related
  if (composite == null)
    return;
  de = composite.getDataElement(1);  // composite element 1362 Related Causes Code
  if (de != null)
    de.get();
  de = composite.getDataElement(2);  // composite element 1362 Related Causes Code
  if (de != null)
    de.get();
  de = composite.getDataElement(3);  // composite element 1362 Related Causes Code
  if (de != null)
    de.get();
  de = composite.getDataElement(4);  // composite element 156 Auto Accident State or Province Code
  if (de != null)
    de.get();
  de = composite.getDataElement(5);  // composite element 26 Country Code
  if (de != null)
    de.get();
  de = segment.getDataElement(12);  // 1366 Special Program Indicator
  if (de != null)
    de.get();
  de = segment.getDataElement(16);  // 1360 Participation Agreement
  if (de != null)
    de.get();
  de = segment.getDataElement(20);  // 1514 Delay Reason Code
  if (de != null)
    de.get();
  }

/** extract data from segment DTP that is part of the Loop2300
*<br>Date - Order Date used 
*<br>To specify any or all of a date, a time, or a time period
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentDateOrderDate_2fromLoop2300(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("DTP", "938");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 374 Date Time Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1250 Date Time Period Format Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1251 Order Date
  if (de != null)
    de.get();
  }

/** extract data from segment DTP that is part of the Loop2300
*<br>Date - Initial Treatment used 
*<br>To specify any or all of a date, a time, or a time period
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentDateInitialTreatment_2fromLoop2300(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("DTP", "454");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 374 Date Time Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1250 Date Time Period Format Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1251 Initial Treatment Date
  if (de != null)
    de.get();
  }

/** extract data from segment DTP that is part of the Loop2300
*<br>Date - Referral Date used 
*<br>To specify any or all of a date, a time, or a time period
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentDateReferralDate_2fromLoop2300(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("DTP", "330");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 374 Date Time Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1250 Date Time Period Format Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1251 Referral Date
  if (de != null)
    de.get();
  }

/** extract data from segment DTP that is part of the Loop2300
*<br>Date - Date Last Seen used 
*<br>To specify any or all of a date, a time, or a time period
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentDateDateLastSeen_2fromLoop2300(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("DTP", "304");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 374 Date Time Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1250 Date Time Period Format Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1251 Last Seen Date
  if (de != null)
    de.get();
  }

/** extract data from segment DTP that is part of the Loop2300
*<br>Date - Onset of Current Illness/Symptom used 
*<br>To specify any or all of a date, a time, or a time period
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentDateOnsetofCurrentIllnessSymptom_2fromLoop2300(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("DTP", "431");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 374 Date Time Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1250 Date Time Period Format Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1251 Onset of Current Illness or Injury Date
  if (de != null)
    de.get();
  }

/** extract data from segment DTP that is part of the Loop2300
*<br>Date - Acute Manifestation used 
*<br>To specify any or all of a date, a time, or a time period
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentDateAcuteManifestation_2fromLoop2300(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("DTP");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("DTP", "453", i);
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 374 Date Time Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 1250 Date Time Period Format Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(3);       // 1251 Acute Manifestation Date
       if (de != null)
         de.get();
    }
  }

/** extract data from segment DTP that is part of the Loop2300
*<br>Date - Similar Illness/Symptom Onset used 
*<br>To specify any or all of a date, a time, or a time period
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentDateSimilarIllnessSymptomOnset_2fromLoop2300(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("DTP");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("DTP", "438", i);
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 374 Date Time Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 1250 Date Time Period Format Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(3);       // 1251 Similar Illness or Symptom Date
       if (de != null)
         de.get();
    }
  }

/** extract data from segment DTP that is part of the Loop2300
*<br>Date - Accident used 
*<br>To specify any or all of a date, a time, or a time period
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentDateAccident_2fromLoop2300(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("DTP");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("DTP", "439", i);
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 374 Date Time Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 1250 Date Time Period Format Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(3);       // 1251 Accident Date
       if (de != null)
         de.get();
    }
  }

/** extract data from segment DTP that is part of the Loop2300
*<br>Date - Last Menstrual Period used 
*<br>To specify any or all of a date, a time, or a time period
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentDateLastMenstrualPeriod_2fromLoop2300(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("DTP", "484");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 374 Date Time Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1250 Date Time Period Format Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1251 Last Menstrual Period Date
  if (de != null)
    de.get();
  }

/** extract data from segment DTP that is part of the Loop2300
*<br>Date - Last X-ray used 
*<br>To specify any or all of a date, a time, or a time period
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentDateLastXray_2fromLoop2300(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("DTP", "455");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 374 Date Time Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1250 Date Time Period Format Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1251 Last X-Ray Date
  if (de != null)
    de.get();
  }

/** extract data from segment DTP that is part of the Loop2300
*<br>Date - Estimated Date of Birth used 
*<br>To specify any or all of a date, a time, or a time period
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentDateEstimatedDateofBirth_2fromLoop2300(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("DTP", "ABC");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 374 Date Time Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1250 Date Time Period Format Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1251 Estimated Birth Date
  if (de != null)
    de.get();
  }

/** extract data from segment DTP that is part of the Loop2300
*<br>Date - Hearing and Vision Prescription Date used 
*<br>To specify any or all of a date, a time, or a time period
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentDateHearingandVisionPrescriptionDate_2fromLoop2300(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("DTP", "471");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 374 Date Time Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1250 Date Time Period Format Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1251 Prescription Date
  if (de != null)
    de.get();
  }

/** extract data from segment DTP that is part of the Loop2300
*<br>Date - Disability Begin used 
*<br>To specify any or all of a date, a time, or a time period
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentDateDisabilityBegin_2fromLoop2300(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("DTP");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("DTP", "360", i);
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 374 Date Time Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 1250 Date Time Period Format Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(3);       // 1251 Disability From Date
       if (de != null)
         de.get();
    }
  }

/** extract data from segment DTP that is part of the Loop2300
*<br>Date - Disability End used 
*<br>To specify any or all of a date, a time, or a time period
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentDateDisabilityEnd_2fromLoop2300(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("DTP");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("DTP", "361", i);
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 374 Date Time Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 1250 Date Time Period Format Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(3);       // 1251 Disability To Date
       if (de != null)
         de.get();
    }
  }

/** extract data from segment DTP that is part of the Loop2300
*<br>Date - Last Worked used 
*<br>To specify any or all of a date, a time, or a time period
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentDateLastWorked_2fromLoop2300(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("DTP", "297");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 374 Date Time Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1250 Date Time Period Format Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1251 Last Worked Date
  if (de != null)
    de.get();
  }

/** extract data from segment DTP that is part of the Loop2300
*<br>Date - Authorized Return to Work used 
*<br>To specify any or all of a date, a time, or a time period
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentDateAuthorizedReturntoWork_2fromLoop2300(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("DTP", "296");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 374 Date Time Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1250 Date Time Period Format Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1251 Work Return Date
  if (de != null)
    de.get();
  }

/** extract data from segment DTP that is part of the Loop2300
*<br>Date - Admission used 
*<br>To specify any or all of a date, a time, or a time period
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentDateAdmission_2fromLoop2300(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("DTP", "435");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 374 Date Time Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1250 Date Time Period Format Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1251 Related Hospitalization Admission Date
  if (de != null)
    de.get();
  }

/** extract data from segment DTP that is part of the Loop2300
*<br>Date - Discharge used 
*<br>To specify any or all of a date, a time, or a time period
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentDateDischarge_2fromLoop2300(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("DTP", "096");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 374 Date Time Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1250 Date Time Period Format Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1251 Related Hospitalization Discharge Date
  if (de != null)
    de.get();
  }

/** extract data from segment DTP that is part of the Loop2300
*<br>Date - Assumed and Relinquished Care Dates used 
*<br>To specify any or all of a date, a time, or a time period
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentDateAssumedandRelinquishedCareDates_2fromLoop2300(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("DTP");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("DTP", "090", i);
 // other key values: "091" 
   // there can be 2 of these segments.
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 374 Date Time Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 1250 Date Time Period Format Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(3);       // 1251 Assumed or Relinquished Care Date
       if (de != null)
         de.get();
    }
  }

/** extract data from segment PWK that is part of the Loop2300
*<br>Claim Supplemental Information used 
*<br>To identify the type or transmission or both of paperwork or supporting information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentClaimSupplementalInformation_2fromLoop2300(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("PWK");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("PWK", i);
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 755 Attachment Report Type Code
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 756 Attachment Transmission Code
       if (de != null)
         de.get();
       de = segment.getDataElement(5);       // 66 Identification Code Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(6);       // 67 Attachment Control Number
       if (de != null)
         de.get();
    }
  }

/** extract data from segment CN1 that is part of the Loop2300
*<br>Contract Information used 
*<br>To specify basic data about the contract or contract line item
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentContractInformation_2fromLoop2300(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("CN1");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 1166 Contract Type Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 782 Contract Amount
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 332 Contract Percentage
  if (de != null)
    de.get();
  de = segment.getDataElement(4);  // 127 Contract Code
  if (de != null)
    de.get();
  de = segment.getDataElement(5);  // 338 Terms Discount Percentage
  if (de != null)
    de.get();
  de = segment.getDataElement(6);  // 799 Contract Version Identifier
  if (de != null)
    de.get();
  }

/** extract data from segment AMT that is part of the Loop2300
*<br>Credit/Debit Card Maximum Amount used 
*<br>To indicate the total monetary amount
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentCreditDebitCardMaximumAmount_2fromLoop2300(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("AMT", "MA");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 522 Amount Qualifier Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 782 Credit or Debit Card Maximum Amount
  if (de != null)
    de.get();
  }

/** extract data from segment AMT that is part of the Loop2300
*<br>Patient Amount Paid used 
*<br>To indicate the total monetary amount
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentPatientAmountPaid_2fromLoop2300(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("AMT", "F5");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 522 Amount Qualifier Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 782 Patient Amount Paid
  if (de != null)
    de.get();
  }

/** extract data from segment AMT that is part of the Loop2300
*<br>Total Purchased Service Amount used 
*<br>To indicate the total monetary amount
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentTotalPurchasedServiceAmount_2fromLoop2300(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("AMT", "NE");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 522 Amount Qualifier Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 782 Total Purchased Service Amount
  if (de != null)
    de.get();
  }

/** extract data from segment REF that is part of the Loop2300
*<br>Service Authorization Exception Code used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentServiceAuthorizationExceptionCode_2fromLoop2300(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("REF", "4N");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 128 Reference Identification Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 127 Service Authorization Exception Code
  if (de != null)
    de.get();
  }

/** extract data from segment REF that is part of the Loop2300
*<br>Mandatory Medicare (Section 4081) Crossover Indicator used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentMandatoryMedicareSection4081CrossoverIndicator_2fromLoop2300(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("REF", "F5");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 128 Reference Identification Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 127 Medicare Section 4081 Indicator
  if (de != null)
    de.get();
  }

/** extract data from segment REF that is part of the Loop2300
*<br>Mammography Certification Number used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentMammographyCertificationNumber_2fromLoop2300(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("REF", "EW");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 128 Reference Identification Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 127 Mammography Certification Number
  if (de != null)
    de.get();
  }

/** extract data from segment REF that is part of the Loop2300
*<br>Prior Authorization or Referral Number used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentPriorAuthorizationorReferralNumber_2fromLoop2300(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("REF");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("REF", "9F", i);
 // other key values: "G1" 
   // there can be 2 of these segments.
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 128 Reference Identification Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 127 Prior Authorization or Referral Number
       if (de != null)
         de.get();
    }
  }

/** extract data from segment REF that is part of the Loop2300
*<br>Original Reference Number (ICN/DCN) used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentOriginalReferenceNumberICNDCN_2fromLoop2300(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("REF", "F8");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 128 Reference Identification Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 127 Claim Original Reference Number
  if (de != null)
    de.get();
  }

/** extract data from segment REF that is part of the Loop2300
*<br>Clinical Laboratory Improvement Amendment (CLIA) Number used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentClinicalLaboratoryImprovementAmendmentCLIANumber_2fromLoop2300(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("REF");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("REF", "X4", i);
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 128 Reference Identification Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 127 Clinical Laboratory Improvement Amendment Number
       if (de != null)
         de.get();
    }
  }

/** extract data from segment REF that is part of the Loop2300
*<br>Repriced Claim Number used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentRepricedClaimNumber_2fromLoop2300(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("REF", "9A");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 128 Reference Identification Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 127 Repriced Claim Reference Number
  if (de != null)
    de.get();
  }

/** extract data from segment REF that is part of the Loop2300
*<br>Adjusted Repriced Claim Number used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentAdjustedRepricedClaimNumber_2fromLoop2300(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("REF", "9C");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 128 Reference Identification Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 127 Adjusted Repriced Claim Reference Number
  if (de != null)
    de.get();
  }

/** extract data from segment REF that is part of the Loop2300
*<br>Investigational Device Exemption Number used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentInvestigationalDeviceExemptionNumber_2fromLoop2300(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("REF", "LX");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 128 Reference Identification Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 127 Investigational Device Exemption Identifier
  if (de != null)
    de.get();
  }

/** extract data from segment REF that is part of the Loop2300
*<br>Claim Identification Number for Clearing Houses and Other Transmission Intermediaries used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentClaimIdentificationNumberforClearingHousesandOtherTransmissionIntermediaries_2fromLoop2300(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("REF", "D9");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 128 Reference Identification Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 127 Clearinghouse Trace Number
  if (de != null)
    de.get();
  }

/** extract data from segment REF that is part of the Loop2300
*<br>Ambulatory Patient Group (APG) used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentAmbulatoryPatientGroupAPG_2fromLoop2300(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("REF");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("REF", "1S", i);
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 128 Reference Identification Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 127 Ambulatory Patient Group Number
       if (de != null)
         de.get();
    }
  }

/** extract data from segment REF that is part of the Loop2300
*<br>Medical Record Number used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentMedicalRecordNumber_2fromLoop2300(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("REF", "EA");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 128 Reference Identification Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 127 Medical Record Number
  if (de != null)
    de.get();
  }

/** extract data from segment REF that is part of the Loop2300
*<br>Demonstration Project Identifier used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentDemonstrationProjectIdentifier_2fromLoop2300(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("REF", "P4");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 128 Reference Identification Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 127 Demonstration Project Identifier
  if (de != null)
    de.get();
  }

/** extract data from segment K3 that is part of the Loop2300
*<br>File Information used 
*<br>To transmit a fixed-format record or matrix contents
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentFileInformation_2fromLoop2300(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("K3");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("K3", i);
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 449 Fixed Format Information
       if (de != null)
         de.get();
    }
  }

/** extract data from segment NTE that is part of the Loop2300
*<br>Claim Note used 
*<br>To transmit information in a free-form format, if necessary, for comment or special instruction
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentClaimNote_2fromLoop2300(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("NTE");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 363 Note Reference Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 352 Claim Note Text
  if (de != null)
    de.get();
  }

/** extract data from segment CR1 that is part of the Loop2300
*<br>Ambulance Transport Information used 
*<br>To supply information related to the ambulance service rendered to a patient
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentAmbulanceTransportInformation_2fromLoop2300(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("CR1");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 355 Unit or Basis for Measurement Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 81 Patient Weight
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1316 Ambulance Transport Code
  if (de != null)
    de.get();
  de = segment.getDataElement(4);  // 1317 Ambulance Transport Reason Code
  if (de != null)
    de.get();
  de = segment.getDataElement(5);  // 355 Unit or Basis for Measurement Code
  if (de != null)
    de.get();
  de = segment.getDataElement(6);  // 380 Transport Distance
  if (de != null)
    de.get();
  de = segment.getDataElement(9);  // 352 Round Trip Purpose Description
  if (de != null)
    de.get();
  de = segment.getDataElement(10);  // 352 Stretcher Purpose Description
  if (de != null)
    de.get();
  }

/** extract data from segment CR2 that is part of the Loop2300
*<br>Spinal Manipulation Service Information used 
*<br>To supply information related to the chiropractic service rendered to a patient
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentSpinalManipulationServiceInformation_2fromLoop2300(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("CR2");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 609 Treatment Series Number
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 380 Treatment Count
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1367 Subluxation Level Code
  if (de != null)
    de.get();
  de = segment.getDataElement(4);  // 1367 Subluxation Level Code
  if (de != null)
    de.get();
  de = segment.getDataElement(5);  // 355 Unit or Basis for Measurement Code
  if (de != null)
    de.get();
  de = segment.getDataElement(6);  // 380 Treatment Period Count
  if (de != null)
    de.get();
  de = segment.getDataElement(7);  // 380 Monthly Treatment Count
  if (de != null)
    de.get();
  de = segment.getDataElement(8);  // 1342 Patient Condition Code
  if (de != null)
    de.get();
  de = segment.getDataElement(9);  // 1073 Complication Indicator
  if (de != null)
    de.get();
  de = segment.getDataElement(10);  // 352 Patient Condition Description
  if (de != null)
    de.get();
  de = segment.getDataElement(11);  // 352 Patient Condition Description
  if (de != null)
    de.get();
  de = segment.getDataElement(12);  // 1073 X-ray Availability Indicator
  if (de != null)
    de.get();
  }

/** extract data from segment CRC that is part of the Loop2300
*<br>Ambulance Certification used 
*<br>To supply information on conditions
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentAmbulanceCertification_2fromLoop2300(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("CRC");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("CRC", "07", i);
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 1136 Code Category
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 1073 Certification Condition Indicator
       if (de != null)
         de.get();
       de = segment.getDataElement(3);       // 1321 Condition Code
       if (de != null)
         de.get();
       de = segment.getDataElement(4);       // 1321 Condition Code
       if (de != null)
         de.get();
       de = segment.getDataElement(5);       // 1321 Condition Code
       if (de != null)
         de.get();
       de = segment.getDataElement(6);       // 1321 Condition Code
       if (de != null)
         de.get();
       de = segment.getDataElement(7);       // 1321 Condition Code
       if (de != null)
         de.get();
    }
  }

/** extract data from segment CRC that is part of the Loop2300
*<br>Patient Condition Information: Vision used 
*<br>To supply information on conditions
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentPatientConditionInformationVision_2fromLoop2300(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("CRC");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("CRC", "E1", i);
 // other key values: "E2" "E3" 
   // there can be 3 of these segments.
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 1136 Code Category
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 1073 Certification Condition Indicator
       if (de != null)
         de.get();
       de = segment.getDataElement(3);       // 1321 Condition Code
       if (de != null)
         de.get();
       de = segment.getDataElement(4);       // 1321 Condition Code
       if (de != null)
         de.get();
       de = segment.getDataElement(5);       // 1321 Condition Code
       if (de != null)
         de.get();
       de = segment.getDataElement(6);       // 1321 Condition Code
       if (de != null)
         de.get();
       de = segment.getDataElement(7);       // 1321 Condition Code
       if (de != null)
         de.get();
    }
  }

/** extract data from segment CRC that is part of the Loop2300
*<br>Homebound Indicator used 
*<br>To supply information on conditions
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentHomeboundIndicator_2fromLoop2300(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("CRC", "75");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 1136 Code Category
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1073 Certification Condition Indicator
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1321 Homebound Indicator
  if (de != null)
    de.get();
  }

/** extract data from segment HI that is part of the Loop2300
*<br>Health Care Diagnosis Code used 
*<br>To supply information related to the delivery of health care
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentHealthCareDiagnosisCode_2fromLoop2300(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("HI");
  if (segment == null)
    return;
  DataElement de;
    CompositeDE  composite = (CompositeDE) segment.getCompositeDE(1);  // C022 Health Care
  if (composite == null)
    return;
  de = composite.getDataElement(1);  // composite element 1270 Diagnosis Type Code
  if (de != null)
    de.get();
  de = composite.getDataElement(2);  // composite element 1271 Diagnosis Code
  if (de != null)
    de.get();
  composite = (CompositeDE) segment.getCompositeDE(2);  // C022 Health Care
  if (composite == null)
    return;
  de = composite.getDataElement(1);  // composite element 1270 Diagnosis Type Code
  if (de != null)
    de.get();
  de = composite.getDataElement(2);  // composite element 1271 Diagnosis Code
  if (de != null)
    de.get();
  composite = (CompositeDE) segment.getCompositeDE(3);  // C022 Health Care
  if (composite == null)
    return;
  de = composite.getDataElement(1);  // composite element 1270 Diagnosis Type Code
  if (de != null)
    de.get();
  de = composite.getDataElement(2);  // composite element 1271 Diagnosis Code
  if (de != null)
    de.get();
  composite = (CompositeDE) segment.getCompositeDE(4);  // C022 Health Care
  if (composite == null)
    return;
  de = composite.getDataElement(1);  // composite element 1270 Diagnosis Type Code
  if (de != null)
    de.get();
  de = composite.getDataElement(2);  // composite element 1271 Diagnosis Code
  if (de != null)
    de.get();
  composite = (CompositeDE) segment.getCompositeDE(5);  // C022 Health Care
  if (composite == null)
    return;
  de = composite.getDataElement(1);  // composite element 1270 Diagnosis Type Code
  if (de != null)
    de.get();
  de = composite.getDataElement(2);  // composite element 1271 Diagnosis Code
  if (de != null)
    de.get();
  composite = (CompositeDE) segment.getCompositeDE(6);  // C022 Health Care
  if (composite == null)
    return;
  de = composite.getDataElement(1);  // composite element 1270 Diagnosis Type Code
  if (de != null)
    de.get();
  de = composite.getDataElement(2);  // composite element 1271 Diagnosis Code
  if (de != null)
    de.get();
  composite = (CompositeDE) segment.getCompositeDE(7);  // C022 Health Care
  if (composite == null)
    return;
  de = composite.getDataElement(1);  // composite element 1270 Diagnosis Type Code
  if (de != null)
    de.get();
  de = composite.getDataElement(2);  // composite element 1271 Diagnosis Code
  if (de != null)
    de.get();
  composite = (CompositeDE) segment.getCompositeDE(8);  // C022 Health Care
  if (composite == null)
    return;
  de = composite.getDataElement(1);  // composite element 1270 Diagnosis Type Code
  if (de != null)
    de.get();
  de = composite.getDataElement(2);  // composite element 1271 Diagnosis Code
  if (de != null)
    de.get();
  }

/** extract data from segment HCP that is part of the Loop2300
*<br>Claim Pricing/Repricing Information used 
*<br>To specify pricing or repricing information about a health care claim or line item
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentClaimPricingRepricingInformation_2fromLoop2300(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("HCP");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 1473 Pricing Methodology
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 782 Repriced Allowed Amount
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 782 Repriced Saving Amount
  if (de != null)
    de.get();
  de = segment.getDataElement(4);  // 127 Repricing Organization Identifier
  if (de != null)
    de.get();
  de = segment.getDataElement(5);  // 118 Repricing Per Diem or Flat Rate Amount
  if (de != null)
    de.get();
  de = segment.getDataElement(6);  // 127 Repriced Approved Ambulatory Patient Group Code
  if (de != null)
    de.get();
  de = segment.getDataElement(7);  // 782 Repriced Approved Ambulatory Patient Group Amount
  if (de != null)
    de.get();
  de = segment.getDataElement(13);  // 901 Reject Reason Code
  if (de != null)
    de.get();
  de = segment.getDataElement(14);  // 1526 Policy Compliance Code
  if (de != null)
    de.get();
  de = segment.getDataElement(15);  // 1527 Exception Code
  if (de != null)
    de.get();
  }

/** extract data from loop 2305 that is part of Loop2300
*<br>Home Health Care Plan Information used 
* @param inLoop loop containing this loop
*@throws OBOEException - most likely loop not found
*/
public void extractLoop2305_2fromLoop2300(Loop inLoop)  throws OBOEException
{
  Loop loop;
  int numberInVector = inLoop.getCount("2305");
  for (int i = 0; i <  numberInVector; i++)
   {
   loop = inLoop.getLoop("2305", i);
   if (loop == null) return;
      extractSegmentHomeHealthCarePlanInformation_2fromLoop2305(loop);
      extractSegmentHealthCareServicesDelivery_2fromLoop2305(loop);
    }
  }

/** extract data from segment CR7 that is part of the Loop2305
*<br>Home Health Care Plan Information used 
*<br>To supply information related to the home health care plan of treatment and services
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentHomeHealthCarePlanInformation_2fromLoop2305(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("CR7");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 921 Discipline Type Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1470 Total Visits Rendered Count
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1470 Certification Period Projected Visit Count
  if (de != null)
    de.get();
  }

/** extract data from segment HSD that is part of the Loop2305
*<br>Health Care Services Delivery used 
*<br>To specify the delivery pattern of health care services
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentHealthCareServicesDelivery_2fromLoop2305(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("HSD");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("HSD", i);
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 673 Visits
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 380 Number of Visits
       if (de != null)
         de.get();
       de = segment.getDataElement(3);       // 355 Frequency Period
       if (de != null)
         de.get();
       de = segment.getDataElement(4);       // 1167 Frequency Count
       if (de != null)
         de.get();
       de = segment.getDataElement(5);       // 615 Duration of Visits Units
       if (de != null)
         de.get();
       de = segment.getDataElement(6);       // 616 Duration of Visits, Number of Units
       if (de != null)
         de.get();
       de = segment.getDataElement(7);       // 678 Ship, Delivery or Calendar Pattern Code
       if (de != null)
         de.get();
       de = segment.getDataElement(8);       // 679 Delivery Pattern Time Code
       if (de != null)
         de.get();
    }
  }

/** extract data from loop 2310A that is part of Loop2300
*<br>Referring Provider Name used 
* @param inLoop loop containing this loop
*@throws OBOEException - most likely loop not found
*/
public void extractLoop2310A_2fromLoop2300(Loop inLoop)  throws OBOEException
{
  Loop loop;
  int numberInVector = inLoop.getCount("2310A");
  for (int i = 0; i <  numberInVector; i++)
   {
   loop = inLoop.getLoop("2310A", i);
   if (loop == null) return;
      extractSegmentReferringProviderName_2fromLoop2310A(loop);
      extractSegmentReferringProviderSpecialtyInformation_2fromLoop2310A(loop);
      extractSegmentAdditionalReferringProviderNameInformation_2fromLoop2310A(loop);
      extractSegmentReferringProviderSecondaryIdentification_2fromLoop2310A(loop);
    }
  }

/** extract data from segment NM1 that is part of the Loop2310A
*<br>Referring Provider Name used 
*<br>To supply the full name of an individual or organizational entity
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentReferringProviderName_2fromLoop2310A(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("NM1");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 98 Entity Identifier Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1065 Entity Type Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1035 Referring Provider Last Name
  if (de != null)
    de.get();
  de = segment.getDataElement(4);  // 1036 Referring Provider First Name
  if (de != null)
    de.get();
  de = segment.getDataElement(5);  // 1037 Referring Provider Middle Name
  if (de != null)
    de.get();
  de = segment.getDataElement(7);  // 1039 Referring Provider Name Suffix
  if (de != null)
    de.get();
  de = segment.getDataElement(8);  // 66 Identification Code Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(9);  // 67 Referring Provider Identifier
  if (de != null)
    de.get();
  }

/** extract data from segment PRV that is part of the Loop2310A
*<br>Referring Provider Specialty Information used 
*<br>To specify the identifying characteristics of a provider
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentReferringProviderSpecialtyInformation_2fromLoop2310A(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("PRV");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 1221 Provider Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 128 Reference Identification Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 127 Provider Taxonomy Code
  if (de != null)
    de.get();
  }

/** extract data from segment N2 that is part of the Loop2310A
*<br>Additional Referring Provider Name Information used 
*<br>To specify additional names or those longer than 35 characters in length
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentAdditionalReferringProviderNameInformation_2fromLoop2310A(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("N2");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 93 Referring Provider Name Additional Text
  if (de != null)
    de.get();
  }

/** extract data from segment REF that is part of the Loop2310A
*<br>Referring Provider Secondary Identification used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentReferringProviderSecondaryIdentification_2fromLoop2310A(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("REF");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("REF", i);
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 128 Reference Identification Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 127 Referring Provider Secondary Identifier
       if (de != null)
         de.get();
    }
  }

/** extract data from loop 2310B that is part of Loop2300
*<br>Rendering Provider Name used 
* @param inLoop loop containing this loop
*@throws OBOEException - most likely loop not found
*/
public void extractLoop2310B_2fromLoop2300(Loop inLoop)  throws OBOEException
{
  Loop loop = inLoop.getLoop("2310B");
  if (loop == null) return;
  extractSegmentRenderingProviderName_2fromLoop2310B(loop);
  extractSegmentRenderingProviderSpecialtyInformation_2fromLoop2310B(loop);
  extractSegmentAdditionalRenderingProviderNameInformation_2fromLoop2310B(loop);
  extractSegmentRenderingProviderSecondaryIdentification_2fromLoop2310B(loop);
  }

/** extract data from segment NM1 that is part of the Loop2310B
*<br>Rendering Provider Name used 
*<br>To supply the full name of an individual or organizational entity
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentRenderingProviderName_2fromLoop2310B(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("NM1");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 98 Entity Identifier Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1065 Entity Type Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1035 Rendering Provider Last or Organization Name
  if (de != null)
    de.get();
  de = segment.getDataElement(4);  // 1036 Rendering Provider First Name
  if (de != null)
    de.get();
  de = segment.getDataElement(5);  // 1037 Rendering Provider Middle Name
  if (de != null)
    de.get();
  de = segment.getDataElement(7);  // 1039 Rendering Provider Name Suffix
  if (de != null)
    de.get();
  de = segment.getDataElement(8);  // 66 Identification Code Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(9);  // 67 Rendering Provider Identifier
  if (de != null)
    de.get();
  }

/** extract data from segment PRV that is part of the Loop2310B
*<br>Rendering Provider Specialty Information used 
*<br>To specify the identifying characteristics of a provider
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentRenderingProviderSpecialtyInformation_2fromLoop2310B(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("PRV");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 1221 Provider Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 128 Reference Identification Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 127 Provider Taxonomy Code
  if (de != null)
    de.get();
  }

/** extract data from segment N2 that is part of the Loop2310B
*<br>Additional Rendering Provider Name Information used 
*<br>To specify additional names or those longer than 35 characters in length
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentAdditionalRenderingProviderNameInformation_2fromLoop2310B(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("N2");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 93 Rendering Provider Name Additional Text
  if (de != null)
    de.get();
  }

/** extract data from segment REF that is part of the Loop2310B
*<br>Rendering Provider Secondary Identification used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentRenderingProviderSecondaryIdentification_2fromLoop2310B(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("REF");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("REF", i);
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 128 Reference Identification Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 127 Rendering Provider Secondary Identifier
       if (de != null)
         de.get();
    }
  }

/** extract data from loop 2310C that is part of Loop2300
*<br>Purchased Service Provider Name used 
* @param inLoop loop containing this loop
*@throws OBOEException - most likely loop not found
*/
public void extractLoop2310C_2fromLoop2300(Loop inLoop)  throws OBOEException
{
  Loop loop = inLoop.getLoop("2310C");
  if (loop == null) return;
  extractSegmentPurchasedServiceProviderName_2fromLoop2310C(loop);
  extractSegmentPurchasedServiceProviderSecondaryIdentification_2fromLoop2310C(loop);
  }

/** extract data from segment NM1 that is part of the Loop2310C
*<br>Purchased Service Provider Name used 
*<br>To supply the full name of an individual or organizational entity
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentPurchasedServiceProviderName_2fromLoop2310C(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("NM1");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 98 Entity Identifier Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1065 Entity Type Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(8);  // 66 Identification Code Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(9);  // 67 Purchased Service Provider Identifier
  if (de != null)
    de.get();
  }

/** extract data from segment REF that is part of the Loop2310C
*<br>Purchased Service Provider Secondary Identification used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentPurchasedServiceProviderSecondaryIdentification_2fromLoop2310C(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("REF");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("REF", i);
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 128 Reference Identification Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 127 Purchased Service Provider Secondary Identifier
       if (de != null)
         de.get();
    }
  }

/** extract data from loop 2310D that is part of Loop2300
*<br>Service Facility Location used 
* @param inLoop loop containing this loop
*@throws OBOEException - most likely loop not found
*/
public void extractLoop2310D_2fromLoop2300(Loop inLoop)  throws OBOEException
{
  Loop loop = inLoop.getLoop("2310D");
  if (loop == null) return;
  extractSegmentServiceFacilityLocation_2fromLoop2310D(loop);
  extractSegmentAdditionalServiceFacilityLocationNameInformation_2fromLoop2310D(loop);
  extractSegmentServiceFacilityLocationAddress_2fromLoop2310D(loop);
  extractSegmentServiceFacilityLocationCityStateZIP_2fromLoop2310D(loop);
  extractSegmentServiceFacilityLocationSecondaryIdentification_2fromLoop2310D(loop);
  }

/** extract data from segment NM1 that is part of the Loop2310D
*<br>Service Facility Location used 
*<br>To supply the full name of an individual or organizational entity
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentServiceFacilityLocation_2fromLoop2310D(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("NM1");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 98 Entity Identifier Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1065 Entity Type Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1035 Laboratory or Facility Name
  if (de != null)
    de.get();
  de = segment.getDataElement(8);  // 66 Identification Code Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(9);  // 67 Laboratory or Facility Primary Identifier
  if (de != null)
    de.get();
  }

/** extract data from segment N2 that is part of the Loop2310D
*<br>Additional Service Facility Location Name Information used 
*<br>To specify additional names or those longer than 35 characters in length
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentAdditionalServiceFacilityLocationNameInformation_2fromLoop2310D(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("N2");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 93 Laboratory or Facility Name Additional Text
  if (de != null)
    de.get();
  }

/** extract data from segment N3 that is part of the Loop2310D
*<br>Service Facility Location Address used 
*<br>To specify the location of the named party
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentServiceFacilityLocationAddress_2fromLoop2310D(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("N3");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 166 Laboratory or Facility Address Line
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 166 Laboratory or Facility Address Line
  if (de != null)
    de.get();
  }

/** extract data from segment N4 that is part of the Loop2310D
*<br>Service Facility Location City/State/ZIP used 
*<br>To specify the geographic place of the named party
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentServiceFacilityLocationCityStateZIP_2fromLoop2310D(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("N4");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 19 Laboratory or Facility City Name
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 156 Laboratory or Facility State or Province Code
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 116 Laboratory or Facility Postal Zone or ZIP Code
  if (de != null)
    de.get();
  de = segment.getDataElement(4);  // 26 Country Code
  if (de != null)
    de.get();
  }

/** extract data from segment REF that is part of the Loop2310D
*<br>Service Facility Location Secondary Identification used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentServiceFacilityLocationSecondaryIdentification_2fromLoop2310D(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("REF");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("REF", i);
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 128 Reference Identification Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 127 Laboratory or Facility Secondary Identifier
       if (de != null)
         de.get();
    }
  }

/** extract data from loop 2310E that is part of Loop2300
*<br>Supervising Provider Name used 
* @param inLoop loop containing this loop
*@throws OBOEException - most likely loop not found
*/
public void extractLoop2310E_2fromLoop2300(Loop inLoop)  throws OBOEException
{
  Loop loop = inLoop.getLoop("2310E");
  if (loop == null) return;
  extractSegmentSupervisingProviderName_2fromLoop2310E(loop);
  extractSegmentAdditionalSupervisingProviderNameInformation_2fromLoop2310E(loop);
  extractSegmentSupervisingProviderSecondaryIdentification_2fromLoop2310E(loop);
  }

/** extract data from segment NM1 that is part of the Loop2310E
*<br>Supervising Provider Name used 
*<br>To supply the full name of an individual or organizational entity
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentSupervisingProviderName_2fromLoop2310E(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("NM1");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 98 Entity Identifier Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1065 Entity Type Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1035 Supervising Provider Last Name
  if (de != null)
    de.get();
  de = segment.getDataElement(4);  // 1036 Supervising Provider First Name
  if (de != null)
    de.get();
  de = segment.getDataElement(5);  // 1037 Supervising Provider Middle Name
  if (de != null)
    de.get();
  de = segment.getDataElement(7);  // 1039 Supervising Provider Name Suffix
  if (de != null)
    de.get();
  de = segment.getDataElement(8);  // 66 Identification Code Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(9);  // 67 Supervising Provider Identifier
  if (de != null)
    de.get();
  }

/** extract data from segment N2 that is part of the Loop2310E
*<br>Additional Supervising Provider Name Information used 
*<br>To specify additional names or those longer than 35 characters in length
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentAdditionalSupervisingProviderNameInformation_2fromLoop2310E(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("N2");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 93 Supervising Provider Name Additional Text
  if (de != null)
    de.get();
  }

/** extract data from segment REF that is part of the Loop2310E
*<br>Supervising Provider Secondary Identification used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentSupervisingProviderSecondaryIdentification_2fromLoop2310E(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("REF");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("REF", i);
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 128 Reference Identification Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 127 Supervising Provider Secondary Identifier
       if (de != null)
         de.get();
    }
  }

/** extract data from loop 2320 that is part of Loop2300
*<br>Other Subscriber Information used 
* @param inLoop loop containing this loop
*@throws OBOEException - most likely loop not found
*/
public void extractLoop2320_2fromLoop2300(Loop inLoop)  throws OBOEException
{
  Loop loop;
  int numberInVector = inLoop.getCount("2320");
  for (int i = 0; i <  numberInVector; i++)
   {
   loop = inLoop.getLoop("2320", i);
   if (loop == null) return;
      extractSegmentOtherSubscriberInformation_2fromLoop2320(loop);
      extractSegmentClaimLevelAdjustments_2fromLoop2320(loop);
      extractSegmentCoordinationofBenefitsCOBPayerPaidAmount_2fromLoop2320(loop);
      extractSegmentCoordinationofBenefitsCOBApprovedAmount_2fromLoop2320(loop);
      extractSegmentCoordinationofBenefitsCOBAllowedAmount_2fromLoop2320(loop);
      extractSegmentCoordinationofBenefitsCOBPatientResponsibilityAmount_2fromLoop2320(loop);
      extractSegmentCoordinationofBenefitsCOBCoveredAmount_2fromLoop2320(loop);
      extractSegmentCoordinationofBenefitsCOBDiscountAmount_2fromLoop2320(loop);
      extractSegmentCoordinationofBenefitsCOBPerDayLimitAmount_2fromLoop2320(loop);
      extractSegmentCoordinationofBenefitsCOBPatientPaidAmount_2fromLoop2320(loop);
      extractSegmentCoordinationofBenefitsCOBTaxAmount_2fromLoop2320(loop);
      extractSegmentCoordinationofBenefitsCOBTotalClaimBeforeTaxesAmount_2fromLoop2320(loop);
      extractSegmentSubscriberDemographicInformation_2fromLoop2320(loop);
      extractSegmentOtherInsuranceCoverageInformation_2fromLoop2320(loop);
      extractSegmentMedicareOutpatientAdjudicationInformation_2fromLoop2320(loop);
      extractLoop2330A_2fromLoop2320(loop);
      extractLoop2330B_2fromLoop2320(loop);
      extractLoop2330C_2fromLoop2320(loop);
      extractLoop2330D_2fromLoop2320(loop);
      extractLoop2330E_2fromLoop2320(loop);
      extractLoop2330F_2fromLoop2320(loop);
      extractLoop2330G_2fromLoop2320(loop);
      extractLoop2330H_2fromLoop2320(loop);
    }
  }

/** extract data from segment SBR that is part of the Loop2320
*<br>Other Subscriber Information used 
*<br>To record information specific to the primary insured and the insurance carrier for that insured
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentOtherSubscriberInformation_2fromLoop2320(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("SBR");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 1138 Payer Responsibility Sequence Number Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1069 Individual Relationship Code
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 127 Insured Group or Policy Number
  if (de != null)
    de.get();
  de = segment.getDataElement(4);  // 93 Other Insured Group Name
  if (de != null)
    de.get();
  de = segment.getDataElement(5);  // 1336 Insurance Type Code
  if (de != null)
    de.get();
  de = segment.getDataElement(9);  // 1032 Claim Filing Indicator Code
  if (de != null)
    de.get();
  }

/** extract data from segment CAS that is part of the Loop2320
*<br>Claim Level Adjustments used 
*<br>To supply adjustment reason codes and amounts as needed for an entire claim or for a particular service within the claim being paid
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentClaimLevelAdjustments_2fromLoop2320(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("CAS");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("CAS", i);
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 1033 Claim Adjustment Group Code
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 1034 Adjustment Reason Code
       if (de != null)
         de.get();
       de = segment.getDataElement(3);       // 782 Adjustment Amount
       if (de != null)
         de.get();
       de = segment.getDataElement(4);       // 380 Adjustment Quantity
       if (de != null)
         de.get();
       de = segment.getDataElement(5);       // 1034 Adjustment Reason Code
       if (de != null)
         de.get();
       de = segment.getDataElement(6);       // 782 Adjustment Amount
       if (de != null)
         de.get();
       de = segment.getDataElement(7);       // 380 Adjustment Quantity
       if (de != null)
         de.get();
       de = segment.getDataElement(8);       // 1034 Adjustment Reason Code
       if (de != null)
         de.get();
       de = segment.getDataElement(9);       // 782 Adjustment Amount
       if (de != null)
         de.get();
       de = segment.getDataElement(10);       // 380 Adjustment Quantity
       if (de != null)
         de.get();
       de = segment.getDataElement(11);       // 1034 Adjustment Reason Code
       if (de != null)
         de.get();
       de = segment.getDataElement(12);       // 782 Adjustment Amount
       if (de != null)
         de.get();
       de = segment.getDataElement(13);       // 380 Adjustment Quantity
       if (de != null)
         de.get();
       de = segment.getDataElement(14);       // 1034 Adjustment Reason Code
       if (de != null)
         de.get();
       de = segment.getDataElement(15);       // 782 Adjustment Amount
       if (de != null)
         de.get();
       de = segment.getDataElement(16);       // 380 Adjustment Quantity
       if (de != null)
         de.get();
       de = segment.getDataElement(17);       // 1034 Adjustment Reason Code
       if (de != null)
         de.get();
       de = segment.getDataElement(18);       // 782 Adjustment Amount
       if (de != null)
         de.get();
       de = segment.getDataElement(19);       // 380 Adjustment Quantity
       if (de != null)
         de.get();
    }
  }

/** extract data from segment AMT that is part of the Loop2320
*<br>Coordination of Benefits (COB) Payer Paid Amount used 
*<br>To indicate the total monetary amount
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentCoordinationofBenefitsCOBPayerPaidAmount_2fromLoop2320(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("AMT", "D");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 522 Amount Qualifier Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 782 Payer Paid Amount
  if (de != null)
    de.get();
  }

/** extract data from segment AMT that is part of the Loop2320
*<br>Coordination of Benefits (COB) Approved Amount used 
*<br>To indicate the total monetary amount
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentCoordinationofBenefitsCOBApprovedAmount_2fromLoop2320(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("AMT", "AAE");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 522 Amount Qualifier Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 782 Approved Amount
  if (de != null)
    de.get();
  }

/** extract data from segment AMT that is part of the Loop2320
*<br>Coordination of Benefits (COB) Allowed Amount used 
*<br>To indicate the total monetary amount
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentCoordinationofBenefitsCOBAllowedAmount_2fromLoop2320(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("AMT", "B6");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 522 Amount Qualifier Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 782 Allowed Amount
  if (de != null)
    de.get();
  }

/** extract data from segment AMT that is part of the Loop2320
*<br>Coordination of Benefits (COB) Patient Responsibility Amount used 
*<br>To indicate the total monetary amount
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentCoordinationofBenefitsCOBPatientResponsibilityAmount_2fromLoop2320(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("AMT", "F2");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 522 Amount Qualifier Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 782 Other Payer Patient Responsibility Amount
  if (de != null)
    de.get();
  }

/** extract data from segment AMT that is part of the Loop2320
*<br>Coordination of Benefits (COB) Covered Amount used 
*<br>To indicate the total monetary amount
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentCoordinationofBenefitsCOBCoveredAmount_2fromLoop2320(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("AMT", "AU");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 522 Amount Qualifier Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 782 Other Payer Covered Amount
  if (de != null)
    de.get();
  }

/** extract data from segment AMT that is part of the Loop2320
*<br>Coordination of Benefits (COB) Discount Amount used 
*<br>To indicate the total monetary amount
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentCoordinationofBenefitsCOBDiscountAmount_2fromLoop2320(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("AMT", "D8");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 522 Amount Qualifier Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 782 Other Payer Discount Amount
  if (de != null)
    de.get();
  }

/** extract data from segment AMT that is part of the Loop2320
*<br>Coordination of Benefits (COB) Per Day Limit Amount used 
*<br>To indicate the total monetary amount
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentCoordinationofBenefitsCOBPerDayLimitAmount_2fromLoop2320(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("AMT", "DY");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 522 Amount Qualifier Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 782 Other Payer Per Day Limit Amount
  if (de != null)
    de.get();
  }

/** extract data from segment AMT that is part of the Loop2320
*<br>Coordination of Benefits (COB) Patient Paid Amount used 
*<br>To indicate the total monetary amount
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentCoordinationofBenefitsCOBPatientPaidAmount_2fromLoop2320(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("AMT", "F5");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 522 Amount Qualifier Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 782 Other Payer Patient Paid Amount
  if (de != null)
    de.get();
  }

/** extract data from segment AMT that is part of the Loop2320
*<br>Coordination of Benefits (COB) Tax Amount used 
*<br>To indicate the total monetary amount
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentCoordinationofBenefitsCOBTaxAmount_2fromLoop2320(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("AMT", "T");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 522 Amount Qualifier Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 782 Other Payer Tax Amount
  if (de != null)
    de.get();
  }

/** extract data from segment AMT that is part of the Loop2320
*<br>Coordination of Benefits (COB) Total Claim Before Taxes Amount used 
*<br>To indicate the total monetary amount
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentCoordinationofBenefitsCOBTotalClaimBeforeTaxesAmount_2fromLoop2320(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("AMT", "T2");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 522 Amount Qualifier Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 782 Other Payer Pre-Tax Claim Total Amount
  if (de != null)
    de.get();
  }

/** extract data from segment DMG that is part of the Loop2320
*<br>Subscriber Demographic Information used 
*<br>To supply demographic information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentSubscriberDemographicInformation_2fromLoop2320(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("DMG");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 1250 Date Time Period Format Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1251 Other Insured Birth Date
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1068 Other Insured Gender Code
  if (de != null)
    de.get();
  }

/** extract data from segment OI that is part of the Loop2320
*<br>Other Insurance Coverage Information used 
*<br>To specify information associated with other health insurance coverage
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentOtherInsuranceCoverageInformation_2fromLoop2320(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("OI");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(3);  // 1073 Benefits Assignment Certification Indicator
  if (de != null)
    de.get();
  de = segment.getDataElement(4);  // 1351 Patient Signature Source Code
  if (de != null)
    de.get();
  de = segment.getDataElement(6);  // 1363 Release of Information Code
  if (de != null)
    de.get();
  }

/** extract data from segment MOA that is part of the Loop2320
*<br>Medicare Outpatient Adjudication Information used 
*<br>To convey claim-level data related to the adjudication of Medicare claims not related to an inpatient setting
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentMedicareOutpatientAdjudicationInformation_2fromLoop2320(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("MOA");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 954 Reimbursement Rate
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 782 HCPCS Payable Amount
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 127 Remark Code
  if (de != null)
    de.get();
  de = segment.getDataElement(4);  // 127 Remark Code
  if (de != null)
    de.get();
  de = segment.getDataElement(5);  // 127 Remark Code
  if (de != null)
    de.get();
  de = segment.getDataElement(6);  // 127 Remark Code
  if (de != null)
    de.get();
  de = segment.getDataElement(7);  // 127 Remark Code
  if (de != null)
    de.get();
  de = segment.getDataElement(8);  // 782 End Stage Renal Disease Payment Amount
  if (de != null)
    de.get();
  de = segment.getDataElement(9);  // 782 Non-Payable Professional Component Billed Amount
  if (de != null)
    de.get();
  }

/** extract data from loop 2330A that is part of Loop2320
*<br>Other Subscriber Name used 
* @param inLoop loop containing this loop
*@throws OBOEException - most likely loop not found
*/
public void extractLoop2330A_2fromLoop2320(Loop inLoop)  throws OBOEException
{
  Loop loop = inLoop.getLoop("2330A");
  if (loop == null) return;
  extractSegmentOtherSubscriberName_2fromLoop2330A(loop);
  extractSegmentAdditionalOtherSubscriberNameInformation_2fromLoop2330A(loop);
  extractSegmentOtherSubscriberAddress_2fromLoop2330A(loop);
  extractSegmentOtherSubscriberCityStateZIPCode_2fromLoop2330A(loop);
  extractSegmentOtherSubscriberSecondaryIdentification_2fromLoop2330A(loop);
  }

/** extract data from segment NM1 that is part of the Loop2330A
*<br>Other Subscriber Name used 
*<br>To supply the full name of an individual or organizational entity
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentOtherSubscriberName_2fromLoop2330A(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("NM1");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 98 Entity Identifier Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1065 Entity Type Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1035 Other Insured Last Name
  if (de != null)
    de.get();
  de = segment.getDataElement(4);  // 1036 Other Insured First Name
  if (de != null)
    de.get();
  de = segment.getDataElement(5);  // 1037 Other Insured Middle Name
  if (de != null)
    de.get();
  de = segment.getDataElement(7);  // 1039 Other Insured Name Suffix
  if (de != null)
    de.get();
  de = segment.getDataElement(8);  // 66 Identification Code Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(9);  // 67 Other Insured Identifier
  if (de != null)
    de.get();
  }

/** extract data from segment N2 that is part of the Loop2330A
*<br>Additional Other Subscriber Name Information used 
*<br>To specify additional names or those longer than 35 characters in length
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentAdditionalOtherSubscriberNameInformation_2fromLoop2330A(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("N2");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 93 Other Insured Additional Name
  if (de != null)
    de.get();
  }

/** extract data from segment N3 that is part of the Loop2330A
*<br>Other Subscriber Address used 
*<br>To specify the location of the named party
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentOtherSubscriberAddress_2fromLoop2330A(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("N3");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 166 Other Insured Address Line
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 166 Other Insured Address Line
  if (de != null)
    de.get();
  }

/** extract data from segment N4 that is part of the Loop2330A
*<br>Other Subscriber City/State/ZIP Code used 
*<br>To specify the geographic place of the named party
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentOtherSubscriberCityStateZIPCode_2fromLoop2330A(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("N4");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 19 Other Insured City Name
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 156 Other Insured State Code
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 116 Other Insured Postal Zone or ZIP Code
  if (de != null)
    de.get();
  de = segment.getDataElement(4);  // 26 Country Code
  if (de != null)
    de.get();
  }

/** extract data from segment REF that is part of the Loop2330A
*<br>Other Subscriber Secondary Identification used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentOtherSubscriberSecondaryIdentification_2fromLoop2330A(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("REF");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("REF", i);
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 128 Reference Identification Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 127 Other Insured Additional Identifier
       if (de != null)
         de.get();
    }
  }

/** extract data from loop 2330B that is part of Loop2320
*<br>Other Payer Name used 
* @param inLoop loop containing this loop
*@throws OBOEException - most likely loop not found
*/
public void extractLoop2330B_2fromLoop2320(Loop inLoop)  throws OBOEException
{
  Loop loop = inLoop.getLoop("2330B");
  if (loop == null) return;
  extractSegmentOtherPayerName_2fromLoop2330B(loop);
  extractSegmentAdditionalOtherPayerNameInformation_2fromLoop2330B(loop);
  extractSegmentOtherPayerContactInformation_2fromLoop2330B(loop);
  extractSegmentClaimAdjudicationDate_2fromLoop2330B(loop);
  extractSegmentOtherPayerSecondaryIdentifier_2fromLoop2330B(loop);
  extractSegmentOtherPayerPriorAuthorizationorReferralNumber_2fromLoop2330B(loop);
  extractSegmentOtherPayerClaimAdjustmentIndicator_2fromLoop2330B(loop);
  }

/** extract data from segment NM1 that is part of the Loop2330B
*<br>Other Payer Name used 
*<br>To supply the full name of an individual or organizational entity
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentOtherPayerName_2fromLoop2330B(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("NM1");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 98 Entity Identifier Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1065 Entity Type Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1035 Other Payer Last or Organization Name
  if (de != null)
    de.get();
  de = segment.getDataElement(8);  // 66 Identification Code Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(9);  // 67 Other Payer Primary Identifier
  if (de != null)
    de.get();
  }

/** extract data from segment N2 that is part of the Loop2330B
*<br>Additional Other Payer Name Information used 
*<br>To specify additional names or those longer than 35 characters in length
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentAdditionalOtherPayerNameInformation_2fromLoop2330B(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("N2");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 93 Other Payer Additional Name Text
  if (de != null)
    de.get();
  }

/** extract data from segment PER that is part of the Loop2330B
*<br>Other Payer Contact Information used 
*<br>To identify a person or office to whom administrative communications should be directed
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentOtherPayerContactInformation_2fromLoop2330B(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("PER");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("PER", i);
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 366 Contact Function Code
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 93 Other Payer Contact Name
       if (de != null)
         de.get();
       de = segment.getDataElement(3);       // 365 Communication Number Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(4);       // 364 Communication Number
       if (de != null)
         de.get();
       de = segment.getDataElement(5);       // 365 Communication Number Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(6);       // 364 Communication Number
       if (de != null)
         de.get();
       de = segment.getDataElement(7);       // 365 Communication Number Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(8);       // 364 Communication Number
       if (de != null)
         de.get();
    }
  }

/** extract data from segment DTP that is part of the Loop2330B
*<br>Claim Adjudication Date used 
*<br>To specify any or all of a date, a time, or a time period
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentClaimAdjudicationDate_2fromLoop2330B(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("DTP");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 374 Date Time Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1250 Date Time Period Format Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1251 Adjudication or Payment Date
  if (de != null)
    de.get();
  }

/** extract data from segment REF that is part of the Loop2330B
*<br>Other Payer Secondary Identifier used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentOtherPayerSecondaryIdentifier_2fromLoop2330B(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("REF");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("REF", "2U", i);
 // other key values: "F8" "FY" "NF" "TJ" 
   // there can be 2 of these segments.
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 128 Reference Identification Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 127 Other Payer Secondary Identifier
       if (de != null)
         de.get();
    }
  }

/** extract data from segment REF that is part of the Loop2330B
*<br>Other Payer Prior Authorization or Referral Number used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentOtherPayerPriorAuthorizationorReferralNumber_2fromLoop2330B(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("REF");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("REF", "9F", i);
 // other key values: "G1" 
   // there can be 2 of these segments.
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 128 Reference Identification Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 127 Other Payer Prior Authorization or Referral Number
       if (de != null)
         de.get();
    }
  }

/** extract data from segment REF that is part of the Loop2330B
*<br>Other Payer Claim Adjustment Indicator used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentOtherPayerClaimAdjustmentIndicator_2fromLoop2330B(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("REF");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("REF", "T4", i);
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 128 Reference Identification Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 127 Other Payer Claim Adjustment Indicator
       if (de != null)
         de.get();
    }
  }

/** extract data from loop 2330C that is part of Loop2320
*<br>Other Payer Patient Information used 
* @param inLoop loop containing this loop
*@throws OBOEException - most likely loop not found
*/
public void extractLoop2330C_2fromLoop2320(Loop inLoop)  throws OBOEException
{
  Loop loop = inLoop.getLoop("2330C");
  if (loop == null) return;
  extractSegmentOtherPayerPatientInformation_2fromLoop2330C(loop);
  extractSegmentOtherPayerPatientIdentification_2fromLoop2330C(loop);
  }

/** extract data from segment NM1 that is part of the Loop2330C
*<br>Other Payer Patient Information used 
*<br>To supply the full name of an individual or organizational entity
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentOtherPayerPatientInformation_2fromLoop2330C(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("NM1");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 98 Entity Identifier Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1065 Entity Type Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1035 Patient Last Name
  if (de != null)
    de.get();
  de = segment.getDataElement(8);  // 66 Identification Code Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(9);  // 67 Other Payer Patient Primary Identifier
  if (de != null)
    de.get();
  }

/** extract data from segment REF that is part of the Loop2330C
*<br>Other Payer Patient Identification used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentOtherPayerPatientIdentification_2fromLoop2330C(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("REF");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("REF", i);
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 128 Reference Identification Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 127 Other Payer Patient Secondary Identifier
       if (de != null)
         de.get();
    }
  }

/** extract data from loop 2330D that is part of Loop2320
*<br>Other Payer Referring Provider used 
* @param inLoop loop containing this loop
*@throws OBOEException - most likely loop not found
*/
public void extractLoop2330D_2fromLoop2320(Loop inLoop)  throws OBOEException
{
  Loop loop;
  int numberInVector = inLoop.getCount("2330D");
  for (int i = 0; i <  numberInVector; i++)
   {
   loop = inLoop.getLoop("2330D", i);
   if (loop == null) return;
      extractSegmentOtherPayerReferringProvider_2fromLoop2330D(loop);
      extractSegmentOtherPayerReferringProviderIdentification_2fromLoop2330D(loop);
    }
  }

/** extract data from segment NM1 that is part of the Loop2330D
*<br>Other Payer Referring Provider used 
*<br>To supply the full name of an individual or organizational entity
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentOtherPayerReferringProvider_2fromLoop2330D(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("NM1");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 98 Entity Identifier Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1065 Entity Type Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1035 Referring Provider Last Name
  if (de != null)
    de.get();
  }

/** extract data from segment REF that is part of the Loop2330D
*<br>Other Payer Referring Provider Identification used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentOtherPayerReferringProviderIdentification_2fromLoop2330D(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("REF");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("REF", i);
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 128 Reference Identification Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 127 Other Payer Referring Provider Identifier
       if (de != null)
         de.get();
    }
  }

/** extract data from loop 2330E that is part of Loop2320
*<br>Other Payer Rendering Provider used 
* @param inLoop loop containing this loop
*@throws OBOEException - most likely loop not found
*/
public void extractLoop2330E_2fromLoop2320(Loop inLoop)  throws OBOEException
{
  Loop loop = inLoop.getLoop("2330E");
  if (loop == null) return;
  extractSegmentOtherPayerRenderingProvider_2fromLoop2330E(loop);
  extractSegmentOtherPayerRenderingProviderSecondaryIdentification_2fromLoop2330E(loop);
  }

/** extract data from segment NM1 that is part of the Loop2330E
*<br>Other Payer Rendering Provider used 
*<br>To supply the full name of an individual or organizational entity
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentOtherPayerRenderingProvider_2fromLoop2330E(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("NM1");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 98 Entity Identifier Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1065 Entity Type Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1035 Rendering Provider Last or Organization Name
  if (de != null)
    de.get();
  }

/** extract data from segment REF that is part of the Loop2330E
*<br>Other Payer Rendering Provider Secondary Identification used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentOtherPayerRenderingProviderSecondaryIdentification_2fromLoop2330E(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("REF");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("REF", i);
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 128 Reference Identification Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 127 Other Payer Rendering Provider Secondary Identifier
       if (de != null)
         de.get();
    }
  }

/** extract data from loop 2330F that is part of Loop2320
*<br>Other Payer Purchased Service Provider used 
* @param inLoop loop containing this loop
*@throws OBOEException - most likely loop not found
*/
public void extractLoop2330F_2fromLoop2320(Loop inLoop)  throws OBOEException
{
  Loop loop = inLoop.getLoop("2330F");
  if (loop == null) return;
  extractSegmentOtherPayerPurchasedServiceProvider_2fromLoop2330F(loop);
  extractSegmentOtherPayerPurchasedServiceProviderIdentification_2fromLoop2330F(loop);
  }

/** extract data from segment NM1 that is part of the Loop2330F
*<br>Other Payer Purchased Service Provider used 
*<br>To supply the full name of an individual or organizational entity
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentOtherPayerPurchasedServiceProvider_2fromLoop2330F(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("NM1");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 98 Entity Identifier Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1065 Entity Type Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1035 Purchased Service Provider Name
  if (de != null)
    de.get();
  }

/** extract data from segment REF that is part of the Loop2330F
*<br>Other Payer Purchased Service Provider Identification used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentOtherPayerPurchasedServiceProviderIdentification_2fromLoop2330F(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("REF");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("REF", i);
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 128 Reference Identification Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 127 Other Payer Purchased Service Provider Identifier
       if (de != null)
         de.get();
    }
  }

/** extract data from loop 2330G that is part of Loop2320
*<br>Other Payer Service Facility Location used 
* @param inLoop loop containing this loop
*@throws OBOEException - most likely loop not found
*/
public void extractLoop2330G_2fromLoop2320(Loop inLoop)  throws OBOEException
{
  Loop loop = inLoop.getLoop("2330G");
  if (loop == null) return;
  extractSegmentOtherPayerServiceFacilityLocation_2fromLoop2330G(loop);
  extractSegmentOtherPayerServiceFacilityLocationIdentification_2fromLoop2330G(loop);
  }

/** extract data from segment NM1 that is part of the Loop2330G
*<br>Other Payer Service Facility Location used 
*<br>To supply the full name of an individual or organizational entity
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentOtherPayerServiceFacilityLocation_2fromLoop2330G(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("NM1");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 98 Entity Identifier Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1065 Entity Type Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1035 Service Facility Name
  if (de != null)
    de.get();
  }

/** extract data from segment REF that is part of the Loop2330G
*<br>Other Payer Service Facility Location Identification used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentOtherPayerServiceFacilityLocationIdentification_2fromLoop2330G(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("REF");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("REF", i);
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 128 Reference Identification Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 127 Other Payer Service Facility Location Identifier
       if (de != null)
         de.get();
    }
  }

/** extract data from loop 2330H that is part of Loop2320
*<br>Other Payer Supervising Provider used 
* @param inLoop loop containing this loop
*@throws OBOEException - most likely loop not found
*/
public void extractLoop2330H_2fromLoop2320(Loop inLoop)  throws OBOEException
{
  Loop loop = inLoop.getLoop("2330H");
  if (loop == null) return;
  extractSegmentOtherPayerSupervisingProvider_2fromLoop2330H(loop);
  extractSegmentOtherPayerSupervisingProviderIdentification_2fromLoop2330H(loop);
  }

/** extract data from segment NM1 that is part of the Loop2330H
*<br>Other Payer Supervising Provider used 
*<br>To supply the full name of an individual or organizational entity
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentOtherPayerSupervisingProvider_2fromLoop2330H(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("NM1");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 98 Entity Identifier Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1065 Entity Type Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1035 Supervising Provider Last Name
  if (de != null)
    de.get();
  }

/** extract data from segment REF that is part of the Loop2330H
*<br>Other Payer Supervising Provider Identification used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentOtherPayerSupervisingProviderIdentification_2fromLoop2330H(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("REF");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("REF", i);
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 128 Reference Identification Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 127 Other Payer Supervising Provider Identifier
       if (de != null)
         de.get();
    }
  }

/** extract data from loop 2400 that is part of Loop2300
*<br>Service Line used 
* @param inLoop loop containing this loop
*@throws OBOEException - most likely loop not found
*/
public void extractLoop2400_2fromLoop2300(Loop inLoop)  throws OBOEException
{
  Loop loop;
  int numberInVector = inLoop.getCount("2400");
  for (int i = 0; i <  numberInVector; i++)
   {
   loop = inLoop.getLoop("2400", i);
   if (loop == null) return;
      extractSegmentServiceLine_2fromLoop2400(loop);
      extractSegmentProfessionalService_2fromLoop2400(loop);
      extractSegmentPrescriptionNumber_2fromLoop2400(loop);
      extractSegmentDMERCCMNIndicator_2fromLoop2400(loop);
      extractSegmentAmbulanceTransportInformation_2fromLoop2400(loop);
      extractSegmentSpinalManipulationServiceInformation_2fromLoop2400(loop);
      extractSegmentDurableMedicalEquipmentCertification_2fromLoop2400(loop);
      extractSegmentHomeOxygenTherapyInformation_2fromLoop2400(loop);
      extractSegmentAmbulanceCertification_2fromLoop2400(loop);
      extractSegmentHospiceEmployeeIndicator_2fromLoop2400(loop);
      extractSegmentDMERCConditionIndicator_2fromLoop2400(loop);
      extractSegmentDateServiceDate_2fromLoop2400(loop);
      extractSegmentDateCertificationRevisionDate_2fromLoop2400(loop);
      extractSegmentDateReferralDate_2fromLoop2400(loop);
      extractSegmentDateBeginTherapyDate_2fromLoop2400(loop);
      extractSegmentDateLastCertificationDate_2fromLoop2400(loop);
      extractSegmentDateOrderDate_2fromLoop2400(loop);
      extractSegmentDateDateLastSeen_2fromLoop2400(loop);
      extractSegmentDateTest_2fromLoop2400(loop);
      extractSegmentDateOxygenSaturationArterialBloodGasTest_2fromLoop2400(loop);
      extractSegmentDateShipped_2fromLoop2400(loop);
      extractSegmentDateOnsetofCurrentSymptomIllness_2fromLoop2400(loop);
      extractSegmentDateLastXray_2fromLoop2400(loop);
      extractSegmentDateAcuteManifestation_2fromLoop2400(loop);
      extractSegmentDateInitialTreatment_2fromLoop2400(loop);
      extractSegmentDateSimilarIllnessSymptomOnset_2fromLoop2400(loop);
      extractSegmentAnesthesiaModifyingUnits_2fromLoop2400(loop);
      extractSegmentTestResult_2fromLoop2400(loop);
      extractSegmentContractInformation_2fromLoop2400(loop);
      extractSegmentRepricedLineItemReferenceNumber_2fromLoop2400(loop);
      extractSegmentAdjustedRepricedLineItemReferenceNumber_2fromLoop2400(loop);
      extractSegmentPriorAuthorizationorReferralNumber_2fromLoop2400(loop);
      extractSegmentLineItemControlNumber_2fromLoop2400(loop);
      extractSegmentMammographyCertificationNumber_2fromLoop2400(loop);
      extractSegmentClinicalLaboratoryImprovementAmendmentCLIAIdentification_2fromLoop2400(loop);
      extractSegmentReferringClinicalLaboratoryImprovementAmendmentCLIAFacilityIdentification_2fromLoop2400(loop);
      extractSegmentImmunizationBatchNumber_2fromLoop2400(loop);
      extractSegmentAmbulatoryPatientGroupAPG_2fromLoop2400(loop);
      extractSegmentOxygenFlowRate_2fromLoop2400(loop);
      extractSegmentUniversalProductNumberUPN_2fromLoop2400(loop);
      extractSegmentSalesTaxAmount_2fromLoop2400(loop);
      extractSegmentApprovedAmount_2fromLoop2400(loop);
      extractSegmentPostageClaimedAmount_2fromLoop2400(loop);
      extractSegmentFileInformation_2fromLoop2400(loop);
      extractSegmentLineNote_2fromLoop2400(loop);
      extractSegmentPurchasedServiceInformation_2fromLoop2400(loop);
      extractSegmentHealthCareServicesDelivery_2fromLoop2400(loop);
      extractSegmentLinePricingRepricingInformation_2fromLoop2400(loop);
      extractLoop2420A_2fromLoop2400(loop);
      extractLoop2420B_2fromLoop2400(loop);
      extractLoop2420C_2fromLoop2400(loop);
      extractLoop2420D_2fromLoop2400(loop);
      extractLoop2420E_2fromLoop2400(loop);
      extractLoop2420F_2fromLoop2400(loop);
      extractLoop2420G_2fromLoop2400(loop);
      extractLoop2430_2fromLoop2400(loop);
      extractLoop2440_2fromLoop2400(loop);
    }
  }

/** extract data from segment LX that is part of the Loop2400
*<br>Service Line used 
*<br>To reference a line number in a transaction set
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentServiceLine_2fromLoop2400(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("LX");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 554 Assigned Number
  if (de != null)
    de.get();
  }

/** extract data from segment SV1 that is part of the Loop2400
*<br>Professional Service used 
*<br>To specify the claim service detail for a Health Care professional
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentProfessionalService_2fromLoop2400(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("SV1");
  if (segment == null)
    return;
  DataElement de;
    CompositeDE  composite = (CompositeDE) segment.getCompositeDE(1);  // C003 Composite Medical
  if (composite == null)
    return;
  de = composite.getDataElement(1);  // composite element 235 Product or Service ID Qualifier
  if (de != null)
    de.get();
  de = composite.getDataElement(2);  // composite element 234 Procedure Code
  if (de != null)
    de.get();
  de = composite.getDataElement(3);  // composite element 1339 Procedure Modifier
  if (de != null)
    de.get();
  de = composite.getDataElement(4);  // composite element 1339 Procedure Modifier
  if (de != null)
    de.get();
  de = composite.getDataElement(5);  // composite element 1339 Procedure Modifier
  if (de != null)
    de.get();
  de = composite.getDataElement(6);  // composite element 1339 Procedure Modifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 782 Line Item Charge Amount
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 355 Unit or Basis for Measurement Code
  if (de != null)
    de.get();
  de = segment.getDataElement(4);  // 380 Service Unit Count
  if (de != null)
    de.get();
  de = segment.getDataElement(5);  // 1331 Place of Service Code
  if (de != null)
    de.get();
  composite = (CompositeDE) segment.getCompositeDE(7);  // C004 Composite Diagnosis
  if (composite == null)
    return;
  de = composite.getDataElement(1);  // composite element 1328 Diagnosis Code Pointer
  if (de != null)
    de.get();
  de = composite.getDataElement(2);  // composite element 1328 Diagnosis Code Pointer
  if (de != null)
    de.get();
  de = composite.getDataElement(3);  // composite element 1328 Diagnosis Code Pointer
  if (de != null)
    de.get();
  de = composite.getDataElement(4);  // composite element 1328 Diagnosis Code Pointer
  if (de != null)
    de.get();
  de = segment.getDataElement(9);  // 1073 Emergency Indicator
  if (de != null)
    de.get();
  de = segment.getDataElement(11);  // 1073 EPSDT Indicator
  if (de != null)
    de.get();
  de = segment.getDataElement(12);  // 1073 Family Planning Indicator
  if (de != null)
    de.get();
  de = segment.getDataElement(15);  // 1327 Co-Pay Status Code
  if (de != null)
    de.get();
  }

/** extract data from segment SV4 that is part of the Loop2400
*<br>Prescription Number used 
*<br>To specify the claim service detail for prescription drugs
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentPrescriptionNumber_2fromLoop2400(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("SV4");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 127 Prescription Number
  if (de != null)
    de.get();
  }

/** extract data from segment PWK that is part of the Loop2400
*<br>DMERC CMN Indicator used 
*<br>To identify the type or transmission or both of paperwork or supporting information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentDMERCCMNIndicator_2fromLoop2400(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("PWK");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 755 Attachment Report Type Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 756 Attachment Transmission Code
  if (de != null)
    de.get();
  }

/** extract data from segment CR1 that is part of the Loop2400
*<br>Ambulance Transport Information used 
*<br>To supply information related to the ambulance service rendered to a patient
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentAmbulanceTransportInformation_2fromLoop2400(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("CR1");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 355 Unit or Basis for Measurement Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 81 Patient Weight
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1316 Ambulance Transport Code
  if (de != null)
    de.get();
  de = segment.getDataElement(4);  // 1317 Ambulance Transport Reason Code
  if (de != null)
    de.get();
  de = segment.getDataElement(5);  // 355 Unit or Basis for Measurement Code
  if (de != null)
    de.get();
  de = segment.getDataElement(6);  // 380 Transport Distance
  if (de != null)
    de.get();
  de = segment.getDataElement(9);  // 352 Round Trip Purpose Description
  if (de != null)
    de.get();
  de = segment.getDataElement(10);  // 352 Stretcher Purpose Description
  if (de != null)
    de.get();
  }

/** extract data from segment CR2 that is part of the Loop2400
*<br>Spinal Manipulation Service Information used 
*<br>To supply information related to the chiropractic service rendered to a patient
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentSpinalManipulationServiceInformation_2fromLoop2400(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("CR2");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("CR2", i);
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 609 Treatment Series Number
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 380 Treatment Count
       if (de != null)
         de.get();
       de = segment.getDataElement(3);       // 1367 Subluxation Level Code
       if (de != null)
         de.get();
       de = segment.getDataElement(4);       // 1367 Subluxation Level Code
       if (de != null)
         de.get();
       de = segment.getDataElement(5);       // 355 Unit or Basis for Measurement Code
       if (de != null)
         de.get();
       de = segment.getDataElement(6);       // 380 Treatment Period Count
       if (de != null)
         de.get();
       de = segment.getDataElement(7);       // 380 Monthly Treatment Count
       if (de != null)
         de.get();
       de = segment.getDataElement(8);       // 1342 Patient Condition Code
       if (de != null)
         de.get();
       de = segment.getDataElement(9);       // 1073 Complication Indicator
       if (de != null)
         de.get();
       de = segment.getDataElement(10);       // 352 Patient Condition Description
       if (de != null)
         de.get();
       de = segment.getDataElement(11);       // 352 Patient Condition Description
       if (de != null)
         de.get();
       de = segment.getDataElement(12);       // 1073 X-ray Availability Indicator
       if (de != null)
         de.get();
    }
  }

/** extract data from segment CR3 that is part of the Loop2400
*<br>Durable Medical Equipment Certification used 
*<br>To supply information regarding a physician's certification for durable medical equipment
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentDurableMedicalEquipmentCertification_2fromLoop2400(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("CR3");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 1322 Certification Type Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 355 Unit or Basis for Measurement Code
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 380 Durable Medical Equipment Duration
  if (de != null)
    de.get();
  }

/** extract data from segment CR5 that is part of the Loop2400
*<br>Home Oxygen Therapy Information used 
*<br>To supply information regarding certification of medical necessity for home oxygen therapy
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentHomeOxygenTherapyInformation_2fromLoop2400(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("CR5");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 1322 Certification Type Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 380 Treatment Period Count
  if (de != null)
    de.get();
  de = segment.getDataElement(10);  // 380 Arterial Blood Gas Quantity
  if (de != null)
    de.get();
  de = segment.getDataElement(11);  // 380 Oxygen Saturation Quantity
  if (de != null)
    de.get();
  de = segment.getDataElement(12);  // 1349 Oxygen Test Condition Code
  if (de != null)
    de.get();
  de = segment.getDataElement(13);  // 1350 Oxygen Test Findings Code
  if (de != null)
    de.get();
  de = segment.getDataElement(14);  // 1350 Oxygen Test Findings Code
  if (de != null)
    de.get();
  de = segment.getDataElement(15);  // 1350 Oxygen Test Findings Code
  if (de != null)
    de.get();
  }

/** extract data from segment CRC that is part of the Loop2400
*<br>Ambulance Certification used 
*<br>To supply information on conditions
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentAmbulanceCertification_2fromLoop2400(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("CRC");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("CRC", "07", i);
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 1136 Code Category
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 1073 Certification Condition Indicator
       if (de != null)
         de.get();
       de = segment.getDataElement(3);       // 1321 Condition Code
       if (de != null)
         de.get();
       de = segment.getDataElement(4);       // 1321 Condition Code
       if (de != null)
         de.get();
       de = segment.getDataElement(5);       // 1321 Condition Code
       if (de != null)
         de.get();
       de = segment.getDataElement(6);       // 1321 Condition Code
       if (de != null)
         de.get();
       de = segment.getDataElement(7);       // 1321 Condition Code
       if (de != null)
         de.get();
    }
  }

/** extract data from segment CRC that is part of the Loop2400
*<br>Hospice Employee Indicator used 
*<br>To supply information on conditions
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentHospiceEmployeeIndicator_2fromLoop2400(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("CRC", "70");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 1136 Code Category
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1073 Hospice Employed Provider Indicator
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1321 Condition Indicator
  if (de != null)
    de.get();
  }

/** extract data from segment CRC that is part of the Loop2400
*<br>DMERC Condition Indicator used 
*<br>To supply information on conditions
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentDMERCConditionIndicator_2fromLoop2400(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("CRC");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("CRC", "09", i);
 // other key values: "11" 
   // there can be 2 of these segments.
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 1136 Code Category
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 1073 Certification Condition Indicator
       if (de != null)
         de.get();
       de = segment.getDataElement(3);       // 1321 Condition Indicator
       if (de != null)
         de.get();
       de = segment.getDataElement(4);       // 1321 Condition Indicator
       if (de != null)
         de.get();
       de = segment.getDataElement(5);       // 1321 Condition Indicator
       if (de != null)
         de.get();
       de = segment.getDataElement(6);       // 1321 Condition Indicator
       if (de != null)
         de.get();
       de = segment.getDataElement(7);       // 1321 Condition Indicator
       if (de != null)
         de.get();
    }
  }

/** extract data from segment DTP that is part of the Loop2400
*<br>Date - Service Date used 
*<br>To specify any or all of a date, a time, or a time period
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentDateServiceDate_2fromLoop2400(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("DTP", "472");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 374 Date Time Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1250 Date Time Period Format Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1251 Service Date
  if (de != null)
    de.get();
  }

/** extract data from segment DTP that is part of the Loop2400
*<br>Date - Certification Revision Date used 
*<br>To specify any or all of a date, a time, or a time period
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentDateCertificationRevisionDate_2fromLoop2400(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("DTP", "607");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 374 Date Time Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1250 Date Time Period Format Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1251 Certification Revision Date
  if (de != null)
    de.get();
  }

/** extract data from segment DTP that is part of the Loop2400
*<br>Date - Referral Date used 
*<br>To specify any or all of a date, a time, or a time period
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentDateReferralDate_2fromLoop2400(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("DTP", "330");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 374 Date Time Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1250 Date Time Period Format Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1251 Referral Date
  if (de != null)
    de.get();
  }

/** extract data from segment DTP that is part of the Loop2400
*<br>Date - Begin Therapy Date used 
*<br>To specify any or all of a date, a time, or a time period
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentDateBeginTherapyDate_2fromLoop2400(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("DTP", "463");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 374 Date Time Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1250 Date Time Period Format Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1251 Begin Therapy Date
  if (de != null)
    de.get();
  }

/** extract data from segment DTP that is part of the Loop2400
*<br>Date - Last Certification Date used 
*<br>To specify any or all of a date, a time, or a time period
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentDateLastCertificationDate_2fromLoop2400(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("DTP", "461");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 374 Date Time Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1250 Date Time Period Format Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1251 Last Certification Date
  if (de != null)
    de.get();
  }

/** extract data from segment DTP that is part of the Loop2400
*<br>Date - Order Date used 
*<br>To specify any or all of a date, a time, or a time period
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentDateOrderDate_2fromLoop2400(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("DTP", "938");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 374 Date Time Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1250 Date Time Period Format Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1251 Order Date
  if (de != null)
    de.get();
  }

/** extract data from segment DTP that is part of the Loop2400
*<br>Date - Date Last Seen used 
*<br>To specify any or all of a date, a time, or a time period
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentDateDateLastSeen_2fromLoop2400(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("DTP", "304");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 374 Date Time Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1250 Date Time Period Format Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1251 Last Seen Date
  if (de != null)
    de.get();
  }

/** extract data from segment DTP that is part of the Loop2400
*<br>Date - Test used 
*<br>To specify any or all of a date, a time, or a time period
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentDateTest_2fromLoop2400(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("DTP");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("DTP", "738", i);
 // other key values: "739" 
   // there can be 2 of these segments.
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 374 Date Time Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 1250 Date Time Period Format Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(3);       // 1251 Test Performed Date
       if (de != null)
         de.get();
    }
  }

/** extract data from segment DTP that is part of the Loop2400
*<br>Date - Oxygen Saturation/Arterial Blood Gas Test used 
*<br>To specify any or all of a date, a time, or a time period
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentDateOxygenSaturationArterialBloodGasTest_2fromLoop2400(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("DTP");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("DTP", "119", i);
 // other key values: "GRA" "480" "481" 
   // there can be 3 of these segments.
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 374 Date Time Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 1250 Date Time Period Format Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(3);       // 1251 Oxygen Saturation Test Date
       if (de != null)
         de.get();
    }
  }

/** extract data from segment DTP that is part of the Loop2400
*<br>Date - Shipped used 
*<br>To specify any or all of a date, a time, or a time period
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentDateShipped_2fromLoop2400(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("DTP", "011");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 374 Date Time Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1250 Date Time Period Format Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1251 Shipped Date
  if (de != null)
    de.get();
  }

/** extract data from segment DTP that is part of the Loop2400
*<br>Date - Onset of Current Symptom/Illness used 
*<br>To specify any or all of a date, a time, or a time period
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentDateOnsetofCurrentSymptomIllness_2fromLoop2400(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("DTP", "431");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 374 Date Time Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1250 Date Time Period Format Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1251 Onset Date
  if (de != null)
    de.get();
  }

/** extract data from segment DTP that is part of the Loop2400
*<br>Date - Last X-ray used 
*<br>To specify any or all of a date, a time, or a time period
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentDateLastXray_2fromLoop2400(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("DTP", "455");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 374 Date Time Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1250 Date Time Period Format Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1251 Last X-Ray Date
  if (de != null)
    de.get();
  }

/** extract data from segment DTP that is part of the Loop2400
*<br>Date - Acute Manifestation used 
*<br>To specify any or all of a date, a time, or a time period
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentDateAcuteManifestation_2fromLoop2400(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("DTP", "453");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 374 Date Time Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1250 Date Time Period Format Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1251 Acute Manifestation Date
  if (de != null)
    de.get();
  }

/** extract data from segment DTP that is part of the Loop2400
*<br>Date - Initial Treatment used 
*<br>To specify any or all of a date, a time, or a time period
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentDateInitialTreatment_2fromLoop2400(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("DTP", "454");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 374 Date Time Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1250 Date Time Period Format Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1251 Initial Treatment Date
  if (de != null)
    de.get();
  }

/** extract data from segment DTP that is part of the Loop2400
*<br>Date - Similar Illness/Symptom Onset used 
*<br>To specify any or all of a date, a time, or a time period
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentDateSimilarIllnessSymptomOnset_2fromLoop2400(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("DTP", "438");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 374 Date Time Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1250 Date Time Period Format Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1251 Similar Illness or Symptom Date
  if (de != null)
    de.get();
  }

/** extract data from segment QTY that is part of the Loop2400
*<br>Anesthesia Modifying Units used 
*<br>To specify quantity information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentAnesthesiaModifyingUnits_2fromLoop2400(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("QTY");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("QTY", i);
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 673 Quantity Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 380 Anesthesia Modifying Units
       if (de != null)
         de.get();
    }
  }

/** extract data from segment MEA that is part of the Loop2400
*<br>Test Result used 
*<br>To specify physical measurements or counts, including dimensions, tolerances, variances, and weights
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentTestResult_2fromLoop2400(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("MEA");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("MEA", i);
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 737 Measurement Reference Identification Code
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 738 Measurement Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(3);       // 739 Test Results
       if (de != null)
         de.get();
    }
  }

/** extract data from segment CN1 that is part of the Loop2400
*<br>Contract Information used 
*<br>To specify basic data about the contract or contract line item
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentContractInformation_2fromLoop2400(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("CN1");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 1166 Contract Type Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 782 Contract Amount
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 332 Contract Percentage
  if (de != null)
    de.get();
  de = segment.getDataElement(4);  // 127 Contract Code
  if (de != null)
    de.get();
  de = segment.getDataElement(5);  // 338 Terms Discount Percentage
  if (de != null)
    de.get();
  de = segment.getDataElement(6);  // 799 Contract Version Identifier
  if (de != null)
    de.get();
  }

/** extract data from segment REF that is part of the Loop2400
*<br>Repriced Line Item Reference Number used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentRepricedLineItemReferenceNumber_2fromLoop2400(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("REF", "9B");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 128 Reference Identification Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 127 Repriced Line Item Reference Number
  if (de != null)
    de.get();
  }

/** extract data from segment REF that is part of the Loop2400
*<br>Adjusted Repriced Line Item Reference Number used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentAdjustedRepricedLineItemReferenceNumber_2fromLoop2400(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("REF", "9D");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 128 Reference Identification Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 127 Adjusted Repriced Line Item Reference Number
  if (de != null)
    de.get();
  }

/** extract data from segment REF that is part of the Loop2400
*<br>Prior Authorization or Referral Number used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentPriorAuthorizationorReferralNumber_2fromLoop2400(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("REF");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("REF", "9F", i);
 // other key values: "G1" 
   // there can be 2 of these segments.
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 128 Reference Identification Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 127 Prior Authorization or Referral Number
       if (de != null)
         de.get();
    }
  }

/** extract data from segment REF that is part of the Loop2400
*<br>Line Item Control Number used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentLineItemControlNumber_2fromLoop2400(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("REF", "6R");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 128 Reference Identification Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 127 Line Item Control Number
  if (de != null)
    de.get();
  }

/** extract data from segment REF that is part of the Loop2400
*<br>Mammography Certification Number used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentMammographyCertificationNumber_2fromLoop2400(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("REF", "EW");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 128 Reference Identification Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 127 Mammography Certification Number
  if (de != null)
    de.get();
  }

/** extract data from segment REF that is part of the Loop2400
*<br>Clinical Laboratory Improvement Amendment (CLIA) Identification used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentClinicalLaboratoryImprovementAmendmentCLIAIdentification_2fromLoop2400(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("REF", "X4");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 128 Reference Identification Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 127 Clinical Laboratory Improvement Amendment Number
  if (de != null)
    de.get();
  }

/** extract data from segment REF that is part of the Loop2400
*<br>Referring Clinical Laboratory Improvement Amendment (CLIA) Facility Identification used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentReferringClinicalLaboratoryImprovementAmendmentCLIAFacilityIdentification_2fromLoop2400(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("REF", "F4");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 128 Reference Identification Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 127 Referring CLIA Number
  if (de != null)
    de.get();
  }

/** extract data from segment REF that is part of the Loop2400
*<br>Immunization Batch Number used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentImmunizationBatchNumber_2fromLoop2400(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("REF", "BT");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 128 Reference Identification Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 127 Immunization Batch Number
  if (de != null)
    de.get();
  }

/** extract data from segment REF that is part of the Loop2400
*<br>Ambulatory Patient Group (APG) used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentAmbulatoryPatientGroupAPG_2fromLoop2400(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("REF");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("REF", "1S", i);
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 128 Reference Identification Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 127 Ambulatory Patient Group Number
       if (de != null)
         de.get();
    }
  }

/** extract data from segment REF that is part of the Loop2400
*<br>Oxygen Flow Rate used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentOxygenFlowRate_2fromLoop2400(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("REF", "TP");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 128 Reference Identification Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 127 Oxygen Flow Rate
  if (de != null)
    de.get();
  }

/** extract data from segment REF that is part of the Loop2400
*<br>Universal Product Number (UPN) used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentUniversalProductNumberUPN_2fromLoop2400(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("REF", "OZ");
 // other key values: "VP" 
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 128 Reference Identification Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 127 Universal Product Number
  if (de != null)
    de.get();
  }

/** extract data from segment AMT that is part of the Loop2400
*<br>Sales Tax Amount used 
*<br>To indicate the total monetary amount
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentSalesTaxAmount_2fromLoop2400(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("AMT", "T");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 522 Amount Qualifier Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 782 Sales Tax Amount
  if (de != null)
    de.get();
  }

/** extract data from segment AMT that is part of the Loop2400
*<br>Approved Amount used 
*<br>To indicate the total monetary amount
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentApprovedAmount_2fromLoop2400(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("AMT", "AAE");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 522 Amount Qualifier Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 782 Approved Amount
  if (de != null)
    de.get();
  }

/** extract data from segment AMT that is part of the Loop2400
*<br>Postage Claimed Amount used 
*<br>To indicate the total monetary amount
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentPostageClaimedAmount_2fromLoop2400(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("AMT", "F4");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 522 Amount Qualifier Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 782 Postage Claimed Amount
  if (de != null)
    de.get();
  }

/** extract data from segment K3 that is part of the Loop2400
*<br>File Information used 
*<br>To transmit a fixed-format record or matrix contents
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentFileInformation_2fromLoop2400(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("K3");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("K3", i);
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 449 Fixed Format Information
       if (de != null)
         de.get();
    }
  }

/** extract data from segment NTE that is part of the Loop2400
*<br>Line Note used 
*<br>To transmit information in a free-form format, if necessary, for comment or special instruction
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentLineNote_2fromLoop2400(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("NTE");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 363 Note Reference Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 352 Line Note Text
  if (de != null)
    de.get();
  }

/** extract data from segment PS1 that is part of the Loop2400
*<br>Purchased Service Information used 
*<br>To specify the information about services that are purchased
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentPurchasedServiceInformation_2fromLoop2400(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("PS1");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 127 Purchased Service Provider Identifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 782 Purchased Service Charge Amount
  if (de != null)
    de.get();
  }

/** extract data from segment HSD that is part of the Loop2400
*<br>Health Care Services Delivery used 
*<br>To specify the delivery pattern of health care services
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentHealthCareServicesDelivery_2fromLoop2400(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("HSD");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 673 Visits
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 380 Number of Visits
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 355 Frequency Period
  if (de != null)
    de.get();
  de = segment.getDataElement(4);  // 1167 Frequency Count
  if (de != null)
    de.get();
  de = segment.getDataElement(5);  // 615 Duration of Visits Units
  if (de != null)
    de.get();
  de = segment.getDataElement(6);  // 616 Duration of Visits, Number of Units
  if (de != null)
    de.get();
  de = segment.getDataElement(7);  // 678 Ship, Delivery or Calendar Pattern Code
  if (de != null)
    de.get();
  de = segment.getDataElement(8);  // 679 Delivery Pattern Time Code
  if (de != null)
    de.get();
  }

/** extract data from segment HCP that is part of the Loop2400
*<br>Line Pricing/Repricing Information used 
*<br>To specify pricing or repricing information about a health care claim or line item
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentLinePricingRepricingInformation_2fromLoop2400(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("HCP");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 1473 Pricing Methodology
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 782 Repriced Allowed Amount
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 782 Repriced Saving Amount
  if (de != null)
    de.get();
  de = segment.getDataElement(4);  // 127 Repricing Organization Identifier
  if (de != null)
    de.get();
  de = segment.getDataElement(5);  // 118 Repricing Per Diem or Flat Rate Amount
  if (de != null)
    de.get();
  de = segment.getDataElement(6);  // 127 Repriced Approved Ambulatory Patient Group Code
  if (de != null)
    de.get();
  de = segment.getDataElement(7);  // 782 Repriced Approved Ambulatory Patient Group Amount
  if (de != null)
    de.get();
  de = segment.getDataElement(9);  // 235 Product or Service ID Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(10);  // 234 Procedure Code
  if (de != null)
    de.get();
  de = segment.getDataElement(11);  // 355 Unit or Basis for Measurement Code
  if (de != null)
    de.get();
  de = segment.getDataElement(12);  // 380 Repriced Approved Service Unit Count
  if (de != null)
    de.get();
  de = segment.getDataElement(13);  // 901 Reject Reason Code
  if (de != null)
    de.get();
  de = segment.getDataElement(14);  // 1526 Policy Compliance Code
  if (de != null)
    de.get();
  de = segment.getDataElement(15);  // 1527 Exception Code
  if (de != null)
    de.get();
  }

/** extract data from loop 2420A that is part of Loop2400
*<br>Rendering Provider Name used 
* @param inLoop loop containing this loop
*@throws OBOEException - most likely loop not found
*/
public void extractLoop2420A_2fromLoop2400(Loop inLoop)  throws OBOEException
{
  Loop loop = inLoop.getLoop("2420A");
  if (loop == null) return;
  extractSegmentRenderingProviderName_2fromLoop2420A(loop);
  extractSegmentRenderingProviderSpecialtyInformation_2fromLoop2420A(loop);
  extractSegmentAdditionalRenderingProviderNameInformation_2fromLoop2420A(loop);
  extractSegmentRenderingProviderSecondaryIdentification_2fromLoop2420A(loop);
  }

/** extract data from segment NM1 that is part of the Loop2420A
*<br>Rendering Provider Name used 
*<br>To supply the full name of an individual or organizational entity
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentRenderingProviderName_2fromLoop2420A(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("NM1");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 98 Entity Identifier Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1065 Entity Type Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1035 Rendering Provider Last or Organization Name
  if (de != null)
    de.get();
  de = segment.getDataElement(4);  // 1036 Rendering Provider First Name
  if (de != null)
    de.get();
  de = segment.getDataElement(5);  // 1037 Rendering Provider Middle Name
  if (de != null)
    de.get();
  de = segment.getDataElement(7);  // 1039 Rendering Provider Name Suffix
  if (de != null)
    de.get();
  de = segment.getDataElement(8);  // 66 Identification Code Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(9);  // 67 Rendering Provider Identifier
  if (de != null)
    de.get();
  }

/** extract data from segment PRV that is part of the Loop2420A
*<br>Rendering Provider Specialty Information used 
*<br>To specify the identifying characteristics of a provider
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentRenderingProviderSpecialtyInformation_2fromLoop2420A(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("PRV");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 1221 Provider Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 128 Reference Identification Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 127 Provider Taxonomy Code
  if (de != null)
    de.get();
  }

/** extract data from segment N2 that is part of the Loop2420A
*<br>Additional Rendering Provider Name Information used 
*<br>To specify additional names or those longer than 35 characters in length
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentAdditionalRenderingProviderNameInformation_2fromLoop2420A(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("N2");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 93 Rendering Provider Name Additional Text
  if (de != null)
    de.get();
  }

/** extract data from segment REF that is part of the Loop2420A
*<br>Rendering Provider Secondary Identification used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentRenderingProviderSecondaryIdentification_2fromLoop2420A(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("REF");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("REF", i);
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 128 Reference Identification Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 127 Rendering Provider Secondary Identifier
       if (de != null)
         de.get();
    }
  }

/** extract data from loop 2420B that is part of Loop2400
*<br>Purchased Service Provider Name used 
* @param inLoop loop containing this loop
*@throws OBOEException - most likely loop not found
*/
public void extractLoop2420B_2fromLoop2400(Loop inLoop)  throws OBOEException
{
  Loop loop = inLoop.getLoop("2420B");
  if (loop == null) return;
  extractSegmentPurchasedServiceProviderName_2fromLoop2420B(loop);
  extractSegmentPurchasedServiceProviderSecondaryIdentification_2fromLoop2420B(loop);
  }

/** extract data from segment NM1 that is part of the Loop2420B
*<br>Purchased Service Provider Name used 
*<br>To supply the full name of an individual or organizational entity
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentPurchasedServiceProviderName_2fromLoop2420B(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("NM1");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 98 Entity Identifier Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1065 Entity Type Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(8);  // 66 Identification Code Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(9);  // 67 Purchased Service Provider Identifier
  if (de != null)
    de.get();
  }

/** extract data from segment REF that is part of the Loop2420B
*<br>Purchased Service Provider Secondary Identification used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentPurchasedServiceProviderSecondaryIdentification_2fromLoop2420B(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("REF");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("REF", i);
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 128 Reference Identification Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 127 Purchased Service Provider Secondary Identifier
       if (de != null)
         de.get();
    }
  }

/** extract data from loop 2420C that is part of Loop2400
*<br>Service Facility Location used 
* @param inLoop loop containing this loop
*@throws OBOEException - most likely loop not found
*/
public void extractLoop2420C_2fromLoop2400(Loop inLoop)  throws OBOEException
{
  Loop loop = inLoop.getLoop("2420C");
  if (loop == null) return;
  extractSegmentServiceFacilityLocation_2fromLoop2420C(loop);
  extractSegmentAdditionalServiceFacilityLocationNameInformation_2fromLoop2420C(loop);
  extractSegmentServiceFacilityLocationAddress_2fromLoop2420C(loop);
  extractSegmentServiceFacilityLocationCityStateZIP_2fromLoop2420C(loop);
  extractSegmentServiceFacilityLocationSecondaryIdentification_2fromLoop2420C(loop);
  }

/** extract data from segment NM1 that is part of the Loop2420C
*<br>Service Facility Location used 
*<br>To supply the full name of an individual or organizational entity
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentServiceFacilityLocation_2fromLoop2420C(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("NM1");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 98 Entity Identifier Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1065 Entity Type Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1035 Laboratory or Facility Name
  if (de != null)
    de.get();
  de = segment.getDataElement(8);  // 66 Identification Code Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(9);  // 67 Laboratory or Facility Primary Identifier
  if (de != null)
    de.get();
  }

/** extract data from segment N2 that is part of the Loop2420C
*<br>Additional Service Facility Location Name Information used 
*<br>To specify additional names or those longer than 35 characters in length
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentAdditionalServiceFacilityLocationNameInformation_2fromLoop2420C(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("N2");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 93 Laboratory or Facility Name Additional Text
  if (de != null)
    de.get();
  }

/** extract data from segment N3 that is part of the Loop2420C
*<br>Service Facility Location Address used 
*<br>To specify the location of the named party
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentServiceFacilityLocationAddress_2fromLoop2420C(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("N3");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 166 Laboratory or Facility Address Line
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 166 Laboratory or Facility Address Line
  if (de != null)
    de.get();
  }

/** extract data from segment N4 that is part of the Loop2420C
*<br>Service Facility Location City/State/ZIP used 
*<br>To specify the geographic place of the named party
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentServiceFacilityLocationCityStateZIP_2fromLoop2420C(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("N4");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 19 Laboratory or Facility City Name
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 156 Laboratory or Facility State or Province Code
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 116 Laboratory or Facility Postal Zone or ZIP Code
  if (de != null)
    de.get();
  de = segment.getDataElement(4);  // 26 Country Code
  if (de != null)
    de.get();
  }

/** extract data from segment REF that is part of the Loop2420C
*<br>Service Facility Location Secondary Identification used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentServiceFacilityLocationSecondaryIdentification_2fromLoop2420C(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("REF");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("REF", i);
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 128 Reference Identification Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 127 Service Facility Location Secondary Identifier
       if (de != null)
         de.get();
    }
  }

/** extract data from loop 2420D that is part of Loop2400
*<br>Supervising Provider Name used 
* @param inLoop loop containing this loop
*@throws OBOEException - most likely loop not found
*/
public void extractLoop2420D_2fromLoop2400(Loop inLoop)  throws OBOEException
{
  Loop loop = inLoop.getLoop("2420D");
  if (loop == null) return;
  extractSegmentSupervisingProviderName_2fromLoop2420D(loop);
  extractSegmentAdditionalSupervisingProviderNameInformation_2fromLoop2420D(loop);
  extractSegmentSupervisingProviderSecondaryIdentification_2fromLoop2420D(loop);
  }

/** extract data from segment NM1 that is part of the Loop2420D
*<br>Supervising Provider Name used 
*<br>To supply the full name of an individual or organizational entity
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentSupervisingProviderName_2fromLoop2420D(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("NM1");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 98 Entity Identifier Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1065 Entity Type Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1035 Supervising Provider Last Name
  if (de != null)
    de.get();
  de = segment.getDataElement(4);  // 1036 Supervising Provider First Name
  if (de != null)
    de.get();
  de = segment.getDataElement(5);  // 1037 Supervising Provider Middle Name
  if (de != null)
    de.get();
  de = segment.getDataElement(7);  // 1039 Supervising Provider Name Suffix
  if (de != null)
    de.get();
  de = segment.getDataElement(8);  // 66 Identification Code Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(9);  // 67 Supervising Provider Identifier
  if (de != null)
    de.get();
  }

/** extract data from segment N2 that is part of the Loop2420D
*<br>Additional Supervising Provider Name Information used 
*<br>To specify additional names or those longer than 35 characters in length
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentAdditionalSupervisingProviderNameInformation_2fromLoop2420D(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("N2");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 93 Supervising Provider Name Additional Text
  if (de != null)
    de.get();
  }

/** extract data from segment REF that is part of the Loop2420D
*<br>Supervising Provider Secondary Identification used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentSupervisingProviderSecondaryIdentification_2fromLoop2420D(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("REF");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("REF", i);
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 128 Reference Identification Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 127 Supervising Provider Secondary Identifier
       if (de != null)
         de.get();
    }
  }

/** extract data from loop 2420E that is part of Loop2400
*<br>Ordering Provider Name used 
* @param inLoop loop containing this loop
*@throws OBOEException - most likely loop not found
*/
public void extractLoop2420E_2fromLoop2400(Loop inLoop)  throws OBOEException
{
  Loop loop = inLoop.getLoop("2420E");
  if (loop == null) return;
  extractSegmentOrderingProviderName_2fromLoop2420E(loop);
  extractSegmentAdditionalOrderingProviderNameInformation_2fromLoop2420E(loop);
  extractSegmentOrderingProviderAddress_2fromLoop2420E(loop);
  extractSegmentOrderingProviderCityStateZIPCode_2fromLoop2420E(loop);
  extractSegmentOrderingProviderSecondaryIdentification_2fromLoop2420E(loop);
  extractSegmentOrderingProviderContactInformation_2fromLoop2420E(loop);
  }

/** extract data from segment NM1 that is part of the Loop2420E
*<br>Ordering Provider Name used 
*<br>To supply the full name of an individual or organizational entity
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentOrderingProviderName_2fromLoop2420E(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("NM1");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 98 Entity Identifier Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1065 Entity Type Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1035 Ordering Provider Last Name
  if (de != null)
    de.get();
  de = segment.getDataElement(4);  // 1036 Ordering Provider First Name
  if (de != null)
    de.get();
  de = segment.getDataElement(5);  // 1037 Ordering Provider Middle Name
  if (de != null)
    de.get();
  de = segment.getDataElement(7);  // 1039 Ordering Provider Name Suffix
  if (de != null)
    de.get();
  de = segment.getDataElement(8);  // 66 Identification Code Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(9);  // 67 Ordering Provider Identifier
  if (de != null)
    de.get();
  }

/** extract data from segment N2 that is part of the Loop2420E
*<br>Additional Ordering Provider Name Information used 
*<br>To specify additional names or those longer than 35 characters in length
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentAdditionalOrderingProviderNameInformation_2fromLoop2420E(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("N2");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 93 Ordering Provider Name Additional Text
  if (de != null)
    de.get();
  }

/** extract data from segment N3 that is part of the Loop2420E
*<br>Ordering Provider Address used 
*<br>To specify the location of the named party
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentOrderingProviderAddress_2fromLoop2420E(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("N3");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 166 Ordering Provider Address Line
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 166 Ordering Provider Address Line
  if (de != null)
    de.get();
  }

/** extract data from segment N4 that is part of the Loop2420E
*<br>Ordering Provider City/State/ZIP Code used 
*<br>To specify the geographic place of the named party
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentOrderingProviderCityStateZIPCode_2fromLoop2420E(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("N4");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 19 Ordering Provider City Name
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 156 Ordering Provider State Code
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 116 Ordering Provider Postal Zone or ZIP Code
  if (de != null)
    de.get();
  de = segment.getDataElement(4);  // 26 Country Code
  if (de != null)
    de.get();
  }

/** extract data from segment REF that is part of the Loop2420E
*<br>Ordering Provider Secondary Identification used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentOrderingProviderSecondaryIdentification_2fromLoop2420E(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("REF");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("REF", i);
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 128 Reference Identification Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 127 Ordering Provider Secondary Identifier
       if (de != null)
         de.get();
    }
  }

/** extract data from segment PER that is part of the Loop2420E
*<br>Ordering Provider Contact Information used 
*<br>To identify a person or office to whom administrative communications should be directed
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentOrderingProviderContactInformation_2fromLoop2420E(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("PER");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 366 Contact Function Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 93 Ordering Provider Contact Name
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 365 Communication Number Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(4);  // 364 Communication Number
  if (de != null)
    de.get();
  de = segment.getDataElement(5);  // 365 Communication Number Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(6);  // 364 Communication Number
  if (de != null)
    de.get();
  de = segment.getDataElement(7);  // 365 Communication Number Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(8);  // 364 Communication Number
  if (de != null)
    de.get();
  }

/** extract data from loop 2420F that is part of Loop2400
*<br>Referring Provider Name used 
* @param inLoop loop containing this loop
*@throws OBOEException - most likely loop not found
*/
public void extractLoop2420F_2fromLoop2400(Loop inLoop)  throws OBOEException
{
  Loop loop;
  int numberInVector = inLoop.getCount("2420F");
  for (int i = 0; i <  numberInVector; i++)
   {
   loop = inLoop.getLoop("2420F", i);
   if (loop == null) return;
      extractSegmentReferringProviderName_2fromLoop2420F(loop);
      extractSegmentReferringProviderSpecialtyInformation_2fromLoop2420F(loop);
      extractSegmentAdditionalReferringProviderNameInformation_2fromLoop2420F(loop);
      extractSegmentReferringProviderSecondaryIdentification_2fromLoop2420F(loop);
    }
  }

/** extract data from segment NM1 that is part of the Loop2420F
*<br>Referring Provider Name used 
*<br>To supply the full name of an individual or organizational entity
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentReferringProviderName_2fromLoop2420F(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("NM1");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 98 Entity Identifier Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1065 Entity Type Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1035 Referring Provider Last Name
  if (de != null)
    de.get();
  de = segment.getDataElement(4);  // 1036 Referring Provider First Name
  if (de != null)
    de.get();
  de = segment.getDataElement(5);  // 1037 Referring Provider Middle Name
  if (de != null)
    de.get();
  de = segment.getDataElement(7);  // 1039 Referring Provider Name Suffix
  if (de != null)
    de.get();
  de = segment.getDataElement(8);  // 66 Identification Code Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(9);  // 67 Referring Provider Identifier
  if (de != null)
    de.get();
  }

/** extract data from segment PRV that is part of the Loop2420F
*<br>Referring Provider Specialty Information used 
*<br>To specify the identifying characteristics of a provider
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentReferringProviderSpecialtyInformation_2fromLoop2420F(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("PRV");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 1221 Provider Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 128 Reference Identification Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 127 Provider Taxonomy Code
  if (de != null)
    de.get();
  }

/** extract data from segment N2 that is part of the Loop2420F
*<br>Additional Referring Provider Name Information used 
*<br>To specify additional names or those longer than 35 characters in length
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentAdditionalReferringProviderNameInformation_2fromLoop2420F(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("N2");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 93 Referring Provider Name Additional Text
  if (de != null)
    de.get();
  }

/** extract data from segment REF that is part of the Loop2420F
*<br>Referring Provider Secondary Identification used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentReferringProviderSecondaryIdentification_2fromLoop2420F(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("REF");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("REF", i);
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 128 Reference Identification Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 127 Referring Provider Secondary Identifier
       if (de != null)
         de.get();
    }
  }

/** extract data from loop 2420G that is part of Loop2400
*<br>Other Payer Prior Authorization or Referral Number used 
* @param inLoop loop containing this loop
*@throws OBOEException - most likely loop not found
*/
public void extractLoop2420G_2fromLoop2400(Loop inLoop)  throws OBOEException
{
  Loop loop;
  int numberInVector = inLoop.getCount("2420G");
  for (int i = 0; i <  numberInVector; i++)
   {
   loop = inLoop.getLoop("2420G", i);
   if (loop == null) return;
      extractSegmentOtherPayerPriorAuthorizationorReferralNumber_3fromLoop2420G(loop);
      extractSegmentOtherPayerPriorAuthorizationorReferralNumber_4fromLoop2420G(loop);
    }
  }

/** extract data from segment NM1 that is part of the Loop2420G
*<br>Other Payer Prior Authorization or Referral Number used 
*<br>To supply the full name of an individual or organizational entity
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentOtherPayerPriorAuthorizationorReferralNumber_3fromLoop2420G(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("NM1");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 98 Entity Identifier Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1065 Entity Type Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1035 Payer Name
  if (de != null)
    de.get();
  de = segment.getDataElement(8);  // 66 Identification Code Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(9);  // 67 Other Payer Identification Number
  if (de != null)
    de.get();
  }

/** extract data from segment REF that is part of the Loop2420G
*<br>Other Payer Prior Authorization or Referral Number used 
*<br>To specify identifying information
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentOtherPayerPriorAuthorizationorReferralNumber_4fromLoop2420G(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("REF");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("REF", i);
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 128 Reference Identification Qualifier
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 127 Other Payer Prior Authorization or Referral Number
       if (de != null)
         de.get();
    }
  }

/** extract data from loop 2430 that is part of Loop2400
*<br>Line Adjudication Information used 
* @param inLoop loop containing this loop
*@throws OBOEException - most likely loop not found
*/
public void extractLoop2430_2fromLoop2400(Loop inLoop)  throws OBOEException
{
  Loop loop;
  int numberInVector = inLoop.getCount("2430");
  for (int i = 0; i <  numberInVector; i++)
   {
   loop = inLoop.getLoop("2430", i);
   if (loop == null) return;
      extractSegmentLineAdjudicationInformation_2fromLoop2430(loop);
      extractSegmentLineAdjustment_2fromLoop2430(loop);
      extractSegmentLineAdjudicationDate_2fromLoop2430(loop);
    }
  }

/** extract data from segment SVD that is part of the Loop2430
*<br>Line Adjudication Information used 
*<br>To convey service line adjudication information for coordination of benefits between the initial payers of a health care claim and all subsequent payers
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentLineAdjudicationInformation_2fromLoop2430(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("SVD");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 67 Other Payer Primary Identifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 782 Service Line Paid Amount
  if (de != null)
    de.get();
    CompositeDE  composite = (CompositeDE) segment.getCompositeDE(3);  // C003 Composite Medical
  if (composite == null)
    return;
  de = composite.getDataElement(1);  // composite element 235 Product or Service ID Qualifier
  if (de != null)
    de.get();
  de = composite.getDataElement(2);  // composite element 234 Procedure Code
  if (de != null)
    de.get();
  de = composite.getDataElement(3);  // composite element 1339 Procedure Modifier
  if (de != null)
    de.get();
  de = composite.getDataElement(4);  // composite element 1339 Procedure Modifier
  if (de != null)
    de.get();
  de = composite.getDataElement(5);  // composite element 1339 Procedure Modifier
  if (de != null)
    de.get();
  de = composite.getDataElement(6);  // composite element 1339 Procedure Modifier
  if (de != null)
    de.get();
  de = composite.getDataElement(7);  // composite element 352 Procedure Code Description
  if (de != null)
    de.get();
  de = segment.getDataElement(5);  // 380 Paid Service Unit Count
  if (de != null)
    de.get();
  de = segment.getDataElement(6);  // 554 Bundled or Unbundled Line Number
  if (de != null)
    de.get();
  }

/** extract data from segment CAS that is part of the Loop2430
*<br>Line Adjustment used 
*<br>To supply adjustment reason codes and amounts as needed for an entire claim or for a particular service within the claim being paid
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentLineAdjustment_2fromLoop2430(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("CAS");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("CAS", i);
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 1033 Claim Adjustment Group Code
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 1034 Adjustment Reason Code
       if (de != null)
         de.get();
       de = segment.getDataElement(3);       // 782 Adjustment Amount
       if (de != null)
         de.get();
       de = segment.getDataElement(4);       // 380 Adjustment Quantity
       if (de != null)
         de.get();
       de = segment.getDataElement(5);       // 1034 Adjustment Reason Code
       if (de != null)
         de.get();
       de = segment.getDataElement(6);       // 782 Adjustment Amount
       if (de != null)
         de.get();
       de = segment.getDataElement(7);       // 380 Adjustment Quantity
       if (de != null)
         de.get();
       de = segment.getDataElement(8);       // 1034 Adjustment Reason Code
       if (de != null)
         de.get();
       de = segment.getDataElement(9);       // 782 Adjustment Amount
       if (de != null)
         de.get();
       de = segment.getDataElement(10);       // 380 Adjustment Quantity
       if (de != null)
         de.get();
       de = segment.getDataElement(11);       // 1034 Adjustment Reason Code
       if (de != null)
         de.get();
       de = segment.getDataElement(12);       // 782 Adjustment Amount
       if (de != null)
         de.get();
       de = segment.getDataElement(13);       // 380 Adjustment Quantity
       if (de != null)
         de.get();
       de = segment.getDataElement(14);       // 1034 Adjustment Reason Code
       if (de != null)
         de.get();
       de = segment.getDataElement(15);       // 782 Adjustment Amount
       if (de != null)
         de.get();
       de = segment.getDataElement(16);       // 380 Adjustment Quantity
       if (de != null)
         de.get();
       de = segment.getDataElement(17);       // 1034 Adjustment Reason Code
       if (de != null)
         de.get();
       de = segment.getDataElement(18);       // 782 Adjustment Amount
       if (de != null)
         de.get();
       de = segment.getDataElement(19);       // 380 Adjustment Quantity
       if (de != null)
         de.get();
    }
  }

/** extract data from segment DTP that is part of the Loop2430
*<br>Line Adjudication Date used 
*<br>To specify any or all of a date, a time, or a time period
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentLineAdjudicationDate_2fromLoop2430(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("DTP");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 374 Date Time Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1250 Date Time Period Format Qualifier
  if (de != null)
    de.get();
  de = segment.getDataElement(3);  // 1251 Adjudication or Payment Date
  if (de != null)
    de.get();
  }

/** extract data from loop 2440 that is part of Loop2400
*<br>Form Identification Code used 
* @param inLoop loop containing this loop
*@throws OBOEException - most likely loop not found
*/
public void extractLoop2440_2fromLoop2400(Loop inLoop)  throws OBOEException
{
  Loop loop;
  int numberInVector = inLoop.getCount("2440");
  for (int i = 0; i <  numberInVector; i++)
   {
   loop = inLoop.getLoop("2440", i);
   if (loop == null) return;
      extractSegmentFormIdentificationCode_2fromLoop2440(loop);
      extractSegmentSupportingDocumentation_2fromLoop2440(loop);
    }
  }

/** extract data from segment LQ that is part of the Loop2440
*<br>Form Identification Code used 
*<br>Code to transmit standard industry codes
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentFormIdentificationCode_2fromLoop2440(Loop inLoop)  throws OBOEException
{
  Segment segment = inLoop.getSegment("LQ");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 1270 Code List Qualifier Code
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 1271 Form Identifier
  if (de != null)
    de.get();
  }

/** extract data from segment FRM that is part of the Loop2440
*<br>Supporting Documentation used 
*<br>To specify information in response to a codified questionnaire document.
* @param inLoop Loop containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentSupportingDocumentation_2fromLoop2440(Loop inLoop)  throws OBOEException
{
  Segment segment;
  int numberOfSegmentsInVector = inLoop.getCount("FRM");
  for (int i = 0; i <  numberOfSegmentsInVector; i++)
    {
       segment = inLoop.getSegment("FRM", i);
       if (segment == null)
         return;
       DataElement de;
       de = segment.getDataElement(1);       // 350 Question Number/Letter
       if (de != null)
         de.get();
       de = segment.getDataElement(2);       // 1073 Question Response
       if (de != null)
         de.get();
       de = segment.getDataElement(3);       // 127 Question Response
       if (de != null)
         de.get();
       de = segment.getDataElement(4);       // 373 Question Response
       if (de != null)
         de.get();
       de = segment.getDataElement(5);       // 332 Question Response
       if (de != null)
         de.get();
    }
  }

/** extract data from segment SE that is part of the TableDetail
*<br>Transaction Set Trailer used 
*<br>To indicate the end of the transaction set and provide the count of the transmitted segments (including the beginning (ST) and ending (SE) segments)
* @param inTable Table containing this segment
*@throws OBOEException - most likely segment not found
*/
public void extractSegmentTransactionSetTrailerfromTableDetail(Table inTable)
  throws OBOEException
{
  Segment segment = inTable.getSegment("SE");
  if (segment == null)
    return;
  DataElement de;
  de = segment.getDataElement(1);  // 96 Transaction Segment Count
  if (de != null)
    de.get();
  de = segment.getDataElement(2);  // 329 Transaction Set Control Number
  if (de != null)
    de.get();
  }

}
