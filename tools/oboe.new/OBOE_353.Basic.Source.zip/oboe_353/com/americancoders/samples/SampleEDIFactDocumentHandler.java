package com.americancoders.samples;

/**
 *OBOE - Open Business Objects for EDI
 *<P>java access to EDI
 *<p>Copyright 1998-2007 - American Coders, LTD  - Raleigh NC USA
 *<p>All rights reserved
 *<p>American Coders, Ltd
 *<br>P. O. Box 97462
 *<br>Raleigh, NC  27624  USA
 *<br>1-919-846-2014
 *<br>http://www.americancoders.com
@author Joe McVerry - American Coders, Ltd.
@version buildNotToBeReleased
 */

import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;

import com.americancoders.edi.DocumentErrors;
import com.americancoders.edi.EDIDocumentHandler;
import com.americancoders.edi.Envelope;
import com.americancoders.edi.FunctionalGroup;
import com.americancoders.edi.Segment;
import com.americancoders.edi.TransactionSet;
import com.americancoders.edi.EDIFact.EDIFactDocumentParser;
import com.americancoders.edi.EDIFact.EDIFactEnvelope;
import com.americancoders.edi.EDIFact.EDIFactFunctionalGroup;

/**
 * class to parse input string for all defined OBOE Transaction Sets
 * <br> program will create Valid XML formatted data for each transaction set
 * <br> output sent to System.out (console)
 * <br> EDIFact dependent
 *
 */

public class SampleEDIFactDocumentHandler implements EDIDocumentHandler {

	EDIFactEnvelope envelope = null;
	FunctionalGroup functionalGroup = null;
	/** do nothing constructor
	 */
	public SampleEDIFactDocumentHandler() {
		;
	}

	/** start parsing not used here */

	public void startParsing(java.io.Reader inRDR) {
		;
	}

	/** do nothing when an envelope is started */
	public void startEnvelope(Envelope inEnv) {
		envelope = (EDIFactEnvelope) inEnv;
	}

	/** called when an FunctionalGroup object is created
	 * @param inFG FunctionalGroup found
	 */

	public void startFunctionalGroup(FunctionalGroup inFG) {
		functionalGroup = inFG;
		envelope.addFunctionalGroup(inFG);
	}

	/** called when an TransactionSet object is created
	 * @param inTS TransactionSet found
	 */
	public void startTransactionSet(TransactionSet inTS) {
		functionalGroup.addTransactionSet(inTS);
	}

	/** called when an Segment object is created
	 * <br>only called for segments at the Envelope and functionalGroup level
	 * does not get called for segments within TransactionSet
	 * @param inSeg  Segment found
	 */
	public void startSegment(Segment inSeg) {

		
		if (inSeg.getID().compareTo(EDIFactEnvelope.idInterchangeHeader) == 0)
			envelope.addSegment(inSeg);
		else if (
			inSeg.getID().compareTo(EDIFactEnvelope.idInterchangeTrailer) == 0)
			envelope.addSegment(inSeg);
		
		else if (inSeg.getID().compareTo(EDIFactFunctionalGroup.idHeader) == 0)
			functionalGroup.addSegment(inSeg);
		else if (inSeg.getID().compareTo(EDIFactFunctionalGroup.idTrailer) == 0)
			functionalGroup.addSegment(inSeg);

	}

	/** do nothing when an envelope is ended
	*/
	public void endEnvelope(Envelope inEnv) {

		envelope = (EDIFactEnvelope) inEnv;
	}

	/** do nothing when an fg is ended
	*/
	public void endFunctionalGroup(FunctionalGroup inFG) {
		;
	}

	/** create a Valid XML document for each ts found
	*/
	public void endTransactionSet(TransactionSet inTS) {

	}

	/** do nothing when an seg is ended
	 * <br>Note that these segments are only envelope and fg segments NOT SEGMENTS inside of Transaction Sets
	*/
	public void endSegment(Segment inSeg) {
		;
	}
	
	public void parse(String file)
	{
		EDIFactDocumentParser p1 = null;
		
		try {

			FileReader fr = new FileReader(file); // set up to read the file

			p1 = new EDIFactDocumentParser(); // create a parser object

			
			p1.registerHandler(this); // register with the parser
			p1.parseDocument(fr, false); // start doing some work
			envelope.validate(p1.getDocumentErrors());
			
			fr.close();

		} catch (IOException ioe) {
			ioe.printStackTrace();
		} catch (Exception e1) {
			p1.getDocumentErrors().logErrors();
			e1.printStackTrace();
		}
		
		de = p1.getDocumentErrors();
		de.logErrors();
	    
	}
	
	DocumentErrors de;

	public DocumentErrors getDocumentErrors() {
		
		return de; 
	}

	
	/** from command line
	 * <br> java com.americancoders.samples.SampleEDIFactDocumentHandler xxxx,
	 * where xxxx is a EDIFact document filename
	 * output sent to System.out
	 * error message also sent to System.out
	 */

	public static void main(String args[]) {
		if (args == null || args.length < 1) {
			System.out.println(
				"usage: java com.americancoders.samples.SampleEDIFactDocumentHandler edidatafilename ");
			System.exit(-1);
		}
		SampleEDIFactDocumentHandler sxdh = new SampleEDIFactDocumentHandler();
		sxdh.parse(args[0]);
        try {
            sxdh.envelope.writeFormattedText(new PrintWriter(System.out), Envelope.XML_FORMAT);
			System.out.flush();
        }
        catch (IOException ioe)
        {
        	ioe.printStackTrace();
        }
		

	}

}