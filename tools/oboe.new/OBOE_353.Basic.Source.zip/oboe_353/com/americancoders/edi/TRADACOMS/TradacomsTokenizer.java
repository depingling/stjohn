package com.americancoders.edi.TRADACOMS;

import java.io.IOException;
import java.io.PushbackReader;
import java.io.Reader;

import org.apache.log4j.Logger;


import com.americancoders.edi.DocumentErrors;
import com.americancoders.edi.Envelope;
import com.americancoders.edi.ITokenizer;
import com.americancoders.edi.OBOEException;
import com.americancoders.edi.ReaderTokenizer;
import com.americancoders.edi.Tokenizer;
import com.americancoders.util.Util;

/**
 *  class to assist in tokenizing input transaction sets
 *  <br>  x12 field seperator uses 3rd byte of input string
 *  <br>  x12 segment separator uses 16th field + 1 byte field, if it sees a cr character then checks for a lf character and then assumes a \\n character
 *  <br>  EDIFact uses different control positions.  see header segment.
 *<p>OBOE - Open Business Objects for EDI
 *<p>Part of the OBOE Basic Extended Package
 *<br>An EDI and XML Translator Written In Java
 *<br>Copyright 1998-2007 - American Coders, LTD  - Raleigh NC USA
 *<br>All rights reserved
 *<br>American Coders, Ltd
 *<br>P. O. Box 97462
 *<br>Raleigh, NC  27624  USA
 *<br>1-919-846-2014
 *<br>http://www.americancoders.com
@author Joe McVerry - American Coders, Ltd.
  @version   3.5.3
 */

public class TradacomsTokenizer  extends Tokenizer implements ITokenizer {

	/** log4j object */
    static Logger logr = Logger.getLogger(TradacomsTokenizer.class);
	static 	{Util.isLog4JNotConfigured();}


	/** builds the parsing object for a transaction set
	 * @param inReader what's to be tokenized
	 * @param inDErr DocumentError
	 * @throws OBOEException invalid token most likely
	 */
	public TradacomsTokenizer(Reader inReader, DocumentErrors inDErr)
		throws OBOEException {
		
		super(inDErr);

			PushbackReader pbr = new PushbackReader(inReader, 10);
			char firstSeg[] = new char[10];
			try {
				if (pbr.read(firstSeg, 0, 10) != 10)
					throw new OBOEException("expected data not read");
			} catch (IOException ioe) {
				ioe.printStackTrace();
				throw new OBOEException(ioe.getMessage());
			}
				try {
					pbr.unread(firstSeg);
				} catch (IOException ioe) {
					ioe.printStackTrace();
					throw new OBOEException(ioe.getMessage());
				}
				transactionSetTokenizer =
					new ReaderTokenizer(pbr, Envelope.TRADACOMS_SEGMENT_DELIMITER, "?");
				separators.append(Envelope.TRADACOMS_SEGMENT_DELIMITER);
				tokenSeperatorCharacter = Envelope.TRADACOMS_FIELD_DELIMITER+Envelope.TRADACOMS_SEGID_DELIMITER;
				separators.append(Envelope.TRADACOMS_FIELD_DELIMITER);
				tokenGroups[0] = Envelope.TRADACOMS_GROUP_DELIMITER.charAt(0);
				separators.append(tokenGroups[0]);
				this.escapeCharacters = Envelope.TRADACOMS_ESCAPE_CHARACTER;
			dataElementReady = false;
	}



}
