/*
 * Copyright (C) 2006-2007 by Joseph McVerry - American Coders, Ltd.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

package org.pixes;

import org.apache.log4j.Logger;


/**
 * @author Joe McVerry - American Coders, Ltd.
 *
 * executor object to allow the return step to change
 *
 */
public class ChangeStep extends Executable {


	/**
	 * tag that is continuable must be registered
	 */
    IContinuable myContinue;

    /**
     * continue forward or backwards, constructor will let us know
     */
    boolean directionForward;


    static {
        Util.isLog4JNotConfigured();
    }

    /**
     *
     * @param line xml file line number
     * @param continueObject object working with
     * @param iContinue direction to continue to
     */
    public ChangeStep(int line, IContinuable continueObject, boolean iContinue) {
    	
    	super(null);

        logr = Logger.getLogger(ChangeStep.class);
        setLogger();
        logr.debug("changestep constructor " + continueObject + " continue " + iContinue
                + " " + line);
        setMyXMLLine(line);

        myContinue = continueObject;
        directionForward = iContinue;

    }

    /**
     * return the next step of the continue object if going forward
     * (non-Javadoc)
     * @see org.pixes.Executable#execute()
     */
    public int execute(Executor inExec) {

        if (directionForward == true) // break statement
            return myContinue.getNextStep();

        return myContinue.getContinueStep() - 1;

    }

}
