package com.americancoders.edi.x12;
/**
 *OBOE - Open Business Objects for EDI
 *<P>java access to EDI
 *<p>Copyright 1998-2007 - American Coders, LTD  - Raleigh NC USA
 *<p>All rights reserved
 *<p>American Coders, Ltd
 *<br>P. O. Box 97462
 *<br>Raleigh, NC  27624  USA
 *<br>1-919-846-2014
 *<br>http://www.americancoders.com
@author Joe McVerry - American Coders, Ltd.
  @version   3.5.3
 */

import com.americancoders.edi.DataElement;
import com.americancoders.edi.Envelope;
import com.americancoders.edi.OBOEException;
import com.americancoders.edi.Segment;
import com.americancoders.edi.Table;
import com.americancoders.edi.TransactionSet;
import com.americancoders.edi.TransactionSetFactory;

public class Functional_Acknowledgment
{

  /**
   * Static class method used to generate a 997 transactionSet.  It always returns a positive
   *  acknowledgment and assumes it is reponding to 1 transaction set.
   *  @param tsRespondingTo TransactionSet ts we're responding to
   *  @param ISASegment Segment ISA segment used for control numbers to indicate what we are responding to
   *  @return TransactionSet - functional acknowledgement transaction set
   *  @exception OBOEException - for instance using FA to respond to a FA is not correct.
   */


  public static TransactionSet postiveAcknowledgment(TransactionSet tsRespondingTo, Segment ISASegment)
  throws OBOEException
  {

    if (tsRespondingTo.getID().compareTo("997") == 0)
    throw new OBOEException("Functional Acknowledgment should not be used to respond to another Functional Acknowledgment");

    Table responseTable, currentTable;
    Segment responseSegment, currentSegment;
    DataElement currentDE;

    responseTable = tsRespondingTo.getHeaderTable();
    responseSegment = responseTable.getSegment("ST");

    TransactionSet transactionSet = TransactionSetFactory.buildTransactionSet("997");
    transactionSet.setFormat(Envelope.X12_FORMAT);

    currentTable = transactionSet.getHeaderTable();

    currentSegment = currentTable.getTemplateTable().createSegment("ST");
    currentTable.addSegment(currentSegment);
    currentDE = (DataElement) currentSegment.buildDE(0);
    currentDE.set("997");
    currentDE = (DataElement) currentSegment.buildDE(1);
    currentDE.set(responseSegment.getDataElement(2).get());

    currentSegment = currentTable.getTemplateTable().createSegment("AK1");
    currentTable.addSegment(currentSegment);
    currentDE = (DataElement) currentSegment.buildDE(0);
    currentDE.set(tsRespondingTo.getFunctionalGroup());
    currentDE = (DataElement) currentSegment.buildDE(1);
    currentDE.set(ISASegment.getDataElement("ISA13").get());

    currentSegment = currentTable.getTemplateTable().createSegment("AK9");
    currentTable.addSegment(currentSegment);
    currentDE = (DataElement) currentSegment.buildDE(0);
    currentDE.set("A");
    currentDE = (DataElement) currentSegment.buildDE(1);
    currentDE.set("1");
    currentDE = (DataElement) currentSegment.buildDE(2);
    currentDE.set("1");

    currentSegment = currentTable.getTemplateTable().createSegment("SE");
    currentTable.addSegment(currentSegment);
    currentDE = (DataElement) currentSegment.buildDE(0);
    currentDE.set("4");
    currentDE = (DataElement) currentSegment.buildDE(1);
    currentDE.set(responseSegment.getDataElement(2).get());

    return transactionSet;
  }

}
