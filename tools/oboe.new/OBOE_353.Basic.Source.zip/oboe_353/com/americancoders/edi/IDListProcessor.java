package com.americancoders.edi;

import java.io.Externalizable;
import java.util.Vector;

/** An interface for classes that process ID lists
 *<p>OBOE - Open Business Objects for EDI
 *<p>Part of the OBOE Basic Extended Package
 *<br>An EDI and XML Translator Written In Java
 *<br>Copyright 1998-2007 - American Coders, LTD  - Raleigh NC USA
 *<br>All rights reserved
 *<br>American Coders, Ltd
 *<br>P. O. Box 97462
 *<br>Raleigh, NC  27624  USA
 *<br>1-919-846-2014
 *<br>http://www.americancoders.com
@author Joe McVerry - American Coders, Ltd.
  @version   3.5.3
 */

public interface IDListProcessor extends Externalizable {

	/** Add code and description
	 *<br>An optional method.
	 * @param inCode String code
	 * @param inDescribe String descriptive value
	 * @exception java.lang.UnsupportedOperationException
	 */
	public void add(String inCode, String inDescribe)
		throws java.lang.UnsupportedOperationException;

	/** tests if the passed code is valid
	 * @param inCode String to test
	 * @return boolean
	 */
	public boolean isCodeValid(String inCode);

	/** returns the descriptive value of the code,  if it is not found then the code is returned
	 * @param inCode String to test
	 * @return String
	 */
	public String describe(String inCode);

	/** returns the code value for a descriptive value.  if it is not found the value is returned
	 * @param inValue String to test
	 * @return String
	 */

	public String getCode(String inValue);

	/** returns a code at a specific position in vector
	 *<br>An optional method.
	 * @param pos int String position
	 * @return String
	 * @exception java.lang.UnsupportedOperationException
	 */
	public String getCodeByPos(int pos)
		throws java.lang.UnsupportedOperationException;

	/**
	 * returns the code vector
	 *
	 * @return Vector
	 */

	public Vector getCodes();

	/**
	 * returns the value vector
	 *
	 * @return Vector
	 */

	public Vector getValues();

}
