package com.americancoders.samples;

import java.applet.Applet;

/** sample applet routine used at americancoders web page
*<br>OBOE - Open Business Objects for EDI
 *<br>An EDI and XML Translator Written In Java
 *<br>Copyright 1998-2007 - American Coders, LTD  - Raleigh NC USA
 *<brp>All rights reserved
 *<br>American Coders, Ltd
 *<br>P. O. Box 97462
 *<br>Raleigh, NC  27624  USA
 *<br>1-919-846-2014
 *<br>http://www.americancoders.com
 @author Joe McVerry - American Coders, Ltd.
 @version buildNotToBeReleased
 */

public class viewsample extends Applet {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	viewsamples vs;

	public viewsample() {
	}
	public void start() {
		vs = new viewsamples(getCodeBase(), getParameter("type").charAt(0));
		vs.setVisible(true);
	}

}
