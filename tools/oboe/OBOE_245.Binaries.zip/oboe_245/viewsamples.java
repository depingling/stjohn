package com.americancoders.samples;

import java.io.*;

import java.applet.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;
import java.net.*;

import com.americancoders.edi.*;
import com.americancoders.edi.x12.*;
import com.americancoders.edi.EDIFact.*;


/**
 *java awt application to test documents,
 *also used by www.americancoders.com web site to show a working applet
 *<br>Class contains a main method to allow it to invoked as an application.
 *<br>format: java com.americancoders.edi.viewsamples filename
 *<br>where filename is a EDI document
 *<p>OBOE - Open Business Objects for EDI
 *<br>An EDI and XML Translator Written In Java
 *<br>Copyright 1998-2001 - American Coders, LTD  - Raleigh NC USA
 *<br>All rights reserved
 *<br>American Coders, Ltd
 *<br>P. O. Box 97462
 *<br>Raleigh, NC  27624  USA
 *<br>1-919-846-2014
 *<br>http://www.americancoders.com
 @author Joe McVerry, American Coders Ltd.
 @version buildNotToBeReleased
 */


public class viewsamples extends Frame
implements ActionListener, WindowListener, ComponentListener

{
  Panel p;
  GridBagLayout gb;
  GridBagConstraints gbc;
  TextArea intext, outtext;
  Button clear, processfmt, processxml, processvxml, processx12, processedifact; //, done;
  String sb;
  TransactionSet ts;
  URL url = null;
  char dotype = 'e';
  public viewsamples(URL cb, char type)

  {
    super("view EDI Objects by URL");
    dotype = type;
    URL tURL;
    try {
      System.out.println(cb);
      if (type == 'x')
      tURL = new URL(cb + "rfq.xml");
      else
      if (type == 'u')
      tURL = new URL(cb + "orders");
      else
      tURL = new URL(cb + "sample.output.840.1");
      InputStream is = tURL.openStream();
      process(is);
      url = cb;
    }
    catch (Exception e1) {
      System.out.println(e1.getMessage());
      e1.printStackTrace();
      System.exit(0);
    }
  }

  public viewsamples(String inString, char type)
  //throws Exception
  {
    super("view EDI Objects by Input String");
    dotype = type;
    try {
      process(inString);
    }

    catch (Exception e1) {
      System.out.println(e1.getMessage());
      e1.printStackTrace();
      //throw e1;
    }
  }


  public viewsamples(FileInputStream is, char type)
  //throws Exception
  {
    super("view EDI Objects by File");
    dotype = type;
    try {
      process(is);
    }

    catch (Exception e1) {
      System.out.println(e1.getMessage());
      e1.printStackTrace();
      //throw e1;
    }
  }

  /**
   * <br>Class contains a main method to allow it to invoked as an application.
   * <br>format: java com.americancoders.edi.viewsamples filename [filetype]
   * <br>where filename is a EDI document
   * <br><ul>filetype
   * <li>'e'  for edi-x12
   * <li>'u' for un-edifact
   * <li>'x' for wellformed xml
   * <li> 'v' for valid xml
   * </ul>
   */

  public static void main(String args[])
  {
    char type = 'e'; // plain ol' x12
    try {  if (args.length > 1)
      { if (args[1].charAt(0) == 'x') // xml conversion
        type = 'x';
        else if (args[1].charAt(0) == 'v') // valid xml
        type = 'v';
        else if (args[1].charAt(0) == 'u') // EDIFact
        type = 'u';
      }

      FileInputStream fis = new FileInputStream(args[0]);
      viewsamples vs = new viewsamples(fis, type);
    }

    catch (Exception e1) {
      System.out.println(e1.getMessage());
      e1.printStackTrace();
      System.exit(0);
    }
  }


  public void process(String inString)
  throws Exception
  {
    setLayout(null);
    removeAll();
    addWindowListener(this);
    addComponentListener(this);
    gb = new GridBagLayout();
    gbc = new  GridBagConstraints();
    setLayout(gb);
    intext = new TextArea();
    intext.setText(inString);
    outtext = new TextArea();
    clear = new Button("Clear");
    clear.addActionListener(this);
    processfmt = new Button("Format");
    processxml = new Button("Well Formed XML");
    processvxml = new Button("Valid XML");
    processx12 = new Button("X12");
    processedifact = new Button("EDIFACT");
    processfmt.addActionListener(this);
    processxml.addActionListener(this);
    processvxml.addActionListener(this);
    processx12.addActionListener(this);
    processedifact.addActionListener(this);
    try {
      addComponent(this, intext, GridBagConstraints.RELATIVE,GridBagConstraints.RELATIVE, 45,75,  GridBagConstraints.BOTH, GridBagConstraints.CENTER);
      addComponent(this, processfmt, GridBagConstraints.RELATIVE, GridBagConstraints.RELATIVE, 10, 20, GridBagConstraints.BOTH, GridBagConstraints.CENTER);
      addComponent(this, processxml, GridBagConstraints.RELATIVE, 20, 10, 10, GridBagConstraints.BOTH, GridBagConstraints.CENTER);
      addComponent(this, processvxml, GridBagConstraints.RELATIVE, 30, 10, 10, GridBagConstraints.BOTH, GridBagConstraints.CENTER);
      addComponent(this, processx12, GridBagConstraints.RELATIVE, 40, 10, 10, GridBagConstraints.BOTH, GridBagConstraints.CENTER);
      addComponent(this, processedifact, GridBagConstraints.RELATIVE, 50, 10, 10, GridBagConstraints.BOTH, GridBagConstraints.CENTER);
      addComponent(this, clear, GridBagConstraints.RELATIVE, 60, 10, 10, GridBagConstraints.HORIZONTAL, GridBagConstraints.WEST);
      addComponent(this, outtext, GridBagConstraints.RELATIVE,GridBagConstraints.RELATIVE, 45,75,  GridBagConstraints.BOTH, GridBagConstraints.CENTER);
    }
    catch (Exception e1)
    {
      System.out.println(e1.getMessage());
      throw e1;
    }

    pack();
    show();
  }

  public void process(InputStream is)
  throws Exception
  {
    setLayout(null);
    removeAll();
    addWindowListener(this);
    addComponentListener(this);
    gb = new GridBagLayout();
    gbc = new  GridBagConstraints();
    setLayout(gb);
    intext = new TextArea();

    StringBuffer sb = new StringBuffer();

    BufferedReader br = new BufferedReader(new InputStreamReader(is));

    String s;
    try {
      while(true) {
        s = br.readLine();
        if (s == null)
          break;
		sb.append(s+'\n');
	  }
	}
	catch (EOFException e) {;}
    is.close();
    process(new String(sb));
  }

  public void windowClosing(WindowEvent event) {
    setVisible(false);
    dispose();
    if (url != null)
    System.exit(0);
  }


  public void windowClosed(WindowEvent event) {
  }

  public void windowDeiconified(WindowEvent event) {
  }

  public void windowIconified(WindowEvent event) {
  }

  public void windowActivated(WindowEvent event) {
  }

  public void windowDeactivated(WindowEvent event) {
  }

  public void windowOpened(WindowEvent event) {
  }

public void componentHidden(ComponentEvent Event) {}

public void componentMoved(ComponentEvent Event) {}

public void componentShown(ComponentEvent Event) {}

public void componentResized(ComponentEvent Event) {}

  public void actionPerformed(ActionEvent event)

  {

    com.americancoders.edi.x12.X12DocumentHandler p1;
    com.americancoders.edi.EDIFact.Parser p2;
    com.americancoders.edi.Envelope env;

    if ( (event.getSource() == processfmt) |
    (event.getSource() == processxml) |
    (event.getSource() == processvxml) |
    (event.getSource() == processx12) |
    (event.getSource() == processedifact) ) {
      try {

        if (dotype == 'x')
        {
          EDIXMLParser exp;
          if (url != null)
          {
            System.out.println("calling edixml parser with url " + url.toString());
            exp = new EDIXMLParser();
            exp.parse(url, intext.getText());
          }
          else {
            exp = new EDIXMLParser();
            exp.parse(intext.getText());
          }
          ts = exp.getEnvelope().getFunctionalGroup(0).getTransactionSet(0);
          ts.validate();
          String s = "string not set";
          if (event.getSource() == processfmt)
            s = ts.getFormattedText(0);
          if (event.getSource() == processxml)
            s = ts.getFormattedText(Envelope.XML_FORMAT);
          if (event.getSource() == processvxml)
            s = ts.getFormattedText(Envelope.VALID_XML_FORMAT);
          if (event.getSource() == processx12)
            s = ts.getFormattedText(Envelope.X12_FORMAT);
          if (event.getSource() == processedifact)
            s = ts.getFormattedText(Envelope.EDIFACT_FORMAT);
          outtext.setText(s);
        }
        else if (dotype == 'v') {
          ValidXMLEDIParser vxep;
          if (url != null)
          {
            System.out.println("calling validxmlediparser with url " + url.toString());
            vxep = new ValidXMLEDIParser();
          }
          else vxep = new ValidXMLEDIParser();
          vxep.parse(intext.getText());
          env = vxep.getEnvelope();
          env.validate();
          String s = "string not set";
          if (event.getSource() == processfmt)
            s = env.getFormattedText(0);
          if (event.getSource() == processxml)
            s = env.getFormattedText(Envelope.XML_FORMAT);
          if (event.getSource() == processvxml)
            s = env.getFormattedText(Envelope.VALID_XML_FORMAT);
          if (event.getSource() == processx12)
            s = env.getFormattedText(Envelope.X12_FORMAT);
          if (event.getSource() == processedifact)
            s = env.getFormattedText(Envelope.EDIFACT_FORMAT);
          outtext.setText(s);
        }
        else if (dotype == 'u') {
          if (url != null)
          {
            System.out.println("calling parser with url " + url.toString());
            p2 = new com.americancoders.edi.EDIFact.Parser(url, intext.getText());
          }
          else p2 = new com.americancoders.edi.EDIFact.Parser(intext.getText());
          env = p2.getEnvelope();
          env.validate();
          String s  = "string not set";
          if (event.getSource() == processfmt)
            s = env.getFormattedText(0);
          if (event.getSource() == processxml)
            s = env.getFormattedText(Envelope.XML_FORMAT);
          if (event.getSource() == processvxml)
            s = env.getFormattedText(Envelope.VALID_XML_FORMAT);
          if (event.getSource() == processx12)
            s = env.getFormattedText(Envelope.X12_FORMAT);
          if (event.getSource() == processedifact)
            s = env.getFormattedText(Envelope.EDIFACT_FORMAT);
          outtext.setText(s);
        }
        else {
          if (url != null)
          {
            System.out.println("calling parser with url " + url.toString());
            //p1 = new com.americancoders.edi.x12.X12DocumentHandlerParser(url, intext.getText());
          }
          //else
          p1 = new com.americancoders.edi.x12.X12DocumentHandler(intext.getText());
          env = p1.getEnvelope();
          env.validate();
          String s = "string not set";
          if (event.getSource() == processfmt)
            s = env.getFormattedText(0);
          if (event.getSource() == processxml)
            s = env.getFormattedText(Envelope.XML_FORMAT);
          if (event.getSource() == processvxml)
            s = env.getFormattedText(Envelope.VALID_XML_FORMAT);
          if (event.getSource() == processx12)
            s = env.getFormattedText(Envelope.X12_FORMAT);
          if (event.getSource() == processedifact)
            s = env.getFormattedText(Envelope.EDIFACT_FORMAT);
          outtext.setText(s);
        }

      }
      catch (Exception e1) {
        System.out.println(e1.getMessage());
        new displayMessage(this, e1.getMessage());
        e1.printStackTrace();
      }
      return;
    }
    if (event.getSource() == clear) {
      outtext.setText("");
      return;
    }
  }
  void gotResponse()
  {
    //setVisible(false);
    //dispose();
    //System.exit(1);
  }

  void addComponent (Container container, Component component,
  int gridx, int gridy, int gridwidth, int gridheight, int fill,
  int anchor) throws AWTException {
    LayoutManager lm = container.getLayout();
    if (!(lm instanceof GridBagLayout)) {
      throw new AWTException ("Invalid layout: " + lm);
    } else {
      GridBagConstraints gbc = new GridBagConstraints ();
      gbc.gridx = gridx;
      gbc.gridy = gridy;
      gbc.gridwidth = gridwidth;
      gbc.gridheight = gridheight;
      gbc.fill = fill;
      gbc.anchor = anchor;
      ((GridBagLayout)lm).setConstraints(component, gbc);
      container.add (component);
    }
  }
  public class displayMessage extends Frame
  implements ActionListener, WindowListener, ComponentListener

  {
    Panel p;
    GridBagLayout gb;
    GridBagConstraints gbc;
    String sb;
    TransactionSet ts;
    viewsamples parent;
    URL url;
    Label text1 = new Label();
    TextField text2 = new TextField();
    Button button1 = new Button();

    public displayMessage(viewsamples inFrame, String Message)
    {
      super("OBOE Message");
      parent = inFrame;
      setLayout(null);
      removeAll();
      addWindowListener(this);
      addComponentListener(this);
      setSize(430,270);
      text1.setText("See java console for exception condition and messages");
      add(text1);
      text1.setBounds(48,36,320,23);
      if (Message == null)
      text2.setText("Unknown exception");
      else
      text2.setText(Message);
      add(text2);
      text2.setBounds(48,84,328,25);
      text2.setEditable(false);
      setSize(430,270);
      button1.setLabel("Exit");
      add(button1);
      button1.setBackground(java.awt.Color.lightGray);
      button1.setBounds(144,144,130,18);
      button1.addActionListener(this);
      pack();
      show();
      setLayout(null);
      setSize(590,292);
      setTitle("Untitled");
    }

    public void windowClosing(WindowEvent event) {
      setVisible(false);
      dispose();
      parent.gotResponse();
    }


    public void windowClosed(WindowEvent event) {
    }

    public void windowDeiconified(WindowEvent event) {
    }

    public void windowIconified(WindowEvent event) {
    }

    public void windowActivated(WindowEvent event) {
    }

    public void windowDeactivated(WindowEvent event) {
    }

    public void windowOpened(WindowEvent event) {
    }

  public void componentHidden(ComponentEvent Event) {}

  public void componentMoved(ComponentEvent Event) {}

  public void componentShown(ComponentEvent Event) {}

  public void componentResized(ComponentEvent Event) {}

    public void actionPerformed(ActionEvent event)

    {
      if (event.getSource() == button1) {
        setVisible(false);
        dispose();
        parent.gotResponse();
        return;
      }
    }


  }

}