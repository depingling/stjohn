package com.americancoders.edi;

import java.io.IOException;
import java.io.PushbackInputStream;
import java.util.Vector;

import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.americancoders.util.Util;

/**
 *   class for all Composite Data Elements
 *
 *<P>OBOE - Open Business Objects for EDI
 *<p>Part of the OBOE Basic Extended Package
 *<br>An EDI and XML Translator Written In Java
 *<br>Copyright 1998-2007 - American Coders, LTD  - Raleigh NC USA
 *<br>All rights reserved
 *<br>American Coders, Ltd
 *<br>P. O. Box 97462
 *<br>Raleigh, NC  27624  USA
 *<br>1-919-846-2014
 *<br>http://www.americancoders.com
@author Joe McVerry - American Coders, Ltd.
  @version   3.5.3
 */

public class CompositeDE implements IDataElementContainer, IContainedObject
{

    /** an array of Field objects
     */
  protected Object deArray[];
    /** String of composite's xml tag
     */
  protected TemplateComposite myTemplate = null;

  /** cursor to current deArrayGroup
   */
  protected int cursor = -1;

  /** deArray group
   */
  protected Vector deArrayGroup = null;

  /** creates a compsosite using a templage
 * @param inTemplateComposite TemplateComposite used to build this composite
      * @param inParent owning Object
*/
  public CompositeDE(TemplateComposite inTemplateComposite, IContainedObject inParent)
  {
    deArray = new Object[inTemplateComposite.getTemplateDESize()];
    myTemplate = inTemplateComposite;
    setParent(inParent);

    if (getOccurs() > 1) {
       deArrayGroup = new Vector(getOccurs());
       deArrayGroup.add(deArray);
       cursor = 0;
    }
 }


  /**
   * returns the templateComposite object used to build this CompoisteDE
   *
   * @return TemplateComposite
   */
  public TemplateComposite getTemplate()
   { return myTemplate;}


  /** defines a dataelement by the predefined templateDE array
 * @param pos field to build is identified by its templates position
 * <br><b>position is relative to 1.</b>
 * @return Object always a DataElement, I used Object to keep it consistent with what
 * Segments buildDE returns.
 */
  public Object buildDE(int pos)
  {


    if (myTemplate.isTemplateDE(pos) == false)
      return null;


    TemplateDE tde;
    tde = myTemplate.getTemplateDE(pos);


    switch (tde.getType().charAt(0))
    {
      case 'A':
      if (tde.getIDList()!= null)
      deArray[pos-1] = new IDDE(tde, this);
      else
      deArray[pos-1] = new CharDE(tde, this);
      break;
      case 'C':
      if (tde.getIDList()!= null)
      deArray[pos-1] = new IDDE(tde, this);
      else
      deArray[pos-1] = new CharDE(tde, this);
      break;
      case 'I':
      deArray[pos-1] = new IDDE(tde, this);
      break;
      case 'D':
      deArray[pos-1] = new DateDE(tde, this);
      break;
      case 'T':
      deArray[pos-1] = new TimeDE(tde, this);
      break;
      case 'N':
      deArray[pos-1] = new NumericDE(tde, this);
      break;
      case 'R':
      deArray[pos-1] = new RealDE(tde, this);
      break;
      default:
      throw new OBOEException("Unknown dataElement type");
    }
    return deArray[pos-1];
  }

  /**
   * creates a new dearray set for multi-occuring composites
   * @return Object[]
   * @throws OBOEException
   */
  public Object[] createNewGroup() throws OBOEException
  {
	if (getOccurs() == 1)
	  throw new OBOEException("Method not valid for single occuring composite.");

	cursor++;
	if (cursor > getOccurs())
	  throw new OBOEException("deArrayGroup size exceeded.");

	deArray = new Object[getTemplate().getTemplateDESize()];

	deArrayGroup.add(deArray);


    return (Object[]) deArray.clone();
  }

  /**
   * moves the cursor to a dearraygroup and resets the group.
   * <br>offset by 1
   * @param inPos
   * @return int offset in vector
   * @throws OBOEException
   */
  public int gotoGroup(int inPos) throws OBOEException{
  	if (getOccurs() == 1)
  	  throw new OBOEException("Method not valid for single occuring composite.");
	if (inPos < 1)
		throw new OBOEException("inPos too small.");
	if (inPos > deArrayGroup.size())
		throw new OBOEException("inPos too large for number of groups.");
  	cursor = inPos-1;
  	deArray = (Object[]) deArrayGroup.get(cursor);
  	return cursor;
  }

/**
 * moves the cursor to the first deArray and sets the deArray
 * @return int always zero
 * @throws OBOEException
 */
  public int resetCursor() throws OBOEException
  {
	if (getOccurs() == 1)
	  throw new OBOEException("Method not valid for single occuring composite.");
    cursor = 0;
	deArray = (Object[]) deArrayGroup.get(cursor);
  	return 0;

  }
  /**
   * returns number of elements in deArrayGroup
   * @return int
   */
  public int getDEArrayCount()  throws OBOEException
  {
	if (getOccurs() == 1)
	  throw new OBOEException("Method not valid for single occuring composite.");
  	return deArrayGroup.size();
  }

/**
 * moves the cursor to the next group
 * @return Object[], null if at end of group
 * @throws OBOEException
 */
  public Object[] nextGroup() throws OBOEException
  {
	if (getOccurs() == 1)
	  throw new OBOEException("Method not valid for single occuring composite.");

	cursor++;

	if (cursor >= deArrayGroup.size())
	   return null;

	deArray = (Object[]) deArrayGroup.get(cursor);
	return (Object[]) deArray.clone();
  }

  /**
   * returns the id field
   * @return String id value
   */


  public String getID()  { return myTemplate.getID();}

  /**
   * returns the name field
   * @return String name value
   */


  public String getName() { return myTemplate.getName(); }

  /**
   * returns the xml tag field
   * @return String tag value
   */


  public String getXMLTag() { return myTemplate.getXMLTag(); }


  /** 
   * returns boolean indicating if composite is used
   * @return boolean
   * 
   */
  
  public boolean isUsed() { return myTemplate.isUsed();}
  
  /**
   * returns the required indicator
   * @return char
   */

public char getRequired() {return myTemplate.getRequired(); }


  /**
   * returns the sequence
   * @return int
   */

public int getSequence() {return myTemplate.getSequence(); }

/**
 * returns the occurs value
 * @return int
 */
public int getOccurs() { return myTemplate.getOccurs();

}

  /**
   * returns the number of defined data element
   * @return int DataElement count
   */

public int  getDataElementSize() { return deArray.length; }


  /** returns a data element by its id
 * @return DataElement
 * @param inID String  id of dataelement to return
 */

  public DataElement getDataElement(String inID)
  {
    int i;
    DataElement currentDE = null;

    for (i=0; i < deArray.length; i++)
    {
      currentDE = (DataElement) deArray[i];
      if (currentDE == null) continue;
      if (currentDE.getID().compareTo(inID) == 0)
         return currentDE;
    }
    return null;
  }

  /** returns a data element by its location
 * @return DataElement
 * @param inPos int  position of data element to return
 * <br><b>position is relative to 1.</b>
 */

  public DataElement getDataElement(int inPos)
  {
    if (inPos == 0) return null;
    if (inPos > deArray.length) return null;
    if (isDataElement(inPos)) return (DataElement) deArray[inPos-1];
    return null;

  }

    /** returns a boolean if vector position held by a data element
     * @return boolean
     * @param inPos is object in the array a dataelement
     * <br><b>position is relative to 1.</b>
     */

    public boolean isDataElement(int inPos)
    {

        if (inPos ==0) return false;
        if (inPos > deArray.length)  return false;
        return (deArray[inPos-1] instanceof com.americancoders.edi.DataElement);
    }

  /** parsing logic for compositeDE
 * @param TransactionTokenizedString
 * @throws OBOEException most likely the composite item can't find any of the fields coming in.
 * @return boolean true if tokenizedstring was used
 */

  public boolean parse(ITokenizer TransactionTokenizedString)
  throws OBOEException
  {
    int i;
    int elementsToParse;

    DataElement currentDE;

    IDataTokenizer dt = TransactionTokenizedString.makeSubfieldTokenizer();

    elementsToParse = dt.countTokens();
    for (i=0;    (i < elementsToParse);    i++)
    {
      if (myTemplate != null  && i >= myTemplate.getTemplateDESize())
         return false;
      if (i >= deArray.length || deArray[i] == null)
         buildDE(i+1);
      currentDE = (DataElement) deArray[i];
      if (currentDE!= null)
         try {
			currentDE.set(Util.unEscape(dt.nextToken(),TransactionTokenizedString.getEscapeCharacters()));
             }
         catch (Exception exc)
             {
              TransactionTokenizedString.reportError("Parsing Error: "+exc.getMessage());
             }
      else dt.nextToken(); // skip unused data
    }
    return true;
  }


  /** parsing logic for compositeDE for repeating composites
 * @param TokenizedString String partially tokenized
 * @param TransactionTokenizedString ITokenizer - parent of DataTokenizer
 * @throws OBOEException most likely the composite item can't find any of the fields coming in.
 * @return boolean true if tokenizedstring was used
 */

  public boolean parse(String TokenizedString, ITokenizer TransactionTokenizedString)
  throws OBOEException
  {
	int i;
	int elementsToParse;

	DataElement currentDE;


	DataTokenizer dt = new DataTokenizer(TokenizedString, TransactionTokenizedString.getElementSeparator(), TransactionTokenizedString.getEscapeCharacters());

	elementsToParse = dt.countTokens();
	for (i=0;  i < elementsToParse;    i++)
	{
	  if (myTemplate != null  && i >= myTemplate.getTemplateDESize())
		 return false;
	  if (i >= deArray.length || deArray[i] == null)
		 buildDE(i+1);
	  currentDE = (DataElement) deArray[i];
	  if (currentDE!= null)
		 try {
			if (currentDE.getOccurs() > 1) {
			 	DataTokenizer dt2 = new DataTokenizer(TransactionTokenizedString.getCurrentDataElement(),
			 											TransactionTokenizedString.getRepeaterCharacter(),
			 											TransactionTokenizedString.getEscapeCharacters());
			 	for (int dti = 0; dti < dt2.countTokens(); dti++){
				 currentDE.setNext(dt2.getTokenAt(dti));
			 	}
			}
			else {
			currentDE.set(Util.unEscape(dt.nextToken(),TransactionTokenizedString.getEscapeCharacters()));
			}
			 }
		 catch (Exception exc)
			 {
			  TransactionTokenizedString.reportError("Parsing Error: "+exc.getMessage());
			 }
	  else dt.nextToken(); // skip unused data
	}
	return true;
  }

    /** parses a Fixed Length EDI Document
     * adds to datalement vector or compositeDE
     * and adds to secondary segment vector
     * @param pis PushbackInputStream
     * @throws OBOEException as thrown
     */

    public void parse(PushbackInputStream pis)
    throws OBOEException, IOException
      {
        int i=0;

        DataElement currentDE;

        for (i=0; i < myTemplate.getTemplateDESize(); i++)
        {
                if (myTemplate.getTemplateDE(i+1) == null)
                  continue;
                byte me[] = new byte[myTemplate.getTemplateDE(i+1).getMaxLength()];
                pis.read(me);
                if (me[0] == 0)
                  continue;
                String s = Util.rightTrim(new String(me));
                buildDE(i+1);
                currentDE = (DataElement) deArray[i];
                StringBuffer sb = new StringBuffer(s);
                if (currentDE.getRequired()=='M')
                  {
                     for (int j = s.length(); j < currentDE.getMinLength(); j++)
                        sb.append(' ');
                     s=new String(sb);
                  }
                else
                if (s.length() > 0)
                  {
                     for (int j = s.length(); j < currentDE.getMinLength(); j++)
                        sb.append(' ');
                     s=new String(sb);
                  }
			if (currentDE.getOccurs() > 1)
				 currentDE.setNext(s);
			else
				currentDE.set(s);

        }


    }





  /** parses a XML EDI Document
 * adds to datalement vector
 * @param node Node
 * @throws OBOEException Node is unknown to composite
 */

  public void parse(Node node)
  throws OBOEException
  {
    int i, n, cn;

    NodeList nl = node.getChildNodes();
    NodeList cnl;
    DataElement currentDE;
    Node currentNode;

    Node cnode;
    int lastDETested = -1;
    nodeLoop: for (n = 0; n < nl.getLength(); n++)
    {
      currentNode = nl.item(n);
      if (currentNode.getNodeType() != Node.ELEMENT_NODE)  continue nodeLoop;
      cnl = currentNode.getChildNodes();
      if (myTemplate != null)
          i = myTemplate.doYouUseThisXMLElement(currentNode.getNodeName(), lastDETested);
      else
          i = doIUseThisXMLElement(currentNode.getNodeName(), lastDETested);
      if (i < 0)
      throw new OBOEException("Unknown node found " +  currentNode.getNodeName());
      if (myTemplate != null && i > lastDETested)
      {
        for (cn = lastDETested+1; cn <= i; cn++)
		currentDE = (DataElement) buildDE(cn+1);
   		//currentDE.set("");
      }
      lastDETested = i;
      currentDE = (DataElement) deArray[i];
      if (currentDE.getXMLTag().compareTo(currentNode.getNodeName()) == 0)
      {
        if (cnl.getLength() == 0)
        {
            currentDE.set("");
        }
        else
        for (int nn = 0; nn < cnl.getLength(); nn++)
        {
          cnode = cnl.item(nn);
          if (cnode.getNodeType() == Node.TEXT_NODE)
		  if (currentDE instanceof NumericDE)
			  ((NumericDE) currentDE).setFormatted(cnode.getNodeValue());
		  else
		  if (currentDE.getOccurs() > 1)
     		  currentDE.setNext(cnode.getNodeValue());
		  else
			  currentDE.set(cnode.getNodeValue());
           }
        if (currentDE.getOccurs() > 1)
           lastDETested--;
        continue nodeLoop;
      }
    }
  }


  /**
   * returns all the data associated
   * <br>field values separated by '*'
   * @return String for all DataElements
   */
  public String get()
  {
    if (deArray == null) return "";
    int i;
    StringBuffer sbGet = new StringBuffer();
    DataElement de;
    for (i = 0; i < deArray.length; i++)
    {
      if (deArray[i]==null)
        continue;
      de = (DataElement)deArray[i];
      if (de.get() == null) break;
      if (i>0)
         sbGet.append(':');
      sbGet.append(de.get());
    }
    return new String(sbGet);
  }

  /** returns the length of the data in the data elements
   * @return int
   */
  public int getDataElementLength()
    {
		if (deArray == null) return 0;

		 int i;
		 int len = 0;

		 DataElement de;
		 for (i = 0; i < deArray.length; i++)
		 {
		   if (deArray[i]==null)
			 continue;
		   de = (DataElement)deArray[i];
		   if (de.get() == null) continue;
		   len += de.getLength();
		 }
		 return len;
    }


  /** returns the formatted text
 * @param formatType x12, edifact...
 * @return String of formatted text
 */

  public String getFormattedText(int formatType)
  {

    if (deArray==null)
     if (formatType == Envelope.X12_FORMAT || formatType == Envelope.EDIFACT_FORMAT || formatType == Envelope.TRADACOMS_FORMAT)
      return "";

	if (getOccurs() > 1)
	   this.resetCursor();

    int i;
	StringBuffer sbFormattedText = new StringBuffer();

    for (int ii=0; ii < getOccurs(); ii++)
    {

    DataElement currentDE;

    switch (formatType)
    {
      case Envelope.CSV_FORMAT:
        sbFormattedText.append("Composite DE,"+getID()+","+getName()+"\""+com.americancoders.util.Util.lineFeed);
        break;
      case Envelope.XML_FORMAT:
      if (getXMLTag() != null)
      sbFormattedText.append('<' +  getXMLTag() + ">"+com.americancoders.util.Util.lineFeed);
      else
      sbFormattedText.append('<' +  getID() + ">"+com.americancoders.util.Util.lineFeed);
      break;
      case Envelope.VALID_XML_FORMAT:
	  case Envelope.VALID_XML_FORMAT_WITH_POSITION:
	      sbFormattedText.append("<composite code=\""+getID()+"\"");
		  sbFormattedText.append(" name=\"" + getName() + "\"");
		  if (formatType == Envelope.VALID_XML_FORMAT_WITH_POSITION)
			  sbFormattedText.append(" docPosition=\""+this.getSequence() + "\"");
		  sbFormattedText.append(">"+com.americancoders.util.Util.lineFeed);
	      break;
	  case Envelope.PIXES_FORMAT:
	      sbFormattedText.append("<composite position=\""+getSequence()+"\">"+com.americancoders.util.Util.lineFeed);
	      break;
      case Envelope.X12_FORMAT:
      break;
	  case Envelope.EDIFACT_FORMAT:
	  break;
	  case Envelope.TRADACOMS_FORMAT:
	  break;
      default:
      sbFormattedText.append(getID() + ": ");
    }

    i = -1;

    if (deArray != null)
      for (i=deArray.length-1; i>-1; i--)
        {
          if (deArray[i] == null)
            continue;
          if (getDataElement(i+1).get() != null)
               break;

      }
    int elementsUsed = i;

    for (i=0; i < elementsUsed+1; i++)

    {
      currentDE = (DataElement) deArray[i];
      if (currentDE == null || currentDE.get() == null)
         ;
      else
        sbFormattedText.append(currentDE.getFormattedText(formatType));
      if (i < elementsUsed) {

       switch (formatType) {
        case Envelope.X12_FORMAT:
        
        sbFormattedText.append(getDelimiter(Envelope.X12_GROUP_DELIMITER.charAt(0)));
        break;
		case  Envelope.EDIFACT_FORMAT:
		sbFormattedText.append(getDelimiter(Envelope.EDIFact_GROUP_DELIMITER.charAt(0)));
		break;
		case  Envelope.TRADACOMS_FORMAT:
		sbFormattedText.append(getDelimiter(Envelope.TRADACOMS_GROUP_DELIMITER.charAt(0)));
		break;
       }
      }

    }

    switch (formatType)
    {
      case Envelope.XML_FORMAT:
      if (getXMLTag() != null)
        sbFormattedText.append("</" +  getXMLTag() + ">"+com.americancoders.util.Util.lineFeed);
      else
        sbFormattedText.append("</" +  getID() + ">"+com.americancoders.util.Util.lineFeed);
      break;
	  case Envelope.VALID_XML_FORMAT:
	  case Envelope.VALID_XML_FORMAT_WITH_POSITION:
	  case Envelope.PIXES_FORMAT:
        sbFormattedText.append("</composite>"+com.americancoders.util.Util.lineFeed);
      break;
      case Envelope.X12_FORMAT:
      break;
      case Envelope.EDIFACT_FORMAT:
      break;
      default:
      break;
    }
    if (getOccurs() > 1)
      {
      	if (this.nextGroup() == null)
      	  break;
		if (ii < this.getDEArrayCount())
		switch (formatType) {
		 case Envelope.X12_FORMAT:
		 sbFormattedText.append(getDelimiter(Envelope.X12_REPEAT_DELIMITER.charAt(0)));
		 break;
		 case  Envelope.EDIFACT_FORMAT:
		 sbFormattedText.append(getDelimiter(Envelope.EDIFact_REPEAT_DELIMITER.charAt(0)));
		 break;
		}

      }
	}

    return new String(sbFormattedText);


  }

    /** returns error responses of contents
     * @param inDErr DocumentErrors
     */
    public void validate(DocumentErrors inDErr)
    {

        if (getOccurs() > 1 ){
           this.resetCursor();

        }
        
  
        int deUseCount = 0;
		for (int ii=0; ii < getOccurs(); ii++)
		{

        for (int i = 0; i < deArray.length; i++) {
                if (myTemplate.isTemplateDE(i + 1)) {
                    if ((getDataElement(i + 1) != null)
                            && (getDataElement(i + 1).getLength() > 0))
                        deUseCount++;

                }
            }

			if (getOccurs() > 1)
			   {
				 if (nextGroup() == null)
				   break;
			   }
    	}

        if (getRequired()!='M' &&   deUseCount == 0) // nothing to show (EDIFACT only)
        {

         return;
       }
      
    	if (isUsed() == false) {
              inDErr.addError(0, getID(), "field is not used, see " +getName() + " at position " + getSequence(),  getParent(), "10", this, 2);
              return;
    	}
        


		for (int ii=0; ii < getOccurs(); ii++)
		{
        for (int i=0; i < deArray.length; i++)
            {
                if (myTemplate.isTemplateDE(i+1))
                if ( (myTemplate.getTemplateDE(i+1).getRequired() == 'M') )

                 {
                    if (getDataElement(i+1) == null)
                      inDErr.addError(i, getID(), "Missing required data element "+myTemplate.getTemplateDE(i+1).getID()+" at position " + myTemplate.getTemplateDE(i+1).getSequence(), parent, "1", this, 1);
                    else
                    if (getDataElement(i+1).getLength() == 0)
                      inDErr.addError(i, getID(), "Missing required data element "+myTemplate.getTemplateDE(i+1).getID()+" at position " + myTemplate.getTemplateDE(i+1).getSequence(), parent, "1", this, 1);
                    else
                      getDataElement(i+1).validate(inDErr);
                 }
                else
                if ( (getDataElement(i+1) != null)
                  && (getDataElement(i+1).getLength() > 0) )
                    getDataElement(i+1).validate(inDErr);
            }

			if (getOccurs() > 1)
			   {
				 if (nextGroup() == null)
				   break;
			   }
		}

    }

    /** removes empty trailing data elements and returns the number of used dataelements
     * @return int
     */

    public int trim()
    {
        int i;
        DataElement currentDE = null;

        for (i=deArray.length-1; i > -1; i--)
        {
              currentDE = (DataElement) deArray[i];
              if (currentDE.getLength() > 0)
                 return i+1;
              deArray[i] = null;
        }
        return i+1;
    }
    /** routine to ask if it uses a dataelement
     * @return boolen true the segment id is part of this group
     * @param inTag String id
     * @param startAt int position to start at
     */
    public int doIUseThisXMLElement(String inTag, int startAt)
    {
        DataElement de;
        CompositeDE cde;

        for (int i=startAt+1; i<deArray.length; i++)
         {  if (deArray[i] instanceof DataElement)
            {
                de = (DataElement) deArray[i];
                if ( de.getXMLTag().compareTo(inTag) == 0)
                    return i;
            }
            else
            {
                cde = (CompositeDE) deArray[i];
                if ( cde.getXMLTag().compareTo(inTag) == 0)
                    return i;
            }
         }
        return -1;

    }

  /**
    owning object
    */

  protected IContainedObject parent=null;

    /** sets parent attribute
     * @param inParent TemplateSegmentContainer
     */
    public void setParent(IContainedObject inParent) {parent = inParent;}

    /** gets parent attribute
     * @return TemplateSegmentContainer
     */
    public IContainedObject  getParent() { return parent;}

    /**
     * gets the text formatted to maximum length of fields
     * @return String
     */
    public String getFixedLengthFormattedText()
    {
        StringBuffer sb = new StringBuffer();
        for (int i=0; i<deArray.length; i++)
         {
          if (deArray[i] == null)
            {
              if (getTemplate().isTemplateDE(i+1))
                {
                    sb.append(getTemplate().getTemplateDE(i+1).getEmptyData());
                }
            }
          else  if (deArray[i] instanceof DataElement)
            {
            if (getDataElement(i+1).getLength()==0)
               sb.append(getTemplate().getTemplateDE(i+1).getEmptyData());
            else
                sb.append(getDataElement(i+1).getFixedLengthFormattedText());
            }
          else if (deArray[i] instanceof CompositeDE)
            {
                CompositeDE cde = (CompositeDE) deArray[i];
                sb.append(cde.getFixedLengthFormattedText());
            }
         }
        return new String(sb);

    }

    /**
     * the toString method
     */
   public String toString()
   {
   	 return "composite  id:" + getID() + " name:" + getName() + " seq: " + getSequence();  	 		
   	 	
   }

   /* (non-Javadoc)
    * @see com.americancoders.edi.IContainedObject#getDelimiter(char)
    */

   	public char getDelimiter(char inOriginal) {
   		
   		if (parent == null)  // for junit tests
   			return inOriginal; 
   		return parent.getDelimiter(inOriginal);
   	}


}
