package com.americancoders.edi;


/**
 *OBOE - Open Business Objects for EDI
 *<p>Copyright 1998-2007 - American Coders, LTD  - Raleigh NC USA
 *<p>All rights reserved
 *<p>American Coders, Ltd
 *<br>P. O. Box 97462
 *<br>Raleigh, NC  27624  USA
 *<br>1-919-846-2014
 *<br>http://www.americancoders.com
@author Joe McVerry - American Coders, Ltd.
  @version   3.5.3
 */


import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.io.Writer;
import java.util.Vector;

/**
 * class for container Functional_Group
 *
 */
public abstract class  FunctionalGroup extends SegmentContainer implements Externalizable, IContainedObject, ISegmentContainer 
 
{
  String  headerId;
  String trailerId;

  protected Vector transactionSets = new Vector();
  
  protected TemplateFunctionalGroup myTemplate = null;

  /** instantiates a functional group
   */

   public FunctionalGroup(TemplateFunctionalGroup inTFG, IContainedObject inParent, String inHeaderID, String inTrailerID)
   {
    myTemplate = inTFG;
    setParent(inParent);
    myTemplateContainer = myTemplate;
    headerId = inHeaderID;
    trailerId = inTrailerID;

   }

public void setHeaderId(String headerId) {
	this.headerId = headerId;
}
public void setTrailerId(String trailerId) {
	this.trailerId = trailerId;
}
  /** add a transaction set to the vector (container)
   *  @param inTransactionSet
   *  @exception used for X12FunctionalGroup
   */
  public void addTransactionSet(TransactionSet inTransactionSet)
  throws OBOEException
  {
	  transactionSets.addElement(inTransactionSet);
	  inTransactionSet.setParent(this);
	  
  }


  /** get transaction set count
   *  @return int
   */
  public int getTransactionSetCount() {return transactionSets.size();}

  /** get a transaction set from the vector
   * <br> can throw runtime exception array out of bounds
   * @param pos position in vector
   * @return TransactionSet
   */

  public TransactionSet getTransactionSet(int pos) {return (TransactionSet)transactionSets.elementAt(pos);}

  /** get the transaction set vector
   * @return Vector of transaction sets
   */
  public Vector getTransactionSets() {return transactionSets;}

  /** helper routine to get header segment
   * 
   * 
   * @return segment
   */
  
  public Segment getHeader()
  { return getSegment(headerId);   }

  /** helper routine to get trailer segment 
   * 
   * 
   * @return segment
   */
  
  public  Segment getTrailer()
  { return getSegment(trailerId);   }


  /**
   * returns the EDI (EDIFact) formatted document in a String
   * @param format int - format type see TransactionSet
   * @return String the formatted document
   *
   *  */

public String getFormattedText(int format)
  {


    StringBuffer sb = new StringBuffer();
    if (format == Envelope.CSV_FORMAT)
       sb.append("Functional Group"+com.americancoders.util.Util.lineFeed);
    else
    	  if (format == Envelope.VALID_XML_FORMAT || format == Envelope.VALID_XML_FORMAT_WITH_POSITION
    	     || format == Envelope.PIXES_FORMAT) {
    	    	            sb.append("<functionalgroup>"+com.americancoders.util.Util.lineFeed);
    }

    Segment seg = getSegment(headerId);
    if (seg != null)
       sb.append(seg.getFormattedText(format));



    int i;
    TransactionSet ts;
    for (i=0; i < getTransactionSetCount(); i++)
    {
      ts = (TransactionSet) getTransactionSet(i);
      sb.append(ts.getFormattedText(format));
    }

    seg = getSegment(trailerId);
    if (seg != null)
      sb.append(seg.getFormattedText(format));

	if (format == Envelope.VALID_XML_FORMAT 
		|| format == Envelope.VALID_XML_FORMAT_WITH_POSITION
		|| format == Envelope.PIXES_FORMAT) {
            sb.append("</functionalgroup>"+com.americancoders.util.Util.lineFeed);
    }

    return new String(sb);
  }
  
  /** like getFormattedText; writes to a Writer object instead
   * of building a string.
   * @param inWriter writer - object written to
   * @param format int - format type see TransactionSet
   * @exception OBOEException
   * @exception IOException
   */

public void writeFormattedText(Writer inWriter, int format) throws IOException
  {	
	if (format == Envelope.CSV_FORMAT)
	   inWriter.write("Functional Group"+com.americancoders.util.Util.lineFeed);
	else
		if (format == Envelope.VALID_XML_FORMAT || format == Envelope.VALID_XML_FORMAT_WITH_POSITION
				|| format == Envelope.PIXES_FORMAT) {
			inWriter.write("<functionalgroup>"+com.americancoders.util.Util.lineFeed);
	}

	Segment seg = getSegment(headerId);
	if (seg != null)
	   inWriter.write(seg.getFormattedText(format));



	int i;
	TransactionSet ts;
	for (i=0; i < getTransactionSetCount(); i++)
	{
	  ts = (TransactionSet) getTransactionSet(i);
	  ts.writeFormattedText(inWriter, format);
	}

	seg = getSegment(trailerId);
	if (seg != null)
		inWriter.write(seg.getFormattedText(format));
	
	if (format == Envelope.VALID_XML_FORMAT || format == Envelope.VALID_XML_FORMAT_WITH_POSITION
			|| format == Envelope.PIXES_FORMAT) {
			inWriter.write("</functionalgroup>"+com.americancoders.util.Util.lineFeed);
	}
	
	inWriter.flush();


  }

   /**
   * validates
   * @exception OBOEException indicates why envelope is invalid
   */

   public void validate()
    throws OBOEException
    {
   	 Segment seg = getSegment(headerId);
     if (seg != null)
     	
         seg.validate();
    int i;
    TransactionSet ts;
    for (i=0; i < getTransactionSetCount(); i++)
      {
        ts = (TransactionSet) getTransactionSet(i);
        ts.validate();
      }
    
    seg = getSegment(trailerId);
    if (seg != null)
       seg.validate();
    }

   /**
   * validates
   * <br> doesn't throw exception but placess error message in DocumentErrors object
   */

   public void validate(DocumentErrors inDErr)
   {
   	 Segment seg = getSegment(headerId);
     if (seg != null)
         seg.validate(inDErr);
    int i;
    TransactionSet ts;
    if (getTransactionSetCount() == 0)
      inDErr.addError(0, "FG", "No transaction sets", this, "5", this, 1);
    else
    for (i=0; i < getTransactionSetCount(); i++)
      {
        ts = (TransactionSet) getTransactionSet(i);
        ts.validate(inDErr);
      }
    seg = getSegment(trailerId);
    if (seg != null)
       seg.validate(inDErr);

   }


   /** used by externalize methods
     * @param in ObjectInput stream
     * @exception IOException - most likely class changed since written
     * @exception ClassNotFoundException - only when dummy constructro not found
     */

    public void readExternal(ObjectInput in)
    throws IOException, ClassNotFoundException
    {
        addSegment((Segment) in.readObject());
        int vectorSize = in.readInt();
        int i;
        for (i = 0; i < vectorSize; i++)
           transactionSets.addElement(in.readObject());
        addSegment((Segment) in.readObject());
    }

   /** used by externalize methods
     * @param out ObjectOutput stream
     * @exception IOException java.io error
     */
    public void writeExternal(ObjectOutput out)
    throws IOException
    {
        out.writeObject(getSegment(headerId));
        out.writeInt(transactionSets.size());
        for (int i = 0 ; i < transactionSets.size(); i++)
            out.writeObject(transactionSets.elementAt(i));
        out.writeObject(getSegment(trailerId));
    }

  /** set the Transaction Count in the trailer object
   */
  public abstract void setCountInTrailer() throws OBOEException;

   /** method of SegmentContainer interface
    * <br> Functional Group's segments built from instance methods
    * so we return a null and hope the call can figure it out
    * @param inID - template segment to get
    * @return TemplateSegment - in this case a null
    */
    public TemplateSegment getTemplateSegment(String inID)

    { return null; }

  public FunctionalGroup() {}

   /** returns the ID which is "envelope".
    * <br> required for SegmentContainer interface
    */

  public String getID() {return "envelope";}


    protected IContainedObject parent=null;
    /** sets parent attribute
     * @param inParent TemplateSegmentContainer
     */
    public void setParent(IContainedObject inParent) {parent = inParent;}

    /** gets parent attribute
     * @return TemplateSegmentContainer
     */
    public IContainedObject  getParent() { return parent;}

  public String getXMLTag() {return "FunctionalGroup";}
  
  /**
   * the toString method
   */
 public String toString()
 {
 	 return "functional group  format:"+ getID() + " id:" + getID(); 
 	 		
 }

 public int trim()
 {
     int cnt = super.trim();
     for (int i = 0; i < this.getTransactionSetCount(); i++)
         cnt += this.getTransactionSet(i).trim();
     return cnt;
 }

}
