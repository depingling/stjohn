package com.americancoders.edi;

/**
 * Contained Object Interface
 *<p>defines basic contained object methods
 *<P>OBOE - Open Business Objects for EDI
 *<p>Part of the OBOE Basic Extended Package
 *<br>An EDI and XML Translator Written In Java
 *<br>Copyright 1998-2007 - American Coders, LTD  - Raleigh NC USA
 *<br>All rights reserved
 *<br>American Coders, Ltd
 *<br>P. O. Box 97462
 *<br>Raleigh, NC  27624  USA
 *<br>1-919-846-2014
 *<br>http://www.americancoders.com
@author Joe McVerry - American Coders, Ltd.
  @version   3.5.3
 */

public interface IContainedObject extends IIdentifier {


	   /** sets parent attribute
		* @param inParent IContainedObject
		*/
	   public void setParent(IContainedObject inParent);

	   /** gets parent attribute
		* @return IContainedObject
		*/
	   public IContainedObject  getParent();

	   
	   /**
	    * returns the new delimiter based on the old delimiter
	    * @param inOldDelimiter
	    * @return newDelimiter character
	    */
	   public char getDelimiter(char inOldDelimiter);


}
