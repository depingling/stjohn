/*
 * Copyright (C) 2006-2007 by Joseph McVerry - American Coders, Ltd.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

package org.pixes;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.io.Writer;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.xml.sax.Attributes;



/**
 * @author Joe McVerry - American Coders, Ltd.
 *
 * executor object to do file connections
 * <br> using the java buffer file objects
 * <br> this process can do either in or out files but not in/out.
 *
 */
public class BufferedFile extends Executable {


	/** debuging level */
	Level dbgLvl;



	/** file associated with tag */
    String fileName;
    /* in or out */
    String mode;
    /* refid in xml */
    String id;
    /** file assocated with tag */
    java.io.File file;


    /** instatiator
     *
     * @param line - xml file line number
     * @param attr - xml attributes
     * @param parser - who's in charge
     * @throws PIXESException - probably an i/o error
     */
	public BufferedFile(int line, Attributes attr, Parser parser) throws PIXESException {

    	super(parser);

        logr = Logger.getLogger(BufferedFile.class);
        setLogger();

		dbgLvl = prsr.logr.getLevel();
        logr.setLevel(dbgLvl);
		logr.debug("file constructor " + attr + " " + line);
		setMyXMLLine(line);

		fileName = attr.getValue("fileName");
		if (fileName == null || fileName.length() == 0)
			throw new PIXESException("missing fileName attribute; see line "+line);
		mode = attr.getValue("mode");
		if (mode == null)
			throw new PIXESException("missing node attribute; see line "+line);

		if (mode.compareTo("r")==0)
			;
		else if (mode.compareTo("w")==0)
			;
		else if (mode.compareTo("w+")==0)
			;
		else throw new PIXESException("invalid node attribute value. \""+mode+"\"; see line "+line);
		id = attr.getValue("id");
		if (id == null || id.length() == 0)
    		throw new PIXESException("missing id attribute; see line "+line);

	}


	/* reader object, when used with mode = in */
	BufferedReader br = null;
	/* writer object, when used with mode = out */
	BufferedWriter bw = null;

	/*
	 * execute the code and return the next line number
	 * (non-Javadoc)
	 * @see org.pixes.Executable#execute()
	 */
	public int execute(Executor inExec)
	{
		logr.setLevel(dbgLvl);
   		logr.debug("execute call");
		file = new java.io.File(fileName);

		if (mode.compareTo("r")==0)
			{
			   if (file.exists() == false) {
				   logr.error("can't find file "+fileName + "; see line "+getMyXMLLine());
				   return -1;
			   }
			   try {
				br = new BufferedReader(new FileReader(file));
			} catch (FileNotFoundException e) {
				logr.error(e.getMessage() + "; see line "+getMyXMLLine());
				return -1;

			}
			}
		else if (mode.startsWith("w"))  // can be w or w+
		{
			try {
				bw = new BufferedWriter(new FileWriter(file, mode.endsWith("+")));
			} catch (IOException e) {
				logr.error(e.getMessage() + "; see line "+getMyXMLLine());
				return -1;
			}
		}




		return getNextStep();

	}

	/** return ref id
	 *
	 * @return refid
	 */
	protected String getID() { return id;}

	/** return buffered reader
	 *
	 * @return Reader object
	 */
	protected Reader getReader() { return br; }
	/**
	 * returns Writer object
	 * @return Writer
	 */
	protected Writer getWriter() { return bw; }

}
