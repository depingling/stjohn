/*
 * Copyright (C) 2006-2007 by Joseph McVerry - American Coders, Ltd.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */


package org.pixes;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;


/**
 * @author Joe McVerry - American Coders, Ltd.
 *
 * subclass this class when you want to add your own pixes nodes
 *
 */

public class SecondaryParsexecutor {


	static Logger logr = Logger.getLogger(SecondaryParsexecutor.class);

	static 	{Util.isLog4JNotConfigured();}

	public SecondaryParsexecutor() {
	}

	/**
	 * static main method to test xmlparser class
	 *
	 */
	public static void main(String args[]) {
		try {
			SecondaryParsexecutor xmlp = new SecondaryParsexecutor();
			xmlp.parseFile(args[0]);

    		} catch (Exception e1) {
			e1.printStackTrace();
		}
	}

	/**
	 * parses a file by its filename
	 * @param inString filename
	 * @exception FileNotFoundException
	 * @exception IOException
	 * @exception SAXException
	 */

	public void parseFile(String inString)
		throws FileNotFoundException, IOException, SAXException {
		FileInputStream fis = new FileInputStream(inString);
		parse(fis);
	}



	/**
	 * parses a file as an inputstrem
	 * <br>all the work is really done here, the other parse methods call this
	 * @param inStream file as an input stream
	 * @exception OBOEException
	 * <br>                 - continues to throw existing PIXESException
	 *                      - unknown transaction set, this transaction set is undefined to OBOE
	 */

	public void parse(InputStream inStream) {

		try {
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			DocumentBuilder db = dbf.newDocumentBuilder();

			Document document = db.parse(new InputSource(inStream));

			if (document.getNodeType() != Node.DOCUMENT_NODE)
				throw new PIXESException("unknown node type found, should be DOCUMENT_NODE");

			parse(document);


		} catch (Exception e) {
			e.printStackTrace();

		}

	}

	  /** parses a XML  Document
     *
     * @param node Incoming DOM node
     *
     */

    public int parse(Node node)

    {
        int n;

        NodeList nl = node.getChildNodes();

        Node currentNode;
        logr.debug("parsing "+node.getNodeName());

        for (n = 0; n < nl.getLength(); n++)
        {
            currentNode = nl.item(n);
            String nName = currentNode.getNodeName();

            if (currentNode.getNodeType() != Node.ELEMENT_NODE)
                continue;
            logr.debug(nName+" of "+node.getNodeName());

            parse(nl.item(n));

        }

        return n;

    }
}
