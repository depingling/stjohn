/*
 * Copyright (C) 2006-2007 by Joseph McVerry - American Coders, Ltd.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

package org.pixes;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.xml.sax.Attributes;


/**
 * @author Joe McVerry - American Coders, Ltd.
 *
 * executor object to do mathmatical calculations
 *
 */
public class Computer extends Executable{

    Logger logr = Logger.getLogger(Computer.class);

    static {Util.isLog4JNotConfigured();}

    /**
     * name of variable
     */
    String name;

    /**
     * value of variable
     */
    String value;

    /**
     * debugging level
     */
    Level dbgLvl;


	/**
	 * @param line - int xml line number
	 * @param attr - Attributes
	 * @param parser - Parser who's in charge
	 * @throws PIXESException
	 */
	public Computer(int line, Attributes attr, Parser parser) throws PIXESException {

    	super(parser);
    	Logger.getLogger(Computer.class);
    	setLogger();
    	dbgLvl = prsr.logr.getLevel();
        logr.setLevel(dbgLvl);

		logr.debug("computer constructor " + attr + " " + line);
		setMyXMLLine(line);

		name = attr.getValue("name");
		if (name == null)
		{
			throw new PIXESException("missing name field in compute statement at "+line);
		}


	}

	/**
	 * set value
	 * @param in value to set
	 */
	public void setContents(String in)
	{
		value = in;
		prsr.getVarStack().put(name, value);
	}

	/**
	 * (non-Javadoc)
	 * @see org.pixes.Executable#execute()
	 */
	public int execute(Executor inExec) {
		exec = inExec;
		exec.logr.setLevel(dbgLvl);
		logr.setLevel(dbgLvl);
		logr.debug(" calling execute " + name + " " + value);
		String ic;
		try {
			ic = compute(exec.getVarStack().replaceString(value)).toString();
			exec.getVarStack().put(name, ic);
		} catch (Exception e) {
			logr.error(e.getMessage(), e);
			return -1;
		}

		return getNextStep();
	}



	/**
	 * valid operators
	 */
	private static final char[] operators = { '+', '-', '*', '/' };

	/**
	 *
	 * @param inString variable name or value
	 * @return FixedDecimalArithmetic object has computed value
	 * @throws PIXESException
	 */
	private FixedDecimalArithmetic compute(String inString) throws PIXESException {
		FixedDecimalArithmetic lr;
		FixedDecimalArithmetic rr;

		String process;
		if (inString.length() > 0 && inString.charAt(0)=='-')
			process=inString.substring(1,inString.length());
		else
			process = inString;
		int operatorLoc = findOperator(process);
		if (inString.length() > 0 && inString.charAt(0)=='-')
			operatorLoc++;

		if (operatorLoc <= 0) {

			if (Character.isLetter(inString.charAt(0))) {
				String lft = exec.getVarStack().get(inString);
			    if (lft == null)
				  throw new PIXESException("can't find variable "+inString+" see line "+getMyXMLLine());
			    else inString = lft;
			}

            try {
			return new FixedDecimalArithmetic(inString.trim());
            }
            catch (NumberFormatException nfe)
            {
            	throw new PIXESException("Number format exception: "+nfe.getMessage()+" see line "+getMyXMLLine());
            }
		}


        lr = compute(inString.substring(0,operatorLoc).trim());
        String rght = inString.substring(operatorLoc+1).trim();

		if (Character.isLetter(rght.charAt(0))) {
			String var = exec.getVarStack().get(rght);
		    if (var == null)
			  throw new PIXESException("can't find variable "+rght);
		    else rght = var;
		}
		try {
        rr = new FixedDecimalArithmetic(rght);
        }
        catch (NumberFormatException nfe)
        {
        	throw new PIXESException("Number format exception: "+nfe.getMessage()+" see line "+getMyXMLLine());
        }



		switch (inString.charAt(operatorLoc)) {
		case '+':
			lr.add(rr);
			break;
		case '-':
			lr.subtract(rr);
			break;
		case '*':
			lr.multiply(rr);
			break;
		case '/':
			lr.divide(rr);
			break;
		default:
			throw new PIXESException("Illegal operator. "+inString.charAt(operatorLoc));
		}

		return lr;
	}

	/**
	 * what operation is requested
	 * @param string look for the operator in here
	 * @return the position in the string of the operator
	 *
	 */
	private  int findOperator(String string) {
		int index = -1;



		for (int i = operators.length - 1; i >= 0; i--) {
			index = Math.max(string.lastIndexOf(operators[i]),index);
		}

		if (index > -1 && string.charAt(index)=='-')
		{
			int revindex = index;
			for (index--; index > -1; index--)
			{
				if (Character.isWhitespace(string.charAt(index)))
				    continue;
				if (Character.isLetterOrDigit(string.charAt(index)))
					return revindex;
				if (string.charAt(index) == '+' ||
						string.charAt(index) == '*' ||
						string.charAt(index) == '-' ||
						string.charAt(index) == '/')
					return index;

			}
			return revindex;
		}



		return index;
	}


}
