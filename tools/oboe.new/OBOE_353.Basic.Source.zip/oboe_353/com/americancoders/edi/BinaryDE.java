package com.americancoders.edi;

import com.americancoders.util.Util;


/**
 * class for all Data Elements defined as character and alphanumeric
 *
 *<P>OBOE - Open Business Objects for EDI
 *<p>Part of the OBOE Basic Extended Package
 *<br>An EDI and XML Translator Written In Java
 *<br>Copyright 1998-2007 - American Coders, LTD  - Raleigh NC USA
 *<br>All rights reserved
 *<br>American Coders, Ltd
 *<br>P. O. Box 97462
 *<br>Raleigh, NC  27624  USA
 *<br>1-919-846-2014
 *<br>http://www.americancoders.com
@author Joe McVerry - American Coders, Ltd.
  @version   3.5.3
 */

public class BinaryDE extends DataElement
{

    public static void main(String args[]){
        BinaryDE bde = new BinaryDE(null, null);
        bde.getBytes();
        
        
    }
    
    private byte[] value;


    /** constructs from its template
     * @param inTDE TemplateDE
     * @param inParent owning Object
     */
    public BinaryDE(TemplateDE inTDE, IContainedObject inParent)
    {
        super(inTDE, inParent);
    }
    /**
     * sets the value for the Data Element
     * @param inValue String value
     *
     */
    public void setValue(String inValue) {value = inValue.getBytes();}

    /** sets the next but not implemented 
     * @param inValue String value
     * */
    public void setNext(String inValue) {set(inValue);}


     /** sets the fields contents
     * @param inValue byte arra contents
     */
    public void set(String inValue) {value = inValue.getBytes();}

    /**
     * gets the current length for the Data Element
     * @return int retuns length of set value,  can have a null exception if value is not set.
     *
     */
    public int getLength()    {
        if (value == null)
          return 0;
        return value.length;
        }


     /** sets the fields contents
     * @param inValue byte array contents
     */
    public void set(byte inValue[]) 
    {
    	value = (byte[]) inValue.clone();
    }


    /**
     * returns the value for the Data Element
     * @return String
     */

    public String get() {
    if (value == null)
      return null;
    if (value.length == 0)
      return "";
    return new String(value);
    }


     /**
     * returns the value for the Binary Data Element
     * @return byte array
     */

    public byte[] getBytes() {
    return (byte[]) value.clone();
    }


     /** formats text of data element
     * <br> Description of DataElement is defined in the class
     * <br> value is the current value set in the object
     * @param formatType int format type x12, edifact...
     * @return String of formatted  text
     */

    public String getFormattedText(int formatType)
    {
        StringBuffer sb = new StringBuffer();
        String got = ""; 
        if (getBytes() != null)
           got = new String(getBytes());

        switch (formatType)
        {
            case Envelope.CSV_FORMAT:
              sb.append("Binary DE,"+getID()+",\""+getName()+","+got+'"'+com.americancoders.util.Util.lineFeed);
            case Envelope.XML_FORMAT:
            sb.append('<' +getXMLTag() + '>' + Util.normalize(got) + "</" + getXMLTag() + ">"+com.americancoders.util.Util.lineFeed); 
            break;
			case Envelope.VALID_XML_FORMAT:
			case Envelope.VALID_XML_FORMAT_WITH_POSITION:
            sb.append("<element code=\"" + getID() + '"'); 
            sb.append(" name=\"" + getName() + '"'); 
            if (formatType == Envelope.VALID_XML_FORMAT_WITH_POSITION)
            	sb.append(" docPosition=\""+this.getSequence() + '"'); 
			sb.append('>'); 
            sb.append(" <value>" +  Util.normalize(got) + "</value></element>"+com.americancoders.util.Util.lineFeed); 
            break;
			case Envelope.PIXES_FORMAT:
	   	 	  	if (got.length() == 0)
	   	 	  		break;

				sb.append("<set name=\""+parent.getID()+getSequence()+"\">"+Util.normalize(got)
						+"</set>"+com.americancoders.util.Util.lineFeed);
                sb.append("<element position=\"" + this.getSequence() + "\"");
                sb.append(">$");
                sb.append(parent.getID()+getSequence() + "$</element>"+com.americancoders.util.Util.lineFeed);
             break;
            case Envelope.X12_FORMAT:
			case Envelope.EDIFACT_FORMAT:
			case Envelope.TRADACOMS_FORMAT:
               return got;
            default:
            sb.append(' ' + getName() + ": " + got + com.americancoders.util.Util.lineFeed); //$NON-NLS-1$ //$NON-NLS-2$
            break;
        }
        return new String(sb);
    }

    /** returns error responses of contents
     * @param inText String text
     * @return String, null if no error
     */
    public String validate(String inText)
    {

        return null;
    }

    /** sets  error  in DocumentErrors
     * @param inDErr DocumentErrors object
     * @return boolean false = error.
     */
    public boolean validate(DocumentErrors inDErr)
    {
    	if (isUsed() == false) {
            if (get() != null && get().length() > 0)
            {
                inDErr.addError(0, getID(), "field is not used, see " +getName() + " at position " + getSequence(),  getParent(), "10", this, 2);
                return false;
               }
            else return true;
    	}

       return true;
    }


 

}
