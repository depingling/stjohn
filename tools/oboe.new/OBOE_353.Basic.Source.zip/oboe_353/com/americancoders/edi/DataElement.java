package com.americancoders.edi;



/**
 * class for all Data Elements
 *
 *<P>OBOE - Open Business Objects for EDI
 *<p>Part of the OBOE Basic Extended Package
 *<br>An EDI and XML Translator Written In Java
 *<br>Copyright 1998-2007 - American Coders, LTD  - Raleigh NC USA
 *<br>All rights reserved
 *<br>American Coders, Ltd
 *<br>P. O. Box 97462
 *<br>Raleigh, NC  27624  USA
 *<br>1-919-846-2014
 *<br>http://www.americancoders.com
@author Joe McVerry - American Coders, Ltd.
  @version   3.5.3
 */

public abstract class DataElement implements IContainedObject
{
    /** templateDE representing this DataELement
     */
       TemplateDE myTemplate=null;


    /** constructs from its template
     * @param inTDE TemplateDE
     * @param inParent owning Object
     */
    public DataElement(TemplateDE inTDE, IContainedObject inParent)
    {
        myTemplate = inTDE;
        setParent(inParent);
    }


    /**
     * returns the dataElement Type
     * @return String type
     *
     */

     public String getType() {return myTemplate.getType();} // is there a default type?




    /**
     * gets the Data Element id
     * @return String edi id
     *
     */
    public String getID() { return myTemplate.getID(); }


    /**
     * gets the Data Element Name
     * @return String edi Name
     *
     */
    public String getName() { return myTemplate.getName(); }


    /**
     * gets the Data Element sequence
     * @return int sequence with in the segment
     *
     */
    public int getSequence() { return myTemplate.getSequence(); }

    /**
     * gets the required indicator
     * @return char the required indicator
     *
     */
    public int getRequired() { return myTemplate.getRequired(); }
    /**
     * gets the minimum length for the Data Element
     * @return int the defined minimum length
     *
     */
    public int getMinLength() { return myTemplate.getMinLength(); }
    /**
     * gets the maximum length for the Data Element
     * @return int the defined maximum length
     *
     */
    public int getMaxLength() { return myTemplate.getMaxLength();  }

    /**
     * returns the xml tag field
     * @return String tag value
     */

    public String getXMLTag() { return myTemplate.getXMLTag(); }

    /**
     * returns the Description for the Data Element
     * @return String description
     */
    public String getDescription()
    {
        return myTemplate.getDescription();
    }

    /**
     * returns the occurs value for the Data Element
     * @return int
     */
    public int getOccurs() { return myTemplate.getOccurs();

    }
    
    /** 
     * returns the used indicator
     * @return boolean indicator
     */
    public boolean isUsed() { return myTemplate.isUsed();
    
    }
	/** sets the fields contents
	 * @param inValue String contents
	 */
	public abstract void set(String inValue);

	/** sets the fields contents for multiple occuring elements
	 * @param inValue String contents
	 */
	public abstract void setNext(String inValue);

    /** sets the fields contents
     * @param inValue byte array
     */
    public abstract void set(byte inValue[]);

    /**
     * returns the value for the Data Element
     * @return String
     */

    public abstract String get();

    /**
     * gets the current length for the Data Element
     * @return int retuns length of set value,  can have a null exception if value is not set.
     *
     */
    public abstract int getLength();


     /** formats text of data element
     * <br> Description of DataElement is defined in the class
     * <br> value is the current value set in the object
     * @param formatType int format type x12, edifact...
     * @return String of formatted  text
     */

    public abstract String getFormattedText(int formatType);

    /** returns error responses of contents
     * @param inText String text
     * @return String, null if no error
     */
    public abstract String validate(String inText);

    /** sets  error  in DocumentErrors
     * @param inDErr DocumentErrors object
     */
    public abstract boolean validate(DocumentErrors inDErr);


    /** gets the template that built this object
     */
    public TemplateDE getTemplate() {return myTemplate;}

  /**
    owning object
    */

    protected IContainedObject parent=null;
    /** sets parent attribute
     * @param inParent TemplateSegmentContainer
     */
    public void setParent(IContainedObject inParent) {parent = inParent;}

    /** gets parent attribute
     * @return TemplateSegmentContainer
     */
    public IContainedObject  getParent() { return parent;}



    public String getFixedLengthFormattedText()
    {
        StringBuffer sb = new StringBuffer(get());
        for (int i = sb.length(); i < getMaxLength(); i++)
          sb.append(' ');
        return new String(sb);

    }
    
    /**
     * the toString method
     */
   public String toString()
   {
   	 return "data element id:"+ getID()+ " name:" + getName()+ " type:" +  getType() + " sequence:"+ getSequence()
	         + " contents:" + get();
   	 		
   }
   
   /* (non-Javadoc)
    * @see com.americancoders.edi.IContainedObject#getDelimiter(char)
    */

   	public char getDelimiter(char inOriginal) {
   		
   		if (parent == null)
   			return inOriginal;
   		return parent.getDelimiter(inOriginal);
   	}

}
