package com.americancoders.edi;

/**
 * interface for CompositeDE Container
 *
 *<P>OBOE - Open Business Objects for EDI
 *<p>Part of the OBOE Basic Extended Package
 *<br>An EDI and XML Translator Written In Java
 *<br>Copyright 1998-2007 - American Coders, LTD  - Raleigh NC USA
 *<br>All rights reserved
 *<br>American Coders, Ltd
 *<br>P. O. Box 97462
 *<br>Raleigh, NC  27624  USA
 *<br>1-919-846-2014
 *<br>http://www.americancoders.com
@author Joe McVerry - American Coders, Ltd.
  @version   3.5.3
 */

public interface ICompositeDEContainer {

	/** returns a CompositeDE from in the Container
	   * <br>since more than one dataelement with the same id can be
	   * in the container this is not a very effective method for fetching unique datalements.
	   * @return CompositeDE object
	   * @param ID String ID of field to get
	   * @exception OBOEException ID is unknown
	   */

	public CompositeDE getCompositeDE(String ID) throws OBOEException;

	/** returns a CompositeDE from the Container
	* @return CompositeDE  composite de object
	* @param inSequence int - position of field to get
	* @exception OBOEException ID is unknown
	*/

	public CompositeDE getCompositeDE(int inSequence) throws OBOEException;

	/**
	 * returns all the data associated in a String format
	 * @return String for all Dataelements
	 * @exception OBOEException thrown when data is missing from a data element
	 */
	public String get() throws OBOEException;

	/** returns the length of the data in the data elements
	 * @return int
	 */
	public int getDataElementLength();

}
