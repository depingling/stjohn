package com.americancoders.edi;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.NumberFormat;
import java.text.ParseException;

import com.americancoders.util.Util;

/**
 *  class for Data Elements defined as Real
 *<p>OBOE - Open Business Objects for EDI
 *<p>Part of the OBOE Basic Extended Package
 *<br>An EDI and XML Translator Written In Java
 *<br>Copyright 1998-2007 - American Coders, LTD  - Raleigh NC USA
 *<br>All rights reserved
 *<br>American Coders, Ltd
 *<br>P. O. Box 97462
 *<br>Raleigh, NC  27624  USA
 *<br>1-919-846-2014
 *<br>http://www.americancoders.com
@author Joe McVerry - American Coders, Ltd.
  @version   3.5.3
 */

public class RealDE extends DataElement implements IContainedObject {

	protected String value[];
	protected int cursor = -1;


	/** constructs from its template
	* @param inTDE TemplateDE
	* @param inParent owning Object
	*/
	public RealDE(TemplateDE inTDE, IContainedObject inParent) {
		super(inTDE, inParent);
		value = new String[inTDE.getOccurs()];
		cursor++;
			if (cursor >= getOccurs())
			   cursor = 0;

	}
	/** sets the fields contents, cursor set to zero
	 * @param inValue String contents
	 * @throws OBOEException
	 */
	public void set(String inValue) {
		cursor = -1;
		setNext(inValue);
	}


	/** sets the fields contents by moving cursor, cursor will wrap around; not formatted
	 * @param inValue String contents
	 */
	public void setNext(String inValue) throws OBOEException {

		cursor++;
		if (cursor >= getOccurs())
			cursor = 0;

		inValue = inValue.trim();

		if (inValue.length() == 0) {
			value[cursor] = "";
			return;
		}
		
	  	DecimalFormatSymbols dfs = new DecimalFormatSymbols();

		for (int i=0; i < inValue.length(); i++)
		{
			if (Character.isDigit(inValue.charAt(i)))
			  continue;
			if (inValue.charAt(i) ==  dfs.getDecimalSeparator())
				 continue;
			if (inValue.charAt(i) ==  dfs.getGroupingSeparator())
				 continue;
			if (inValue.charAt(i) == dfs.getMinusSign())
				 continue;
			
			throw new OBOEException("numeric parsing error "+inValue);
			
		}
			
		DecimalFormat df = new DecimalFormat();
		
		

		try {
			value[cursor] = df.parse(inValue).toString();
			if (value[cursor].charAt(0) == '0' && value[cursor].length()>1)
			  {
			  	if (dfs.getDecimalSeparator() == value[cursor].charAt(1)) {
			  		if (value[cursor].length() > getMinLength())
			  		  value[cursor] = value[cursor].substring(1);
			  	}
			  }
			   
		} catch (ParseException p1) {
			throw new OBOEException("java parse exception: " + p1.getMessage());
		}

		value[cursor] = get(cursor);

	}

	/** sets the fields contents, not formatted
	 * @param inValue byte array, converted to string and set(String) is called
	 * @exception OBOEException
	 *   inValue contains format characters if field defined with type of N#
	  *
	  */
	public void set(byte inValue[]) throws OBOEException {
		set(new String(inValue));
	}

	/**
	* gets the current length for the Data Element
	* @return int retuns length of set value,  can have a null exception if value is not set.
	*
	*/
	public int getLength() {

	  int len = 0;
	  for (int i = 0; i < getOccurs(); i++)
	   {
		if (value[i] != null)
			  len += get(i).length();
	   }
	  return len;
	}

	/** returns the value for the Data Element
	 * @return String
	 */

	public String get() {
		return get(0);
	}

	/**
	 * returns the value for the Data Element
	 * @param inPos int position in array
	 * @return String
	 */

	public String get(int inPos) {

		if (value[inPos] == null)
			return null;
		if (value[inPos].length() == 0)
			return "";
		StringBuffer sb = new StringBuffer(value[inPos]);

		int l = value[inPos].length();
		if (l < getMinLength()
			|| (l == getMinLength()
				&& value[inPos].indexOf('.') > -1)) // ignore decimal point
			{
			if (value[inPos].indexOf('.') < 0)
				sb.append('.');
			else
				l--;
			for (int i = l; i < getMinLength(); i++)
				sb.append('0');
			value[inPos] = new String(sb);
		}
		return value[inPos];
	}


	/**
	 * gets the number of decimal positions
	 * @return int number of decimal positions
	 *
	 */

	public int getDecimalPositions() {
		return getMinLength();
	}

	/** builds a formatted String of the object
	 * @return String of formatted text
	 * @param formatType int x12, edifact...
	 */
	public String getFormattedText(int formatType) {
		int i;
		String got;
		StringBuffer sb = new StringBuffer();
	
		int repeatCnt = -1;
		for (repeatCnt = value.length-1; repeatCnt > -1 && value[repeatCnt] == null; repeatCnt--);

		for (i = 0; i < value.length; i++) {
			if (value[i] == null && i > 0)
				break;
			got = get(i);
			if (got == null)
				got = "";

			switch (formatType) {
				case Envelope.X12_FORMAT :
					sb.append(got);
					if (getOccurs() > 1 && i < repeatCnt)
						sb.append(getDelimiter(Envelope.X12_REPEAT_DELIMITER.charAt(0)));
					break;

				case Envelope.EDIFACT_FORMAT :
				got = get(i);
					sb.append(got);
					if (getOccurs() > 1 && i < repeatCnt)
						sb.append(getDelimiter(Envelope.EDIFact_REPEAT_DELIMITER.charAt(0)));
					break;
				case Envelope.TRADACOMS_FORMAT :
				got = get(i);
					sb.append(got);
					if (getOccurs() > 1 && i < repeatCnt)
						sb.append(getDelimiter(Envelope.TRADACOMS_REPEAT_DELIMITER.charAt(0)));
					break;


				case  Envelope.CSV_FORMAT:
					sb.append("DE," + getID() + ",\"" + getName() + "\",");
					sb.append(got);
					sb.append("\t" + getName() + ": ");
  					sb.append("\"" + com.americancoders.util.Util.lineFeed);
  					break;

				case Envelope.XML_FORMAT:
					sb.append("<" + getXMLTag() + ">");
					sb.append(got);
					sb.append("</"+ getXMLTag()	+ ">"+ com.americancoders.util.Util.lineFeed);
					break;

				case Envelope.VALID_XML_FORMAT:
				case Envelope.VALID_XML_FORMAT_WITH_POSITION:

					sb.append("<element code=\"" + getID() + "\"");
					sb.append(" name=\"" + getName() + "\"");
					if (formatType == Envelope.VALID_XML_FORMAT_WITH_POSITION)
						sb.append(" docPosition=\""+this.getSequence() + "\"");
					sb.append(">");
					sb.append("<value>");
					sb.append(got);
					sb.append("</value>");
					sb.append("</element>" + com.americancoders.util.Util.lineFeed);
					break;

				case Envelope.PIXES_FORMAT:
		   	 	  	if (got.length() == 0)
		   	 	  		break;

					sb.append("<set name=\""+parent.getID()+getSequence()+"\">"+Util.normalize(got)
							+"</set>\n");
                	sb.append("<element position=\"" + this.getSequence() + "\"");
                	sb.append(">$");
                	sb.append(parent.getID()+getSequence() + "$</element>"+com.americancoders.util.Util.lineFeed);
  					break;

				default:
					sb.append("\t" + getName() + ": ");
					sb.append(value[i]);
					sb.append(com.americancoders.util.Util.lineFeed);
			}
		  }
		return new String(sb);


	}

	/** returns error responses of contents
	 * @param inText String text
	 * @return String - null if no error
	 */
	public String validate(String inText) {
		String returnMessage = myTemplate.validate(inText);
		if (returnMessage == null)
			return returnMessage;

		if (inText == null || inText.trim().length() == 0)
			return null;
		// if it was required the super call above catches that

		NumberFormat nf = NumberFormat.getNumberInstance();
		nf.setMinimumFractionDigits(getMinLength());
		nf.setMaximumFractionDigits(getMinLength());
		nf.setMinimumIntegerDigits(1);
		nf.setMaximumIntegerDigits(getMaxLength());
		try {
			Double.valueOf(inText.trim()).doubleValue();
		} catch (java.lang.NumberFormatException e1) {
			returnMessage = "Invalid Real Number Format";
		}

		return null;
	}

	/** sets  error  in DocumentErrors
	 * @param inDErr DocumentErrors object
	 * @return boolean true if it's okay
	 */
	public boolean validate(DocumentErrors inDErr) {

    	if (isUsed() == false) {
            if (value[0] != null && value[0].length() > 0)
            {
                inDErr.addError(0, getID(), "field is not used, see " +getName() + " at position " + getSequence(),  getParent(), "10", this, 1);
                return false;
               }
            else return true;
    	}
    	
        if (getRequired() == 'M') {
			if (value[0] == null || value[0].length() == 0)
				inDErr.addError(0,	getID(),	"value[0] Required, see " +getName() + " at position " + getSequence(),
					getParent(),"1",this, 1);
			return false;
		} else // not required
			if (value[0] == null || value[0].length() == 0)
				return true;

		if (value[0].length() < getMinLength()) {
			inDErr.addError(getSequence(),	getID(),
				"Data element value (" + value[0] + ") Too Short, see " +getName() + " at position " + getSequence(),
				getParent(),"4",this, 1);
			return false;
		}

		if (value[0].length() > getMaxLength()) {
			inDErr.addError(getSequence(),getID(),
				"Data element value (" + value[0] + ") Too Long, see " +getName() + " at position " + getSequence(),
				getParent(),"5",this, 1);
			return false;
		}

		return true;
	}

	/** returns data with length equal to mamFieldLenth
	 * @return String
	 */

	public String getFixedLengthFormattedText() {
		StringBuffer sb = new StringBuffer();
		String s = get();
		for (int i = s.length(); i < getMaxLength(); i++)
			sb.append('0');
		sb.append(s);
		return new String(sb);

	}


}
