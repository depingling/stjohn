package com.americancoders.edi.EDIFact;

/**
 *OBOE - Open Business Objects for EDI
 *<p>Copyright 1998-2007 - American Coders, LTD  - Raleigh NC USA
 *<p>All rights reserved
 *<p>American Coders, Ltd
 *<br>P. O. Box 97462
 *<br>Raleigh, NC  27624  USA
 *<br>1-919-846-2014
 *<br>http://www.americancoders.com
@author Joe McVerry - American Coders, Ltd.
  @version   3.5.3
 */



import com.americancoders.edi.OBOEException;
import com.americancoders.edi.Segment;
import com.americancoders.edi.TemplateComposite;
import com.americancoders.edi.TemplateDE;
import com.americancoders.edi.TemplateSegment;

/**
 * staticly defined class for EDIFact Segment   Message_Header
 *
 */
public class  Message_Header
{

  public static final String id = "UNH";
  public static final String xmlTag = "MessageHeader";

  /**
   * Factory method to create an Message Header
   * @return Segment Message Header
   * @exception OBOEException can be thrown
   */

  public static Segment getInstance()
  throws OBOEException
  {
    TemplateComposite tcde;

    TemplateSegment returnSeg = new TemplateSegment(id, "Message Header", 0,  "Message Header", 1, 'M', xmlTag, true, null);
    returnSeg.addTemplateDE(new TemplateDE("0062", "Message reference number", 1, "AN", 'O', "Message reference number", 1, 14,
    "messageReferenceNumber", null, null, 1, true));

    tcde = new TemplateComposite("S009", "messageIdentifier", 'O', 2, "messageIdentifier", "messageIdentifier", null, 1, true);
    tcde.addTemplateDE(new TemplateDE("0065", "Message type identifier", 1, "AN", 'O',"Message type identifier", 1, 6,
    "messageTypeIdentifier", null, null, 1, true));
    tcde.addTemplateDE(new TemplateDE("0052", "Message type version", 2, "AN", 'O',"Message type version number", 1, 3,
    "messageTypeVersionNumber", null, null, 1, true));
    tcde.addTemplateDE(new TemplateDE("0054", "Message type release", 3, "AN", 'O',"Message type release number", 1, 3,
    "messageTypeReleaseNumber", null, null, 1, true));
    tcde.addTemplateDE(new TemplateDE("0051", "Controlling agency",4, "AN", 'O',"Controlling agency", 1, 2,
    "controllingAgency", null, null, 1, true));
    tcde.addTemplateDE(new TemplateDE("0057", "Association assigned code", 5, "AN", 'O',"Association assigned code", 1, 6,
    "associationAssignedCode", null, null, 1, true));
    returnSeg.addTemplateComposite(tcde);


    returnSeg.addTemplateDE(new TemplateDE("0068", "Common access reference", 3, "AN", 'O',"Common access reference", 1, 35,
    "commonAccessReference", null, null, 1, true));

    tcde = new TemplateComposite("S009", "messageIdentifier", 'O', 4, "messageIdentifier", "messageIdentifier", null, 1, true);
    tcde.addTemplateDE(new TemplateDE("0070", "Sequence message transfer", 1, "AN", 'O',"Sequence message transfer number", 1, 2,
    "sequenceMessageTransferNumber", null, null, 1, true));
    tcde.addTemplateDE(new TemplateDE("0073", "First/last", 2, "AN", 'O',"First/last sequence message transfer indication", 1, 1,
    "firstLastSequenceMessageTransferIndication", null, null, 1, true));
    returnSeg.addTemplateComposite(tcde);

    return new Segment(returnSeg, null);
  }
}
