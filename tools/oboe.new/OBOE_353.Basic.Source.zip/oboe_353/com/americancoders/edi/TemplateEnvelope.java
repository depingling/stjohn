package com.americancoders.edi;

import java.io.Externalizable;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInput;
import java.io.ObjectInputStream;
import java.io.ObjectOutput;
import java.lang.reflect.Method;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

import org.apache.log4j.Logger;

import com.americancoders.util.Util;


/**
 *class for Template Envelopes
 *<p>OBOE - Open Business Objects for EDI
 *<p>Part of the OBOE Basic Extended Package
 *<br>An EDI and XML Translator Written In Java
 *<br>Copyright 1998-2007 - American Coders, LTD  - Raleigh NC USA
 *<br>All rights reserved
 *<br>American Coders, Ltd
 *<br>P. O. Box 97462
 *<br>Raleigh, NC  27624  USA
 *<br>1-919-846-2014
 *<br>http://www.americancoders.com
@author Joe McVerry - American Coders, Ltd.
  @version   3.5.3
 */

public class TemplateEnvelope
	extends TemplateSegmentContainer
	implements Externalizable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private TemplateFunctionalGroup tfg = null;
	
	private String type;
	
  /** log4j object */
    
    static Logger logr = Logger.getLogger(TemplateEnvelope.class);
	static 	{Util.isLog4JNotConfigured();}

	/** store idListFile datetime stamp */
	protected Hashtable idListFileList = new Hashtable();


	


	/** creates a TemplateEnvelope object
	 */
	public TemplateEnvelope() {
		templateContainer = new Vector();

	}

	/** returns the template functional group used by this envelope
	  * @return templatefunctionalgroup
	  */
	public TemplateFunctionalGroup getTemplateFunctionalGroup() {
		return tfg;
	}

	/** sets the template functional group used by this envelope
	  * @param inTFG templatefunctionalgroup
	  */
	public void setTemplateFunctionalGroup(TemplateFunctionalGroup inTFG) {
		tfg = inTFG;
	}

	/** used by externalize methods
	 * @param in ObjectInput stream
	 * @exception IOException - most likely class changed since written
	 * @exception ClassNotFoundException - only when dummy constructro not found
	 */

	public void readExternal(ObjectInput in)
		throws IOException, ClassNotFoundException {
		templateContainer = (Vector) in.readObject();
		type = in.readUTF();
		idListFileList = (Hashtable) in.readObject();
		tfg = (TemplateFunctionalGroup) in.readObject();
	}

	/** used by externalize methods
	 * @param out ObjectOutput stream
	 * @exception IOException Java.io error
	 */

	public void writeExternal(ObjectOutput out) throws IOException {
		out.writeObject(templateContainer);
		out.writeUTF(type);
		out.writeObject(idListFileList);
		out.writeObject(tfg);

	}

	protected IContainedObject parent = null;
	/** sets parent attribute
	 * @param inParent TemplateSegmentContainer
	 */
	public void setParent(IContainedObject inParent) {
		parent = inParent;
	}

	/** gets parent attribute
	 * @return TemplateSegmentContainer
	 */
	public IContainedObject getParent() {
		return parent;
	}

	public String getID() {
		return "template env";
	}
	public String getXMLTag() {
		return "templateEnv";
	}

	/** returns template functional group object
	 * @return TemplateFunctioanlGroup
	 */
	public TemplateFunctionalGroup getTfg() {
		return tfg;
	}

	/** returns type of envelope
	 * @return string
	 */
	public String getType() {
		return type;
	}

	/**
	 * @param group
	 */
	public void setTfg(TemplateFunctionalGroup group) {
		tfg = group;
	}

	/**
	 * @param string
	 */
	public void setType(String string) {
		type = string;
	}


	protected String xmlPath = null;
	public void setXMLPath(String string) {
		xmlPath = string;
		
	}

	
	public void addIDListFile(File inFile)
	{
		this.idListFileList.put(inFile.getPath(), new Long(inFile.lastModified()));
	}
	

	public boolean checkIDListFiles()
	{
		int i;
		Enumeration enum = idListFileList.keys();
		for (i = 0 ; i < idListFileList.size(); i++) 
		{
			String pth = (String) enum.nextElement();
			File f = new File(pth);
			if (f == null)
				return false;
			if (f.exists()== false)
			   return false;
			Long l = (Long) idListFileList.get(pth);
			if (l.longValue() != f.lastModified())
				return false;
			
		}
		                                             
		return true;
	}
	/* (non-Javadoc)
	 * @see com.americancoders.edi.IContainedObject#getDelimiter(char)
	 */

		public char getDelimiter(char inOriginal) {
			
			return parent.getDelimiter(inOriginal);
		}

}
