package com.americancoders.edi;

import java.io.File;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.util.StringTokenizer;
import java.util.Vector;

import org.apache.log4j.Logger;

import com.americancoders.util.Util;

/** An class that represents ID lists
 *<p>OBOE - Open Business Objects for EDI
 *<p>Part of the OBOE Basic Extended Package
 *<br>An EDI and XML Translator Written In Java
 *<br>Copyright 1998-2007 - American Coders, LTD  - Raleigh NC USA
 *<br>All rights reserved
 *<br>American Coders, Ltd
 *<br>P. O. Box 97462
 *<br>Raleigh, NC  27624  USA
 *<br>1-919-846-2014
 *<br>http://www.americancoders.com
@author Joe McVerry - American Coders, Ltd.
  @version   3.5.3
 */



public class IDList implements IDListProcessor
{
    /**
	 * 
	 */
	private static final long serialVersionUID = -1L;
	/** IDList name
     */
    protected String      name=null;
    /** codes and descriptive values associated with IDList
     */
    protected Vector	  codes, values;

    /** IDList short filename
     */
    protected String      shortname = "";

    /** IDList boolean filtered - filtered data from  filename
     */
    protected boolean     filtered = false;
    protected String filterList="";

    
	/** log4j object */
	static Logger logr = Logger.getLogger(IDList.class);
	static 	{Util.isLog4JNotConfigured();}
	

    
    
    /** Build an IDList structure from an XML file
     * @param xmlFile xml file containing id list structure
     * @param inLastDirectoryToLook - name of the highest directory to find idlist file in
     * @param idListParser SAX2 parser IDListParser
     */
    public IDList(String xmlFile, String inLastDirectoryToLook, IDListParser idListParser) {
        this();
        name = xmlFile;

        File f = new File(name);
        shortname = f.getName();

        idListParser.parse(xmlFile, inLastDirectoryToLook, codes, values);
    }

    /**
     * Construct an id list object with no values
     */
    public IDList(){
        codes = new Vector();
        values = new Vector();
    }

    /** Construct an id list object with no values but a name
     * @param inShortName String name of idList
     */
    public IDList(String inShortName){
        this();
        shortname = inShortName;
    }

    /** used by externalize methods
     * @param in ObjectInput stream
     * @exception IOException - most likely class changed since written
     * @exception ClassNotFoundException - only when dummy constructro not found
     */

    public void readExternal(ObjectInput in)
    throws IOException, ClassNotFoundException
    {
        int length = in.readInt();
        if (length > 0)
          {
             name = in.readUTF();
             File f = new File(name);
             shortname = f.getName();
          }

        filtered = in.readBoolean();
        
        codes = (Vector) in.readObject();
        values = (Vector) in.readObject();
        filterList = in.readUTF();
        
    }

    /** used by externalize methods
     * @param out ObjectOutput stream
     * @exception IOException java.io exception
     */
    public void writeExternal(ObjectOutput out)
    throws IOException
    {
        if (name == null)
          out.writeInt(0);
        else
          {
           out.writeInt(name.length());
           if (name.length() > 0)
            out.writeUTF(name);
          }
        out.writeBoolean(filtered);
        out.writeObject(codes);
        out.writeObject(values);
        out.writeUTF(filterList);
    }

    /**
     * sets the name of id list file
     *
     */
   public void setName(String inName) {
    name=inName;
    if (name != null)
      {
       File f = new File(name);
       shortname = f.getName();
      }
      else shortname = null;
     }

    /**
     * return name of id list file
     *
     * @return String
     */
   public String getName() {return name;}


    /**
     * return short name of id list
     *
     * @return String
     */
    public String getShortName() {
        return shortname;
    }


    /** Add code and description to the vectors
     * @param inCode String code
     * @param inDescribe String descriptive value
     */
    public void add(String inCode, String inDescribe)
    {
        codes.add(inCode);
        values.add(inDescribe);
    }

    /** tests if the passed code is in the code vector
     * @param inCode String to test
     * @return boolean
     */
    public boolean isCodeValid(String inCode)
    {
        String test;
        for (int i = 0; i < codes.size(); i++)
        {
            test = (String) codes.elementAt(i);
            if (test == null)
              continue;
            if (test.compareTo(inCode) == 0) return true;
        }
        return false;
    }

    /** returns the descriptive value of the code,  if it is not found then the code is returned
     * @param inCode String to test
     * @return String
     */
    public String describe(String inCode)
    {
        String test;
        for (int i = 0; i < codes.size(); i++)
        {
            test = (String) codes.elementAt(i);
            if (test.compareTo(inCode) == 0) return (String) values.elementAt(i);
        }
        return inCode;
    }
    /** returns the code value for a descriptive value.  if it is not found the value is returned
     * @param inValue String to test
     * @return String
     */

    public String getCode(String inValue)
    {
        String test;
        for (int i = 0; i < values.size(); i++)
        {
            test = (String) values.elementAt(i);
            if (test.compareTo(inValue) == 0) return (String) codes.elementAt(i);
        }
        return inValue;
    }

    /** returns a code at a specific position in vector
     * @param pos int String position
     * @return String
     */
    public String getCodeByPos(int pos) {    return (String) codes.elementAt(pos); }
    /**
     * returns the code vector
     *
     * @return Vector
     */

    public Vector getCodes() { return codes;}

    /**
     * returns the value vector
     *
     * @return Vector
     */

    public Vector getValues() { return values;}



    public boolean isFiltered() {
        return filtered;
    }
    public void setFiltered(boolean filtered) {
        this.filtered = filtered;
    }
    public String getFilterList() {
        return filterList;
    }
    public void setFilterList(String filterList) {
        this.filterList = filterList;
        setFiltered(true);
    }
    
    
    
	/**
     * @param c 'i' or 'x', inlude or exclude
	 * @param string inclusion/exclusion list
	 * <br> comma seperated and dash range specifier
     * @return new idlist object
     */
    public  IDList idListWork(char c, String string ) {
        
        IDList idl = new IDList();
        idl.shortname=this.shortname;
        idl.setFiltered(true);
        StringTokenizer st = new StringTokenizer(string,",");
        String tkn, strt, stp;
        String lststrt="";
        int i;
        int currentpos=0;
        int currentlength = this.getCodes().size();
        if (string.length()==0)
          throw new OBOEException("IDList inclusion/exclusion attribute error; too small or length is zero");
        while (st.hasMoreTokens()){
            tkn = st.nextToken().trim();
      
           if (tkn.indexOf('-')<0){
                strt=tkn;
                if (strt.length()==0)
                    throw new OBOEException("IDList inclusion/exclusion attribute error; start value too small or length is zero " + tkn );
                stp = tkn;
            }
            else {
                strt="";
                stp="";
                for (i = 0; i < tkn.indexOf('-'); i++)
                    strt += tkn.charAt(i);
                strt = strt.trim();
                if (strt.length()==0)
                    throw new OBOEException("IDList inclusion/exclusion attribute error; start value too small or length is zero " + tkn );
                for (i++; i < tkn.length(); i++)
                {
                    if (tkn.charAt(i) == '-')
                        throw new OBOEException("IDList inclusion/exclusion attribute error; too many dashes in "+tkn+" within "+string);
                    stp += tkn.charAt(i);
                }
                stp = stp.trim();
                if (stp.length()==0)
                    throw new OBOEException("IDList inclusion/exclusion attribute error; stop value too small or length is zero " + tkn );
            }
           
             boolean numCheck = (Util.isInteger(strt) && Util.isInteger(stp)); 
             if (numCheck)
             {
            	 int s = Integer.parseInt(strt);
            	 int p = Integer.parseInt(stp);
                 if (s > p)
                     throw new OBOEException("IDList inclusion/exclusion attribute error; invalid range of values in "+tkn+" within "+string);
             }
             else if (strt.compareTo(stp) > 0)
                throw new OBOEException("IDList inclusion/exclusion attribute error; invalid range of values in "+tkn+" within "+string);
             
             if (Util.isInteger(strt) && Util.isInteger(lststrt))
             {
            	 int s = Integer.parseInt(strt);
            	 int p = Integer.parseInt(lststrt);
                 if (s < p)
                     throw new OBOEException("IDList inclusion/exclusion attribute error; new start value is less than old start value "+tkn+" within "+string);
             }
             else if (strt.compareTo(lststrt)<=0)
                throw new OBOEException("IDList inclusion/exclusion attribute error; new start value is less than old start value "+tkn+" within "+string);
             
            lststrt=strt;
                
            logr.debug("working with "+c+" token is " +tkn+" start is "+strt+" stop is "+stp);
            for (; currentpos < currentlength; currentpos++)
            {
                
                String cd = this.getCodeByPos(currentpos);
                if (c == 'i'){
                	if (numCheck && Util.isInteger(cd) &&(Integer.parseInt(cd)< Integer.parseInt(strt)))
                		continue;
                    if (!numCheck && cd.compareTo(strt)<0) // not there yet
                        continue; // inner while loop;
                	if (numCheck && Util.isInteger(cd) &&(Integer.parseInt(cd)> Integer.parseInt(stp)))
                		break;
                    if (!numCheck && cd.compareTo(stp)>0) // we're done
                        break; // inner while loop;
                    
                    idl.add(cd, this.describe(cd));
                
                }
                else // c is 'x'
                {
                	if (numCheck && Util.isInteger(cd) &&(Integer.parseInt(cd)< Integer.parseInt(strt)))
                    {
                        idl.add(cd, this.describe(cd));
                        continue; // inner while loop;
                    }
                    if (!numCheck && cd.compareTo(strt)<0) // not there yet
                    {
                        idl.add(cd, this.describe(cd));
                        continue; // inner while loop;
                    }
                    // are we done, if so break inner while loop
                	if (numCheck && Util.isInteger(cd) &&(Integer.parseInt(cd)> Integer.parseInt(stp)))
                		break;
                    if (!numCheck && cd.compareTo(stp)>0) 
                        break; 
                    
                }
                
            }
            
            
            
        }
                
        for (; currentpos < currentlength; currentpos++)
        {
            
            String cd = this.getCodeByPos(currentpos);
            if (c == 'x')
                idl.add(cd, this.describe(cd));
        
        }
        
        return idl;
    }
    

    
}
