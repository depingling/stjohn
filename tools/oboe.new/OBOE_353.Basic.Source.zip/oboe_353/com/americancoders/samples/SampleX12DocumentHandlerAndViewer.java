package com.americancoders.samples;

/**
 *OBOE - Open Business Objects for EDI
 *<P>java access to EDI
 *<p>Copyright 1998-2007 - American Coders, LTD  - Raleigh NC USA
 *<p>All rights reserved
 *<p>American Coders, Ltd
 *<br>P. O. Box 97462
 *<br>Raleigh, NC  27624  USA
 *<br>1-919-846-2014
 *<br>http://www.americancoders.com
@author Joe McVerry - American Coders, Ltd.
@version buildNotToBeReleased
 */

import java.io.FileReader;
import java.io.IOException;
import java.io.StringWriter;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;

import org.apache.log4j.Logger;

import com.americancoders.edi.DocumentErrors;
import com.americancoders.edi.EDIDocumentHandler;
import com.americancoders.edi.Envelope;
import com.americancoders.edi.FunctionalGroup;
import com.americancoders.edi.OBOEException;
import com.americancoders.edi.Segment;
import com.americancoders.edi.TransactionSet;
import com.americancoders.edi.x12.X12DocumentParser;
import com.americancoders.edi.x12.X12Envelope;
import com.americancoders.edi.x12.X12FunctionalGroup;
import com.americancoders.util.Util;

/**
 * class to parse input string for all defined OBOE Transaction Sets
 * <br> program will create Valid XML formatted data for each transaction set
 * <br> output sent to System.out (console)
 * <br> x12 dependent
 *
 */

public class SampleX12DocumentHandlerAndViewer
	extends JFrame
	implements EDIDocumentHandler {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JTabbedPane jtp = new JTabbedPane();
	X12Envelope envelope = null;
	FunctionalGroup functionalGroup = null;
	DocumentErrors de = null;
	
	static Logger logr = Logger.getLogger(SampleX12DocumentHandlerAndViewer.class);
	static {Util.isLog4JNotConfigured();}



	public SampleX12DocumentHandlerAndViewer() {
		
		super();
		
		
		
	}

	/** start parsing */
	public void startParsing(java.io.Reader inRDR) {

		X12DocumentParser p1 = new X12DocumentParser();
		// create a parser object
		p1.registerHandler(this); // register with the parser
		getContentPane().add(jtp);
		de = p1.getDocumentErrors();

		try {
			p1.parseDocument(inRDR, false);
			envelope.validate(p1.getDocumentErrors());
		} catch (OBOEException e) {
			StringBuffer sb = new StringBuffer();
			for (int i = 0; i < de.getErrorCount(); i++) {
				sb.append(de.getErrorID(i) + " ");
				sb.append(de.getErrorCode(i) + " ");
				sb.append(de.getErrorPosition(i) + " ");
				sb.append(de.getErrorDescription(i) + " ");
				if (de.getContainer(i) instanceof Segment) {
					sb.append(
						((Segment) de.getContainer(i)).getID()
							+ " "
							+ ((Segment) p1.getDocumentErrors().getContainer(i))
								.getName()
							+ com.americancoders.util.Util.lineFeed);
				} else {
					sb.append(
						de.getContainer(i)
							+ com.americancoders.util.Util.lineFeed);
				}

			}
			javax.swing.JOptionPane.showMessageDialog(
				this,
				new String(sb),
				e.getMessage(),
				javax.swing.JOptionPane.ERROR_MESSAGE);
		}
		pack();
		setVisible(true);
	}

	/** do nothing when an envelope is started */
	public void startEnvelope(Envelope inEnv) {
		envelope = (X12Envelope) inEnv;
	}

	/** called when an FunctionalGroup object is created
	 * @param inFG FunctionalGroup found
	 */

	public void startFunctionalGroup(FunctionalGroup inFG) {
		functionalGroup = inFG;
		envelope.addFunctionalGroup(inFG);
	}

	/** called when an TransactionSet object is created
	 * @param inTS TransactionSet found
	 */
	public void startTransactionSet(TransactionSet inTS) {
		functionalGroup.addTransactionSet(inTS);
	}

	/** called when an Segment object is created
	 * <br>only called for segments at the Envelope and functionalGroup level
	 * does not get called for segments within TransactionSet
	 * @param inSeg  Segment found
	 */
	public void startSegment(Segment inSeg) {

		if (inSeg.getID().compareTo(X12Envelope.idInterchangeHeader) == 0)
			envelope.addSegment(inSeg);
		else if (
			inSeg.getID().compareTo(X12Envelope.idInterchangeTrailer) == 0)
			envelope.addSegment(inSeg);
		else if (
			inSeg.getID().compareTo(X12Envelope.idGradeofServiceRequest) == 0)
			envelope.addSegment(inSeg);
		else if (
			inSeg.getID().compareTo(X12Envelope.idDeferredDeliveryRequest)
				== 0)
			envelope.addSegment(inSeg);
		else if (
			inSeg.getID().compareTo(X12Envelope.idInterchangeAcknowledgment)
				== 0)
			envelope.addSegment(inSeg);
		else if (inSeg.getID().compareTo(X12FunctionalGroup.idHeader) == 0)
			functionalGroup.addSegment(inSeg);
		else if (inSeg.getID().compareTo(X12FunctionalGroup.idTrailer) == 0)
			functionalGroup.addSegment(inSeg);

	}

	/** do nothing when an envelope is ended
	*/
	public void endEnvelope(Envelope inEnv) {
		inEnv.validate(de);
	}

	/** do nothing when an fg is ended
	*/
	public void endFunctionalGroup(FunctionalGroup inFG) {
		;
	}

	/** create a Valid XML document for each ts found
	*/
	public void endTransactionSet(TransactionSet inTS) {
		StringWriter sw = new StringWriter();
		try {
			inTS.writeFormattedText(sw, 0);
		}
		catch (IOException ioe)
		{
			sw.write("IOException occured see message:");
			sw.write(ioe.getMessage());
			sw.write("\nstack trace sent to console.");
		}
  	  
  	  
		JTextArea jta = new JTextArea(sw.toString(), 32, 44);		JScrollPane jsp = new JScrollPane(jta);
		jsp.repaint();
		jsp.validate();
		jtp.addTab(inTS.getName(), jsp);
	}

	/** do nothing when an seg is ended
	 * <br>Note that these segments are only envelope and fg segments NOT SEGMENTS inside of Transaction Sets
	*/
	public void endSegment(Segment inSeg) {
		JTextArea jta = new JTextArea(inSeg.getFormattedText(0), 32, 44);
		JScrollPane jsp = new JScrollPane(jta);
		jsp.repaint();
		jsp.validate();
		jtp.addTab(inSeg.getName(), jsp);
	}

	
	public DocumentErrors getDocumentErrors() {
		
		return de;
	}

	/** from command line
	 * <br> java com.americancoders.samples.SampleX12DocumentHandlerAndViewer xxxx, where xxxx is a X12 document filename
	 * <br> error messages displayed in swing message window
	 * <br> program displays incoming document (using formatted report request)
	 * as
	 * <br> tab 1 - opening envelope segments...
	 * <br> tab 2..x - opening fg segments
	 * <br> tab x...y - transaction sets within each fg
	 * <br> tab y...z - closing fg segments
	 * <br> tab z+1 - closing envelope segments
	 */

	public static void main(String args[]) {
		
		try {
			if (args == null || args.length < 1) {
				System.out.println(
					"usage: java com.americancoders.samples.SampleX12DocumentHandlerAndViewer edidatafilename ");
				System.exit(-1);
			}

			FileReader fr = new FileReader(args[0]); // set up to read the file
			new SampleX12DocumentHandlerAndViewer().startParsing(fr);
			//create the class object

			fr.close();

		} catch (Exception e1) {
			e1.printStackTrace();
		}
	}

}