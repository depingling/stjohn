package com.americancoders.edi;

/**
 *OBOE - Open Business Objects for EDI
 *<P>java access to EDI
 *<p>Copyright 1998-2007 - American Coders, LTD  - Raleigh NC USA
 *<p>All rights reserved
 *<p>American Coders, Ltd
 *<br>P. O. Box 97462
 *<br>Raleigh, NC  27624  USA
 *<br>1-919-846-2014
 *<br>http://www.americancoders.com
@author Joe McVerry - American Coders, Ltd.
  @version   3.5.3
 */





/**
 * interface to handle high level edi objects.
 * once the handler is registered with the EDIDocumentParser
 * the Parser will call make individual method calls
 * when the objects are created or finished
 *
 */

public interface EDIDocumentHandler
{

  /** starts the parser with the passed Reader object
   *
   * @param inReader the edi document in a java io Reader object
   * @exception OBOEException
   *                      - unknown transaction set, this transaction set is undefined to OBOE
   *                      - parsing erros
   */

   public void startParsing(java.io.Reader inReader)
     throws OBOEException;


  /** called when an Envelope object is created
   * @param inEnv Envelope found
   */
  public void startEnvelope(Envelope inEnv);


  /** called when an FunctionalGroup object is created
   * @param inFG FunctionalGroup found
   */
  public void startFunctionalGroup(FunctionalGroup inFG);


  /** called when an TransactionSet object is created
   * @param inTS TransactionSet found
   */
  public void startTransactionSet(TransactionSet inTS);


  /** called when an Segment object is created
   * <br>only called for segments at the Envelope and functionalGroup level
   * does not get called for segments within TransactionSet
   * @param inSeg  Segment found
   */
  public void startSegment(Segment inSeg);


  /** called when an Evelope is finished
   * @param inEnv envelope found
   */
  public void endEnvelope(Envelope inEnv);


  /** called when an FunctionalGroup object is finished
   * @param inFG FunctionalGroup found
   */
  public void endFunctionalGroup(FunctionalGroup inFG);


  /** called when an TransactionSet object is finished
   * @param inTS TransactionSet found
   */
  public void endTransactionSet(TransactionSet inTS);


  /** called when an Segment object is finished
   * <br>only called for segments at the Envelope and functionalGroup level
   * does not get called for segments within TransactionSet
   * @param inSeg  Segment found
   */
  public void endSegment(Segment inSeg);

  //public CompositeDE endCompositeDE();
  //public DataElement endDataElement();

  
  public DocumentErrors getDocumentErrors();
}
