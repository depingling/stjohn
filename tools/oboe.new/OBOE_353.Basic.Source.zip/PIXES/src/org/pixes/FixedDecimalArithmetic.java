/*
 * Copyright (C) 2006-2007 by Joseph McVerry - American Coders, Ltd.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

package org.pixes;
import java.math.BigDecimal;

import org.apache.log4j.Logger;

/**
 * @author Joe McVerry - American Coders, Ltd.
 *
 * executor object to do fixed decimal arithmetic
 *
 */
public class FixedDecimalArithmetic {
    Logger logr=Logger.getLogger(FixedDecimalArithmetic.class);
	static {Util.isLog4JNotConfigured();}

	/** 
	 * long value to store
	 */
	long longValue;
	/** 
	 * how many decimal places
	 */
	int decimalPositions;



	/**
	 * object value
	 * @param in comes in as a String
	 */
	public FixedDecimalArithmetic(String in) {
		decimalPositions = in.indexOf('.');
		if (decimalPositions < 0)
			decimalPositions=0;
		else
			decimalPositions=(in.length()-decimalPositions-1);
		try {
            makeString(in, decimalPositions, false);
        } catch (PIXESException e) {
//          this can't happen when false is passed
            logr.error(e.getMessage(), e);
        }

	}

	/**
	 * an object with decimal positions (real or floating or...
	 * @param in value
	 * @param inDecimalPositons 
	 */
	public FixedDecimalArithmetic(String in,int inDecimalPositons) {
		decimalPositions = inDecimalPositons;
		try {
            makeString(in, decimalPositions, false);
        } catch (PIXESException e) {
//          this can't happen when false is passed
            logr.error(e.getMessage(), e);
        }
	}

	/** 
	 * an integer object with decimal positions?
	 * @param in
	 * @param inDecimalPositons
	 */
	public FixedDecimalArithmetic(int in, int inDecimalPositons) {
		longValue=in;
		decimalPositions = inDecimalPositons;
	}

	
	/** 
	 * an Object with fixed decimal places but the value is not quite right yet
	 * @param in
	 * @param inDecimalPositons
	 * @param impliedDecimal
	 * @throws PIXESException
	 */
	public FixedDecimalArithmetic(String in,int inDecimalPositons, boolean impliedDecimal) throws PIXESException {
		decimalPositions = inDecimalPositons;
		makeString(in, inDecimalPositons, impliedDecimal);
	}

	/** 
	 * an int with fixed decimal places but the value is not quite right yet
	 * @param in
	 * @param inDecimalPositons
	 * @param impliedDecimal
	 * @throws PIXESException
	 */
	public FixedDecimalArithmetic(int in, int inDecimalPositons, boolean impliedDecimal) {
		longValue=in;
		decimalPositions = inDecimalPositons;
	}

	/**
	 * turn the object into a String
	 * @param in
	 * @param inDec
	 * @param impliedDecimal
	 * @throws PIXESException
	 */
	private void makeString(String in, int inDec, boolean impliedDecimal) throws PIXESException
	{

		int decPos = in.indexOf('.');
		in = in.trim();
		if (decPos < 0){
			longValue=Long.parseLong(in);
			return;
		}
		else if (impliedDecimal)
		    throw new PIXESException("don't pass a number with a decimal when impliedDecimal is true");

		String intv=in.substring(0,decPos);
		String decv=in.substring(decPos+1);
            if (decv.length() > inDec)
                decv = decv.substring(0, inDec);
            else {
                int dvl = inDec - decv.length();
                for (int i = 0; i < dvl; i++)
                    decv = decv + "0";
            }

		String s = intv+decv;
		if (s.length() > 20) {
		     this.decimalPositions-=(s.length()-19);
		     s = s.substring(0,19);
		}

		longValue=Long.parseLong(s);


	}

	/**
	 * add one FDA to me
	 * @param in
	 */
	public void add(FixedDecimalArithmetic in) {
		if (in.decimalPositions == decimalPositions){
			longValue+=in.longValue;
		    return;
		}
		if (in.decimalPositions < decimalPositions){
			long val = in.longValue;
			for (int i=0; i < (decimalPositions - in.decimalPositions); i++)
				val *= 10;
			longValue+=val;
		    return;
		}
		if (decimalPositions < in.decimalPositions){
			for (int i=0; i < (in.decimalPositions - decimalPositions); i++)
				longValue *=10;
			longValue+=in.longValue;
			decimalPositions = in.decimalPositions;
			/*for (int i=0; i < (in.decimalPositions - decimalPositions); i++)
				longValue /=10;
				*/
		    return;
		}
		System.err.println("add logic error");

	}
	
	/**
	 * substract one FDA from me
	 * @param in
	 */
	public void subtract(FixedDecimalArithmetic in) {
		if (in.decimalPositions == decimalPositions){
			longValue-=in.longValue;
		    return;
		}
		if (in.decimalPositions < decimalPositions){
			long val = in.longValue;
			for (int i=0; i < (decimalPositions - in.decimalPositions); i++)
				val *= 10;
			longValue-=val;
		    return;
		}
		if (decimalPositions < in.decimalPositions){
			for (int i=0; i < (in.decimalPositions - decimalPositions); i++)
				longValue *=10;
			longValue-=in.longValue;
			decimalPositions = in.decimalPositions;
			/*for (int i=0; i < (in.decimalPositions - decimalPositions); i++)
				longValue /=10;
				*/

		    return;
		}

	}
	
	/**
	 * multiply one FDA to me
	 * @param in
	 */
	public void multiply(FixedDecimalArithmetic in){

		BigDecimal bg = new BigDecimal(this.get());


		BigDecimal bg2 = new BigDecimal(in.get());

		decimalPositions +=  in.decimalPositions;

		try {
            makeString(bg.multiply(bg2).toString(), decimalPositions, false);
        } catch (PIXESException e) {
            //  this can't happen when false is passed
            logr.error(e.getMessage(), e);
        }


	}
	
	
	/**
	 * divide one FDA from me
	 * @param in
	 */
	public void divide(FixedDecimalArithmetic in) {
		BigDecimal bg = new BigDecimal(this.get());
		BigDecimal bg2 = new BigDecimal(in.get());
		decimalPositions += in.decimalPositions;
		try {
            makeString(bg.divide(bg2, BigDecimal.ROUND_UP).toString(), decimalPositions, false);
        } catch (PIXESException e) {
//          this can't happen when false is passed
            logr.error(e.getMessage(), e);
        }

	}


	/** 
	 * compare me to another FDA
	 * @param in
	 * @return long value of compare
	 */
	public long compare(FixedDecimalArithmetic in)
	{
		if (in.decimalPositions == decimalPositions){
			return longValue-in.longValue;
		}
		if (in.decimalPositions < decimalPositions){
			long val = in.longValue;
			for (int i=0; i < (decimalPositions - in.decimalPositions); i++)
				val *= 10;
			return longValue-val;
		}
			for (int i=0; i < (in.decimalPositions - decimalPositions); i++)
				longValue *=10;
			return longValue-in.longValue;
	}

	/**
	 * get my value
	 * @return string
	 */
	public String get(){
        StringBuffer buf = new StringBuffer();
        long dec = 1;
        for (int i = 0; i < decimalPositions; i++)
        	dec = dec * 10;
        boolean neg = false;
        if (longValue < 0)
        {
        	neg = true;
        	longValue *= -1;
        }

        if (decimalPositions==0 && (longValue / dec) == 0)
        	return "0";
        if (neg)
        	buf.append('-');

        buf.append( longValue / (dec) );
        if (decimalPositions>0)
        	buf.append( '.' );
        else {
            if (neg)
                longValue *= -1;
        	return buf.toString();
        }


        String frac = Long.toString((Math.abs( longValue ) % (dec)));

        for (int i = frac.length(); i < decimalPositions; i++)
        	buf.append('0');

        buf.append( frac );

        if (neg)
            longValue *= -1;


        return buf.toString();
	}

	/**
	 * simple return me
	 * @return get();
	 */
	public String toString()
	{
		return get();
	}

}
