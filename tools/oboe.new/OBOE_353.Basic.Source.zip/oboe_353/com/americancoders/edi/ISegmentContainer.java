package com.americancoders.edi;

/**
 * Segment Container Interface
 *<p>defines basic segment container methods
 *<P>OBOE - Open Business Objects for EDI
 *<p>Part of the OBOE Basic Extended Package
 *<br>An EDI and XML Translator Written In Java
 *<br>Copyright 1998-2007 - American Coders, LTD  - Raleigh NC USA
 *<br>All rights reserved
 *<br>American Coders, Ltd
 *<br>P. O. Box 97462
 *<br>Raleigh, NC  27624  USA
 *<br>1-919-846-2014
 *<br>http://www.americancoders.com
@author Joe McVerry - American Coders, Ltd.
  @version   3.5.3
 */

public interface ISegmentContainer {

	/** return segment container template
	 * @return TemplateSegmentContainer
	 */

	public TemplateSegmentContainer getTemplateSegmentContainer();

	/** add a segment to the array
	 * @param inSegment Segmemt to add to vector
	 * @throws OBOEException segment doesn't belong
	 */
	public void addSegment(Segment inSegment) throws OBOEException;

	/** removes a Segment from the segmentArray by id, does this by setting array entry to null
	 * can be used to remove all segments with same id at a vectorized position
	 * @param inID String id
	 * @exception OBOEException unknown segment id
	 */

	public void removeSegment(String inID) throws OBOEException;

	/** returns a Segment by its ID
	 * @return Segment objects - null indicates segment not set
	 * @param inID String id of segment to get
	 * @throws OBOEException id not found
	 */

	public Segment getSegment(String inID) throws OBOEException;

	/** returns a Segment by its ID and position in container
	 * @return Segment objects - null indicates segment not set
	 * @param inID String id of segment to get
	 * @param pos int
	 * @throws OBOEException id not found
	 */

	public Segment getSegment(String inID, int pos) throws OBOEException;

	/** creates a static segment
	 * @return Segment based on this Template, will return null if segment not found
	 * @param id String id of subsegment to create
	 * @exception OBOEException if a Vector is defined at this position.
	*/

	public Segment createSegment(String id) throws OBOEException;

	/** returns the ID of the container, Segment ID, "Envelope",...
	 */

	public String getID();
    /** returns the # of segments within container with the id */
	public int getSegmentCount(String id);
}
