package com.americancoders.edi;

import java.io.IOException;
import java.io.PushbackInputStream;
import java.io.Writer;

import org.apache.log4j.Logger;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.americancoders.util.Util;

/**
 *class for all EDI Transaction Sets
 *<p>OBOE - Open Business Objects for EDI
 *<p>Part of the OBOE Basic Extended Package
 *<br>An EDI and XML Translator Written In Java
 *<br>Copyright 1998-2007 - American Coders, LTD  - Raleigh NC USA
 *<br>All rights reserved
 *<br>American Coders, Ltd
 *<br>P. O. Box 97462
 *<br>Raleigh, NC  27624  USA
 *<br>1-919-846-2014
 *<br>http://www.americancoders.com
@author Joe McVerry - American Coders, Ltd.
  @version   3.5.3
 */

public class TransactionSet
	extends SegmentContainer
	implements IContainedObject {

	/**
	* TransactioSet format
	*/
	int format = -1;
	/**
	 * TransactionSet id (840, ORDER...)
	 */
	String id = "";
	/**
	 * TransactionSet name
	 */
	String name = "";
	/**
	 * TransactionSet revision  (3040, D99A...
	 */
	String revision = "";
	/**
	 * TransactionSet functional group
	 */
	String functionalGroup = "";
	/**
	 * TransactionSet description
	 */
	String shortDescription = "";
	/**
	 * TransactionSet XML tag
	 */
	String xmlTag = "";
	/**
	 * TransactionSet tables three of them.
	 */

	TemplateTransactionSet myTemplate = null;

	Table headerTable = null, detailTable = null, summaryTable = null;

	private Segment headerSegment = null; // ST or UNH
	private Segment trailerSegment = null; // SE or UNT
	private boolean typeX12 = false;
	
    static Logger logr = Logger.getLogger(TransactionSet.class);

	static 	{Util.isLog4JNotConfigured();}

	/** creates a transactionset object from a template
	 * @param inTemplateTransactionSet
	    * @param inParent owning Object
	*/
	public TransactionSet(
		TemplateTransactionSet inTemplateTransactionSet,
		IContainedObject inParent) {
		
		
		myTemplate = inTemplateTransactionSet;
		setParent(inParent);
		setFormat(myTemplate.getFormat());
		setID(myTemplate.getID());

		if (getID().length() > 0)
			typeX12 = Character.isDigit(getID().charAt(0));

		setName(myTemplate.getName());
		setRevision(myTemplate.getRevision());
		setShortDescription(myTemplate.getShortDescription());
		setXMLTag(myTemplate.getXMLTag());
		setFunctionalGroup(myTemplate.getFunctionalGroup());

		if (myTemplate.getHeaderTemplateTable() != null)
			headerTable = new Table(myTemplate.getHeaderTemplateTable(), this);
		if (myTemplate.getDetailTemplateTable() != null)
			detailTable = new Table(myTemplate.getDetailTemplateTable(), this);
		if (myTemplate.getSummaryTemplateTable() != null)
			summaryTable =
				new Table(myTemplate.getSummaryTemplateTable(), this);
	}

	/**
	 * parses an EDI Document from tokenized string
	 *
	 * @param TransactionTokenizedString  input string containing all of the transaction data pretokened by OBOE.Tokenizer
	 *
	 * @exception OBOEException
	 *                         thrown when the transaction id string is incorrect
	 * @exception OBOEException
	 *                         thrown when an unknown segment id string is found
	 */
	public boolean parse(ITokenizer TransactionTokenizedString)
		throws OBOEException {

		boolean used = false;

		if (headerTable != null)
			used |= headerTable.parse(TransactionTokenizedString);
		if (detailTable != null)
			used |= detailTable.parse(TransactionTokenizedString);
		if (summaryTable != null)
			used |= summaryTable.parse(TransactionTokenizedString);

		return used;
	}

	/**
	 * continues to parse an EDI Document after an error.
	 * Searches through the containers until last one container to make a good
	 * request is found.  So the process can continue on.
	 *
	 * @param inContainer last container used.
	 *
	 * @param TransactionTokenizedString  input string containing all of the transaction data pretokened by OBOE.Tokenizer
	 *
	 * @return boolean - reparse started
	 *
	 * @exception OBOEException
	 *                         thrown when the transaction id string is incorrect
	 * @exception OBOEException
	 *                         thrown when an unknown segment id string is found
	 */
	public boolean continueParse(
		SegmentContainer inContainer,
		ITokenizer TransactionTokenizedString)
		throws OBOEException {
		boolean restartSucessful = false;
		if (headerTable != null && restartSucessful == false) {
			restartSucessful =
				headerTable.continueParse(
					inContainer,
					TransactionTokenizedString);
			if (restartSucessful) {
				/* when we come out of here the header table should be done
				   so finish the work in the other tables */
				TransactionTokenizedString.resetSegment();
				if (detailTable != null)
					detailTable.parse(TransactionTokenizedString);
				if (summaryTable != null)
					summaryTable.parse(TransactionTokenizedString);
				return true;
			}
		}
		if (detailTable != null && restartSucessful == false) {
			restartSucessful =
				detailTable.continueParse(
					inContainer,
					TransactionTokenizedString);
			if (restartSucessful) {
				/* when we come out of here the header table should be done
				   so finish the work in the summary tables */
				TransactionTokenizedString.resetSegment();
				if (summaryTable != null)
					summaryTable.parse(TransactionTokenizedString);
				return true;
			}
		}
		if (summaryTable != null && restartSucessful == false) {
			restartSucessful =
				summaryTable.continueParse(
					inContainer,
					TransactionTokenizedString);
		}

		return restartSucessful;
	}
	/**
	 * parses a XML EDI Document from a DOM node.
	 *
	 * @param node  XML Node element
	 *
	 * @exception OBOEException
	 *                         thrown when the transaction id string is incorrect
	 * @exception OBOEException
	 *                         thrown when an unknown segment id string is foundi
	 */
	public void parse(Node node) throws OBOEException {
		Node cnode;
		NodeList nl = node.getChildNodes();
		int i;
		for (i = 0; i < nl.getLength(); i++) {

			cnode = nl.item(i);
			if (cnode.getNodeType() != Node.ELEMENT_NODE)
				continue;

			if (cnode.getNodeName().compareTo("header") == 0)
				headerTable.parse(cnode);
			else if (cnode.getNodeName().compareTo("detail") == 0)
				detailTable.parse(cnode);
			else if (cnode.getNodeName().compareTo("summary") == 0)
				summaryTable.parse(cnode);
		}
	}

	/**
	 * parses a FixedLength EDI Document from a Data Input Stream.
	 *
	 * @param pis PushbackInputStream
	 *
	 * @exception OBOEException
	 *                         thrown when the transaction id string is incorrect
	 * @exception OBOEException
	 *                         thrown when an unknown segment id string is foundi
	 */
	public void parse(PushbackInputStream pis) throws OBOEException, IOException {
	 

		int idLen = 0;

		if (headerTable != null) {
			if (headerTable.myTemplate.isLoop(0))
				idLen = headerTable.myTemplate.getTemplateLoop(0).getID().length();
			else
				idLen = headerTable.myTemplate.getTemplateSegment(0).getID().length();

			byte me[] = new byte[idLen];
			if (pis.read(me) != idLen)
				throw new OBOEException("expected data not read");
			String id = Util.rightTrim(new String(me));
			pis.unread(me);
			while (headerTable.doYouWantThisSegment(id) == true) {
				headerTable.parse(pis);
				if (pis.read(me) != idLen)
					throw new OBOEException("expected data not read");
				id = Util.rightTrim(new String(me));
				pis.unread(me);
			}
		}
		if (detailTable != null) {
			if (detailTable.myTemplate.isLoop(0))
				idLen = detailTable.myTemplate.getTemplateLoop(0).getID().length();
			else
				idLen = detailTable.myTemplate.getTemplateSegment(0).getID().length();

			byte me[] = new byte[idLen];
			if (pis.read(me) != idLen)
				throw new OBOEException("expected data not read");
			String id = Util.rightTrim(new String(me));
			pis.unread(me);
			while (detailTable.doYouWantThisSegment(id) == true) {
				detailTable.parse(pis);
				if (pis.read(me) != idLen)
					throw new OBOEException("expected data not read");
				id = Util.rightTrim(new String(me));
				pis.unread(me);
			}
		}
		if (summaryTable != null) {
			if (summaryTable.myTemplate.isLoop(0))
				idLen = summaryTable.myTemplate.getTemplateLoop(0).getID().length();
			else
				idLen = summaryTable.myTemplate.getTemplateSegment(0).getID().length();

			byte me[] = new byte[idLen];
			if (pis.read(me) != idLen)
				throw new OBOEException("expected data not read");
			String id = Util.rightTrim(new String(me));
			pis.unread(me);
			while (summaryTable.doYouWantThisSegment(id) == true) {
				summaryTable.parse(pis);
				if (pis.read(me) != idLen)
					throw new OBOEException("expected data not read");
				id = Util.rightTrim(new String(me));
				pis.unread(me);
			}
		}
	}
	/** sets format for the Transaction Set
	 * <br> XML_FORMAT = 1;
	 * <br> X12_FORMAT = 2;
	 * <br> EDIFACT_FORMAT = 3;
	 * <br> VALID_XML_FORMAT = 4;
	 * @param inFormat int format
	 */
	public void setFormat(int inFormat) {
		if (inFormat == Envelope.XML_FORMAT
			|| inFormat == Envelope.X12_FORMAT
			|| inFormat == Envelope.EDIFACT_FORMAT
			|| inFormat == Envelope.VALID_XML_FORMAT
			|| inFormat == Envelope.TRADACOMS_FORMAT
			|| inFormat == Envelope.ACH_FORMAT)
			format = inFormat;
		else
			logr.error(
				"Invalid transaction set format "
					+ inFormat
					+ ".  Value set to -1");
	}

	/** sets id for the Transaction Set
	* @param inId String transation set id
	*/
	public void setID(String inId) {
		id = inId;
		if (id.length() > 0)
			typeX12 = Character.isDigit(id.charAt(0));
	}

	/** sets name for the Transaction Set
	 * @param inName String transaction set name
	 */
	public void setName(String inName) {
		name = inName;
	}

	/** sets Revision for the Transaction Set
	 * @param inRevision String revision or version
	 */
	public void setRevision(String inRevision) {
		revision = inRevision;
	}

	/** sets Function Group for the Transaction Set
	 * @param inFunctionalGroup String functional group
	 */
	public void setFunctionalGroup(String inFunctionalGroup) {
		functionalGroup = inFunctionalGroup;
	}

	/** sets Short Description for the Transaction Set
	 * @param inDesc String description
	 */
	public void setShortDescription(String inDesc) {
		shortDescription = inDesc;
	}

	/** sets header table for the Transaction Set
	 * @param inTable Table
	 */
	public void setHeaderTable(Table inTable) {
		headerTable = inTable;
	}

	/** sets detail table for the Transaction Set
	 * @param inTable Table
	 */
	public void setDetailTable(Table inTable) {
		detailTable = inTable;
	}
	/** sets summary table for the Transaction Set
	 * @param inTable Table
	 */
	public void setSummaryTable(Table inTable) {
		summaryTable = inTable;
	}

	/** return the transactionset's template
	 @return TemplateTransactionSet
	 */
	public TemplateTransactionSet getTemplateTransactionSet() {
		return myTemplate;
	}

	/** returns the Transaction Set format
	 * @return int
	 */

	public int getFormat() {
		return format;
	}

	/** returns the Transaction Set id
	 * @return String
	 */

	public String getID() {
		return id;
	}

	/**
	 * returns name for the Transaction Set
	 * @return String
	 *
	 */

	public String getName() {
		return name;
	}

	/**
	 * returns revision value for the Transaction Set
	 * @return String
	 *
	 */

	public String getRevision() {
		return revision;
	}

	/**
	 * return Functional Group for the Transaction Set
	 * @return String
	 *
	 */

	public String getFunctionalGroup() {
		return functionalGroup;
	}

	/**
	 * returns the Short Description for the Transaction Set
	 * @return String
	 */
	public String getShortDescription() {
		if (shortDescription == null || shortDescription.length() == 0)
			return id;
		return shortDescription;
	}

	/**
	 * returns header table for the Transaction Set
	 * @return Table
	 *
	 */

	public Table getHeaderTable() {
		return headerTable;
	}

	/**
	 * returns detail table for the Transaction Set
	 * @return Table
	 *
	 */

	public Table getDetailTable() {
		return detailTable;
	}

	/**
	 * returns summary table for the Transaction Set
	 * @return Table
	 *
	 */

	public Table getSummaryTable() {
		return summaryTable;
	}

	/** sets the xml tag field
	 * @param inXMLTag String xml tag id
	 */

	public void setXMLTag(String inXMLTag) {
		xmlTag = inXMLTag;
	}

	/**
	 * returns the xml tag field
	 * @return String tag value
	 */

	public String getXMLTag() {

		return xmlTag;
	}

	/**
	 * validates segment syntax for correct DataElements
	 * @exception OBOEException indicates why segment is invalid
	 */
	public void validate() throws OBOEException {
		if (headerTable != null)
			headerTable.validate();

		if (detailTable != null)
			detailTable.validate();

		if (summaryTable != null)
			summaryTable.validate();

		setHeaderTrailer();

		if (typeX12) {
			DataElement de1 = headerSegment.getDataElement("329");
			DataElement de2 = trailerSegment.getDataElement("329");
			if (de1.get().compareTo(de2.get()) != 0)
				throw new OBOEException("Control Number Mismatch (329)");
		}

		if (typeX12 && trailerSegment != null) {

		int saidCount = Integer.parseInt(trailerSegment.getDataElement("96").get());

		int readCount = getSegmentCount();
		if (saidCount != readCount) {
			throw new OBOEException("Segment Count Mismatch.  Should Be " + readCount);
		}
	}
}

	/**
	 * validates segment syntax for correct DataElements
	 * <br> doesn't throw exception, places error text in DocumentErrors object
	 */
	public void validate(DocumentErrors inDErr) throws OBOEException {
		if (headerTable != null)
			headerTable.validate(inDErr);

		if (detailTable != null)
			detailTable.validate(inDErr);

		if (summaryTable != null)
			summaryTable.validate(inDErr);

		setHeaderTrailer();

		if (typeX12)
			if (headerSegment != null && trailerSegment != null) {
				DataElement de1 = headerSegment.getDataElement("329");
				if (de1 == null) {
					inDErr.addError(0,
						"ST",	"Control Number Mismatch (329)",
						headerTable,"3",
						headerSegment, 3);
					return;
				}
				DataElement de2 = trailerSegment.getDataElement("329");
				if (de2 == null) {
					inDErr.addError(0,	"ST",
						"Control Number Mismatch (329)",
						headerTable,"3",
						headerSegment, 3);
					return;
				}
				if (de1.get() == null || de2.get() == null) {
					inDErr.addError(0,	"ST",
						"Control Number Mismatch (329)",
						headerTable,	"3",
						headerSegment, 3);
					return;
				}
				if (de1.get().compareTo(de2.get()) != 0)
					inDErr.addError(0,	"ST",
						"Control Number Mismatch (329)",
						headerTable,"3",
						headerSegment, 3);
			}


	}

	/**
	 * returns the number of segments
	 * @return int count
	 */

	public int getSegmentCount() {
		int segCount = 0;

		if (headerTable != null)
			segCount += headerTable.getLoopAndSegmentCount();

		if (detailTable != null)
			segCount += detailTable.getLoopAndSegmentCount();

		if (summaryTable != null)
			segCount += summaryTable.getLoopAndSegmentCount();

		return segCount;
	}

	/** returns a formatted string of the transaction set
	 * @return String formattedOutput
	 * @param formatType int format type, x12, edifact, xml...
	 * 
	 */

	public String getFormattedText(int formatType) {

		StringBuffer sbFormattedText = new StringBuffer();
		switch (formatType) {
			case Envelope.XML_FORMAT :
				sbFormattedText.append(
					'<'
						+ getXMLTag()
						+ ">"
						+ com.americancoders.util.Util.lineFeed);
				break;
			case Envelope.VALID_XML_FORMAT :
			case Envelope.VALID_XML_FORMAT_WITH_POSITION :
				sbFormattedText.append("<transactionset code=\"" + getID() + "\"");
		        sbFormattedText.append(" name=\""	+ getName()	+ "\"");
				/*if (format == Envelope.EDIFACT_FORMAT)
				{
					Segment unh = this.getSegment("UNH");
					String v = unh.getCompositeDE("S009").getDataElement("0052").get().trim()+
					           unh.getCompositeDE("S009").getDataElement("0054").get().trim();
					{
					   sbFormattedText.append(" version=\""	+ v	+ "\"");
					}
				}*/
				sbFormattedText.append(">"
						+ com.americancoders.util.Util.lineFeed);
				break;
			case Envelope.PIXES_FORMAT :
				sbFormattedText.append("<transactionset id=\"" + getID() + "\">"	
						+ com.americancoders.util.Util.lineFeed);
				break;

			case Envelope.X12_FORMAT :
				break;
			case Envelope.EDIFACT_FORMAT :
				break;
			case Envelope.TRADACOMS_FORMAT :
				break;
			case Envelope.FIXED_LENGTH_FORMAT :
				break;
			default :
				sbFormattedText.append(
					"Transaction Set: "
						+ getName()
						+ com.americancoders.util.Util.lineFeed);
		}
		if (headerTable != null)
			sbFormattedText.append(headerTable.getFormattedText(formatType));

		if (detailTable != null)
			sbFormattedText.append(detailTable.getFormattedText(formatType));

		if (summaryTable != null)
			sbFormattedText.append(summaryTable.getFormattedText(formatType));

		switch (formatType) {
			case Envelope.XML_FORMAT :
				sbFormattedText.append(
					"</"
						+ getXMLTag()
						+ ">"
						+ com.americancoders.util.Util.lineFeed);
				break;
			case Envelope.VALID_XML_FORMAT :
			case Envelope.VALID_XML_FORMAT_WITH_POSITION :
			case Envelope.PIXES_FORMAT :
				sbFormattedText.append(
					"</transactionset>"
						+ com.americancoders.util.Util.lineFeed);
				break;
			case Envelope.X12_FORMAT :
				break;
			case Envelope.EDIFACT_FORMAT :
				break;
			case Envelope.TRADACOMS_FORMAT :
				break;
			case Envelope.FIXED_LENGTH_FORMAT :
				break;
			default :
				break;
		}

		return new String(sbFormattedText);
	}
	/** like getFormattedText; writes to a Writer object instead
	  * of building a string.
	  * @param inWriter writer - object written to
	  * @param formatType - format type see TransactionSet
	  * @exception OBOEException
	  * @exception IOException
	  */
	
	public void writeFormattedText(Writer inWriter, int formatType)
	  throws IOException {


		switch (formatType) {
			case Envelope.XML_FORMAT :
				inWriter.write(	'<'	+ getXMLTag() + ">"	+ com.americancoders.util.Util.lineFeed);
				break;
			case Envelope.VALID_XML_FORMAT :
			case Envelope.VALID_XML_FORMAT_WITH_POSITION :
				inWriter.write("<transactionset code=\"" + getID() + "\"");
				inWriter.write(" name=\""+ getName()+ "\">"	+ com.americancoders.util.Util.lineFeed);
				break;
			case Envelope.PIXES_FORMAT :
				inWriter.write("<transactionset id=\"" + getID() + "\">"	
						+ com.americancoders.util.Util.lineFeed);
				break;
			case Envelope.X12_FORMAT :
				break;
			case Envelope.EDIFACT_FORMAT :
				break;
			case Envelope.TRADACOMS_FORMAT :
				break;
			case Envelope.FIXED_LENGTH_FORMAT :
				break;
			default :
				inWriter.write("Transaction Set: "	+ getName()	+ com.americancoders.util.Util.lineFeed);
		}
		if (headerTable != null)
			headerTable.writeFormattedText(inWriter, formatType);

		if (detailTable != null)
			detailTable.writeFormattedText(inWriter, formatType);

		if (summaryTable != null)
			summaryTable.writeFormattedText(inWriter, formatType);

		switch (formatType) {
			case Envelope.XML_FORMAT :
				inWriter.write("</"+ getXMLTag()+ ">"
						+ com.americancoders.util.Util.lineFeed);
				break;
			case Envelope.VALID_XML_FORMAT :
			case Envelope.VALID_XML_FORMAT_WITH_POSITION :
			case Envelope.PIXES_FORMAT :
					inWriter.write(	"</transactionset>"
						+ com.americancoders.util.Util.lineFeed);
				break;
			case Envelope.X12_FORMAT :
				break;
			case Envelope.EDIFACT_FORMAT :
				break;
			case Envelope.TRADACOMS_FORMAT :
				break;
			case Envelope.FIXED_LENGTH_FORMAT :
				break;
			default :
				break;
		}

         inWriter.flush();
	}

	/** sets the SE (for X12) or UNT (for EDIFact) control number and count fields
	 */

	public void setTrailerFields() {
		setHeaderTrailer();

		// if you don't have either header or trailer blow up
		if (headerSegment == null)
			throw new OBOEException("Transaction set header segment not found");
		if (trailerSegment == null)
			throw new OBOEException("Transaction set trailer segment not found");

		if (typeX12) {
			trailerSegment.getDataElement("329").set(
				headerSegment.getDataElement("329").get());
			trailerSegment.getDataElement("96").set(Integer.toString(getSegmentCount()));
		} else {
			trailerSegment.getDataElement("0062").set(
				headerSegment.getDataElement("0062").get());
			trailerSegment.getDataElement("0074").set(Integer.toString(getSegmentCount()));
		}
	}

	/** sets the default value for the data elements
	 *<br>does nothing in Basic Edition, just a stub
	 * <br> will call tables useDefault methods, tables will create mandatory subsegments
	  */
	public void useDefault() {

	}

	/** helper routine to setup segments for validation and default value setting
	 */

	private void setHeaderTrailer() {
		headerSegment = null;
		trailerSegment = null;
		if (getHeaderTable() != null) {
			try {
				if (typeX12)
					headerSegment = getHeaderTable().getSegment("ST");
				else
					headerSegment = getHeaderTable().getSegment("UNB");
			} catch (OBOEException oe) {
				;
			}

			try {
				if (typeX12)
					trailerSegment = getHeaderTable().getSegment("SE");
				else
					trailerSegment = getHeaderTable().getSegment("UNT");
			} catch (OBOEException oe) {
				;
			}
		}
		if (getDetailTable() != null) {

			try {
				if (typeX12)
					trailerSegment = getDetailTable().getSegment("SE");
				else
					trailerSegment = getDetailTable().getSegment("UNT");
			} catch (OBOEException oe) {
				;
			}
		}
		if (getSummaryTable() != null) {

			try {
				if (typeX12)
					trailerSegment = getSummaryTable().getSegment("SE");
				else
					trailerSegment = getSummaryTable().getSegment("UNT");
			} catch (OBOEException oe) {
				;
			}
		}

	}

	/**
	 * trims out unused segments and returns number of used segments
	 * @return int
	 */
	public int trim() {
		int count = 0;

		if (headerTable != null)
			count += headerTable.trim();

		if (detailTable != null)
			count += detailTable.trim();

		if (summaryTable != null)
			count += summaryTable.trim();

		return count;

	}

	protected IContainedObject parent = null;
	/** sets parent attribute
	 * @param inParent TemplateSegmentContainer
	 */
	public void setParent(IContainedObject inParent) {
		parent = inParent;
	}

	/** gets parent attribute
	 * @return TemplateSegmentContainer
	 */
	public IContainedObject getParent() {
		return parent;
	}

	/* (non-Javadoc)
	 * @see com.americancoders.edi.ISegmentContainer#getTemplateSegmentContainer()
	 */
	public TemplateSegmentContainer getTemplateSegmentContainer() {
		
		return this.myTemplateContainer;
	}
	/* (non-Javadoc)
	 * @see com.americancoders.edi.IContainedObject#getDelimiter(char)
	 */

		public char getDelimiter(char inOriginal) {
			if (parent == null)
				return inOriginal;
			
			return parent.getDelimiter(inOriginal);
		}

}
