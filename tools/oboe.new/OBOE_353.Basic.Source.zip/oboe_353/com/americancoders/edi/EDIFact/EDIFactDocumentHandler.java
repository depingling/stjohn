package com.americancoders.edi.EDIFact;

/**
 *OBOE - Open Business Objects for EDI
 *<P>java access to EDI
 *<p>Copyright 1998-2007 - American Coders, LTD  - Raleigh NC USA
 *<p>All rights reserved
 *<p>American Coders, Ltd
 *<br>P. O. Box 97462
 *<br>Raleigh, NC  27624  USA
 *<br>1-919-846-2014
 *<br>http://www.americancoders.com
@author Joe McVerry - American Coders, Ltd.
  @version   3.5.3
 */

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.PrintWriter;
import java.io.Reader;

import org.apache.log4j.Logger;

import com.americancoders.edi.DocumentErrors;
import com.americancoders.edi.EDIDocumentHandler;
import com.americancoders.edi.Envelope;
import com.americancoders.edi.FunctionalGroup;
import com.americancoders.edi.OBOEException;
import com.americancoders.edi.Segment;
import com.americancoders.edi.TransactionSet;

import com.americancoders.util.Util;

/**
 * class to parse input string for all defined OBOE Transaction Sets
 * <br> EDIFact dependent
 *
 */

public class EDIFactDocumentHandler implements EDIDocumentHandler {
	EDIFactDocumentParser parser = null;
	EDIFactEnvelope envelope = null;
	//Segment saveServiceString = null;
	//serviceString is parsed well before the envelope is created
	FunctionalGroup functionalGroup = null;
	//TransactionSet transactionSet = null;

	   static Logger logr = Logger.getLogger(EDIFactDocumentHandler.class);
	   
    	static 	{Util.isLog4JNotConfigured();}

	
	
	/**
	 * create a parser for transaction set and parser what is coming from Reader object
	 */

	public EDIFactDocumentHandler() {
		parser = new EDIFactDocumentParser();
		parser.registerHandler(this);
	}

	/**
	 * create a parser for transaction set and parser what is coming from Reader object
	 * <br>if you use this constructor and there are document errors the method
	 * will not make the envelope object available
	 * @param inReader the edi document in a java io reader object
	 * @exception OBOEException
	 *                      - unknown transaction set, this transaction set is undefined to OBOE
	 *                      - parsing errors
	 */

	public EDIFactDocumentHandler(Reader inReader) throws OBOEException {
		parser = new EDIFactDocumentParser();
		parser.registerHandler(this);
		parser.parseDocument(inReader, false);
		envelope.validate(parser.getDocumentErrors());
	}
	/**
	 * create a parser for transaction set and parser what is coming from Reader object
	 * <br>if you use this constructor and there are document errors the method
	 * will not make the envelope object available
	 * @param inString file name of the edi document
	 * @exception OBOEException
	 *                      - unknown transaction set, this transaction set is undefined to OBOE
	 *                      - parsing erros
	 */

	public EDIFactDocumentHandler(String inString) throws OBOEException {
		try {
		    
		    parser = new EDIFactDocumentParser();
		    
		    parser.registerHandler(this);
		    
		    startParsing(new FileReader(inString));
		    
		    envelope.validate(parser.getDocumentErrors());
        } catch (OBOEException e) {
            
            logr.error(e.getMessage(), e);
        } catch (FileNotFoundException e) {
            //  catch block Sep 9, 2005
            logr.error(e.getMessage(), e);
        }
	}

	/** starts the parser with the passed Reader object
	 *
	 * @param inReader the edi document in a java io reader object
	 * @exception OBOEException
	 *                      - unknown transaction set, this transaction set is undefined to OBOE
	 *                      - parsing erros
	 */

	public void startParsing(Reader inReader) throws OBOEException {
		parser.parseDocument(inReader, false);
	    envelope.validate(parser.getDocumentErrors());
	}

	/** called when an Envelope object is created
	 * @param inEnv Envelope found
	 */
	public void startEnvelope(Envelope inEnv) {
		envelope = (EDIFactEnvelope) inEnv;
	}

	/** called when an FunctionalGroup object is created
	 * @param inFG FunctionalGroup found
	 */
	public void startFunctionalGroup(FunctionalGroup inFG) {
		functionalGroup = inFG;
		envelope.addFunctionalGroup(inFG);
	}

	/** called when an TransactionSet object is created
	 * @param inTS TransactionSet found
	 */
	public void startTransactionSet(TransactionSet inTS) {
		functionalGroup.addTransactionSet(inTS);
	}

	/** called when an Segment object is created
	 * <br>only called for segments at the Envelope and functionalGroup level
	 * does not get called for segments within TransactionSet
	 * @param inSeg  Segment found
	 */
	public void startSegment(Segment inSeg) {

		if (inSeg.getID().compareTo(EDIFactEnvelope.idServiceString) == 0)
			envelope.addSegment(inSeg);
		else if (
			inSeg.getID().compareTo(EDIFactEnvelope.idInterchangeHeader) == 0)
			envelope.addSegment(inSeg);
		else if (inSeg.getID().compareTo(EDIFactFunctionalGroup.idHeader) == 0)
			functionalGroup.addSegment(inSeg);
		else if (
			inSeg.getID().compareTo(EDIFactFunctionalGroup.idTrailer) == 0)
			functionalGroup.addSegment(inSeg);
		else if (
			inSeg.getID().compareTo(EDIFactEnvelope.idInterchangeTrailer) == 0)
			envelope.addSegment(inSeg);

	}

	/** called when an Evelope is finished
	 * @param inEnv envelope found
	 */
	public void endEnvelope(Envelope inEnv) {
		;
	}

	/** called when an FunctionalGroup object is finished
	 * @param inFG FunctionalGroup found
	 */
	public void endFunctionalGroup(FunctionalGroup inFG) {
		;
	}

	/** called when an TransactionSet object is finished
	 * @param inTS TransactionSet found
	 */
	public void endTransactionSet(TransactionSet inTS) {
		;
	}

	/** called when an Segment object is finished
	 * <br>only called for segments at the Envelope and functionalGroup level
	 * does not get called for segments within TransactionSet
	 * @param inSeg  Segment found
	 */
	public void endSegment(Segment inSeg) {
		;
	}

	/**
	 * returns the envelope that was parsed
	 * @return Envelope - the envelope when object was built.
	 */
	public Envelope getEnvelope() {
		return envelope;
	}

	/** gets the DocumentErrors object created by the DocumentParser class
	 * @return DocumentErrors
	 */

	/** main method used for testing purposes
	 * <br>format: java filetoparse
	 * <br>writes valid xml format of file to System.out
	 * @param args String array - only one arg accepted - file to parse
	 */

	public static void main(String args[]) {
		EDIFactDocumentHandler dh = null;
		try {
			FileReader fr = new FileReader(args[0]);

			dh = new EDIFactDocumentHandler();
            			
			dh.startParsing(fr);
			
			dh.parser.getDocumentErrors().logErrors();
			fr.close();
			Envelope x = dh.getEnvelope();
			FileOutputStream fos = new FileOutputStream(args[0]+".xml");
			x.writeFormattedText(new PrintWriter(fos), Envelope.VALID_XML_FORMAT);
		} catch (OBOEException oe) {
			logr.error(oe.getMessage(), oe);
			oe.getDocumentErrors().logErrors();
			Envelope x = dh.getEnvelope();
			System.out.println(x.getFormattedText(Envelope.VALID_XML_FORMAT));
			//x.writeFormattedText(new PrintWriter(System.out), Envelope.VALID_XML_FORMAT);

		} catch (Exception e) {
			logr.error(e.getMessage(), e);
		}

	}

	public DocumentErrors getDocumentErrors() {
		
		return parser.getDocumentErrors();
	}

	public EDIFactDocumentParser getParser() {
		return parser;
	}
}
