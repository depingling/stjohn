package com.americancoders.edi.TRADACOMS;

/**
 *OBOE - Open Business Objects for EDI
 *<P>java access to EDI
 *<p>Copyright 1998-2007 - American Coders, LTD  - Raleigh NC USA
 *<p>All rights reserved
 *<p>American Coders, Ltd
 *<br>P. O. Box 97462
 *<br>Raleigh, NC  27624  USA
 *<br>1-919-846-2014
 *<br>http://www.americancoders.com
@author Joe McVerry - American Coders, Ltd.
  @version   3.5.3
 */

import java.io.Reader;
import java.io.StringReader;

import org.apache.log4j.Logger;

import com.americancoders.edi.DataElement;
import com.americancoders.edi.EDIDocumentParser;
import com.americancoders.edi.Envelope;
import com.americancoders.edi.EnvelopeFactory;
import com.americancoders.edi.FunctionalGroup;
import com.americancoders.edi.OBOEException;
import com.americancoders.edi.Segment;
import com.americancoders.edi.TemplateEnvelope;
import com.americancoders.edi.Tokenizer;
import com.americancoders.edi.TransactionSet;
import com.americancoders.edi.TransactionSetFactory;
import com.americancoders.util.Util;

/**
 * class defining methods for parsing EDI Documents
 * <br> Tradacoms2 dependent
 * <br>Document handlers will register with this class to be notified
 * when specific edi objects are created or finished
 * <br>Unlike the old parser these parsers will not contain the
 * objects,  the process of adding objects to owning parents (such as
 * adding functional groups to an envelope) is left up to the document handler.
 */

public class TradacomsDocumentParser extends EDIDocumentParser {
	static Logger logr = Logger.getLogger(TradacomsDocumentParser.class);
	static {Util.isLog4JNotConfigured();}

	/**
	* parses an Tradacoms Document and passes results to EDIDocumentHandlers
	* @exception OBOEException
	*                      - unknown transaction set, this transaction set is undefined to OBOE
	*/
	public TradacomsDocumentParser() {
		super();
	}

	/** method that controls the parsing
	 *  @param inString String edi document
	 *  @exception OBOEException - most likely unknown segment
	 */
	public void parseDocument(String inString) throws OBOEException {

		int posStart;
		posStart = inString.indexOf(TradacomsEnvelope.idInterchangeHeader);
		if (posStart < 0)
			throw new OBOEException(
				TradacomsEnvelope.idInterchangeHeader + " segment missing");
		int posStop = inString.indexOf(TradacomsEnvelope.idInterchangeTrailer);
		if (posStop < 0)
			throw new OBOEException(
				TradacomsEnvelope.idInterchangeTrailer + " segment missing");

		parseDocument(new StringReader(inString));
	}

	/** method that controls the parsing
	 *  @param inReader object containing edi data
	 *  @exception OBOEException - most likely unknown segment
	 *  @deprecated use parseDocument(Reader, boolean)
	 */
	public void parseDocument(Reader inReader) throws OBOEException {
		parseDocument(inReader, true);
	}
	/** method that controls the parsing
	 * @param inReader reader object containing edi data
	 * @param inValidate boolean - call validation logic on envelope if true
	 * <br> if false is used then don't forget to call the validation method
	 * on the envelope object pass it the documenterrors object created here
	 * and getable using the getDocumentErrors method.
	 * 
	 *  @exception OBOEException - most likely unknown segment
	 */
	
		
		public void parseDocument(Reader inReader, boolean inValidate) throws OBOEException {
		TransactionSet parsedTransactionSet;
		TradacomsEnvelope envelope = new TradacomsEnvelope();
        Util.setOBOEProperty("doPrevalidate", "true");
		try {
			TemplateEnvelope te =
				EnvelopeFactory.buildEnvelope("Tradacoms.envelope","notSetYet");
			envelope = new TradacomsEnvelope(te);
		} catch (OBOEException oe) {
			if (oe.getMessage().startsWith("File not found"))
				envelope = new TradacomsEnvelope();
			else
				throw oe;
		}

		notifyStartEnvelope(envelope);

		Tokenizer et = new TradacomsTokenizer(inReader,  dErr);
		// , posStop-1));
		envelope.setDelimiters(et.getSeparators());

		et.getNextSegment(null);
		String findID = et.getNextDataElement();

		if (findID.compareTo(TradacomsEnvelope.idInterchangeHeader) != 0)
			throw new OBOEException(
				"Segment ID "
					+ findID
					+ " found, was expecting "
					+ TradacomsEnvelope.idInterchangeHeader
					+ ".");
		Segment STX_Start_of_Transmission = envelope.createInterchange_Header();
		STX_Start_of_Transmission.setByteOffsetPositionInIncomingDocument(et.getInputByteCount());
		notifyStartSegment(STX_Start_of_Transmission);
		STX_Start_of_Transmission.parse(et);
		notifyEndSegment(STX_Start_of_Transmission);

		findID = et.getCurrentDataElement();
		boolean iterateOnce =
			(findID.compareTo(TradacomsFunctionalGroup.idHeader) != 0);
		if (iterateOnce)
			findID = TradacomsFunctionalGroup.idHeader;

		while (findID.compareTo(TradacomsFunctionalGroup.idHeader) == 0) {
			FunctionalGroup fg = envelope.createFunctionalGroup();
			notifyStartFunctionalGroup(fg);
			if (iterateOnce);
			else {
				Segment BAT_Functional_Group_Header =
					fg.createSegment(TradacomsFunctionalGroup.idHeader);
				BAT_Functional_Group_Header.setByteOffsetPositionInIncomingDocument(et.getInputByteCount());
				notifyStartSegment(BAT_Functional_Group_Header);
				BAT_Functional_Group_Header.parse(et);
				notifyEndSegment(BAT_Functional_Group_Header);
			}
			findID = et.getCurrentDataElement();

			while (findID.compareTo("MHD") == 0) {
				et.getNextDataElement();
				findID = et.getNextDataElement();
				findID = findID.substring(0,6);
				et.resetSegment();
				DataElement de = STX_Start_of_Transmission.getCompositeDE("FROM").getDataElement(1);
				String from = "";
				if (de != null)  from = de.get();
				de = STX_Start_of_Transmission.getCompositeDE("UNTO").getDataElement(1);
				String unto = "";
				if (de != null)  unto = de.get();
				
					parsedTransactionSet =
						TransactionSetFactory.buildTransactionSet(findID, null,
				// use OBOE.properties searchDirective
							STX_Start_of_Transmission.getCompositeDE("STDS").getDataElement(2).get(), // version
							from, // receiver
							unto, // sender
							"");// test/production does not exist
				//parsedTransactionSet = TransactionSetFactory.buildTransactionSet(findID);
				parsedTransactionSet.setParent(fg);
				parsedTransactionSet.setFormat(Envelope.TRADACOMS_FORMAT);
				notifyStartTransactionSet(parsedTransactionSet);
				parsedTransactionSet.parse(et);
				while (true) {
					findID = et.getCurrentDataElement();
					logr.debug("finding " + findID);
					if (findID.compareTo("MHD") == 0) {
						notifyEndTransactionSet(parsedTransactionSet);
						break;
					} else if (
						findID.compareTo(TradacomsFunctionalGroup.idTrailer) == 0) {
						notifyEndTransactionSet(parsedTransactionSet);
						break;
						}
					 else if (findID.compareTo(TradacomsEnvelope.idInterchangeTrailer) == 0) {
							if (!iterateOnce)
								et.reportError("Should not appear before end of functional group");
							notifyEndTransactionSet(parsedTransactionSet);
							break;
					} else if (
						findID.compareTo(TradacomsEnvelope.idInterchangeTrailer)
							== 0) {
						et.reportError(
							"Should not appears before end of functional group",
							"2");
						notifyEndTransactionSet(parsedTransactionSet);
						break;
					} else if (findID.length() > 0) {

						//et.reportError("Unknown or out of place segment", "2");

						et.getLastSegmentContainer().whyNotUsed(et);
						// here is where we put logic to try and get back into sync.
						et.getNextSegment(et.getLastSegmentContainer());
						et.getNextDataElement();
						parsedTransactionSet.continueParse(
							et.getLastSegmentContainer(),
							et);
					} else {
						et.reportError("Empty Data Line Error", "?");
						// here is where we put logic to try and get back into sync.
						et.getNextSegment(et.getLastSegmentContainer());
						et.getNextDataElement();
						parsedTransactionSet.continueParse(
							et.getLastSegmentContainer(),
							et);
					}
				}			}

			if (iterateOnce);
			else if (findID.compareTo(TradacomsFunctionalGroup.idTrailer) != 0) {
				dErr.addError(0,TradacomsFunctionalGroup.idTrailer,"More segments to process starting at segment position "
				+ et.getSegmentPos()
				+ ". Problem "
				+ et.getCurrentDataElement()
				+ " is not defined. Expecting "
				+ TradacomsFunctionalGroup.idTrailer,envelope,"0",null,1);
				/*throw new OBOEException(
					"More segments to process starting at position "
						+ et.getSegmentPos()
						+ ". Problem "
						+ et.getCurrentDataElement()
						+ " is not defined. Expecting "
						+ TradacomsFunctionalGroup.idTrailer);*/
			} else {
				Segment UNE_Functional_Group_Trailer =
					fg.createSegment(TradacomsFunctionalGroup.idTrailer);
				UNE_Functional_Group_Trailer.setByteOffsetPositionInIncomingDocument(et.getInputByteCount());
				notifyStartSegment(UNE_Functional_Group_Trailer);

				UNE_Functional_Group_Trailer.parse(et);
				notifyEndSegment(UNE_Functional_Group_Trailer);
				findID = et.getCurrentDataElement();
			}
			notifyEndFunctionalGroup(fg);
		}

		if (findID.compareTo(TradacomsEnvelope.idInterchangeTrailer) != 0) {
			dErr.addError(0,TradacomsEnvelope.idInterchangeTrailer,"More segments to process starting at segment position "
			+ et.getSegmentPos()
			+ ". Problem "
			+ et.getCurrentDataElement()
			+ " is not defined. Expecting "
			+ TradacomsEnvelope.idInterchangeTrailer,envelope,"0",null,1);
			/*	throw new OBOEException(
				"More segments to process starting at segment position "
					+ et.getSegmentPos()
					+ ". Problem "
					+ et.getCurrentDataElement()
					+ " is not defined. Expecting "
					+ TradacomsEnvelope.idInterchangeTrailer); */
		} else {
			Segment END_Interchange_Trailer =
				envelope.createInterchange_Trailer();
			END_Interchange_Trailer.setByteOffsetPositionInIncomingDocument(et.getInputByteCount());
			notifyStartSegment(END_Interchange_Trailer);
			END_Interchange_Trailer.parse(et);
			notifyEndSegment(END_Interchange_Trailer);
			notifyEndEnvelope(envelope);
			if (inValidate)
			envelope.validate(dErr);

			if (com.americancoders.util.Util.propertyFileIndicatesThrowParsingException()
				&& dErr.getErrorCount() > 0) {
				dErr.logErrors();
				logr.info("doprevalidate="+Util.propertyFileIndicatesDoPrevalidate());
				throw new OBOEException(dErr);
			}

		}

	}

}
