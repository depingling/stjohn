/*
 * Copyright (C) 2006-2007 by Joseph McVerry - American Coders, Ltd.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

package org.pixes;

import java.util.Enumeration;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;


/**
 * @author Joe McVerry - American Coders, Ltd.
 *
 * executor object to dump/display variables
 *
 */
public class DumpVariables extends Executable implements IExecutable {
    static {Util.isLog4JNotConfigured();}


	/**
	 * debugging level
	 */
	Level dbgLvl;


	/**
	 * @param line - int xml line number
	 * @param parser - who's in charge
	 */

	public DumpVariables(int line, Parser parser) {
    	super(parser);
	    logr = Logger.getLogger(DumpVariables.class);
	    setLogger();
		dbgLvl = prsr.logr.getLevel();
        logr.setLevel(dbgLvl);
		logr.debug("dump variable constructor "+line);
		setMyXMLLine(line);
	}


	/**
	 * execute and return next step
	 * @return next step
	 */
	public int execute(Executor inExec) {
		exec = inExec;
		exec.logr.setLevel(dbgLvl);
		logr.setLevel(dbgLvl);

		Enumeration et = exec.getVarStack().getVariables().keys();
		if (getDebugListener() == null)
			prsr.getOutProcessFile().println("<dumpVariables>");
		else
			getDebugListener().displayOut("<dumpVariables>");
		while(et.hasMoreElements()){
			String s = (String) et.nextElement();
			try {
				if (getDebugListener() == null)
					prsr.getOutProcessFile().println("<"+s+">"+exec.getVarStack().get(s)+"</"+s+">");
				else
					getDebugListener().displayOut("<"+s+">"+exec.getVarStack().get(s)+"</"+s+">");
			} catch (Exception e) {

				logr.error(e.getMessage());
				return -1;
			}
		}
		if (getDebugListener() == null)
			prsr.getOutProcessFile().println("</dumpVariables>");
		else
			getDebugListener().displayOut("</dumpVariables>");

		return getNextStep();
	}
}
