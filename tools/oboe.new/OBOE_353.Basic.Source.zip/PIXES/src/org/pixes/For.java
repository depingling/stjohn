/*
 * Copyright (C) 2006-2007 by Joseph McVerry - American Coders, Ltd.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

package org.pixes;



import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.xml.sax.Attributes;


/**
 * @author Joe McVerry - American Coders, Ltd.
 *
 * executor object to do for statement processing
 *
 */
public class For extends Executable{


    static {Util.isLog4JNotConfigured();}
    /**
     * debugging level
     */
    Level dbgLvl;


    /**
     * me again?
     *
     */
    ForExecute fexec;

    /**
     * my name, start value, incrementor
     */
    String name, from, to, by="1";

    /**
     * list of valid comparison operators
     */
    static String opers[] = {"eq", "ne", "lt", "gt", "le", "ge"};

    /**
     * position of operator in string
     */
    int oper;

	/**
	 * @param line - int xml line number
	 * @param attr - Attributes
	 * @param parser - Parser
	 */

	public For(int line, Attributes attr,  Parser parser) throws PIXESException {
    	super(parser);
    	logr = Logger.getLogger(For.class);
    	setLogger();
		dbgLvl = prsr.logr.getLevel();

		logr.debug("constructor " + attr + line);

		setMyXMLLine(line);
		name = attr.getValue("name");

		if (parser.getVarStack().testVar(name)== false)
		{
			return;
		}

		String operator = attr.getValue("operator");
		if (operator == null)
		{
			throw new PIXESException("no compareOperator at line "+ line);
		}
		boolean found = false;
		for (oper = 0; oper < opers.length && found == false; oper++)
		{
			found = operator.compareTo(opers[oper])==0;
		}

		if (found == false)
		{
			throw new PIXESException("bad compareOperator "+operator+" at line "+ line);
		}
		oper--;
		from = attr.getValue("from");
		fexec = new ForExecute(this, prsr);

		if (parser.getVarStack().testVar(from)== false)
		{
			return;
		}
		to = attr.getValue("to");
		if (parser.getVarStack().testVar(to)== false)
		{
			return;
		}
		String tryBy = attr.getValue("by");
		if (tryBy != null && parser.getVarStack().testVar(tryBy)== true)
		{
			by = tryBy;
			return;
		}


	}


	/**
	 * not used? yet?
	 * @param withinLine
	 */
	public void setWithinLine(int withinLine) {
		//this.withinLine = withinLine;
	}

	/**
	 * execute and return next step
	 * @return int
	 */
	public int execute(Executor inExec) {
		fexec.setStartup();
		return getNextStep();

	}


	/**
	 * if at the end of the loop where do we go
	 * @return the next step to continue at
	 */
	public int getContinueStep() {
		return fexec.getContinueStep();
	}



	/**
	 * the real meat and potatoes of the for loop
	 * @author joseph mcverry
	 *
	 */
	public static class ForExecute extends Executable implements IContinuable{
	    Logger logr;
	    For myFor;
	    private String name, from, to, by="1";
	    int continueStep = -1;
	    Parser prsr;
	    private int oper;

		FixedDecimalArithmetic fdName = null;
		FixedDecimalArithmetic fdBy = null;
		FixedDecimalArithmetic fdTo = null;

	    boolean startup = true;

	    public ForExecute(For inFor, Parser parser) {
	    	super(parser);
	     	logr = Logger.getLogger(this.getClass());
	    	Util.isLog4JNotConfigured();
	    	logr.setLevel(inFor.dbgLvl);
	        logr.debug("constructor");
	        myFor = inFor;
	        prsr = parser;
	        setMyXMLLine(inFor.getMyXMLLine());
	    }



		public void setStartup() {
			name = myFor.name;
			from = myFor.from;
			to = myFor.to;
			by = myFor.by;
			oper = myFor.oper;
			startup = true;
		}



		public int getContinueStep() {
			return continueStep;
		}
		public void setContinueStep(int continueStep) {
			this.continueStep = continueStep;
		}
		public int execute(Executor inExec) {

			logr.debug(" calling execute " + name + " " + from
					+ " " + to + " " + by);
			boolean bln = false;


			if (startup == true) {
				startup = false;
			  	try {
			  		inExec.getVarStack().put(name, inExec.getVarStack().replaceString(from));
				} catch (Exception e) {

					logr.error(e.getMessage());
					return -1;
				}
				try {
					fdName = new FixedDecimalArithmetic(from);
				} catch (java.lang.NumberFormatException nfe) {
					logr.error("invalid value for from value " + from);
					return -1;
				}

			}


			else {

				try {
					fdBy = new FixedDecimalArithmetic(by);
				} catch (java.lang.NumberFormatException nfe) {
					logr.error("invalid value for by value " + by);
					return -1;
				}
				try {
					fdName = new FixedDecimalArithmetic(inExec.getVarStack().get(name));
				} catch (Exception e) {
					logr.error("can't find name in var table " + name);
					return -1;
			}
				fdName.add(fdBy);
				inExec.getVarStack().put(name, fdName.get());

			}
			try {
				fdTo = new FixedDecimalArithmetic(to);
			} catch (Exception e) {
				logr.error("can't find to in var table " + name);
				return -1;
			}

			switch (oper) {
			case 0: // equal

					bln = fdName.compare(fdTo) == 0;

				break;
			case 1: // not equal
					bln = fdName.compare(fdTo) != 0;

				break;
			case 2: // less than
					bln = fdName.compare(fdTo) < 0;

				break;
			case 3: // greater than

					bln = fdName.compare(fdTo) > 0;

				break;
			case 4: // less than or equal

					bln = fdName.compare(fdTo) <= 0;

				break;
			case 5: // greater than or equal

					bln = fdName.compare(fdTo) >= 0;

				break;

			default:
				logr.fatal("logic error");
				break;
			}



			if (bln == false) // we've reached the end
				return getNextStep();
			else
				return continueStep;




		}

	}

	public ForExecute getFexec() {
		return fexec;
	}



}
