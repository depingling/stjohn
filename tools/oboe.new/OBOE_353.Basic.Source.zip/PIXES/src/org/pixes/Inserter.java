/*
 * Copyright (C) 2006-2007 by Joseph McVerry - American Coders, Ltd.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

package org.pixes;

import java.sql.SQLException;
import java.sql.Statement;
import java.util.StringTokenizer;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.xml.sax.Attributes;



/**
 * @author Joe McVerry - American Coders, Ltd.
 *
 * executor object to do database inserts
 *
 */
public class Inserter extends Executable {

    static {Util.isLog4JNotConfigured();}

    /** sql table */
    String table;
    /** table fields in unbounded format */
    String fldnames;
    /** array of table fields */
    String fields[];
    /** field values in unbounded format */
    String values;
    /** sql/jdbc connector object */
    Connecter connecter;
    /** debugging level */
    Level dbgLvl;


	/**
	 * @param line - int xml line number
	 * @param attr - Attributes
	 * @param connecter - Connecter
	 * @param parser - Parser
	 */

	public Inserter(int line, Attributes attr, Connecter connecter, Parser parser) throws PIXESException {

		super(parser);

	    logr = Logger.getLogger(Inserter.class);
	    setLogger();
		dbgLvl = prsr.logr.getLevel();
        logr.setLevel(dbgLvl);
		logr.debug("Inserter constructor " +line);
		setMyXMLLine(line);
		this.connecter = connecter;
		table = attr.getValue("table");
		if (table == null) {
			throw new PIXESException("no table specified at line " + line);

		}
		logr.debug("table specified as " + table);
		fldnames = attr.getValue("fields");
		if (fldnames == null) {
			throw new PIXESException("no fields specified at line " + line);
		}
		StringTokenizer st = new StringTokenizer(fldnames, ",");
		fields = new String[st.countTokens()];
		for (int i = 0; i < fields.length; i++) {
			fields[i] = st.nextToken();
			logr.debug("using field named " + fields[i]);
		}
		values = attr.getValue("values");
		logr.debug("values specfied as " + values);




	}


	/**
	 * execute the code and return the next step
	 * @return the next step
	 */
	public int execute(Executor inExec) {
		exec = inExec;
		exec.logr.setLevel(dbgLvl);
		logr.setLevel(dbgLvl);

		String sql="INSERT INTO "+table+" (";
		StringBuffer sb = new StringBuffer();
		for (int i=0; i<fields.length;i++)
		{
			sb.append(fields[i]);
			if (i+1<fields.length)
				sb.append(", ");
		}
		sql = sql+new String(sb)+") VALUES(";
		StringTokenizer st = new StringTokenizer(values, ",");
		String val;
		sb = new StringBuffer();
		for (int i = 0; i < fields.length; i++) {
			val  = st.nextToken().trim();
			if (val.startsWith("'") && val.endsWith("'")){
			  	sb.append("'"+val+"'");
			}
			else if (val.startsWith("\"") && val.endsWith("\"")){
			  	sb.append("'"+val.substring(1,val.length()-1)+"'");
			}
			else {
				  	try {
						sb.append("'"+exec.getVarStack().replaceString(val)+"'");
					} catch (Exception e1) {

						logr.error(e1.getMessage());
						return -1;
					}
			}
			if (i+1<fields.length)
				sb.append(", ");
		}
		sql=sql+new String(sb)+");";
		logr.debug("executing "+sql);
		try {

		Statement stmnt = connecter.getConnection().createStatement();
		stmnt.execute(sql);


		}
		catch (SQLException e){
			logr.error("SQL PIXESException: "+e.getErrorCode()+" "+e.getMessage());
			logr.error(e.getSQLState());

			return -1;
		}

		return this.getNextStep();

	}

}
