/*
 * Copyright (C) 2006-2007 by Joseph McVerry - American Coders, Ltd.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

package org.pixes;

import java.sql.SQLException;
import java.sql.Statement;
import java.util.Hashtable;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.xml.sax.Attributes;


/**
 * @author Joe McVerry - American Coders, Ltd.
 *
 * executor object to do a database delete
 *
 */
public class Deleter extends Executable {

    static {Util.isLog4JNotConfigured();}

    /**
     * jdbc table
     */
    String table;
    /**
     * sql where clause
     */
    String where;
    /**
     * jdbc connector object
     */
    Connecter connecter;
    /**
     * debugging level
     */
    Level dbgLvl;


	/**
	 * @param line - int xml line number
	 * @param attr - Attributes
	 * @param parser - Parser
	 */

	public Deleter(int line, Attributes attr, Connecter connecter, Parser parser) throws PIXESException {
    	super(parser);
	    logr = Logger.getLogger(Deleter.class);
	    setLogger();
		dbgLvl = prsr.logr.getLevel();
        logr.setLevel(dbgLvl);
		logr.debug("Deleter constructor "+line);
		setMyXMLLine(line);
		this.connecter = connecter;
		table = attr.getValue("table");
		if (table == null) {
			throw new PIXESException("no table specified at line " + line);

		}
		logr.debug("table specified as " + table);
		where = attr.getValue("where");
		if (where == null) {
			throw new PIXESException("no where clause specified at line " + line);
		}



	}


	/**
	 * execute the delete request and return next step
	 * @return next step
	 */

	public int execute(Executor inExec) {
		exec = inExec;
		exec.logr.setLevel(dbgLvl);
		logr.setLevel(dbgLvl);

		String sql="DELETE FROM "+table+" where ";
		try {
			sql=sql+exec.getVarStack().replaceString(where)+";";
		} catch (Exception e1) {
			logr.error(e1.getMessage());
			return -1;
		}
		logr.debug("executing "+sql);
		try {
		Statement stmnt = connecter.getConnection().createStatement();
		stmnt.executeUpdate(sql);

		}
		catch (SQLException e){
			logr.error("SQL PIXESException: "+e.getErrorCode()+" "+e.getMessage());
			logr.error(e.getSQLState());

			return -1;
		}

		return this.getNextStep();

	}
	/**
	 * testing code - test with when not using parsexcutor
	 * @param tbl - String table name
	 * @param connecter - Connecter
	 * @param whr - String where statement
	 * @param ht - hashtable to store contents.
	 * @throws PIXESException
	 */
	public Deleter(String tbl, Connecter connecter,  String whr, Hashtable ht) throws PIXESException {

		super(null);
		logr.debug("Deleter test constructor");
		table = tbl;
		if (table == null)
		{
			throw new PIXESException("no table specified at line ");


		}
		where = whr;
		if (connecter == null)
		{
			throw new PIXESException("a connector must be defined before this select " );
		}
		this.connecter = connecter;

		//this.vars = ht;

	}
}
