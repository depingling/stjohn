package com.americancoders.edi;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.lang.reflect.Method;
import java.util.Vector;

import org.w3c.dom.Node;




/**
 * class for Template Tables
 * a general class for the transaction set's heading detail and summary.
 *
 *<p>OBOE - Open Business Objects for EDI
 *<p>Part of the OBOE Basic Extended Package
 *<br>An EDI and XML Translator Written In Java
 *<br>Copyright 1998-2007 - American Coders, LTD  - Raleigh NC USA
 *<br>All rights reserved
 *<br>American Coders, Ltd
 *<br>P. O. Box 97462
 *<br>Raleigh, NC  27624  USA
 *<br>1-919-846-2014
 *<br>http://www.americancoders.com
@author Joe McVerry - American Coders, Ltd.
  @version   3.5.3
 */
public  class TemplateTable extends TemplateLoopContainer implements
                                Externalizable,
                                IContainedObject
{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/** String XML tag
     */
    protected String xmlTag = "";

    /** constructor takes no parameters
     */
    public TemplateTable()
    {
        templateContainer = new Vector();
        setXMLTag("Unknown");
    }

    /** Constructor
     * @param xmlTag String XML tag
     * @param inParent owning Object
     */
    public TemplateTable(String xmlTag, IContainedObject inParent)
    {
        templateContainer = new Vector();
        setXMLTag(xmlTag);
        setParent(inParent);
    }


    /** tests if the node is part of this table
     * @return boolean true it is part of this table
     * @param node DOM node of transaction data
     * @exception OBOEException thrown when the transaction id string is incorrect
     * @exception OBOEException thrown when an unknown segment id string is foundi
     */
    public boolean doYouWantThisNode(Node node)
    throws OBOEException
    {

        for (int i=0; i < templateContainer.size(); i++)
        {
            if (node.getNodeName().compareTo(((TemplateSegment) templateContainer.elementAt(i)).getXMLTag()) == 0)
            return true;
        }

        return false;
    }


    /** returns the table id, since there are no tables id it returns a zero-length string
     * @return String
     */
    public String getID()
     { return "";}

    /** sets the xml tag field
     * @param inXMLTag String tag
     */

   public void  setXMLTag(String inXMLTag){xmlTag = inXMLTag;}

    /**
     * returns the xml tag field
     * @return String tag value
     */

   public String getXMLTag() { return xmlTag; }


    /** used by externalize methods
     * @param in ObjectInput stream
     * @exception IOException - most likely class changed since written
     * @exception ClassNotFoundException - only when dummy constructro not found
     */

    public void readExternal(ObjectInput in)
    throws IOException, ClassNotFoundException
    {
        xmlTag = in.readUTF();
        templateContainer = (Vector) in.readObject();
        for (int i=0; i<getCount(); i++)
           ((IContainedObject)templateContainer.elementAt(i)).setParent(this);
    }

    /** used by externalize methods
     * @param out ObjectOutput stream
     * @exception IOException java.io error
     */
    public void writeExternal(ObjectOutput out)
    throws IOException
    {
        out.writeUTF(xmlTag);
        out.writeObject(templateContainer);
    }


    IContainedObject parent = null;
    /** sets parent attribute
     * @param inParent templateContainer
     */
    public void setParent(IContainedObject inParent) {parent = inParent;}

    /** gets parent attribute
     * @return templateContainer
     */
    public IContainedObject  getParent() { return parent;}

   /* (non-Javadoc)
    * @see com.americancoders.edi.IContainedObject#getDelimiter(char)
    */

   	public char getDelimiter(char inOriginal) {
   		if (parent == null)
   			return inOriginal;
   		return parent.getDelimiter(inOriginal);
   	}

}

