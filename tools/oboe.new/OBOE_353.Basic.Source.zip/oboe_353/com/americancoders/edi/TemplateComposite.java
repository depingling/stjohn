package com.americancoders.edi;


import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.lang.reflect.Method;
import java.util.Vector;

/** Template Composite holds preliminary structure of Composites
 *<p>OBOE - Open Business Objects for EDI
 *<p>Part of the OBOE Basic Extended Package
 *<br>An EDI and XML Translator Written In Java
 *<br>Copyright 1998-2007 - American Coders, LTD  - Raleigh NC USA
 *<br>All rights reserved
 *<br>American Coders, Ltd
 *<br>P. O. Box 97462
 *<br>Raleigh, NC  27624  USA
 *<br>1-919-846-2014
 *<br>http://www.americancoders.com
@author Joe McVerry - American Coders, Ltd.
  @version   3.5.3
 */
public class TemplateComposite implements
                                IIdentifier,
                                Externalizable,
                                IContainedObject,
								ITemplateElementContainer
{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/** composite id
     */
    protected String id;
    /** composite name
     */
    protected String name;
    /** required indictor
     */
    protected  char required = ' ';
    /** composite sequeunce within segment
     */
    protected int sequence = 0;
    /** composite description
     */
    protected String description;
    /** composite XML tag
     */
    protected String xmlTag;

    /**
     * where its de's go.
     */
    protected Vector templateDEVector;
    /**
      occurs some many times
      */
    protected int occurs = 1;

    /** returns used attribute
     * @return boolean
     */
 	public boolean isUsed() {
 		return used;
 	}
     /** sets used attribute
 	    * @param used boolean
 	    */
 	
 	public void setUsed(boolean used) {
		this.used = used;
	}
 	
    protected boolean used = true;

    /** Constructor
     */
    public TemplateComposite() {}



    /** TemplateComposite, there are two flavors of composites Templates and regular
     * <P> templates are used to define a composite dynamically
     * <p> and are used to build the static form of composites
     * <p> contains template data element
     * @param inId String id of composite
     * @param inName composite name
     * @param inRequired required indicator
     * @param inSequence sequence within segment
     * @param inDescription String description
     * @param inXMLTag String xml tag
     * @param inParent owning Object
     * @param inOccurs int
     * @param inUsed boolean
     */

    public TemplateComposite(String inId, String inName, char inRequired, int inSequence, String inDescription, String inXMLTag, IContainedObject inParent, int inOccurs, boolean inUsed)
    {
        setID(inId);
        setName(inName);
        setRequired(inRequired);
        setSequence(inSequence);
        setDescription(inDescription);
        templateDEVector = new Vector();
        setXMLTag(inXMLTag);
        setParent(inParent);
        setOccurs(inOccurs);
        setUsed(inUsed);
     }


    /** returns the number of elements in DEVector
     * @return int count
     */

public int getTemplateDESize() { return templateDEVector.size(); }

    /** sets TemplateComposite id
     * @param inID String id of composite
     */
public void setID(String inID) {id = inID; }

    /*8
     * sets TemplateComposite name
     * @param string inName composite name
     */
    /** sets composite name
     * @param inName String name
     */
public void setName(String inName) {name = inName; }

    /** gets TemplateComposite id
     * @return string inID composite id
     * @return String
     */
public String getID() { return id; }
    /** gets TemplateComposite name
     * @return string  composite name
     * @return String name
     */
public String getName() { return name; }

    /**
     * @param inRequired char required indicator
     */
public void setRequired(char inRequired){ required = inRequired; }


    /**
     * gets required indicator
     * @return char
     */
public char getRequired(){ return required; }

    /** sets sequence
     * @param inSequence int sequence within segment
     */
public void setSequence(int inSequence){ sequence = inSequence; }


    /**
     * gets sequence
     * @return int sequence
     */
public int getSequence(){ return sequence; }

    /** sets Description for the Segmemt
     * @param inDesc String description
     */

public void setDescription(String inDesc) {description = inDesc;}

    /**
     * returns the Description for the Segment
     * @return String
     */
public String getDescription() {return description;}

    /** sets the xmltag field
     * @param inXMLTag String XML Tag
     */


    public void  setXMLTag(String inXMLTag)
    {
        xmlTag = inXMLTag;
    }

    /**
     * returns the xml tag field
     * @return String tag value
     */


    public String getXMLTag()
    {
        if (xmlTag == null) return getID();
        return xmlTag;
    }

    /** adds  TemplateDE to container
     * <br> checks for duplicate entry at sequence position
     * @param inTemplateDE TemplateDE to add
     * @exception OBOEException -Sequence position already filled
     */
    public void addTemplateDE(TemplateDE inTemplateDE)
      { int pos = inTemplateDE.getSequence()-1;
        if (pos < templateDEVector.size())
          if (isTemplateDE(pos+1))
             throw new OBOEException("Position for DataElement with ID="+inTemplateDE.getID()+" at " + (pos+1) + " already filled  for composite "+getID()+" "+getName());
        if (pos >= templateDEVector.size())
           templateDEVector.setSize(pos);
        templateDEVector.insertElementAt(inTemplateDE, pos);
      }


    /** gets TemplateDE from TemplateDE container by position
     * @return TemplateDE at the specified position
     * @param at int  position of dataelement
     * <br><b>position is relative to 1.</b>
     */
    public TemplateDE getTemplateDE(int at)
      {return (TemplateDE) templateDEVector.elementAt(at-1); }

    /**
     * gets TemplateDE from TemplateDE container by ID
     * @param id of TemplateDE in container
     * @return TemplateDE null if not found
     */
    public TemplateDE getTemplateDE(String id)
    {
        TemplateDE tDE;
        for (int i = 0 ; i < templateDEVector.size(); i++) {
            tDE = (TemplateDE) templateDEVector.elementAt(i);
            if (tDE == null)
            	continue;
            if (tDE.getID().compareTo(id) == 0) return tDE;
        } /* endif */
        return null;
    }

    /** tests if the element at a position is a TemplateDE
     * @return boolean
     * @param at int position
     * <br><b>position is relative to 1.</b>
     */
    public boolean isTemplateDE(int at)
    {
      if (templateDEVector.elementAt(at-1)==null)
           return false;
      return (templateDEVector.elementAt(at-1) instanceof com.americancoders.edi.TemplateDE);
    }

    /** routine to ask if it uses a dataelement
     * @return boolen true the segment id is part of this group
     * @param inID String id
     */
    public int doYouUseThisElement(String inID, int startAt)
    {
        IIdentifier iid;
        for (int i=startAt+1; i<templateDEVector.size(); i++)
        {   iid = (IIdentifier) templateDEVector.elementAt(i);
            if (iid == null)
            	continue;
            if ( iid.getID().compareTo(inID) == 0)
            return i;
        }
        return -1;
    }
    /** routine to ask if it uses a dataelement by its XML Tag
     * @return int position , -1 not  found
     * @param inXML tag of dataelement
     * @param startAt int position
     */
    public int doYouUseThisXMLElement(String inXML, int startAt)
    {
        IIdentifier iid;
        for (int i=startAt+1; i<templateDEVector.size(); i++)
        {   iid = (IIdentifier) templateDEVector.elementAt(i);
            if (iid == null)
            	continue;
            if ( iid.getXMLTag().compareTo(inXML) == 0)
            return i;
        }
        return -1;
    }

    /** used by externalize methods
     * @param in ObjectInput object input stream
     * @exception IOException - most likely class changed since written
     * @exception ClassNotFoundException - only when dummy constructro not found
     */

    public void readExternal(ObjectInput in)
    throws IOException, ClassNotFoundException
    {
        id = in.readUTF();
        name = in.readUTF();
        required = in.readChar();
        sequence = in.readInt();
        description = in.readUTF();
        xmlTag = in.readUTF();
        used = in.readBoolean();
        templateDEVector = (Vector) in.readObject();
        for (int i=0; i < getTemplateDESize(); i++)
        {
            if (isTemplateDE(i+1)){
            TemplateDE tde = getTemplateDE(i+1);
            tde.setParent(this);
            }
        }

    }

    /** used by externalize methods
     * @param out ObjectInput object input stream
     * @exception IOException java.io.error
     */
    public void writeExternal(ObjectOutput out)
    throws IOException
    {
        out.writeUTF(id);
        out.writeUTF(name);
        out.writeChar(required);
        out.writeInt(sequence);
        out.writeUTF(description);

        out.writeUTF(xmlTag);
        out.writeBoolean(used);
        out.writeObject(templateDEVector);

    }
    protected IContainedObject parent=null;
    
    /** sets parent attribute
     * @param inParent TemplateSegmentContainer
     */
    public void setParent(IContainedObject inParent) {parent = inParent;}

    /** gets parent attribute
     * @return parent container
     */
    public IContainedObject  getParent() { return parent;}


	/**
	 * sets the occurs value
	 * @param inOccurs
	 */
	public void setOccurs(int inOccurs) { occurs = inOccurs; }

	/**
	 * gets the occurs value
	 * @return int
	 */
	public int  getOccurs() { return occurs; }

    /**
     * helper routine to get fields that are not built
     * @return String
     */


    public String getEmptyData()
     {
        StringBuffer sb = new StringBuffer();
        TemplateDE tDE;
        for (int i = 0 ; i < templateDEVector.size(); i++) {
            tDE = (TemplateDE) templateDEVector.elementAt(i);
            if (tDE != null)
                  sb.append(tDE.getEmptyData());
        }
        return new String(sb);
     }
   /* (non-Javadoc)
    * @see com.americancoders.edi.ITemplateElementContainer#addTemplateComposite(com.americancoders.edi.TemplateComposite)
    */
   public void addTemplateComposite(TemplateComposite inTemplateComposite) throws OBOEException {
   	throw new OBOEException("can not add TemplateComposite to TemplateComposite");
   	
   }
   /* (non-Javadoc)
    * @see com.americancoders.edi.ITemplateElementContainer#isTemplateComposite(int)
    */
   public boolean isTemplateComposite(int at) {
   	// 
   	return false;
   }
   
   /* (non-Javadoc)
    * @see com.americancoders.edi.IContainedObject#getDelimiter(char)
    */

   	public char getDelimiter(char inOriginal) {
   		
   		return parent.getDelimiter(inOriginal);
   	}


}
