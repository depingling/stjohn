// com.yahoo.platform.yui.compressor.YUICompressTask
package com.yahoo.platform.yui.compressor;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.DirectoryScanner;
import org.apache.tools.ant.Project;
import org.apache.tools.ant.Task;
import org.apache.tools.ant.types.FileSet;
import org.mozilla.javascript.ErrorReporter;
import org.mozilla.javascript.EvaluatorException;

/**
 * ANT Task used to compress a set of files to a target folder.
 * @author <a href="mailto:p.mouawad@ubik-ingenierie.com">Philippe Mouawad</a>
 * www.ubik-ingenierie.com
 *
 */
public class YUICompressTask extends Task{
	
	private Boolean warn = Boolean.FALSE;
	private Boolean munge = Boolean.FALSE;
	private Boolean preserveAllSemiColons = Boolean.TRUE;
	private Boolean preserveStringLitterals = Boolean.TRUE;
	private Integer lineBreak = null;
	private String outputSuffix;
	private File outputFolder;
	private String charset;
	private List inputFileSet = new ArrayList();
	
	/**
	 * 
	 */
	public YUICompressTask() {
		super();
	}

	/**
	 * @see org.apache.tools.ant.Task#execute()
	 */	
	public void execute() throws BuildException {

		validate();
		
		for (Iterator iter = inputFileSet.iterator(); iter.hasNext();) 
		{
			FileSet fs = (FileSet)iter.next();
			DirectoryScanner ds = fs.getDirectoryScanner(getProject());
			File base  = ds.getBasedir();     
			String[] includedFiles = ds.getIncludedFiles();
			for(int i=0; i<includedFiles.length; i++) {
				includedFiles[i] = includedFiles[i].replace('\\', '/');
				
				String includePrefix = "";
				if(includedFiles[i].lastIndexOf('/') != -1)
				{
					includePrefix = includedFiles[i].substring(0,includedFiles[i].lastIndexOf('/'));
				}
				File found = new File(base, includedFiles[i]);                
                File targetFolder = null;
                if(includePrefix.length()>0)
                {
                	targetFolder = new File(outputFolder,includePrefix);
                }
                else
                {
                	targetFolder = new File(outputFolder.getAbsolutePath());
                }
                targetFolder.mkdirs();
                File outputFile = null;
                System.out.println(includedFiles[i] +":" + targetFolder.getAbsolutePath());
            	if(outputSuffix!=null && !(outputSuffix.trim().length()==0))
                {
            		String theFileName = found.getName();
                	int lastIndex = theFileName.lastIndexOf(".");
                	
                	outputFile = new File(targetFolder, theFileName.substring(0, lastIndex) + outputSuffix + 
                			theFileName.substring(lastIndex));
                }
            	else
            	{
            		String theFileName = found.getName();
            		outputFile = new File(targetFolder, theFileName);                	
            	}

            	try {
					doCompression(found, outputFile);
				} catch (Exception e) {
					log("Error compressing "+found.getAbsolutePath() + ", "+e.getMessage(), Project.MSG_ERR);
					throw new BuildException("Error compressing "+found.getAbsolutePath() + ", "+e.getMessage(), e);
				}
            }
		}
	}
	
	/**
	 * 
	 */
	private void validate() {
		if(charset==null)
		{
			charset = System.getProperty("file.encoding");
	        if(charset == null)
	        {
	        	charset = "UTF-8";
	        }
		}
		
		this.munge = (this.munge != null) ? munge : Boolean.FALSE;
		this.lineBreak = (this.lineBreak==null) ? new Integer(-1) : this.lineBreak;		
	}
	
	
	/**
	 * @param src
	 * @param dst
	 * @throws IOException
	 */
	private static final void copy(File src, File dst) throws IOException 
	{
        InputStream in = null;
        OutputStream out = null;
        try
        {
        	in = new FileInputStream(src);
        	out = new FileOutputStream(dst);
	        // Transfer bytes from in to out
	        byte[] buf = new byte[1024];
	        int len = 0;
	        while ((len = in.read(buf)) > 0) 
	        {
	            out.write(buf, 0, len);
	        }
        }
        finally
        {
        	if (in!=null)
        	{
        		try {
					in.close();
				} catch (IOException e) {
					// NOOP
				}
        	}
        	if (out!=null)
        	{
        		try {
        			out.close();
				} catch (IOException e) {
					// NOOP
				}
        	}
        }
    }

	
	/**
	 * @param string
	 * @param outputFile
	 */
	private void doCompression(File inputFile, File outputFile)
		throws Exception
	{		
		log("Compressing " + inputFile.getAbsolutePath() + " to " + outputFile.getAbsolutePath());
		Reader reader = null;
		Writer writer = null;
		File tempFile = null;
		outputFile.getParentFile().mkdirs();
		try
		{			
			if(inputFile.getAbsolutePath().equals(outputFile.getAbsolutePath()))
        	{
				log("Input and Output file are the same, creating a copy");
				tempFile = File.createTempFile("temp", 
	        			inputFile.getName().substring(inputFile.getName().lastIndexOf(".")));
				log("Copying "+inputFile.getAbsolutePath() + " to " + tempFile.getAbsolutePath());        		
        		copy(inputFile, tempFile);
        		reader = new BufferedReader(new FileReader(tempFile));
        	}
        	else
        	{
        		reader = new BufferedReader(new FileReader(inputFile));
        	}
        	
			if(outputFile.getName().endsWith(".js"))
			{				
	            try {
	                JavaScriptCompressor compressor = new JavaScriptCompressor(reader, 
	                		new ErrorReporter() {	
	                    public void warning(String message, String sourceName,
	                            int line, String lineSource, int lineOffset) {
	                        if (line < 0) {
	                            log("\n[WARNING] " + message);
	                        } else {
	                        	log("\n" + line + ':' + lineOffset + ':' + message);
	                        }
	                    }
	
	                    public void error(String message, String sourceName,
	                            int line, String lineSource, int lineOffset) {
	                        if (line < 0) {
	                        	log("\n[ERROR] " + message);
	                        } else {
	                            log("\n" + line + ':' + lineOffset + ':' + message);
	                        }
	                    }
	
	                    public EvaluatorException runtimeError(String message, String sourceName,
	                            int line, String lineSource, int lineOffset) {
	                        error(message, sourceName, line, lineSource, lineOffset);
	                        return new EvaluatorException(message);
	                    }
	                });
	
	                // Close the input stream first, and then open the output stream,
	                // in case the output file should override the input file.
	                writer = new OutputStreamWriter(new FileOutputStream(outputFile), charset);

	                compressor.compress(writer, 
	                		lineBreak.intValue(), 
	                		munge.booleanValue(), 	
	                		warn.booleanValue(),
	                		preserveAllSemiColons.booleanValue(),
	                        preserveStringLitterals.booleanValue());
	
	            } catch (EvaluatorException e) {
	
	                e.printStackTrace();
	                // Return a special error code used specifically by the web front-end.
	                System.exit(2);
	            }
	
	        } 
			else if (outputFile.getName().endsWith(".css")) 
	        {	
	            CssCompressor compressor = new CssCompressor(reader);	
	            // Close the input stream first, and then open the output stream,
	            // in case the output file should override the input file.
	            writer = new OutputStreamWriter(new FileOutputStream(outputFile), charset);	
	            compressor.compress(writer, getLineBreak()!=null ? getLineBreak().intValue() : -1);
	        }
		}
		finally
		{
			if(reader!=null)
			{
				try {
					reader.close();
				} catch (IOException e) {
					// NOOP
				}
			}
			if(writer!=null)
			{
				try {
					writer.close();
				} catch (IOException e) {
					// NOOP
				}
			}
			if(tempFile!=null)
			{
				tempFile.delete();
			}

		}
	}
	
	/**
	 * @param list {@link List}
	 * @return {@link String} Command line
	 */
	private String getLine(List list) {
		StringBuffer buffer = new StringBuffer();
		for (Iterator iter = list.iterator(); iter.hasNext();) {
			String element = (String) iter.next();
			buffer.append(element);
			buffer.append(" ");
		}
		return buffer.toString();
	}


	
	/**
	 * @param fileset
	 */
	public void addFileset(FileSet fileset) {
        inputFileSet.add(fileset);
    }

	/**
	 * @return the charset
	 */
	public String getCharset() {
		return charset;
	}

	/**
	 * @param charset the charset to set
	 */
	public void setCharset(String charset) {
		this.charset = charset;
	}

	/**
	 * @return the lineBreak
	 */
	public Integer getLineBreak() {
		return lineBreak;
	}

	/**
	 * @param lineBreak the lineBreak to set
	 */
	public void setLineBreak(Integer lineBreak) {
		this.lineBreak = lineBreak;
	}

	/**
	 * @return the munge
	 */
	public Boolean getMunge() {
		return munge;
	}

	/**
	 * @param munge the munge to set
	 */
	public void setMunge(Boolean munge) {
		this.munge = munge;
	}

	/**
	 * @return the outputFolder
	 */
	public File getOutputFolder() {
		return outputFolder;
	}

	/**
	 * @param outputFolder the outputFolder to set
	 */
	public void setOutputFolder(File outputFolder) {
		this.outputFolder = outputFolder;
	}

	/**
	 * @return the outputSuffix
	 */
	public String getOutputSuffix() {
		return outputSuffix;
	}

	/**
	 * @param outputSuffix the outputSuffix to set
	 */
	public void setOutputSuffix(String outputSuffix) {
		this.outputSuffix = outputSuffix;
	}

	/**
	 * @return the preserveAllSemiColons
	 */
	public Boolean getPreserveAllSemiColons() {
		return preserveAllSemiColons;
	}

	/**
	 * @param preserveAllSemiColons the preserveAllSemiColons to set
	 */
	public void setPreserveAllSemiColons(Boolean preserveAllSemiColons) {
		this.preserveAllSemiColons = preserveAllSemiColons;
	}

	/**
	 * @return the preserveStringLitterals
	 */
	public Boolean getPreserveStringLitterals() {
		return preserveStringLitterals;
	}

	/**
	 * @param preserveStringLitterals the preserveStringLitterals to set
	 */
	public void setPreserveStringLitterals(Boolean preserveStringLitterals) {
		this.preserveStringLitterals = preserveStringLitterals;
	}

	/**
	 * @return the warn
	 */
	public Boolean getWarn() {
		return warn;
	}

	/**
	 * @param warn the warn to set
	 */
	public void setWarn(Boolean warn) {
		this.warn = warn;
	}
}
