/*
 * Copyright (C) 2006-2007 by Joseph McVerry - American Coders, Ltd.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

package org.pixes;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;



/**
 * @author Joe McVerry - American Coders, Ltd.
 *
 * executor object to display messages
 *
 */
public class Display extends Executable {

	/**
	 * value to display
	 */
	String display;


	/**
	 * debugging level
	 */
	Level dbgLvl;
	/**
	 * @param line - int xml line number
	 * @param displayString
	 * @param parser - Parser
	 */

	public Display(int line, String displayString, Parser parser) {
    	super(parser);
	    logr = Logger.getLogger(Display.class);
	    setLogger();
    	dbgLvl = prsr.getLogger().getLevel();
        logr.setLevel(dbgLvl);
		setMyXMLLine(line);
		logr.debug(displayString);
		display = displayString;
	}

	/**
	 * execute display and return next step
	 * @return next step
	 */
	public int execute(Executor inExec) {

		exec = inExec;
		prsr.getLogger().setLevel(dbgLvl);
	    logr.setLevel(dbgLvl);
		try {
		       if (getDebugListener() != null)
		    	   getDebugListener().displayOut(exec.getVarStack().replaceString(display));
		       else
			       prsr.getProcessOutStream().println(exec.getVarStack().replaceString(display));
		} catch (Exception e) {

			logr.error(e.getMessage());
			return -1;
		}
		return getNextStep();
	}
}
