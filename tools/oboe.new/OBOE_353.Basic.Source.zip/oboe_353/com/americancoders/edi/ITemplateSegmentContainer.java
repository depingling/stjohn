package com.americancoders.edi;

/** interface for Segment Container
 * <br> used by tables and segments
 *
 * <P>OBOE - Open Business Objects for EDI
 * <br>An EDI and XML Translator Written In Java
 * <br>Copyright 1998-2007 - American Coders, LTD  - Raleigh NC USA
 * <br>All rights reserved
 * <br>American Coders, Ltd
 * <br>P. O. Box 97462
 * <br>Raleigh, NC  27624  USA
 * <br>1-919-846-2014
 * <br>http://www.americancoders.com
 * @author Joe McVerry - American Coders, Ltd.
  @version   3.5.3
 */

public interface ITemplateSegmentContainer {


	/** returns a Segment
	 * @return Segment objects - null indicates segment not set
	 * @param ID String ID of TemplateSegment to look for
	 * @exception OBOEException ID is unknown to this Segment
	 */

	public TemplateSegment getTemplateSegment(String ID) throws OBOEException;

	/** returns a Segment
	 * @return Segment objects - null indicates segment not set
	 * @param pos int pos TemplateSegment to look for
	 * @exception OBOEException ID is unknown to this Segment
	 */

	public TemplateSegment getTemplateSegment(int pos) throws OBOEException;

	/** sets a Segment
	 * <UL>
	 * <li> may be used to add a new Segment
	 * <li> may be used to change an existing Segment
	 * <li> may be used to remove an Segment, this is done by passing a null object
	 * </ul>
	 * @param templateSegmentObject TemplateSegment to be added
	 * @exception OBOEException Segment is unknown
	 */

	public void addTemplateSegment(TemplateSegment templateSegmentObject)
		throws OBOEException;

	/** implemented for interface
	 * @return int
	 */
	public int getCount();

}
