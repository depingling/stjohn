//$$allSkip
package com.americancoders.samples;




import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStream;
import java.io.Reader;
import java.text.SimpleDateFormat;
import java.util.Vector;

import javax.servlet.ServletException;

import jxl.Workbook;
import jxl.format.Colour;
import jxl.write.Label;
import jxl.write.WritableCellFormat;
import jxl.write.WritableFont;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;

import org.apache.log4j.Logger;

import com.americancoders.edi.CompositeDE;
import com.americancoders.edi.DataElement;
import com.americancoders.edi.DocumentErrors;
import com.americancoders.edi.EDIDocumentHandler;
import com.americancoders.edi.Envelope;
import com.americancoders.edi.FunctionalGroup;
import com.americancoders.edi.IContainedObject;
import com.americancoders.edi.IDDE;
import com.americancoders.edi.Loop;
import com.americancoders.edi.LoopAndSegmentContainer;
import com.americancoders.edi.Segment;
import com.americancoders.edi.Table;
import com.americancoders.edi.TransactionSet;
import com.americancoders.edi.x12.X12DocumentParser;
import com.americancoders.edi.x12.X12Envelope;
import com.americancoders.edi.x12.X12FunctionalGroup;
import com.americancoders.util.Util;
/**
 * excel sample
 *<P>OBOE - Open Business Objects for EDI
 *<br>An EDI and XML Translator Written In Java
 *<br>Copyright 1998-2007 - American Coders, LTD  - Raleigh NC USA
 *<br>All rights reserved
 *<br>American Coders, Ltd
 *<br>P. O. Box 97462
 *<br>Raleigh, NC  27624  USA
 *<br>1-919-846-2014
 *<br>http://www.americancoders.com

@author Joe McVerry - American Coders, Ltd.
@version buildNotToBeReleased
 */


public class Excel implements EDIDocumentHandler {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	X12Envelope envelope = null;
	FunctionalGroup functionalGroup = null;

	SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd-HH.mm.ss");
	
    static Logger logr = Logger.getLogger(Excel.class);
    static {Util.isLog4JNotConfigured();}

    
    public static void main(String args[]) throws IOException
    {
    	if (args.length != 2)
    	{
    		System.err.println("format: com.americancoders.samples.Excel inputfilename outputfilename");
    		return;
    	}
    	FileReader fr = new FileReader(args[0]);
    	FileOutputStream fw = new FileOutputStream(args[1]);
    	Excel xc = new Excel();
    	xc.doExcel(fr, fw);
    	
    }
                                         
    
	public Excel() 
	{
		super();
		wcf = new WritableFont(WritableFont.TIMES);
	    errFormat = new WritableCellFormat();
		try{
		wcf.setColour(Colour.RED);
		errFormat.setFont(wcf);
		}
		catch (WriteException we) {}
		
	}
	

	WritableWorkbook wb;

	WritableSheet errSheet=null, dataSheet=null;
	WritableFont wcf;
	
    WritableCellFormat errFormat;

	
	/**
	 * @param rdr Reader object
	 * @param outStream response
	 * @throws IOException io
	 * @throws ServletException required for method call
	 */
	public void doExcel(Reader rdr, OutputStream outStream)
			throws IOException {


		wb = Workbook.createWorkbook(outStream);
		dataSheet = wb.createSheet("data", 0);
		errSheet = wb.createSheet("other errors", 1);
		
		Util.setOBOEProperty("doPrevalidate", "false");
		
		X12DocumentParser p1 = new X12DocumentParser(); // create a parser object
		p1.registerHandler(this); // register with the parser
		p1.parseDocument(rdr, false); // start doing some work
		envelope.validate(p1.getDocumentErrors());
		doExcel(p1, errSheet, dataSheet);

			wb.write();
			try {
				wb.close();
			} catch (WriteException e) {
				logr.error(e.getMessage(), e);
			} catch (IOException e) {
				logr.error(e.getMessage(), e);
			}

	}

	/**
	 * @param p1 document parser
	 * @param errSheet excel sheet
	 * @param dataSheet excel sheet
	 */
	
	
	private void doExcel(X12DocumentParser p1, WritableSheet errSheet, WritableSheet dataSheet) {

		
	 DocumentErrors dh = p1.getDocumentErrors();
	 if (dh == null)
	 	dh = new DocumentErrors();
	 
	 myInteger myRow = new myInteger(); 
	 boolean reported[] = new boolean[dh.getErrorCount()];

	 printRequest(envelope, dataSheet, dh, reported, myRow);
	 try {
	  	
      for (int i = 0; i < p1.getDocumentErrors().getErrorCount(); i++)
      {
      	if (reported[i] == true)
      		continue;
      	errSheet.addCell(new Label(0,i,dh.getErrorID(i)));
      	errSheet.addCell(new Label(1,i,dh.getErrorCode(i)));
      	errSheet.addCell(new Label(2,i,""+dh.getErrorPosition(i)));
      	errSheet.addCell(new Label(3,i,dh.getContainer(i).getID() ));
      	errSheet.addCell(new Label(4,i,dh.getErrorDescription(i)));
      }
     }
     catch(Exception e)
	 {
     	logr.error(e.getMessage(), e);
	 }
		
	}
	public void printRequest(
			X12Envelope envelope,
			WritableSheet dataSheet, 
			DocumentErrors dh, 
			boolean reported[], 
			myInteger inInt) {
		report(envelope.getInterchange_Header(), dataSheet, dh, reported, inInt);
		report(envelope.getGrade_of_Service_Request(),  dataSheet,dh, reported, inInt);
		report(envelope.getDeferred_Delivery_Request(),  dataSheet,dh, reported, inInt);
		report(envelope.getFunctionalGroups(),  dataSheet,dh, reported, inInt);
		report(envelope.getInterchange_Trailer(),  dataSheet,dh, reported, inInt);
		}


	/**
	 * @param s segment
	 * @param dataSheet
	 * @param dh
	 * @param reported
	 * @param inInt
	 */
	private void report(Segment s, WritableSheet dataSheet, DocumentErrors dh, boolean[] reported, myInteger inInt)
	{
		if (s == null)
			return;
		int i;
		DataElement currentDE;
		CompositeDE currentComposite;
        int pos = inInt.getInt();
        
        try {
    		dataSheet.addCell(new Label(0, pos, s.getID()));
    		dataSheet.addCell(new Label(1, pos, s.getName()));
    		for (int j = 0; j < dh.getErrorCount(); j++) {
    			if (reported[j])
    				continue;
    			if (dh.getContainer(j) == s) {
    				i = inInt.getInt();
    				
    		      	dataSheet.addCell(new Label(0,i,dh.getErrorID(j),errFormat));
    		      	dataSheet.addCell(new Label(1,i,dh.getErrorCode(j),errFormat));
    		      	dataSheet.addCell(new Label(2,i,""+dh.getErrorPosition(j),errFormat));
    		      	dataSheet.addCell(new Label(3,i,dh.getErrorDescription(j),errFormat));
    		      	//dataSheet.addCell(new Label(4,i,dh.getContainer(j).getID(),errFormat ));
    				reported[j] = true;
    			}
    		}
        }
        catch (Exception e)
		{
        	logr.error(e.getMessage(), e);
        	return;
		}

		for (i = s.getDataElementSize() ; i > 0; i--) {
			if (s.isCompositeDE(i)) {
				if (s.getCompositeDE(i).getDataElementLength() > 0)
					break;
			} else if (s.isDataElement(i)) {
				if (s.getDataElement(i).get() != null)
					break;
			}

		}
		int elementsUsed = i;

		for (i = 0; i < elementsUsed + 1; i++) {
			
			if (s.isCompositeDE(i)) {
				currentComposite = s.getCompositeDE(i);
				if (currentComposite.getDataElementLength() > 0)
					report(currentComposite, dataSheet, dh, reported, inInt);
			} else if (s.isDataElement(i)) {
				currentDE = s.getDataElement(i);
				report(currentDE, dataSheet, dh, reported, inInt);
			}

			}

		try {
		for (int j = 0; j < dh.getErrorCount(); j++) {
			if (reported[j])
				continue;
			if (amITheParent(s,dh.getContainer(j))) {
				i = inInt.getInt();
		      	dataSheet.addCell(new Label(0,i,dh.getErrorID(j),errFormat));
		      	dataSheet.addCell(new Label(1,i,dh.getErrorCode(j),errFormat));
		      	dataSheet.addCell(new Label(2,i,""+dh.getErrorPosition(j),errFormat));
		      	dataSheet.addCell(new Label(3,i,dh.getErrorDescription(j),errFormat));
		      	//dataSheet.addCell(new Label(4,i,dh.getContainer(j).getID(),errFormat ));
				reported[j] = true;
			}
		
		} }
        catch (Exception e)
		{
        	logr.error(e.getMessage(), e);
        	return;
		}

		
	}
	/**
	* @param cde
	* @param dataSheet
	* @param dh
	* @param reported
	* @param inInt
	*/
	private void report(CompositeDE cde, WritableSheet dataSheet, DocumentErrors dh, boolean[] reported, myInteger inInt) {
		if (cde == null)
			return;
		try {
			int pos = inInt.getInt();
			dataSheet.addCell(new Label(2, pos, cde.getSequence()+""));
			dataSheet.addCell(new Label(3, pos, cde.getID()));
		for (int j = 0; j < dh.getErrorCount(); j++) {
			if (reported[j])
				continue;
			if (dh.getContainer(j) == cde) {
				int i = inInt.getInt();
		      	dataSheet.addCell(new Label(0,i,dh.getErrorID(j), errFormat));
		      	dataSheet.addCell(new Label(1,i,dh.getErrorCode(j), errFormat));
		      	dataSheet.addCell(new Label(2,i,""+dh.getErrorPosition(j), errFormat));
		      	dataSheet.addCell(new Label(3,i,dh.getErrorDescription(j), errFormat));
		      	//dataSheet.addCell(new Label(4,i,dh.getContainer(j).getID(), errFormat ));
				reported[j] = true;
			}
		}
		for (int j = 0; j < dh.getErrorCount(); j++) {
			if (reported[j])
				continue;
			if (amITheParent(cde, dh.getContainer(j))== true) {
				int i = inInt.getInt();
		      	dataSheet.addCell(new Label(0,i,dh.getErrorID(j), errFormat));
		      	dataSheet.addCell(new Label(1,i,dh.getErrorCode(j), errFormat));
		      	dataSheet.addCell(new Label(2,i,""+dh.getErrorPosition(j), errFormat));
		      	dataSheet.addCell(new Label(3,i,dh.getErrorDescription(j), errFormat));
		      	//dataSheet.addCell(new Label(4,i,dh.getContainer(j).getID(), errFormat ));
				reported[j] = true;
			}
		}


        }
        catch (Exception e)
		{
        	logr.error(e.getMessage(), e);
        	return;
		}
	}

		/**
		* @param de
		* @param dataSheet
		* @param dh
		* @param reported
		* @param inInt
		*/
		private void report(DataElement de, WritableSheet dataSheet, DocumentErrors dh, boolean[] reported, myInteger inInt) {
			if (de == null || de.get() == null)
				return;
			int pos = inInt.getInt();
		       try {
				dataSheet.addCell(new Label(2, pos, de.getSequence()+""));
				dataSheet.addCell(new Label(3, pos, de.getID()));
				dataSheet.addCell(new Label(4, pos, de.get()));
				if (de instanceof IDDE)
				{
				   IDDE id = (IDDE) de;
                   dataSheet.addCell(new Label(9, pos, id.describe()));
		        }
			for (int j = 0; j < dh.getErrorCount(); j++) {
				if (reported[j])
					continue;
				if (dh.getContainer(j) == de  || (amITheParent(de, dh.getContainer(j))== true)) {
					int i = inInt.getInt();
			      	dataSheet.addCell(new Label(0,i,dh.getErrorID(j), errFormat));
			      	dataSheet.addCell(new Label(1,i,dh.getErrorCode(j), errFormat));
			      	dataSheet.addCell(new Label(2,i,""+dh.getErrorPosition(j), errFormat));
			      	dataSheet.addCell(new Label(3,i,dh.getErrorDescription(j), errFormat));
			      	//dataSheet.addCell(new Label(4,i,dh.getContainer(j).getID(), errFormat));
					reported[j] = true;
				}
		  }
		       }
		        catch (Exception e)
				{
		        	logr.error(e.getMessage(), e);
		        	return;
				}
		}

		
		public boolean amITheParent(IContainedObject me, IContainedObject it)
		{
			if (it == null)
				return false;
			if (me == it)
				return true;
			return amITheParent(me, it.getParent());
		}
	/**
	 * @param v Vector functionalGroups 
	 * @param dataSheet
	 * @param dh
	 * @param reported
	 * @param inInt
	 */
	private void report(Vector v, WritableSheet dataSheet, DocumentErrors dh, boolean[] reported, myInteger inInt) {
		FunctionalGroup fg;
		TransactionSet ts;
		for (int i = 0; i < v.size(); i++) {
			Object o = v.elementAt(i);
			int pos = inInt.getInt();
			if (o instanceof FunctionalGroup) {
				fg = (FunctionalGroup) o;
		        try {
		    		dataSheet.addCell(new Label(1, pos, "Functional Group "+i));
		    		dataSheet.addCell(new Label(3, pos, fg.getID()));
		        }
		        catch(Exception e){
		        	logr.error(e.getMessage(), e);
		        	return;
		        	
		        }
				report(fg.getHeader(), dataSheet, dh, reported, inInt);
				report(fg.getTransactionSets(), dataSheet,  dh, reported, inInt);
				report(fg.getTrailer(), dataSheet,  dh, reported, inInt);
			}
			if (o instanceof TransactionSet) {
				ts = (TransactionSet) o;
				report(ts, dataSheet,  dh, reported, inInt);
			}
		}
		
	}

	/**
	 * @param ts
	 * @param dataSheet
	 * @param dh
	 * @param reported
	 * @param inInt
	 */
	private void report(TransactionSet ts, WritableSheet dataSheet, DocumentErrors dh, boolean[] reported, myInteger inInt) {
		if (ts == null)
			return;
			
		int pos = inInt.getInt();
        try {
    		dataSheet.addCell(new Label(1, pos, "Transaction Set "));
    		dataSheet.addCell(new Label(3, pos, ts.getID()));
    		dataSheet.addCell(new Label(4, pos, ts.getName()));
	
		report(ts.getHeaderTable(), dataSheet,dh, reported, inInt);
		report(ts.getDetailTable(), dataSheet,dh, reported, inInt);
		report(ts.getSummaryTable(), dataSheet,dh, reported, inInt);
		for (int j = 0; j < dh.getErrorCount(); j++) {
			if (reported[j])
				continue;
			if (dh.getContainer(j) == ts) {
				int i = inInt.getInt();
		      	dataSheet.addCell(new Label(0,i,dh.getErrorID(j), errFormat));
		      	dataSheet.addCell(new Label(1,i,dh.getErrorCode(j), errFormat));
		      	dataSheet.addCell(new Label(2,i,""+dh.getErrorPosition(j), errFormat));
		      	dataSheet.addCell(new Label(3,i,dh.getErrorDescription(j), errFormat));
		      	//dataSheet.addCell(new Label(4,i,dh.getContainer(j).getID(), errFormat ));
				reported[j] = true;
			}
		}
        }
        catch(Exception e){
        	logr.error(e.getMessage(), e);
        	return;
        	
        }
		
	}

	/**
	 * @param lasc
	 * @param dataSheet
	 * @param dh
	 * @param reported
	 * @param inInt
	 */
	private void report(LoopAndSegmentContainer lasc, WritableSheet dataSheet, DocumentErrors dh, boolean[] reported, myInteger inInt) {
		
		if (lasc == null)
			return;

		for (int i = 0; i < lasc.getContainerSize(); i++) {
			if (lasc.isVector(i)) {
				int j = lasc.getCount(i);
				for (int ii = 0; ii < j; ii++)
					if (lasc.isLoop(i, ii))
						report(lasc.getLoop(i, ii), dataSheet,dh, reported, inInt);
					else if (lasc.isSegment(i, ii))
						report(lasc.getSegment(i, ii), dataSheet,dh, reported, inInt);
			} else if (lasc.isLoop(i))
				report(lasc.getLoop(i), dataSheet,dh, reported, inInt);
			else if (lasc.isSegment(i))
				report(lasc.getSegment(i), dataSheet,dh, reported, inInt);
		}

		try {
		for (int j = 0; j < dh.getErrorCount(); j++) {
			if (reported[j])
				continue;
			if (dh.getContainer(j) == lasc) {
				int i = inInt.getInt();
		      	dataSheet.addCell(new Label(0,i,dh.getErrorID(j), errFormat));
		      	dataSheet.addCell(new Label(1,i,dh.getErrorCode(j), errFormat));
		      	dataSheet.addCell(new Label(2,i,""+dh.getErrorPosition(j), errFormat));
		      	dataSheet.addCell(new Label(3,i,dh.getErrorDescription(j), errFormat));
		      	//dataSheet.addCell(new Label(4,i,dh.getContainer(j).getID(), errFormat ));
				reported[j] = true;
			}
		}
        }
        catch(Exception e){
        	logr.error(e.getMessage(), e);
        	return;
        	
        }
		
	}


	public  String doContainer(Object inObject, boolean apiRequest) {
		if (inObject == null)
			return "";
		
		StringBuffer sb = new StringBuffer();
		if (apiRequest)
			sb.append(" in ");
		else
		    sb.append("<br>contained in ");
		if (inObject instanceof Envelope) {
			Envelope e = (Envelope) inObject;
			sb.append("Envelope :" + e.getID());
		} else if (inObject instanceof FunctionalGroup) {
			FunctionalGroup fg = (FunctionalGroup) inObject;
			sb.append("Functional Group:" + fg.getID());
			sb.append(doContainer(fg.getParent(),apiRequest));
		} else if (inObject instanceof TransactionSet) {
			TransactionSet ts = (TransactionSet) inObject;
			sb.append("Transasction Set:" + ts.getID());
			sb.append(doContainer(ts.getParent(),apiRequest));
		} else if (inObject instanceof Table) {
			Table tbl = (Table) inObject;
			sb.append("Table:" + tbl.getID());
			sb.append(doContainer(tbl.getParent(),apiRequest));
		} else if (inObject instanceof Loop) {
			Loop loop = (Loop) inObject;
			sb.append("Loop:" + loop.getID());
			sb.append(doContainer(loop.getParent(),apiRequest));
		} else if (inObject instanceof Segment) {
			Segment s = (Segment) inObject;
			sb.append("Segment :" + s.getID() + " name:" + s.getName());
			sb.append(doContainer(s.getParent(),apiRequest));
		} else if (inObject instanceof CompositeDE) {
			CompositeDE cde = (CompositeDE) inObject;
			sb.append("Composite :" + cde.getID() + " name:" + cde.getName());
			sb.append(doContainer(cde.getParent(),apiRequest));
		} else
			sb.append(" unknown:" + inObject);
		return new String(sb);
	}


	/** start parsing not used here */

	public void startParsing(java.io.Reader inRDR) {
		;
	}

	/** do nothing when an envelope is started */
	public void startEnvelope(Envelope inEnv) {
		envelope = (X12Envelope) inEnv;
	}

	/** called when an FunctionalGroup object is created
	 * @param inFG FunctionalGroup found
	 */

	public void startFunctionalGroup(FunctionalGroup inFG) {
		functionalGroup = inFG;
		envelope.addFunctionalGroup(inFG);
	}

	/** called when an TransactionSet object is created
	 * @param inTS TransactionSet found
	 */
	public void startTransactionSet(TransactionSet inTS) {
		functionalGroup.addTransactionSet(inTS);
	}

	/** called when an Segment object is created
	 * <br>only called for segments at the Envelope and functionalGroup level
	 * does not get called for segments within TransactionSet
	 * @param inSeg  Segment found
	 */
	public void startSegment(Segment inSeg) {

		if (inSeg.getID().compareTo(X12Envelope.idInterchangeHeader) == 0)
			envelope.addSegment(inSeg);
		else if (
			inSeg.getID().compareTo(X12Envelope.idInterchangeTrailer) == 0)
			envelope.addSegment(inSeg);
		else if (
			inSeg.getID().compareTo(X12Envelope.idGradeofServiceRequest) == 0)
			envelope.addSegment(inSeg);
		else if (
			inSeg.getID().compareTo(X12Envelope.idDeferredDeliveryRequest)
				== 0)
			envelope.addSegment(inSeg);
		else if (
			inSeg.getID().compareTo(X12Envelope.idInterchangeAcknowledgment)
				== 0)
			envelope.addSegment(inSeg);
		else if (inSeg.getID().compareTo(X12FunctionalGroup.idHeader) == 0)
			functionalGroup.addSegment(inSeg);
		else if (inSeg.getID().compareTo(X12FunctionalGroup.idTrailer) == 0)
			functionalGroup.addSegment(inSeg);

	}

	/** do nothing when an envelope is ended
	*/
	public void endEnvelope(Envelope inEnv) {

		envelope = (X12Envelope) inEnv;
	}

	/** do nothing when an fg is ended
	*/
	public void endFunctionalGroup(FunctionalGroup inFG) {
		;
	}

	/** create a Valid XML document for each ts found
	*/
	public void endTransactionSet(TransactionSet inTS) {

	}

	/** do nothing when an seg is ended
	 * <br>Note that these segments are only envelope and fg segments NOT SEGMENTS inside of Transaction Sets
	*/
	public void endSegment(Segment inSeg) {
		;
	}

	/**
	 * normlizes the string to remove XML characters.
	 * @param inString to be normalized
	 * @return String
	 */
	public static String normalize(String inString) {
		int i;
		StringBuffer sb = new StringBuffer();
		for (i = 0; i < inString.length(); i++)
			switch (inString.charAt(i)) {
				case '&' :
					sb.append("&amp;");
					break;
				case '<' :
					sb.append("&lt;");
					break;
				case '>' :
					sb.append("&gt;");
					break;
				case '"' :
					sb.append("&quot;");
					break;
				case '\'' :
					sb.append("&apos;");
					break;
				case '\n' :
					sb.append("<br>");
					break;
				case ' ' :
					sb.append("&nbsp;");
					break;
				default :
					if (inString.charAt(i) < ' ')
						// what to do with control codes
						sb.append("\n" + inString.charAt(i));
					else
						sb.append(inString.charAt(i));
			}

		sb.append("\n");
		return new String(sb);

	}
	public DocumentErrors getDocumentErrors() {
		
		return null;
	}
	  static class myInteger {
		  	protected int myInt = -1;
		  	protected myInteger(){}
		  	protected int getInt() {
		  		myInt++;
		  		return myInt;
		  	}
		  }
}
