/*
 * Created on Apr 25, 2005
 *
 * Interface for DE and CompDE elements
 *
 */
package com.americancoders.edi;

/**
 * @author Joe McVerry - American Coders, Ltd. 
 *
 */
public interface ITemplateElementContainer {

	public int getTemplateDESize();
    public void addTemplateComposite(TemplateComposite inTemplateComposite)
    	throws OBOEException;
    public void addTemplateDE(TemplateDE inTemplateDE);
    public boolean isTemplateDE(int at);
    public boolean isTemplateComposite(int at);




}
