package com.americancoders.samples;

/**
 *OBOE - Open Business Objects for EDI
 *<P>java access to EDI
 *<p>Copyright 1998-2001 - American Coders, LTD  - Raleigh NC USA
 *<p>All rights reserved
 *<p>American Coders, Ltd
 *<br>P. O. Box 97462
 *<br>Raleigh, NC  27624  USA
 *<br>1-919-846-2014
 *<br>http://www.americancoders.com
@author Joe McVerry, American Coders Ltd.
@version buildNotToBeReleased
 */


import java.util.*;
import java.io.*;

import com.americancoders.edi.*;
import com.americancoders.edi.x12.*;


/**
 * class to parse input string for all defined OBOE Transaction Sets
 * <br> program will create Valid XML formatted data for each transaction set
 * <br> output sent to System.out (console)
 * <br> x12 dependent
 *
 */

public class SampleX12DocumentHandler implements EDIDocumentHandler
{

  X12Envelope envelope = null;
  FunctionalGroup functionalGroup = null;
  /** do nothing constructor
   */
  public SampleX12DocumentHandler() {;}

  /** do nothing when an envelope is started */
  public void startEnvelope(Envelope inEnv)
  {
    envelope = (X12Envelope) inEnv;
  }

  /** called when an FunctionalGroup object is created
   * @param inFG FunctionalGroup found
   */

  public void startFunctionalGroup(FunctionalGroup inFG) {
    functionalGroup = inFG;
    envelope.addFunctionalGroup(inFG);
    }


  /** called when an TransactionSet object is created
   * @param inTS TransactionSet found
   */
  public void startTransactionSet(TransactionSet inTS) {
    functionalGroup.addTransactionSet(inTS);
    }


  /** called when an Segment object is created
   * <br>only called for segments at the Envelope and functionalGroup level
   * does not get called for segments within TransactionSet
   * @param inSeg  Segment found
   */
  public void startSegment(Segment inSeg) {

    if (inSeg.getID().compareTo(Interchange_Control_Header.id) == 0)
       envelope.setInterchange_Header(inSeg);
    else
    if (inSeg.getID().compareTo(Interchange_Control_Trailer.id) == 0)
       envelope.setInterchange_Trailer(inSeg);
    else
    if (inSeg.getID().compareTo(Grade_of_Service_Request.id) == 0)
       envelope.setGrade_of_Service_Request(inSeg);
    else
    if (inSeg.getID().compareTo(Deferred_Delivery_Request.id) == 0)
       envelope.setDeferred_Delivery_Request(inSeg);
    else
    if (inSeg.getID().compareTo(Interchange_Acknowledgment.id) == 0)
        envelope.addInterchange_Acknowledgment(inSeg);
    else
    if (inSeg.getID().compareTo(Functional_Group_Header.id) == 0)
        functionalGroup.setHeader(inSeg);
    else
    if (inSeg.getID().compareTo(Functional_Group_Trailer.id) == 0)
        functionalGroup.setTrailer(inSeg);

    }

  /** do nothing when an envelope is ended
  */
  public void endEnvelope(Envelope inEnv){;}

  /** do nothing when an fg is ended
  */
  public void endFunctionalGroup(FunctionalGroup inFG){;}

  /** create a Valid XML document for each ts found
  */
  public void endTransactionSet(TransactionSet inTS){
	  System.out.println(inTS.getFormattedText(Envelope.VALID_XML_FORMAT));
	  }

  /** do nothing when an seg is ended
   * <br>Note that these segments are only envelope and fg segments NOT SEGMENTS inside of Transaction Sets
  */
  public void endSegment(Segment inSeg){;}



  /** from command line
   * <br> java SampleX12DocumentHandler xxxx, where xxxx is a X12 document filename
   */

  public static void main(String args[])
   {
    try {

    FileInputStream fis = new FileInputStream(args[0]); // set up to read the file
    DataInputStream dis = new DataInputStream(fis);
    BufferedReader br = new BufferedReader(new InputStreamReader(fis));
    StringBuffer sb = new StringBuffer();
    String s;

    try {   // do this for documents that use cr/lf as segment delimiters
      while(true) {
        s = br.readLine();
        if (s == null)
          break;
		sb.append(s+X12Envelope.SEGMENT_DELIMITER);
	  }
	}
	catch (EOFException e) {;}
    fis.close();
    s = new String(sb);

    X12DocumentParser p1 = new X12DocumentParser(); // create a parser object

    SampleX12DocumentHandler h1 = new SampleX12DocumentHandler();//create the class object


    p1.registerHandler(h1); // register with the parser
    p1.parseDocument(s);  // start doing some work

    }
    catch (Exception e1)
      {
        e1.printStackTrace();
      }
   }

}