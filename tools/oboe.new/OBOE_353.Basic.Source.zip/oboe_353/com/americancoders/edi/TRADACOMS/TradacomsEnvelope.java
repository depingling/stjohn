package com.americancoders.edi.TRADACOMS;

/**
 *OBOE - Open Business Objects for EDI
 *<P>java access to EDI
 *<p>Copyright 1998-2007 - American Coders, LTD  - Raleigh NC USA
 *<p>All rights reserved
 *<p>American Coders, Ltd
 *<br>P. O. Box 97462
 *<br>Raleigh, NC  27624  USA
 *<br>1-919-846-2014
 *<br>http://www.americancoders.com
@author Joe McVerry - American Coders, Ltd.
  @version   3.5.3
 */

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PushbackInputStream;
import java.io.Writer;
import java.util.Vector;

import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.americancoders.edi.DocumentErrors;
import com.americancoders.edi.Envelope;
import com.americancoders.edi.FunctionalGroup;
import com.americancoders.edi.OBOEException;
import com.americancoders.edi.Segment;
import com.americancoders.edi.TemplateEnvelope;
import com.americancoders.edi.TemplateSegment;
import com.americancoders.edi.TransactionSet;
import com.americancoders.edi.TransactionSetFactory;
import com.americancoders.util.Util;


/**
 * class for wrapping a EDI transaction set within an EDI Envelope
 *
 */

public class TradacomsEnvelope extends Envelope 
{


 

  /** constants for segments */

 /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
/** segment constants */
  public static final String  idInterchangeHeader = "STX";
  public static final String  idInterchangeTrailer = "END";
  /**
   * instantiates the class from all related OBOE classes
   */

  public TradacomsEnvelope()
  {
    super();
    setFormat(Envelope.TRADACOMS_FORMAT);
    segmentDelimiter = Envelope.TRADACOMS_SEGMENT_DELIMITER;
    fieldDelimiter = Envelope.TRADACOMS_FIELD_DELIMITER;
    groupDelimiter = Envelope.TRADACOMS_GROUP_DELIMITER;
    repeatDelimiter = Envelope.TRADACOMS_REPEAT_DELIMITER;
    escapeCharacter= Envelope.TRADACOMS_ESCAPE_CHARACTER;

  }

  /**
   * instantiates the class from a TemplateEnvelope,
   * creates mandatory segments STX and END and creates one emtpy functional group
   * @param inTempEnv TemplateEnvelope to build this class with
   * @exception OBOEException missing segment definition in envelope xml.
   */

  public TradacomsEnvelope(TemplateEnvelope inTempEnv)
    throws OBOEException
  {
    super();
    setFormat(Envelope.TRADACOMS_FORMAT);
    segmentDelimiter = Envelope.TRADACOMS_SEGMENT_DELIMITER;
    fieldDelimiter = Envelope.TRADACOMS_FIELD_DELIMITER;
    groupDelimiter = Envelope.TRADACOMS_GROUP_DELIMITER;
    repeatDelimiter = Envelope.TRADACOMS_REPEAT_DELIMITER;
    escapeCharacter= Envelope.TRADACOMS_ESCAPE_CHARACTER;
    myTemplate = inTempEnv;
	myTemplateContainer = myTemplate;
    //createInterchange_Header();
    //createFunctionalGroup();
    //createInterchange_Trailer();
  }


 /* method for parsing well formed edi xml files
  * @param node a DOM node object
  * @throws OBOException...
  * @throws FileNotFoundException...
  * @throws IOException...
  */


  public void parse(Node node)
   throws OBOEException, FileNotFoundException, IOException
   {
        Node cnode = null;
        NodeList nl = node.getChildNodes();
        Segment seg;
        int i;
        for (i = 0; i < nl.getLength(); i++)
        {
           cnode = nl.item(i);
           if (cnode.getNodeType() == Node.ELEMENT_NODE)
              break;
        }


        if (i == nl.getLength())
          throw new OBOEException("No element nodes found");


        if (cnode.getNodeName().compareTo(myTemplate.getTemplateSegment(idInterchangeHeader).getXMLTag()) != 0)
          throw new OBOEException("Expected "+ myTemplate.getTemplateSegment(idInterchangeHeader).getXMLTag()+ " got " +cnode.getNodeName());


        seg = new Segment(myTemplate.getTemplateSegment(idInterchangeHeader), this);
        addSegment(seg);
        seg.parse(cnode);

        for (i++; i < nl.getLength(); i++)
        {
           cnode = nl.item(i);
           if (cnode.getNodeType() == Node.ELEMENT_NODE)
              break;
        }


        if (i == nl.getLength())
          throw new OBOEException("Envelope terminated too soon");

        if  (cnode.getNodeName().compareTo(myTemplate.getTemplateFunctionalGroup().getTemplateSegment(TradacomsFunctionalGroup.idHeader).getXMLTag()) != 0)
          {

                   FunctionalGroup functionalGroup = new TradacomsFunctionalGroup(myTemplate.getTemplateFunctionalGroup(), this);
                   addFunctionalGroup(functionalGroup);
                   do
                     {

                      String tsID =Util.getOBOEProperty(cnode.getNodeName());
                      if (tsID == null)
                        throw new OBOEException(cnode.getNodeName() + " not defined in OBOE.properties.");


                      TransactionSet parsedTransactionSet = TransactionSetFactory.buildTransactionSet(tsID);
                      parsedTransactionSet.setFormat(Envelope.TRADACOMS_FORMAT);
                      parsedTransactionSet.parse(nl.item(i));
                      functionalGroup.addTransactionSet(parsedTransactionSet);
                      parsedTransactionSet.setParent(functionalGroup);

                      for (i++; i < nl.getLength(); i++)
                       {
                        cnode = nl.item(i);
                        if (cnode.getNodeType() == Node.ELEMENT_NODE)
                        break;
                       }

                      if (i == nl.getLength())
                         throw new OBOEException("Envelope terminated too soon");
                     } while (cnode.getNodeName().compareTo(myTemplate.getTemplateSegment(idInterchangeTrailer).getXMLTag()) != 0);

          }
        else
         while  (cnode.getNodeName().compareTo(myTemplate.getTemplateFunctionalGroup().getTemplateSegment(TradacomsFunctionalGroup.idHeader).getXMLTag()) == 0)
            {
                   FunctionalGroup functionalGroup = new TradacomsFunctionalGroup(myTemplate.getTemplateFunctionalGroup(), this);
                   addFunctionalGroup(functionalGroup);
                   seg = new Segment(functionalGroup.getTemplateSegment(TradacomsFunctionalGroup.idHeader), functionalGroup);
                   seg.parse(cnode);
                   functionalGroup.addSegment(seg);
                   for (i++; i < nl.getLength(); i++)
                    {
                        cnode = nl.item(i);
                        if (cnode.getNodeType() == Node.ELEMENT_NODE)
                        break;
                    }

                   if (i == nl.getLength())
                      throw new OBOEException("Envelope terminated too soon");

                   while (cnode.getNodeName().compareTo(myTemplate.getTemplateFunctionalGroup().getTemplateSegment(TradacomsFunctionalGroup.idTrailer).getXMLTag()) != 0)
                    {

                      String tsID = Util.getOBOEProperty(cnode.getNodeName());
                      if (tsID == null)
                        throw new OBOEException(cnode.getNodeName() + " not defined in OBOE.properties.");


                      TransactionSet parsedTransactionSet = TransactionSetFactory.buildTransactionSet(tsID);
                      parsedTransactionSet.setFormat(Envelope.TRADACOMS_FORMAT);
                      parsedTransactionSet.parse(nl.item(i));
                      functionalGroup.addTransactionSet(parsedTransactionSet);
                      parsedTransactionSet.setParent(functionalGroup);

                      for (i++; i < nl.getLength(); i++)
                       {
                        cnode = nl.item(i);
                        if (cnode.getNodeType() == Node.ELEMENT_NODE)
                        break;
                       }

                      if (i == nl.getLength())
                         throw new OBOEException("Envelope terminated too soon");
                    }
                   seg = new Segment(functionalGroup.getTemplateSegment(TradacomsFunctionalGroup.idTrailer), functionalGroup);
                   seg.parse(cnode);
                   functionalGroup.addSegment(seg);
                   for (i++; i < nl.getLength(); i++)
                    {
                        cnode = nl.item(i);
                        if (cnode.getNodeType() == Node.ELEMENT_NODE)
                        break;
                    }

                   if (i == nl.getLength())
                      throw new OBOEException("Envelope terminated too soon");

            }

    if (cnode.getNodeName().compareTo(myTemplate.getTemplateSegment(idInterchangeTrailer).getXMLTag()) != 0)
          throw new OBOEException("Expecting " + myTemplate.getTemplateSegment(idInterchangeTrailer).getXMLTag());


    seg = new Segment(myTemplate.getTemplateSegment(idInterchangeTrailer), this);
    seg.parse(cnode);
    addSegment(seg);


   }
 /* method for parsing fixed format edi files
  * @param DataInputStream
  * @throws OBOException...
  * @throws FileNotFoundException...
  * @throws IOException...
  */

  public boolean parse(PushbackInputStream pis)
      throws OBOEException, FileNotFoundException, IOException
      {
        Segment seg;
  

        StringBuffer sb=new StringBuffer(); // first char was already read by parser class
        byte me[] = new byte[4];
        if (pis.read(me) != 4)
           	throw new OBOEException("expected data not read");

        sb.append(me);
        String id = Util.rightTrim(new String(sb));

         if (id.compareTo(myTemplate.getTemplateSegment(idInterchangeHeader).getID()) != 0)
          throw new OBOEException("Expected "+ myTemplate.getTemplateSegment(idInterchangeHeader).getID()+ " got " +id);


        seg = new Segment(myTemplate.getTemplateSegment(idInterchangeHeader), this);
        addSegment(seg);
        seg.parse(pis);

        if  (id.compareTo(myTemplate.getTemplateFunctionalGroup().getTemplateSegment(TradacomsFunctionalGroup.idHeader).getID()) != 0)
          {

                   FunctionalGroup functionalGroup = new TradacomsFunctionalGroup(myTemplate.getTemplateFunctionalGroup(), this);
                   addFunctionalGroup(functionalGroup);
                   String tsID = Util.getOBOEProperty(id);
                   if (tsID == null)
                        throw new OBOEException(id + " not defined in OBOE.properties file");


                   TransactionSet parsedTransactionSet = TransactionSetFactory.buildTransactionSet(tsID);
                   parsedTransactionSet.setFormat(Envelope.TRADACOMS_FORMAT);
                   parsedTransactionSet.parse(pis);
                   functionalGroup.addTransactionSet(parsedTransactionSet);
                   parsedTransactionSet.setParent(functionalGroup);

                   if (pis.read(me) != 4)
                   	throw new OBOEException("expected data not read");
                   id = Util.rightTrim(new String(me));

          }
        else
         while  (id.compareTo(myTemplate.getTemplateSegment(TradacomsFunctionalGroup.idHeader).getID()) == 0)
            {
                   FunctionalGroup functionalGroup = new TradacomsFunctionalGroup(myTemplate.getTemplateFunctionalGroup(), this);
                   addFunctionalGroup(functionalGroup);
                   seg = new Segment(myTemplate.getTemplateFunctionalGroup().getTemplateSegment(TradacomsFunctionalGroup.idHeader), functionalGroup);
                   seg.parse(pis);
                   if (pis.read(me) != 4)
                   	throw new OBOEException("expected data not read");
                   id = Util.rightTrim(new String(me));

                   while (id.compareTo(myTemplate.getTemplateSegment(TradacomsFunctionalGroup.idTrailer).getID()) != 0)
                    {

                      String tsID = Util.getOBOEProperty(id);
                      if (tsID == null)
                        throw new OBOEException(id + " not defined in OBOE.properties file");


                      TransactionSet parsedTransactionSet = TransactionSetFactory.buildTransactionSet(tsID);
                      parsedTransactionSet.setFormat(Envelope.TRADACOMS_FORMAT);
                      parsedTransactionSet.parse(pis);
                      functionalGroup.addTransactionSet(parsedTransactionSet);
                      parsedTransactionSet.setParent(functionalGroup);

                      if (pis.read(me) != 4)
                       	throw new OBOEException("expected data not read");
                      id = Util.rightTrim(new String(me));
                    }
                   seg = new Segment(myTemplate.getTemplateFunctionalGroup().getTemplateSegment(TradacomsFunctionalGroup.idTrailer), functionalGroup);
                   seg.parse(pis);
                   if (pis.read(me) != 4)
                   	throw new OBOEException("expected data not read");
                   id = Util.rightTrim(new String(me));
            }

    if (id.compareTo(myTemplate.getTemplateSegment(idInterchangeTrailer).getID()) != 0)
          throw new OBOEException("Expecting " + myTemplate.getTemplateSegment(idInterchangeTrailer).getID());


    seg = new Segment(myTemplate.getTemplateSegment(idInterchangeTrailer), this);
    seg.parse(pis);
    addSegment(seg);

    return true;

   }




    /** creates a basic functionalgroup object
     * @return TradacomsFunctionalGroup
     */
  public FunctionalGroup createFunctionalGroup()
    {
         return new TradacomsFunctionalGroup(myTemplate.getTemplateFunctionalGroup(), this);
    }




  /** gets the Interchange_Header
   * @return Interchange_Header segment
   */
public Segment getInterchange_Header()  {return getSegment(idInterchangeHeader); }


  /** gets the count of Functional Group object in the vector (container);
   * @return int count
   */
public int getFunctionalGroupCount(){return functionalGroups.size();}

  /** gets a Functional Group object from the vector (container);
   *  <br>check for runtime array out of bounds exception
   * @return a FunctionalGroup object
   */
public FunctionalGroup getFunctionalGroup(int pos){return (FunctionalGroup) functionalGroups.elementAt(pos);}

  /** gets the Vector of Functional Group objects
   * @return a Vector of FunctionalGroup objects
   */
public Vector getFunctionalGroups(){return functionalGroups;}


  /** returns the Interchange Control Trailer built for the envelope
   *  @return Segment
   */

public Segment getInterchange_Trailer() {return getSegment(idInterchangeTrailer);}

  /** sets the functional group count in the trailer */

/** sets the Delimter fields in the header */

public void setDelimitersInHeader()
    throws OBOEException
  {

    if (getInterchange_Header() == null)
       throw new OBOEException("header not set yet");

  }



public void setFGCountInTrailer()
  {

    getInterchange_Trailer().getDataElement(1).set(Integer.toString((getFunctionalGroupCount())));
  }

  /**
   * returns the EDI (Tradacoms) formatted document in a String
   * @param format int - format type see TransactionSet
   * @return String the formatted document
   * 
   */

public String getFormattedText(int format)
  {
	StringBuffer sb = new StringBuffer();
	if (format == Envelope.VALID_XML_FORMAT) {
			sb.append("<?xml version=\"1.0\"?>"+com.americancoders.util.Util.lineFeed);
			sb.append("<!-- OBOE release " +
//++$$textRelease            build.not.to.be.released
			"-->"+com.americancoders.util.Util.lineFeed);
			sb.append("<!DOCTYPE envelope SYSTEM \"envelope.dtd\">"+com.americancoders.util.Util.lineFeed);
			sb.append("<envelope format=\"Tradacoms\">"+com.americancoders.util.Util.lineFeed);
	  }
	if  (format == Envelope.XML_FORMAT)
	  {
			sb.append("<?xml version=\"1.0\"?>"+com.americancoders.util.Util.lineFeed);
			sb.append("<!-- OBOE release " +
//++$$textRelease            build.not.to.be.released
			"-->"+com.americancoders.util.Util.lineFeed);
			sb.append("<Envelope>"+com.americancoders.util.Util.lineFeed);
	  }

	if (format == Envelope.CSV_FORMAT)
	   sb.append("Envelope"+com.americancoders.util.Util.lineFeed);


	sb.append(getSegment(idInterchangeHeader).getFormattedText(format));

	FunctionalGroup fg;
	for (int i=0; i < getFunctionalGroupCount(); i++)
	  {
	   fg = (FunctionalGroup)getFunctionalGroup(i);
	   sb.append(fg.getFormattedText(format));
	  }

	sb.append(getSegment(idInterchangeTrailer).getFormattedText(format));
	if  (format == Envelope.XML_FORMAT)
	  {
			sb.append("</Envelope>"+com.americancoders.util.Util.lineFeed);
	  }
	if (format == Envelope.VALID_XML_FORMAT) {
			sb.append("</envelope>"+com.americancoders.util.Util.lineFeed);
	}
	return new String(sb);
  }

  /**
  * @see com.americancoders.edi.Envelope#writeFormattedText(Writer, int)
  */

public void writeFormattedText(Writer inWriter, int format) throws OBOEException, IOException
  {
	
	if (format == Envelope.VALID_XML_FORMAT) {
			inWriter.write("<?xml version=\"1.0\"?>"+com.americancoders.util.Util.lineFeed);
			inWriter.write("<!-- OBOE release " +
//++$$textRelease            build.not.to.be.released
			"-->"+com.americancoders.util.Util.lineFeed);
			inWriter.write("<!DOCTYPE envelope SYSTEM \"envelope.dtd\">"+com.americancoders.util.Util.lineFeed);
			inWriter.write("<envelope format=\"Tradacoms\">"+com.americancoders.util.Util.lineFeed);
	  }
	if  (format == Envelope.XML_FORMAT)
	  {
			inWriter.write("<?xml version=\"1.0\"?>"+com.americancoders.util.Util.lineFeed);
			inWriter.write("<!-- OBOE release " +
//++$$textRelease            build.not.to.be.released
			"-->"+com.americancoders.util.Util.lineFeed);
			inWriter.write("<Envelope>"+com.americancoders.util.Util.lineFeed);
	  }

	if (format == Envelope.CSV_FORMAT)
	   inWriter.write("Envelope"+com.americancoders.util.Util.lineFeed);


	inWriter.write(getSegment(idInterchangeHeader).getFormattedText(format));

	FunctionalGroup fg;
	for (int i=0; i < getFunctionalGroupCount(); i++)
	  {
	   fg = (FunctionalGroup)getFunctionalGroup(i);
	   fg.writeFormattedText(inWriter, format);
	  }

	inWriter.write(getSegment(idInterchangeTrailer).getFormattedText(format));
	if  (format == Envelope.XML_FORMAT)
	  {
			inWriter.write("</Envelope>"+com.americancoders.util.Util.lineFeed);
	  }
	if (format == Envelope.VALID_XML_FORMAT) {
			inWriter.write("</envelope>"+com.americancoders.util.Util.lineFeed);
	}
	
	inWriter.flush();
	
  }


  /**
   * validates
   * @exception OBOEException indicates why envelope is invalid
   */

   public void validate()
    throws OBOEException
	{
   	
   	Segment seg = getSegment(idInterchangeHeader);
    if (seg != null)
       seg.validate();

    FunctionalGroup fg;
    for (int i=0; i < getFunctionalGroupCount(); i++)
      {
       fg = (FunctionalGroup)getFunctionalGroup(i);
       fg.validate();
      }
    seg = getSegment(idInterchangeTrailer);
    if (seg != null)
        seg.validate();
    }

  /**
   * validates and places errors in DocumentErrors object
   * @param inDErr DocumentErrors
   */

   public void validate(DocumentErrors inDErr)
    throws OBOEException
    {
   	Segment seg = getSegment(idInterchangeHeader);
    if (seg != null)
       seg.validate(inDErr);

    FunctionalGroup fg;
    for (int i=0; i < getFunctionalGroupCount(); i++)
      {
       fg = (FunctionalGroup)getFunctionalGroup(i);
       fg.validate(inDErr);
      }

   	 seg = getSegment(idInterchangeTrailer);
    if (seg != null)
       seg.validate(inDErr);
    }



  /** creates, sets and returns the Interchange Control Header built for the envelope
   *  @return Segment - can return null if templateenvelope is null or segment not defined in envelope xml rules file
   */

  public Segment createInterchange_Header() {

    if (myTemplate == null) return null;
    TemplateSegment tsg = myTemplate.getTemplateSegment(TradacomsEnvelope.idInterchangeHeader);

    
    Segment seg = new Segment(tsg, this);
    addSegment(seg);
    return seg;
    }

  /** creates, sets and returns the Interchange Control Trailer built for the envelope
   *  @return Segment - can return null if templateenvelope is null or segment not defined in envelope xml rules file
   */

 public Segment createInterchange_Trailer()
   {
    if (myTemplate == null) return null;
    TemplateSegment tsg = myTemplate.getTemplateSegment(TradacomsEnvelope.idInterchangeTrailer);
    Segment seg = new Segment(tsg, this);
    addSegment(seg);
    return seg;
    }
 /* (non-Javadoc)
  * @see com.americancoders.edi.IContainedObject#getDelimiter(char)
  */

 	public char getDelimiter(char inOriginal) {
 		
		return inOriginal;
	}
 	

}
