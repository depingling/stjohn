//$$skipAll
package com.americancoders.util;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Hashtable;
import java.util.Vector;

import com.americancoders.edi.EnvelopeFactory;
import com.americancoders.edi.OBOEException;
import com.americancoders.edi.TemplateComposite;
import com.americancoders.edi.TemplateDE;
import com.americancoders.edi.TemplateEnvelope;
import com.americancoders.edi.TemplateLoop;
import com.americancoders.edi.TemplateSegment;
import com.americancoders.edi.TemplateSegmentContainer;
import com.americancoders.edi.TemplateTable;
import com.americancoders.edi.TemplateTransactionSet;
import com.americancoders.edi.TransactionSet;
import com.americancoders.edi.TransactionSetFactory;

/**
 * OBOE - Open Business Objects for EDI
 * <p> Copyright 1998-2007 - American Coders, LTD - Raleigh NC USA
 * <p> All rights reserved
 * <p>
 * American Coders, Ltd <br>
 * P. O. Box 97462 <br>
 * Raleigh, NC 27624 USA <br>
 * 1-919-846-2014 <br>
 * http://www.americancoders.com
 *
 * <pre>
 *  use this application to generate a program that uses a parsed OBOE object or create an OBOE object.
 *   The application reads in a rules file to generate the code.
 *   A lot of code is generated but not enough to be completely useful.
 *   You will have to remove code for segments and data elements you don't use and
 *   add code for logic that is specific to your system requirements.
 *   format: java com.americancoders.OBOECodeGenerator pJ|pP|bj|bP envelope tsid [-useName] [outputFileName]
 *      where pJ generates a Java program that parses an EDI document
 *         or pP generates a PIXES process that parses an EDI document
 *  	   or bJ generates a Java program that builds an EDI document
 *         or bP generates a PIXES process that builds an EDI document.
 *      and envelope is the envelope xml file to use
 *      and tsid is the transactionset id to build
 *      and optional -useName indicates that method names should be defined by the objects name
 *      attribute and not its id attribute.
 *      and optional outputFileName is any valid file name to where results are stored.
 *
 *  If the file name ends with .java the program will create the class name from the file name
 *    otherwise it will generate the class name from the type of build and the transaction set id.
 * </pre>
 *
 * <br>
 * Copyright 2000-2007 - American Coders, Ltd Raleigh NC USA <br>
 * All rights reserved
 *
 * @author Joe McVerry - American Coders, Ltd.
  @version   3.5.3
 */

public class OBOECodeGenerator

{

	
	/** pw control output file */
	private PrintWriter pw = null;
	/** what are we building */
	private char ediType; /* x - x12, e - edifact, t - tradacoms, a -ach */
	/** id of transaction set */
	private String tsID;

	private String lineFeed = System.getProperty("line.separator");

	private boolean useName = false;

	private Hashtable methodNameTable = new Hashtable(2000);

	/**
	 * wake up and smell the coffee. This method is used to show the correct
	 * format for calling the application
	 */
	private static void describeStart() {
		System.err.println("format: java com.americancoders.OBOECodeGenerator pJ|pP|bJ|bP envelopeRulesFileName tsid [-useName] [outputFileName]");
		System.err.println("    where pJ generates a Java program that parses an EDI document.");
		System.err.println("       or pP generates a PIXES process that parses an EDI document.");
		System.err.println("       or bJ generates a Java program that builds an EDI document.");
		System.err.println("       or bP generates a PIXES process that builds an EDI document.");
		System.err.println("    and envelopeRulesFileName is the OBOE Envlope Rules File to use with the transaction set");
		System.err.println("    and tsid is the transactionset id to build");
		System.err.println("    and optional -useName is a switch to indicate the Java method names are built with the object's name");
		System.err.println("        otherwise Java method names are buit with the object's id.");
		System.err.println("    and optional outputFileName is any valid file name to where results are stored.");
		System.err.println("If the file name ends with .java or .xml the program will create the class name from the file name");
		System.err.println("  otherwise it will generate the class name from the type and tsid.");
		System.err.println("Copyright 2000-2007 - American Coders, Ltd Raleigh NC USA");
		System.err.println("All rights reserved");
		System.exit(0);
	}

	/**
	 * to make this a java application the class needs a main method.
	 * <ul>
	 * accepts 3 or 4 arguments
	 * <li>p or b - indicates if the application is for use with Parsed object
	 * or to Build an object
	 * <li>tsid - transaction set id to use
	 * <li>-useName - optional paramter to indicate that method names are built
	 * with the object's name otherwise use the object's id
	 * <li>outputFilename - optional output file name, if not used output sent
	 * to System.out
	 */
	public static void main(String args[]) {

		String envelope = "";

		String tsid = "";
		String type = "";

		String outputFileName = null;
		boolean useName = false;

		// if (args.length == 0);
		// else
		if (args.length != 3 && args.length != 4 && args.length != 5) {
			describeStart();
		} else if (args[0].length() != 2) {
			describeStart();
		} else if ((args[0].charAt(0) != 'p' && args[0].charAt(0) != 'b')
				|| (args[0].charAt(1) != 'J' && args[0].charAt(1) != 'P')) {
			describeStart();
		} else {
			type = args[0];
			envelope = args[1];
			tsid = args[2];
			if (args.length == 4) {
				if (args[3].charAt(0) == '-') {
					if (args[3].compareTo("-useName") != 0) {
						describeStart();
					}
					useName = true;
				} else
					outputFileName = args[3];
			} else if (args.length == 5) {
				if (args[3].compareTo("-useName") != 0) {
					describeStart();
				}
				useName = true;
				outputFileName = args[4];
			}
		}

		TransactionSet ts = TransactionSetFactory.buildTransactionSet(tsid);

		new OBOECodeGenerator(envelope, ts, type, useName, outputFileName);
	}

	/**
	 * constructor <br>
	 * accepts 5 arguments
	 *
	 * @param inEnvelope
	 *            xml file name
	 * @param inTS -
	 *            transaction set id to use
	 * @param type
	 *            "pJ", "pP", "bJ" or "bP"; pJ - Java parsing program; pP -
	 *            PIXES parsing process; bJ - Java building program; bP - PIXES
	 *            building process
	 * @param inUseName -
	 *            boolean to indicate if object names are used
	 * @param outputFileName -
	 *            write resultant code to this filename, if null then send to
	 *            System.out If filename ends with .java then creates the
	 *            classname from the filename otherwise uses type and tsid
	 *            fields.
	 */
	public OBOECodeGenerator(String inEnvelope, TransactionSet inTS,
			String type, boolean inUseName, String outputFileName) {
		String programname = type + tsID;
		try {
			if (outputFileName == null)
				pw = new PrintWriter(System.out);
			else {
				FileOutputStream fos = new FileOutputStream(outputFileName);
				if (outputFileName.toLowerCase().endsWith(".java")) {
					File file = new File(outputFileName);
					String filename = file.getName();
					programname = filename.substring(0, filename.length() - 5);
				}
				pw = new PrintWriter(fos);
			}

			TemplateEnvelope env = EnvelopeFactory.buildEnvelope(inEnvelope,
					"notSetYet");

			if (type.endsWith("J"))
				doJava(env, inTS, type, inUseName, programname);
			else
				doPIXES(env, inTS, type, inUseName);

			pw.close();
		} catch (FileNotFoundException e1) {
			e1.printStackTrace();
			System.exit(1);
		} catch (Exception e1) {
			e1.printStackTrace();
			System.exit(1);
		}
	}

		
	public void doJava(TemplateEnvelope inEnv, TransactionSet inTS,
			String type, boolean inUseName, String inPgmName) throws Exception
	{
		useName = inUseName;
		tsID = inTS.getID();
		String programname = inPgmName;
		pw.write("import com.americancoders.edi.*;" + lineFeed);

		if (inEnv.getType().compareTo("X12") == 0)
			this.ediType = 'x';
		else if (inEnv.getType().compareTo("EDIFact") == 0)
			this.ediType = 'e';
		else if (inEnv.getType().compareTo("Tradacoms") == 0)
			this.ediType = 't';
		else if (inEnv.getType().compareTo("ACH") == 0)
			this.ediType = 'a';
		else
			throw new OBOEException("Unknown type " + inEnv.getType());

		if (ediType == 'x')
			pw.write("import com.americancoders.edi.x12.*;" + lineFeed);
		else if (ediType == 'e')
			pw.write("import com.americancoders.edi.EDIFact.*;"
							+ lineFeed);
		else if (ediType == 't')
			pw.write("import com.americancoders.edi.Tradacoms.*;"
					+ lineFeed);
		else if (ediType == 'a')
			pw.write("import com.americancoders.edi.ACH.*;" + lineFeed);

		if (type.compareTo("bJ") == 0) {
			pw.write(lineFeed);
			pw.write("/** code template to build" + lineFeed
					+ "*<br>class " + tsID + " " + inTS.getName()
					+ lineFeed + "*<br>" + lineFeed);
		} else if (type.compareTo("pJ") == 0){
			pw.write("import java.io.*;" + lineFeed);
			pw.write(lineFeed);
			pw.write("/** code template to parse" + lineFeed
					+ "*<br>class " + tsID + " " + inTS.getName()
					+ lineFeed + "*<br>" + lineFeed);
		}
		int ispace;
		for (int ic = 0; ic < inTS.getShortDescription().length(); ic++) {
			ispace = inTS.getShortDescription().indexOf(' ', ic + 60);
			if (ispace < 0)
				ispace = inTS.getShortDescription().length();
			pw.write("* "
					+ inTS.getShortDescription().substring(ic, ispace)
					+ lineFeed);
			ic = ispace;
		}
		pw.write("*@author OBOECodeGenerator" + lineFeed + "*/"
						+ lineFeed);
		pw.write("public class " + programname + lineFeed + "{"
						+ lineFeed);
		pw.write("/** constructor for class " + programname + lineFeed);
		if (type.compareTo("pJ") == 0)
			pw.write("*@param inFileName - String filename to be parsed"
					+ lineFeed);

		pw.write("*@throws OBOEException - most likely transactionset not found"
						+ lineFeed);
		if (type.compareTo("pJ") == 0)
			pw.write("*@throws IOException - most likely input file not found"
							+ lineFeed);

		pw.write("*/" + lineFeed);
		if (type.compareTo("bJ") == 0) {
			pw.write("public " + programname + "()" + lineFeed
					+ "  throws OBOEException" + lineFeed + "{" + lineFeed);
			if (ediType == 'x') {
				pw.write("  X12Envelope env = new X12Envelope(EnvelopeFactory.buildEnvelope(\"x12.envelope\", \"\"));"
								+ lineFeed);
				pw.write("  /** add code here to work with the headers and other envelope control segments */"
								+ lineFeed);
				pw.write("  Segment interchange_Control_Header = env.createInterchange_Header();"
								+ lineFeed);
				pw.write("  interchange_Control_Header.useDefault();"
						+ lineFeed);
				pw.write("  //  Grade of Service Request not required"
						+ lineFeed);
				pw.write("  Segment grade_of_Service_Request = env.createGrade_of_Service_Request();"
								+ lineFeed);
				pw.write("  grade_of_Service_Request.useDefault();"
						+ lineFeed);
				pw.write("  //  Deferred Delivery Request not required"
						+ lineFeed);
				pw.write("  Segment deferred_Delivery_Request = env.createDeferred_Delivery_Request();"
								+ lineFeed);
				pw.write("  deferred_Delivery_Request.useDefault();"
						+ lineFeed);

			} else if (ediType == 'e') {
				pw.write("  EDIFactEnvelope env = new EDIFactEnvelope(EnvelopeFactory.buildEnvelope(\"EDIFact.envelope\"));"
								+ lineFeed);
				pw.write(lineFeed
								+ "  /** add code here to work with the headers and other envelope control segments */"
								+ lineFeed);
				pw.write("  Segment interchange_Control_Header = env.createInterchange_Header();"
								+ lineFeed);
				pw.write("  interchange_Control_Header.useDefault();"
						+ lineFeed);
			} else if (ediType == 't') {
				pw.write("  TradacomsEnvelope env = new TradacomsEnvelope(EnvelopeFactory.buildEnvelope(\"Tradacoms.envelope\"));"
								+ lineFeed);
				pw.write(lineFeed
								+ "  /** add code here to work with the headers and other envelope control segments */"
								+ lineFeed);
				pw.write("  Segment interchange_Control_Header = env.createInterchange_Header();"
								+ lineFeed);
				pw.write("  interchange_Control_Header.useDefault();"
						+ lineFeed);
			} else if (ediType == 'a') {
				pw.write("  ACHEnvelope env = new ACHEnvelope(EnvelopeFactory.buildEnvelope(\"ACH.envelope\"));"
								+ lineFeed);
				pw.write(lineFeed
								+ "  /** add code here to work with the headers and other envelope control segments */"
								+ lineFeed);
				pw.write("  Segment interchange_Control_Header = env.createInterchange_Header();"
								+ lineFeed);
				pw.write("  interchange_Control_Header.useDefault();"
						+ lineFeed);
			}
			pw.write("  FunctionalGroup fg = env.createFunctionalGroup();"
					+ lineFeed + lineFeed);
			if (ediType == 'x') {
				pw.write(lineFeed
								+ "  /** add code here to work with the fg header and trailer segments */"
								+ lineFeed);
				pw.write("  Segment fgHeader = fg.getHeader();"
								+ lineFeed);
				pw.write("  fgHeader.useDefault();" + lineFeed);
				pw.write("  fg.addSegment(fgHeader);" + lineFeed
								+ lineFeed);
				pw.write("  Segment fgTrailer = fg.getTrailer();"
						+ lineFeed);
				pw.write("  fgTrailer.useDefault();" + lineFeed);
				pw.write("  fg.addSegment(fgTrailer);" + lineFeed
						+ lineFeed);
			} else {

			}

			pw.write("  env.addFunctionalGroup(fg);" + lineFeed);
			pw.write("  TransactionSet ts = TransactionSetFactory.buildTransactionSet(\""
							+ tsID + "\");" + lineFeed);
			pw.write("  fg.addTransactionSet(ts);" + lineFeed + lineFeed);
		} else if (type.compareTo("pJ") == 0) {
			pw.write("public " + programname + "(String inFileName)"
					+ lineFeed + "  throws OBOEException, IOException"
					+ lineFeed + "{" + lineFeed);
			pw.write("  File fileToParse = new File(inFileName);"
					+ lineFeed);
			pw.write("  if (fileToParse.exists() == false)" + lineFeed);
			pw.write("     throw new OBOEException(\"File: \"+ inFileName + \" does not exist.\");"
							+ lineFeed);
			if (ediType == 'x') {
				pw.write("  X12DocumentHandler dh = new X12DocumentHandler();"
								+ lineFeed);
				pw.write("  dh.startParsing(new FileReader(fileToParse));"
						+ lineFeed);
				pw.write("  X12Envelope env = (X12Envelope) dh.getEnvelope();"
								+ lineFeed);
			} else if (ediType == 'e') {
				pw.write("  EDIFactDocumentHandler dh = new EDIDocumentHandler();"
								+ lineFeed);
				pw.write("  dh.startParsing(new FileReader(fileToParse));"
						+ lineFeed);
				pw.write("  EDIFactEnvelope env = (EDIFactEnvelope) parsed.getEnvelope();"
								+ lineFeed);
			} else if (ediType == 't') {
				pw.write("  TradacomsDocumentHandler dh = new EDIDocumentHandler();"
								+ lineFeed);
				pw.write("  dh.startParsing(new FileReader(fileToParse));"
						+ lineFeed);
				pw.write("  TradacomsEnvelope env = (TradacomsEnvelope) parsed.getEnvelope();"
								+ lineFeed);
			}
		}

		pw.write(lineFeed);

		pw.write("  Table table;" + lineFeed);

		if (type.compareTo("bJ") == 0) {
			doBuildForJava(inTS);
		} else if (type.compareTo("pJ") == 0){
			pw.write("  FunctionalGroup fg;" + lineFeed);
			pw.write("  TransactionSet ts;" + lineFeed);
			doParseForJava(inTS);
		}



	pw.println("}");

	}
		
		
	/**
	 * when parsing an OBOE object this code generates the code to work with
	 * Envelopes, Functional Groups and Transaction Sets
	 *
	 * @param inTS
	 *            TransactionSet
	 */
	public void doParseForJava(TransactionSet inTS) {
		
		TemplateTransactionSet ts = inTS.getTemplateTransactionSet();

		pw.write("  int fgCount = env.getFunctionalGroupCount();" + lineFeed);
		pw.write("  int tsCount = -1;" + lineFeed);
		pw.write("  for (int fgPosition = 0; fgPosition < fgCount; fgPosition++)"
						+ lineFeed);
		pw.write("     {" + lineFeed);
		pw.write("        fg = env.getFunctionalGroup(fgPosition);"
						+ lineFeed);
		pw.write("        tsCount = fg.getTransactionSetCount();" + lineFeed);
		pw.write("        for (int tsPosition = 0; tsPosition < tsCount; tsPosition++)"
						+ lineFeed);
		pw.write("           {" + lineFeed);
		pw.write("             ts = fg.getTransactionSet(tsPosition);"
				+ lineFeed);

		TemplateTable table = ts.getHeaderTemplateTable();
		
		StringBuffer sb = new StringBuffer();
		
		int i;
		if (table != null) {
			pw.write("             table = ts.getHeaderTable();" + lineFeed);
			pw.write("             if (table != null)" + lineFeed
					+ "               {" + lineFeed);
			for (i = 0; i < table.getCount(); i++) {
				if (table.isLoop(i) && table.getTemplateLoop(i).isUsed()) {
					if (useName) {
						pw.write("                 extractLoop"
								+ table.getTemplateLoop(i).getXMLTag()
								+ "fromTableHeader(table);" + lineFeed);
						sb.append(parseLoopCodeForJava(table, "TableHeader", table.getTemplateLoop(i), table.getTemplateLoop(i).getXMLTag()));
					} else {
						pw.write("                 extractLoop"
								+ table.getTemplateLoop(i).getID()
								+ "fromTableHeader(table);" + lineFeed);
						sb.append(parseLoopCodeForJava(table, "TableHeader", table.getTemplateLoop(i), table.getTemplateLoop(i).getID()));
					}
				} else if (table.isSegment(i)
						&& table.getTemplateSegment(i).isUsed()) {
					if (useName) {
						pw.write("                 extractSegment"
								+ table.getTemplateSegment(i).getXMLTag()
								+ "fromTableHeader(table);" + lineFeed);
						sb.append(parseSegmentCodeForJava(table, "TableHeader", table.getTemplateSegment(i), table.getTemplateSegment(i).getXMLTag()));
					} else {
						pw.write("                 extractSegment"
								+ table.getTemplateSegment(i).getID()
								+ "fromTableHeader(table);" + lineFeed);
						sb.append(parseSegmentCodeForJava(table, "TableHeader", table.getTemplateSegment(i), table.getTemplateSegment(i).getID()));
					}
				}
			}
			pw.write(lineFeed + "              }" + lineFeed);
		}

		table = ts.getDetailTemplateTable();
		if (table != null) {
			pw.write("             table = ts.getDetailTable();" + lineFeed);
			pw.write("             if (table != null)" + lineFeed
					+ "               {" + lineFeed);

			for (i = 0; i < table.getCount(); i++) {
				if (table.isLoop(i) && table.getTemplateLoop(i).isUsed()) {
					if (useName) {
						pw.write("                 extractLoop"
								+ table.getTemplateLoop(i).getXMLTag()
								+ "fromTableDetail(table);" + lineFeed);
						sb.append(parseLoopCodeForJava(table, "TableDetail", table.getTemplateLoop(i), table.getTemplateLoop(i).getXMLTag()));
					} else {
						pw.write("                 extractLoop"
								+ table.getTemplateLoop(i).getID()
								+ "fromTableDetail(table);" + lineFeed);
						sb.append(parseLoopCodeForJava(table, "TableDetail", table.getTemplateLoop(i), table.getTemplateLoop(i).getID()));
					}
				} else if (table.isSegment(i)
						&& table.getTemplateSegment(i).isUsed()) {
					if (useName) {
						pw.write("                 extractSegment"
								+ table.getTemplateSegment(i).getXMLTag()
								+ "fromTableDetail(table);" + lineFeed);
						sb.append(parseSegmentCodeForJava(table, "TableDetail", table.getTemplateSegment(i), table.getTemplateSegment(i).getXMLTag()));
					} else {
						pw.write("                 extractSegment"
								+ table.getTemplateSegment(i).getID()
								+ "fromTableDetail(table);" + lineFeed);
						sb.append(parseSegmentCodeForJava(table, "TableDetail", table.getTemplateSegment(i), table.getTemplateSegment(i).getID()));
					}
				}
			}
			pw.write(lineFeed + "              }" + lineFeed);
		}

		table = ts.getSummaryTemplateTable();
		if (table != null) {
			pw.write("            table = ts.getSummaryTable();" + lineFeed);
			pw.write("             if (table != null)" + lineFeed
					+ "               {" + lineFeed);
			for (i = 0; i < table.getCount(); i++) {
				if (table.isLoop(i) && table.getTemplateLoop(i).isUsed()) {
					if (useName) {
						pw.write("                 extractLoop"
								+ table.getTemplateLoop(i).getXMLTag()
								+ "fromTableSummary(table);" + lineFeed);
						sb.append(parseLoopCodeForJava(table, "TableSummary", table.getTemplateLoop(i), table.getTemplateLoop(i).getXMLTag()));
					} else {
						pw.write("                 extractLoop"
								+ table.getTemplateLoop(i).getID()
								+ "fromTableSummary(table);" + lineFeed);
						sb.append(parseLoopCodeForJava(table, "TableSummary", table.getTemplateLoop(i), table.getTemplateLoop(i).getID()));
					}
				} else if (table.isSegment(i)
						&& table.getTemplateSegment(i).isUsed()) {
					if (useName) {
						pw.write("                 extractSegment"
								+ table.getTemplateSegment(i).getXMLTag()
								+ "fromTableSummary(table);" + lineFeed);
						sb.append(parseSegmentCodeForJava(table, "TableSummary", table.getTemplateSegment(i), table.getTemplateSegment(i).getXMLTag()));
					} else {
						pw.write("                 extractSegment"
								+ table.getTemplateSegment(i).getID()
								+ "fromTableSummary(table);" + lineFeed);
						sb.append(parseSegmentCodeForJava(table, "TableSummary", table.getTemplateSegment(i), table.getTemplateSegment(i).getID()));
					}
				}
			}
			pw.write(lineFeed + "              }" + lineFeed);
		}

		pw.write("           }" + lineFeed);
		pw.write("     }" + lineFeed);
		
		pw.write(lineFeed + "}" + lineFeed);

		pw.write(sb.toString()+lineFeed);

		
	}

	/**
	 * when building an OBOE object this code generates the code to work with
	 * Envelopes, Functional Groups and Transaction Sets
	 *
	 * @param inTS
	 *            TransactionSet
	 */
	private void doBuildForJava(TransactionSet inTS) {
		
		TemplateTransactionSet ts = inTS.getTemplateTransactionSet();
		TemplateTable table = ts.getHeaderTemplateTable();
		
		StringBuffer sb = new StringBuffer();


		int i;
		if (table != null) {
			pw.write("  table = ts.getHeaderTable();" + lineFeed);
			for (i = 0; i < table.getCount(); i++) {
				if (table.isSegment(i) && table.getTemplateSegment(i).isUsed()) {
					if (table.getTemplateSegment(i).getOccurs() > 1
							|| table.getTemplateSegment(i).getOccurs() == -1)
						pw.write("  // for (i = 0; i < multipletimes; i++)"
								+ lineFeed);
					if (useName)
						pw.write("  buildSegment"
								+ table.getTemplateSegment(i).getXMLTag()
								+ "forTableHeader(table);" + lineFeed);
					else
						pw.write("  buildSegment"
								+ table.getTemplateSegment(i).getID()
								+ "forTableHeader(table);" + lineFeed);
					sb.append(buildSegmentCodeForJava(table, "TableHeader", table.getTemplateSegment(i), "Header"));
				} else if (table.isLoop(i) && table.getTemplateLoop(i).isUsed()) {
					if (table.getTemplateLoop(i).getOccurs() > 1
							|| table.getTemplateLoop(i).getOccurs() == -1)
						pw.write("  // for (i = 0; i < multipletimes; i++)"
								+ lineFeed);
					if (useName)
						pw.write("  buildLoop"
								+ table.getTemplateLoop(i).getXMLTag()
								+ "forTableHeader(table);" + lineFeed);
					else
						pw.write("  buildLoop"
								+ table.getTemplateLoop(i).getID()
								+ "forTableHeader(table);" + lineFeed);
					sb.append(buildLoopCodeForJava(table, "TableHeader", table.getTemplateLoop(i), "Header"));
				}
			}
		}

		table = ts.getDetailTemplateTable();
		if (table != null) {
			pw.write("  table = ts.getDetailTable();" + lineFeed);
			for (i = 0; i < table.getCount(); i++) {
				if (table.isSegment(i) && table.getTemplateSegment(i).isUsed()) {
					if (table.getTemplateSegment(i).getOccurs() > 1
							|| table.getTemplateSegment(i).getOccurs() == -1)
						pw.write("  // for (i = 0; i < multipletimes; i++)"
								+ lineFeed);
					if (useName)
						pw.write("  buildSegment"
								+ table.getTemplateSegment(i).getXMLTag()
								+ "forTableDetail(table);" + lineFeed);
					else
						pw.write("  buildSegment"
								+ table.getTemplateSegment(i).getID()
								+ "forTableDetail(table);" + lineFeed);
					sb.append(buildSegmentCodeForJava(table, "TableDetail", table.getTemplateSegment(i), "Segment"));
				} else if (table.isLoop(i) && table.getTemplateLoop(i).isUsed()) {
					if (table.getTemplateLoop(i).getOccurs() > 1
							|| table.getTemplateLoop(i).getOccurs() == -1)
						pw.write("  // for (i = 0; i < multipletimes; i++)"
								+ lineFeed);
					if (useName)
						pw.write("  buildLoop"
								+ table.getTemplateLoop(i).getXMLTag()
								+ "forTableDetail(table);" + lineFeed);
					else
						pw.write("  buildLoop"
								+ table.getTemplateLoop(i).getID()
								+ "forTableDetail(table);" + lineFeed);
					sb.append(buildLoopCodeForJava(table, "TableDetail", table.getTemplateLoop(i), "Detail"));
				}
			}
		}

		table = ts.getSummaryTemplateTable();
		if (table != null) {
			pw.write("  table = ts.getSummaryTable();" + lineFeed);
			for (i = 0; i < table.getCount(); i++) {
				if (table.isSegment(i) && table.getTemplateSegment(i).isUsed()) {
					if (table.getTemplateSegment(i).getOccurs() > 1
							|| table.getTemplateSegment(i).getOccurs() == -1)
						pw.write("  // for (i = 0; i < multipletimes; i++)"
								+ lineFeed);
					if (useName)
						pw.write("  buildSegment"
								+ table.getTemplateSegment(i).getXMLTag()
								+ "forTableSummary(table);" + lineFeed);
					else
						pw.write("  buildSegment"
								+ table.getTemplateSegment(i).getID()
								+ "forTableSummary(table);" + lineFeed);
					sb.append(buildSegmentCodeForJava(table, "TableSummary", table.getTemplateSegment(i), "Summary"));
				} else if (table.isLoop(i) && table.getTemplateLoop(i).isUsed()) {
					if (table.getTemplateLoop(i).getOccurs() > 1
							|| table.getTemplateLoop(i).getOccurs() == -1)
						pw.write("  // for (i = 0; i < multipletimes; i++)"
								+ lineFeed);
					if (useName)
						pw.write("  buildLoop"
								+ table.getTemplateLoop(i).getXMLTag()
								+ "forTableSummary(table);" + lineFeed);
					else
						pw.write("  buildLoop"
								+ table.getTemplateLoop(i).getID()
								+ "forTableSummary(table);" + lineFeed);
					sb.append(buildLoopCodeForJava(table, "TableSummary", table.getTemplateLoop(i), "Summary"));
				}
			}
		}
		pw.write(lineFeed);
		if (ediType == 'x') {
			pw.write("  Segment interchange_Control_Trailer = env.createInterchange_Trailer();"
							+ lineFeed);
			pw.write("  interchange_Control_Trailer.useDefault();" + lineFeed);
		} else if (ediType == 'e') {
			pw.write("  Segment interchange_Control_Trailer = env.createInterchange_Trailer();"
							+ lineFeed);
			pw.write("  interchange_Control_Trailer.useDefault();" + lineFeed);
		} else if (ediType == 't') {
			pw.write("  Segment interchange_Control_Trailer = env.createInterchange_Trailer();"
							+ lineFeed);
			pw.write("  interchange_Control_Trailer.useDefault();" + lineFeed);
		} else if (ediType == 'a') {
			pw.write("  Segment interchange_Control_Trailer = env.createInterchange_Trailer();"
							+ lineFeed);
			pw.write("  interchange_Control_Trailer.useDefault();" + lineFeed);
		}
		pw.write(lineFeed
				+ " for (int i = 0; i < env.getFunctionalGroupCount(); i++)"
				+ lineFeed);
		pw.write("    {" + lineFeed);
		pw.write("     env.getFunctionalGroup(i).setCountInTrailer();"
				+ lineFeed);
		pw.write("     for (int j = 0; j < env.getFunctionalGroup(i).getTransactionSetCount(); j++) {"
						+ lineFeed);
		pw.write("       env.getFunctionalGroup(i).getTransactionSet(j).trim();"
						+ lineFeed);
		pw.write("       env.getFunctionalGroup(i).getTransactionSet(j).setTrailerFields(); }"
						+ lineFeed);
		pw.write("    }" + lineFeed);

		pw.write(lineFeed + " env.setFGCountInTrailer();");
		
		pw.write(lineFeed + "}" + lineFeed);

		pw.write(sb.toString());
		
	}

	/**
	 * when building an OBOE object this code generates the segment logic
	 *
	 * @param parent
	 *            object either a Table or TemplateSegment
	 * @param name
	 *            parent name path
	 * @param loop
	 *            TemplateLoop currently working with
	 * @param methodName -
	 *            part of method name to use
	 */
	private String parseLoopCodeForJava(Object parent, String name, TemplateLoop loop,
			String methodName) {
		StringWriter pw = new StringWriter();


		String indent = "";
		int i;
		StringBuffer sb = new StringBuffer();
		pw.write("/** extract data from loop " + loop.getID()
				+ " that is part of " + name + lineFeed);
		pw.write("*<br>" + loop.getName() + " used " + lineFeed);

		if (parent instanceof TemplateTable)
			pw.write("* @param inTable table containing this loop" + lineFeed);
		else
			pw.write("* @param inLoop loop containing this loop" + lineFeed);

		pw.write("*@throws OBOEException - most likely loop not found"
				+ lineFeed);
		pw.write("*/" + lineFeed);
		if (parent instanceof TemplateTable) {
			if (useName)
				pw.write("public void extractLoop" + methodName + "from"
						+ name + "(Table inTable)" + lineFeed
						+ "  throws OBOEException" + lineFeed + "{" + lineFeed);
			else
				pw.write("public void extractLoop" + methodName + "from"
						+ name + "(Table inTable)" + lineFeed
						+ "  throws OBOEException" + lineFeed + "{" + lineFeed);
			pw.write("  Loop loop");
			if (loop.getOccurs() > 1 || loop.getOccurs() == -1) {
				pw.write(";" + lineFeed);
				pw.write("  int numberInVector = inTable.getCount(\""
						+ loop.getID() + "\");" + lineFeed);
				pw.write("  for (int i = 0; i <  numberInVector; i++)"
						+ lineFeed);
				pw.write("   {" + lineFeed);
				pw.write("     loop = inTable.getLoop(\"" + loop.getID()
						+ "\", i);" + lineFeed);
				pw.write("     if (loop == null) return;" + lineFeed);
				indent = "   ";
			} else {
				pw.write(" = inTable.getLoop(\"" + loop.getID() + "\");"
						+ lineFeed);
				pw.write("    if (loop == null) return;" + lineFeed);
			}
		} else // templateloop
		{
			if (useName)
				pw.write("public void extractLoop" + methodName + "from"
						+ name + "(Loop inLoop)  throws OBOEException"
						+ lineFeed + "{" + lineFeed);
			else
				pw.write("public void extractLoop" + methodName + "from"
						+ name + "(Loop inLoop)  throws OBOEException"
						+ lineFeed + "{" + lineFeed);
			pw.write("  Loop loop");
			if (loop.getOccurs() > 1 || loop.getOccurs() == -1) {
				pw.write(";" + lineFeed);
				pw.write("  int numberInVector = inLoop.getCount(\""
						+ loop.getID() + "\");" + lineFeed);
				pw.write("  for (int i = 0; i <  numberInVector; i++)"
						+ lineFeed);
				pw.write("   {" + lineFeed);

				pw.write("   loop = inLoop.getLoop(\"" + loop.getID()
						+ "\", i);" + lineFeed);
				pw.write("   if (loop == null) return;" + lineFeed);
				indent = "    ";
			} else {
				pw.write(" = inLoop.getLoop(\"" + loop.getID() + "\");"
						+ lineFeed);
				pw.write("  if (loop == null) return;" + lineFeed);
			}
		}

		for (i = 0; i < loop.getCount(); i++) {
			if (loop.isSegment(i) && loop.getTemplateSegment(i).isUsed()) {

				if (useName) {
					String pmName = this.whatMethodName(loop.getXMLTag(), loop.getTemplateSegment(i).getXMLTag());
					pw.write(indent + "  extractSegment" + pmName + "fromLoop"
							+ loop.getXMLTag() + "(loop);" + lineFeed);
					sb.append(parseSegmentCodeForJava(loop, "Loop" + loop.getXMLTag(), loop.getTemplateSegment(i), pmName));
				} else {
					String pmName = this.whatMethodName(name, loop.getTemplateSegment(i).getID());
					pw.write(indent + "  extractSegment" + pmName + "from"
							+ name + "Loop" + loop.getID() + "(loop);"
							+ lineFeed);
					sb.append(parseSegmentCodeForJava(loop, name + "Loop" + loop.getID(), loop.getTemplateSegment(i), pmName));
				}
			} else if (loop.isLoop(i) && loop.getTemplateLoop(i).isUsed()) {
				if (useName) {
					String pmName = this.whatMethodName(loop.getXMLTag(), loop.getTemplateLoop(i).getXMLTag());
					pw.write(indent + "  extractLoop" + pmName + "fromLoop"
							+ loop.getXMLTag() + "(loop);" + lineFeed);
					sb.append(parseLoopCodeForJava(loop, "Loop" + loop.getXMLTag(), loop.getTemplateLoop(i), pmName));
				} else {
					String pmName = this.whatMethodName(name, loop.getTemplateLoop(i).getID());
					pw.write(indent + "  extractLoop" + pmName + "from" + name
							+ "Loop" + loop.getID() + "(loop);" + lineFeed);
					sb.append(parseLoopCodeForJava(loop, name + "Loop" + loop.getID(), loop.getTemplateLoop(i), pmName));
				}
			}
		}

		if (loop.getOccurs() > 1 || loop.getOccurs() == -1) {
			pw.write("    }" + lineFeed);
		}
		
		pw.write("  }" + lineFeed);
		
		pw.write(sb.toString()+lineFeed);
		
		
		return pw.toString();
	}

	/**
	 * when building an OBOE object this code generates the segment logic
	 *
	 * @param parent
	 *            object either a Table or TemplateSegment
	 * @param name
	 *            parent name path
	 * @param seg
	 *            TemplateSegment currently working with
	 * @param methodName -
	 *            part of method name to use
	 */
	private String parseSegmentCodeForJava(Object parent, String name,
			TemplateSegment seg, String methodName) {
		

		StringWriter pw = new StringWriter();
		String indent = "  ";
		int i;

		pw.write("/** extract data from segment " + seg.getID()
				+ " that is part of the " + name + lineFeed);
		pw.write("*<br>" + seg.getName() + " used " + lineFeed);
		pw.write("*<br>" + seg.getDescription() + lineFeed);
		if (parent instanceof TemplateTable)
			pw.write("* @param inTable Table containing this segment"
					+ lineFeed);
		else
			pw.write("* @param inLoop Loop containing this segment"
							+ lineFeed);

		pw.write("*@throws OBOEException - most likely segment not found"
				+ lineFeed);
		pw.write("*/" + lineFeed);
		if (parent instanceof TemplateTable) {
			if (useName)
				pw.write("public void extractSegment" + methodName + "from"
						+ name + "(Table inTable)" + lineFeed
						+ "  throws OBOEException" + lineFeed + "{" + lineFeed);
			else
				pw.write("public void extractSegment" + methodName + "from"
						+ name + "(Table inTable)" + lineFeed
						+ "  throws OBOEException" + lineFeed + "{" + lineFeed);
			pw.write("  Segment segment");
			if (seg.getOccurs() > 1 || seg.getOccurs() == -1) {
				pw.write(";" + lineFeed);
				pw.write("  int numberOfSegmentsInVector = inTable.getCount(\""
								+ seg.getID() + "\");" + lineFeed);
				pw.write("  for (int i = 0; i <  numberOfSegmentsInVector; i++)"
								+ lineFeed);
				pw.write("   {" + lineFeed);
				if (seg.canYouPrevalidate()
						&& ((TemplateSegmentContainer) seg.getParent()).getCount(seg.getID()) > 1) {
					Vector v = seg.getIDListThatPrevalidates().getCodes();
					String vs = (String) v.elementAt(0);
					pw.write(" = inTable.getSegment(\"" + seg.getID()
							+ "\", \"" + vs + "\", i);" + lineFeed);
					if (v.size() > 1) {
						pw.write("  //  other key values: ");
						for (int ii = 1; ii < v.size(); ii++) {
							pw.write("\"" + (String) v.elementAt(ii) + "\" ");
						}
						pw.write(lineFeed);
						pw.write("   // there can be " + seg.getOccurs()
								+ " of these segments." + lineFeed);
					}
				} else
					pw.write("     segment = inTable.getSegment(\""
							+ seg.getID() + "\", i);" + lineFeed);
				indent = "     ";
			} else {
				if (seg.canYouPrevalidate()
						&& ((TemplateSegmentContainer) seg.getParent()).getCount(seg.getID()) > 1) {
					Vector v = seg.getIDListThatPrevalidates().getCodes();
					if (v.size() < 4) {
						String vs = (String) v.elementAt(0);
						pw.write(" = inTable.getSegment(\"" + seg.getID()
								+ "\", \"" + vs + "\");" + lineFeed);
						if (v.size() > 1) {
							pw.write("  //  other key values: ");
							for (int ii = 1; ii < v.size(); ii++) {
								pw.write("\"" + (String) v.elementAt(ii)
										+ "\" ");
							}
							pw.write(lineFeed);
						} else {
							pw.write(" = inTable.getSegment(\"" + seg.getID()
									+ "\");" + lineFeed);
							pw.write("       //  could have used getSegmetn(id, primarykeyvalue) "
											+ lineFeed);
						}

					} else
						pw.write(" = inTable.getSegment(\"" + seg.getID()
								+ "\");" + lineFeed);
				} else
					pw.write(" = inTable.getSegment(\"" + seg.getID() + "\");"
							+ lineFeed);
			}
		} else // loop
		{
			if (useName)
				pw.write("public void extractSegment" + methodName + "from"
						+ name + "(Loop inLoop)  throws OBOEException"
						+ lineFeed + "{" + lineFeed);
			else
				pw.write("public void extractSegment" + methodName + "from"
						+ name + "(Loop inLoop)  throws OBOEException"
						+ lineFeed + "{" + lineFeed);
			pw.write("  Segment segment");
			if (seg.getOccurs() > 1 || seg.getOccurs() == -1) {
				pw.write(";" + lineFeed);
				pw.write("  int numberOfSegmentsInVector = inLoop.getCount(\""
						+ seg.getID() + "\");" + lineFeed);
				pw.write("  for (int i = 0; i <  numberOfSegmentsInVector; i++)"
								+ lineFeed);
				pw.write("    {" + lineFeed);
				if (seg.canYouPrevalidate()
						&& ((TemplateSegmentContainer) seg.getParent()).getCount(seg.getID()) > 1) {
					Vector v = seg.getIDListThatPrevalidates().getCodes();
					String vs = (String) v.elementAt(0);
					pw.write("       segment = inLoop.getSegment(\""
							+ seg.getID() + "\", \"" + vs + "\", i);"
							+ lineFeed);
					if (v.size() > 1) {
						pw.write(" // other key values: ");
						for (int ii = 1; ii < v.size(); ii++) {
							pw.write("\"" + (String) v.elementAt(ii) + "\" ");
						}
						pw.write(lineFeed);
						pw.write("   // there can be " + seg.getOccurs()
								+ " of these segments." + lineFeed);
					}

				} else
					pw.write("       segment = inLoop.getSegment(\""
							+ seg.getID() + "\", i);" + lineFeed);
				indent = "       ";
			} else {
				if (seg.canYouPrevalidate()
						&& ((TemplateSegmentContainer) seg.getParent()).getCount(seg.getID()) > 1) {
					Vector v = seg.getIDListThatPrevalidates().getCodes();
					if (v.size() < 4) {
						String vs = (String) v.elementAt(0);
						pw.write(" = inLoop.getSegment(\"" + seg.getID()
								+ "\", \"" + vs + "\");" + lineFeed);
						if (v.size() > 1) {
							pw.write(" // other key values: ");
							for (int ii = 1; ii < v.size(); ii++) {
								pw.write("\"" + (String) v.elementAt(ii)
										+ "\" ");
							}
							pw.write(lineFeed);
						}
					} else {
						pw.write(" = inLoop.getSegment(\"" + seg.getID()
								+ "\");" + lineFeed);
						pw.write("  //  could have used getSegment(id, primarykeyvalue) "
										+ lineFeed);

					}
				} else
					pw.write(" = inLoop.getSegment(\"" + seg.getID() + "\");"
							+ lineFeed);
			}
		}

		pw.write(indent + "if (segment == null)" + lineFeed + indent
				+ "  return;" + lineFeed);

		pw.write(indent + "DataElement de;" + lineFeed);
		boolean compositeDone = false;
		for (i = 0; i < seg.getTemplateDESize(); i++) {
			if (seg.isTemplateComposite(i + 1)
					&& seg.getTemplateComposite(i + 1).isUsed()) {
				if (compositeDone == false) {
					pw.write(indent + "  CompositeDE");
					compositeDone = true;
				}
				pw.write(parseCompositeCodeForJava(seg.getTemplateComposite(i + 1), i));

			} else if (seg.isTemplateDE(i + 1)
					&& seg.getTemplateDE(i + 1).isUsed()) {
				pw.write(indent + "de = segment.getDataElement(" + (i + 1)
						+ ");");
				pw.write(indent + "// " + seg.getTemplateDE(i + 1).getID()
						+ " " + seg.getTemplateDE(i + 1).getName() + lineFeed);
				pw.write(indent + "if (de != null)" + lineFeed);
				pw.write(indent + "  de.get();" + lineFeed);
			}
		}

		if (seg.getOccurs() > 1 || seg.getOccurs() == -1)
			pw.write("    }" + lineFeed);

		pw.write("  }" + lineFeed);
		
		return pw.toString();

	}

	/**
	 * when building an OBOE object this code generates the composite logic
	 *
	 * @param tce
	 *            TemplateComposite currently working with
	 * @param inI
	 *            position of Composite within parent object, used for output
	 *            code
	 */
	private String parseCompositeCodeForJava(TemplateComposite tce, 
			int inI) {
		
		StringWriter pw = new StringWriter();
		pw.write("  composite = (CompositeDE) segment.getCompositeDE("
				+ (inI + 1) + ");");
		pw.write("  // " + tce.getID() + " " + tce.getName() + lineFeed);
		pw.write("  if (composite == null)" + lineFeed + "    return;"
				+ lineFeed);
		int i;
		for (i = 0; i < tce.getTemplateDESize(); i++) {
			if (tce.isTemplateDE(i + 1) && tce.getTemplateDE(i + 1).isUsed()) {
				pw.write("  de = composite.getDataElement(" + (i + 1) + ");");
				pw.write("  // composite element "
						+ tce.getTemplateDE(i + 1).getID() + " "
						+ tce.getTemplateDE(i + 1).getName() + lineFeed);
				pw.write("  if (de != null)" + lineFeed);
				pw.write("    de.get();" + lineFeed);
			}
		}
		return pw.toString();
	}

	/**
	 * when parsing an OBOE object this code generates the loop logic
	 *
	 * @param parent
	 *            object either a Table or TemplateLoop
	 * @param name
	 *            parent name path
	 * @param loop
	 *            TemplateLoop currently working with
	 *
	 */
	private String buildLoopCodeForJava(Object parent, String name, TemplateLoop loop,
			String methodName) {
		
		StringWriter pw = new StringWriter();
		
		StringBuffer sb = new  StringBuffer();

		pw.write("/** builds loop " + loop.getID() + " that is part of the "
				+ name + lineFeed);
		pw.write("*<br>" + loop.getName() + " used " + lineFeed);

		if (parent instanceof TemplateTable)
			pw.write("* @param inTable table containing this segment"
					+ lineFeed);
		else
			pw.write("* @param inLoop loop" + lineFeed);
		pw.write("* @return loop object " + loop.getID() + lineFeed);
		pw.write("* @throws OBOEException - most likely segment not found"
				+ lineFeed);
		pw.write("*/" + lineFeed);
		if (parent instanceof TemplateTable) {
			if (useName)
				pw.write("public Loop buildLoop" + loop.getXMLTag() + "for"
						+ name + "(Table inTable)" + lineFeed
						+ "  throws OBOEException" + lineFeed + "{" + lineFeed);
			else
				pw.write("public Loop buildLoop" + loop.getID() + "for" + name
						+ "(Table inTable)" + lineFeed
						+ "  throws OBOEException" + lineFeed + "{" + lineFeed);
			pw.write("  Loop loop = inTable.createLoop(\"" + loop.getID()
					+ "\");" + lineFeed);
			pw.write("  inTable.addLoop(loop);" + lineFeed);
		} else {
			if (useName)
				pw.write("public Loop buildLoop" + methodName + "for" + name
						+ "(Loop inLoop)  throws OBOEException" + lineFeed
						+ "{" + lineFeed);
			else
				pw.write("public Loop buildLoop" + methodName + "for" + name
						+ "(Loop inLoop)  throws OBOEException" + lineFeed
						+ "{" + lineFeed);
			pw.write("  Loop loop = inLoop.createLoop(\"" + loop.getID()
					+ "\");" + lineFeed);
			pw.write("  inLoop.addLoop(loop);" + lineFeed);
		}
		int i;
		for (i = 0; i < loop.getCount(); i++) {
			if (loop.isSegment(i) && loop.getTemplateSegment(i).isUsed()) {
				if (useName) {
					String pmName = this.whatMethodName(loop.getXMLTag(), loop.getTemplateSegment(i).getXMLTag());
					pw.write("  buildSegment" + pmName + "forLoop"
							+ loop.getID() + "(loop);" + lineFeed);
					sb.append(buildSegmentCodeForJava(loop, "Loop" + loop.getID(), loop.getTemplateSegment(i), pmName));
				} else {
					String pmName = this.whatMethodName(name + loop.getID(),
							loop.getTemplateSegment(i).getID());
					pw.write("  buildSegment" + pmName + "for" + name
							+ loop.getID() + "(loop);" + lineFeed);
					sb.append(buildSegmentCodeForJava(loop, name + loop.getID(), loop.getTemplateSegment(i), pmName));
				}
			} else if (loop.isLoop(i) && loop.getTemplateLoop(i).isUsed()) {
				if (useName) {
					String pmName = this.whatMethodName(loop.getXMLTag(), loop.getTemplateLoop(i).getXMLTag());
					pw.write("  buildLoop" + pmName + "forLoop" + loop.getID()
							+ "(loop);" + lineFeed);
					sb.append(buildLoopCodeForJava(loop, "Loop" + loop.getID(), loop.getTemplateLoop(i), pmName));
				} else {
					String pmName = this.whatMethodName(name + loop.getID(),
							loop.getTemplateLoop(i).getID());
					pw.write("  buildLoop" + pmName + "for" + name
							+ loop.getID() + "(loop);" + lineFeed);
					sb.append(buildLoopCodeForJava(loop, name + loop.getID(), loop.getTemplateLoop(i), pmName));
				}
			}
		}
		pw.write("  return loop;" + lineFeed);

		pw.write("  }" + lineFeed);
		
		pw.write(sb.toString());
		return pw.toString();
	}

	/**
	 * when parsing an OBOE object this code generates the segment logic
	 *
	 * @param parent
	 *            object either a Table or TemplateSegment
	 * @param name
	 *            parent name path
	 * @param seg
	 *            TemplateSegment currently working with
	 * @param methodName -
	 *            part of method name
	 */
	private String buildSegmentCodeForJava(Object parent, String name,
			TemplateSegment seg, String methodName) {

		StringWriter pw = new StringWriter();

		pw.write("/** builds segment " + seg.getID() + " that is part of the "
				+ name + lineFeed);
		pw.write("*<br>" + seg.getName() + " used " + lineFeed);
		pw.write("*<br>" + seg.getDescription() + lineFeed);
		if (parent instanceof TemplateTable)
			pw.write("* @param inTable table containing this segment"
					+ lineFeed);
		else
			pw.write("* @param inLoop loop containing this segment"
							+ lineFeed);
		pw.write("* @return segment object " + seg.getID() + lineFeed);
		pw.write("* @throws OBOEException - most likely segment not found"
				+ lineFeed);
		pw.write("*/" + lineFeed);
		if (parent instanceof TemplateTable) {
			if (useName)
				pw.write("public Segment buildSegment" + seg.getXMLTag()
						+ "for" + name + "(Table inTable)" + lineFeed
						+ "  throws OBOEException" + lineFeed + "{" + lineFeed);
			else
				pw.write("public Segment buildSegment" + seg.getID() + "for"
						+ name + "(Table inTable)" + lineFeed
						+ "  throws OBOEException" + lineFeed + "{" + lineFeed);
			if (seg.canYouPrevalidate()) {
				Vector v = this.getIDList(seg);
				if (v.size() == 1)
					pw.write("  Segment segment = inTable.createSegment(\""
							+ seg.getID() + "\", \"" + v.get(0) + "\");"
							+ lineFeed);
				else if (v.size() < 5) {
					pw.write("  Segment segment = inTable.createSegment(\""
							+ seg.getID() + "\", StringReplace);" + lineFeed);
					pw.write("// remove the StringReplace argument or replace StringReplace with one of the following..."
									+ lineFeed);
					pw.write("//");
					for (int vi = 0; vi < v.size(); vi++) {
						pw.write("\"" + v.get(vi) + "\" ");
					}
					pw.write(lineFeed);
				} else {
					pw.write("  Segment segment = inTable.createSegment(\""
							+ seg.getID() + "\");" + lineFeed);
					pw.write("// but you may want to try createSegment(String, String);"
									+ lineFeed);
				}
			} else
				pw.write("  Segment segment = inTable.createSegment(\""
						+ seg.getID() + "\");" + lineFeed);
			pw.write("  inTable.addSegment(segment);" + lineFeed);
		} else {
			if (useName)
				pw.write("public Segment buildSegment" + methodName + "for"
						+ name + "(Loop inLoop)  throws OBOEException"
						+ lineFeed + "{" + lineFeed);
			else
				pw.write("public Segment buildSegment" + methodName + "for"
						+ name + "(Loop inLoop)  throws OBOEException"
						+ lineFeed + "{" + lineFeed);
			if (seg.canYouPrevalidate()) {
				Vector v = this.getIDList(seg);
				if (v.size() == 1)
					pw.write("  Segment segment = inLoop.createSegment(\""
							+ seg.getID() + "\", \"" + v.get(0) + "\");"
							+ lineFeed);
				else if (v.size() < 5) {
					pw.write("  Segment segment = inLoop.createSegment(\""
							+ seg.getID() + "\", StringReplace);" + lineFeed);
					pw.write("// remove the StringReplace argument or replace StringReplace with one of the following..."
									+ lineFeed);
					pw.write("//");
					for (int vi = 0; vi < v.size(); vi++) {
						pw.write("\"" + v.get(vi) + "\" ");
					}
					pw.write(lineFeed);
				} else {
					pw.write("  Segment segment = inLoop.createSegment(\""
							+ seg.getID() + "\");" + lineFeed);
					pw.write("// but you may want to try createSegment(String, String);"
									+ lineFeed);
				}
			} else
				pw.write("  Segment segment = inLoop.createSegment(\""
						+ seg.getID() + "\");" + lineFeed);
			pw.write("  inLoop.addSegment(segment);" + lineFeed);
		}
		int i;

		pw.write("  DataElement de;" + lineFeed);
		boolean compositeDone = false;
		for (i = 0; i < seg.getTemplateDESize(); i++) {
			if (seg.isTemplateComposite(i + 1)
					&& seg.getTemplateComposite(i + 1).isUsed()) {
				if (compositeDone == false) {
					pw.write("  CompositeDE");
					compositeDone = true;
				}
				pw.write(buildCompositeCodeForJava(seg.getTemplateComposite(i + 1), i));

			} else if (seg.isTemplateDE(i + 1)
					&& seg.getTemplateDE(i + 1).isUsed()) {
				pw.write("  de = (DataElement) segment.buildDE(" + (i + 1)
						+ ");");
				pw.write("  // " + seg.getTemplateDE(i + 1).getID() + " "
						+ seg.getTemplateDE(i + 1).getName() + lineFeed);
				if (ediType == 'x' && seg.getID().compareTo("ST") == 0
						&& i == 0)
					pw.write("  de.set(\"" + tsID + "\");" + lineFeed);
				else if (seg.getTemplateDE(i + 1).getRequired() == 'M')
 pw.write(" de.set(\"\");"+lineFeed);
				else
					pw.write("  //de.set(\"\");//not required" + lineFeed);
			}
		}
 pw.write("/* segment.useDefault(); */"+lineFeed);

		pw.write("  return segment;" + lineFeed);

		pw.write("  }" + lineFeed);
		
		return pw.toString();
	}

	/**
	 * when parsing an OBOE object that code generates the composite logic
	 *
	 * @param tce
	 *            TemplateComposite currently working with
	 * @param inI
	 *            position of Composite within parent object, used for output
	 *            code
	 */
	private String buildCompositeCodeForJava(TemplateComposite tce, 
			int inI) {
		
		StringWriter pw = new StringWriter();

		pw.write("  composite = (CompositeDE) segment.buildDE(" + (inI + 1)
				+ ");");
		pw.write("  // " + tce.getID() + " " + tce.getName() + lineFeed);
		int i;
		for (i = 0; i < tce.getTemplateDESize(); i++) {
			if (tce.isTemplateDE(i + 1) && tce.getTemplateDE(i + 1).isUsed()) {
				pw.write("  de = (DataElement) composite.buildDE(" + (i + 1)
						+ ");");
				pw.write("  // composite element "
						+ tce.getTemplateDE(i + 1).getID() + " "
						+ tce.getTemplateDE(i + 1).getName() + lineFeed);
				pw.write("  de.set(\"\");" + lineFeed);
			}
		}
		
		return pw.toString();
	}

	private Vector getIDList(TemplateSegment seg) {
		for (int i = 0; i < seg.getTemplateDESize(); i++) {
			if (seg.isTemplateComposite(i + 1)
					&& seg.getTemplateComposite(i + 1).getRequired() == 'M') {
				TemplateComposite tce = seg.getTemplateComposite(i + 1);
				TemplateDE tde = tce.getTemplateDE(1);
				if (tde.getRequired() == 'M'
						&& tde.getType().compareTo("ID") == 0) {
					if (tde.getIDList() == null)
						break;

					return tde.getIDList().getCodes();
				}
				continue;
			}
			if (seg.isTemplateDE(i + 1) == false)
				continue;
			if (seg.getTemplateDE(i + 1).getRequired() != 'M')
				continue;
			if (seg.getTemplateDE(i + 1).getType().compareTo("ID") == 0) {
				if (seg.getTemplateDE(i + 1).getIDList() == null)
					continue;
				return seg.getTemplateDE(i + 1).getIDList().getCodes();
			}
		}
		return null;
	}

	public String whatMethodName(String parent, String mine) {
		String pm = parent + mine;
		Integer intgr = (Integer) this.methodNameTable.get(pm);
		if (intgr == null) {
			this.methodNameTable.put(pm, new Integer(1));
			return mine;// +"_"+1;
		}

		int i = intgr.intValue() + 1;
		this.methodNameTable.remove(pm);
		this.methodNameTable.put(pm, new Integer(i));
		return mine + "_" + i;

	}
	public void doPIXES(TemplateEnvelope inEnv, TransactionSet inTS,
			String type, boolean inUseName) throws Exception
	{
		pw.write("<?xml version=\"1.0\" encoding=\"UTF-8\"?>"+ lineFeed);
		pw.write("<!-- OBOE release 3.4.0 (alpha)  -->"+ lineFeed);
		pw.write("<process>"+ lineFeed);
		pw.write(" <xmlProcessor className=\"com.americancoders.pixes.edi.ParsexectorForOBOE\"/>"+ lineFeed);
		pw.write("  <!--connect driverClass=\"com.mysql.jdbc.Driver\" dbConnection=\"jdbc:mysql://localhost/edi_control\"-->"+ lineFeed);
		pw.write("  <!--connect driverClass=\"COM.ibm.db2.jdbc.app.DB2Driver\" dbConnection=\"jdbc:db2:edi\"-->"+ lineFeed);
		if (type.compareTo("pP")==0)
			pw.write("  	<ediProcess mode=\"inbound\"  directory=\"${incomingDirectory}\" backupDirectory=\"${backupDirectory\">"+ lineFeed);
		else
			pw.write("  <ediProcess mode=\"outbound\"  directory=\"${outgoingDirectory}\" >"+ lineFeed);
		pw.write("  <envelope format=\"x12\" >"+ lineFeed);
		buildSegmentCodeForPIXES(inEnv.getTemplateSegment("ISA"),1);
		pw.write(addDepth(1)+"<functionalgroup>"+ lineFeed);
		buildSegmentCodeForPIXES(inEnv.getTemplateFunctionalGroup().getTemplateSegment("GS"),2);
		doBuildForPIXES(inTS, 2);
		buildSegmentCodeForPIXES(inEnv.getTemplateFunctionalGroup().getTemplateSegment("GE"),2);
		pw.write(addDepth(1)+"</functionalgroup>"+ lineFeed);
		buildSegmentCodeForPIXES(inEnv.getTemplateSegment("ISE"),1);
		pw.write("  </envelope>"+ lineFeed);
		pw.write(" </ediProcess>"+ lineFeed);
		pw.write("</process>"+ lineFeed);

		
	}

	
	/**
	 * when building an OBOE object this code generates the code to work with
	 * Envelopes, Functional Groups and Transaction Sets
	 *
	 * @param inTS
	 *            TransactionSet
	 * @param depth printing indentation value
	 */
	private void doBuildForPIXES(TransactionSet inTS, int depth) {
		
		
		pw.write(addDepth(depth)+"<transactionset id=\""+inTS.getID()+"\">"+ lineFeed);

		TemplateTransactionSet ts = inTS.getTemplateTransactionSet();
		TemplateTable table = ts.getHeaderTemplateTable();

		int i;
		if (table != null) {
			pw.write(addDepth(depth+1)+"<table section=\"header\">" + lineFeed);
			for (i = 0; i < table.getCount(); i++) {
				if (table.isSegment(i) && table.getTemplateSegment(i).isUsed()) {
					buildSegmentCodeForPIXES(table.getTemplateSegment(i), depth+2);
				} else if (table.isLoop(i) && table.getTemplateLoop(i).isUsed()) {
					buildLoopCodeForPIXES(table.getTemplateLoop(i), depth+2);
				}
			}
			pw.write(addDepth(depth+1)+"</table>" + lineFeed);

		}

		table = ts.getDetailTemplateTable();
		if (table != null) {
			pw.write(addDepth(depth+1)+"<table section=\"detail\">" + lineFeed);
			for (i = 0; i < table.getCount(); i++) {
				if (table.isSegment(i) && table.getTemplateSegment(i).isUsed()) {
					buildSegmentCodeForPIXES(table.getTemplateSegment(i), depth+2);
				} else if (table.isLoop(i) && table.getTemplateLoop(i).isUsed()) {
					buildLoopCodeForPIXES(table.getTemplateLoop(i), depth+2);
				}
			}
			pw.write(addDepth(depth+1)+"</table>" + lineFeed);
		}

		table = ts.getSummaryTemplateTable();
		if (table != null) {
			pw.write(addDepth(depth+1)+"<table section=\"summary\">" + lineFeed);
			for (i = 0; i < table.getCount(); i++) {
				if (table.isSegment(i) && table.getTemplateSegment(i).isUsed()) {
					buildSegmentCodeForPIXES(table.getTemplateSegment(i), depth+2);
				} else if (table.isLoop(i) && table.getTemplateLoop(i).isUsed()) {
					buildLoopCodeForPIXES(table.getTemplateLoop(i), depth+2);
				}
				pw.write(addDepth(depth+1)+"</table>" + lineFeed);
			}
		}
		pw.write(addDepth(depth)+"</transactionset>"+ lineFeed);

		
	}

	
	/**
	 * when parsing an OBOE object this code generates the loop logic
	 *
	 * @param loop
	 *            TemplateLoop currently working with
	 * @param depth
	 *            how many \t to put into text
	 */
	private void buildLoopCodeForPIXES(TemplateLoop loop, int depth) {

		pw.write(addDepth(depth)+"<loop id=\""+loop.getID()+"\">" + lineFeed);
		for (int i = 0;  i < loop.getContainerSize(); i++) {
			if (loop.isLoop(i))
				buildLoopCodeForPIXES(loop.getTemplateLoop(i), depth+1);
			else
				buildSegmentCodeForPIXES(loop.getTemplateSegment(i), depth+1);
		}

		pw.write(addDepth(depth)+"</loop>" + lineFeed);
	}
	/**
	 * when parsing an OBOE object this code generates the segment logic
	 *
	 * @param seg
	 *            TemplateSegment currently working with
	 * @param depth
	 *            how many \t to put into text
	 */
	private void buildSegmentCodeForPIXES(TemplateSegment seg, int depth) {

		pw.write(addDepth(depth)+"<segment id=\""+seg.getID()+"\">" + lineFeed);
		for (int i = 0; i < seg.getTemplateDESize(); i++) {
			if (seg.isTemplateComposite(i + 1)
					&& seg.getTemplateComposite(i + 1).isUsed()) {
				buildCompositeCodeForPIXES(seg.getTemplateComposite(i + 1), depth+1);

			} else if (seg.isTemplateDE(i + 1)
					&& seg.getTemplateDE(i + 1).isUsed()) {
				pw.write(addDepth(depth+1)+"<element position=\""+seg.getTemplateDE(i + 1).getSequence()+"\">${"+seg.getTemplateDE(i + 1).getXMLTag()+"}</element>"+ lineFeed);
			}
		}
		pw.write(addDepth(depth)+"</segment>" + lineFeed);
	}
	/**
	 * when parsing an OBOE object this code generates the composite logic
	 *
	 * @param tcde
	 *            TemplateComposite currently working with
	 * @param depth
	 *            how many \t to put into text
	 */
	private void buildCompositeCodeForPIXES(TemplateComposite tcde, int depth) {

		pw.write(addDepth(depth)+"<composite position=\""+tcde.getSequence()+"\">" + lineFeed);
		for (int i = 0; i < tcde.getTemplateDESize(); i++) {
			if  (tcde.getTemplateDE(i + 1).isUsed()) {
				pw.write(addDepth(depth+1)+"<element position=\""+tcde.getTemplateDE(i + 1).getSequence()+"\">${"+tcde.getTemplateDE(i + 1).getXMLTag()+"}</element>"+ lineFeed);
			}
		}

		pw.write(addDepth(depth)+"</composite>" + lineFeed);
	}


	public String addDepth(int count)
	{
		String s = "";
		for (int i = 0; i < count; i++)
			s += '\t';
		return s;
	}
	                                 

}
