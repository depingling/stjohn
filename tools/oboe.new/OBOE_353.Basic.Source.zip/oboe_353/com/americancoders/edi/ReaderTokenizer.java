package com.americancoders.edi;

import java.io.IOException;
import java.io.PushbackReader;
import java.io.Reader;

/**
 *  class to assist in tokenizing input transaction sets
 *<p>OBOE - Open Business Objects for EDI
 *<p>Part of the OBOE Basic Extended Package
 *<br>An EDI and XML Translator Written In Java
 *<br>Copyright 1998-2007 - American Coders, LTD  - Raleigh NC USA
 *<br>All rights reserved
 *<br>American Coders, Ltd
 *<br>P. O. Box 97462
 *<br>Raleigh, NC  27624  USA
 *<br>1-919-846-2014
 *<br>http://www.americancoders.com
@author Joe McVerry - American Coders, Ltd.
  @version   3.5.3
 */

/** Tokenizes from a Reader Object
 */

public class ReaderTokenizer implements IDataTokenizer {
	/**
	 * current position within tokenized string
	 */
	protected int currentPos;
	/**
	 * current tokenized string
	 */
	protected PushbackReader tokenReader;
	/**
	 * what breaks up fields
	 */
	protected String tokens;

	/** cr/lf used as a segment delimiter can also be lf/cr
		*  we want to skip the second character
	*/

	private char skipChar = (char) - 1;

	/**
	 * escape characters to allow tokens in the text
	 */
	protected String escapeCharacters = "";

	/**
	 *  constructor
	 *  @param inReader - Reader object containing tokenized data
	 *  @param inTokens - list of tokens
	 *  @param inEscapeCharacters - list of characters to escape and allow tokens in the text
	 *      pass an empty string or null if no escape characters used
	 */
	public ReaderTokenizer(
		Reader inReader,
		String inTokens,
		String inEscapeCharacters) {
		currentPos = -1;
		tokenReader = new PushbackReader(inReader, 1);
		tokens = inTokens;

		if (inEscapeCharacters != null)
			escapeCharacters = inEscapeCharacters;

	}

	/**
	 *  to get next token
	 *  @return String - the next token
	 *
	 */
	public String nextToken() {

		StringBuffer stringBuffer = new StringBuffer(80);

		int currentValue;
		char currentChar;

		try {
			while (tokenReader.ready()) {
				currentValue = tokenReader.read();
				if (currentValue == -1) {
					break;
				}

				currentChar = (char) currentValue;
				if (escapeCharacters.indexOf(currentChar) > -1) {
					char tempChar = currentChar;
					currentChar = (char) tokenReader.read();
					if (currentChar == -1) {
						break;
					}
					if ((tokens.indexOf(currentChar) > -1)
						&& (escapeCharacters.indexOf(currentChar) > -1))
						//  escaping a delimiter so keep it
						stringBuffer.append(currentChar);
					else {
						stringBuffer.append(tempChar);
						stringBuffer.append(currentChar);
					}
					continue;
				}

				if (currentChar == skipChar)
					// ignore the carriage return and catch the linefeed
					continue;
				if (tokens.indexOf(currentChar) > -1)
					break;
				stringBuffer.append(currentChar);
			}
		} catch (java.io.IOException ioe) {
			return null;
		}

		return stringBuffer.toString(); // trim for one last cleanup
	}

	/**
	 *  pulls more data out of reader stream for binarytokenizer
	 *  @param inLength int length
	 *  @return byte[]
	 *  @exception OBOEException - not enough data read
	 */
	public byte[] getMoreData(int inLength) throws OBOEException {

		byte readArray[] = new byte[inLength];

		int pos = 0;
		for (pos = 0; pos < tokens.length(); pos++)
			readArray[pos] = (byte) tokens.charAt(pos);
		// assume the end marker not read

		int currentValue;
		char currentChar = ' ';

		try {
			while (tokenReader.ready() && pos < inLength) {
				currentValue = tokenReader.read();
				if (currentValue == -1) {
					break;
				}
				readArray[pos] = (byte) currentValue;
				pos++;
			}
		} catch (java.io.IOException ioe) {
			ioe.printStackTrace();
			throw new OBOEException("IO error: " + ioe.getMessage());
		}

		if (pos != inLength)
			throw new OBOEException(
				"Binary read length error.  Asked for "
					+ inLength
					+ " read only "
					+ pos);

		try {
			currentValue = tokenReader.read();
			if (currentValue != -1)
				currentChar = (char) currentValue;
		} catch (java.io.IOException ioe) {
			ioe.printStackTrace();
			throw new OBOEException("IO error: " + ioe.getMessage());
		}

		if (tokens.indexOf(currentChar) < 0)
			throw new OBOEException(
				"Binary read error.  Last character not end of segment delimiter found "
					+ currentChar);

		return readArray; // trim for one last cleanup
	}

	/** gets the token in tokenized string at a specifiec position
	 * @param pos int position, if < 0 or > the total returns null
	 * @return String
	 */
	public String getTokenAt(int pos) {
		return null;

	}
	public void setSkipChar(char inChar) {
		skipChar = inChar;
	}

	/**
	 *  indicates if there are more data elements to parse
	 *  @return boolean  more to parse?
	 *
	 */
	public boolean hasMoreElements() {
		try {
			int c = tokenReader.read();
			tokenReader.unread(c);
			if (c == -1)
				return false;
			return true; // moreTokens;
		} catch (IOException ioe) {
			return false;
		}

	}

	/**
	 *  how many tokens in list
	 *  @return int - a count
	 *
	 */
	public int countTokens() {

		return -1;
	}

	int positionInStream=-1;
	public int getPositionInStream() {
		return positionInStream;
	}

	public void setPositionInStream(int positionInStream) {
	  this.positionInStream=positionInStream;
		
	}
}
