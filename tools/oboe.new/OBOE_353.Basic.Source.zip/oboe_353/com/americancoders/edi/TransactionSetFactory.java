package com.americancoders.edi;

import java.io.CharArrayWriter;
import java.io.Externalizable;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.io.StringReader;
import java.lang.reflect.Method;
import java.util.Hashtable;
import java.util.Stack;
import java.util.StringTokenizer;
import java.util.Vector;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.apache.log4j.Logger;
import org.xml.sax.Attributes;
import org.xml.sax.ContentHandler;
import org.xml.sax.EntityResolver;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import org.xml.sax.ext.LexicalHandler;
import org.xml.sax.helpers.DefaultHandler;

import com.americancoders.util.Util;

/**
 * class for building a Transaction Set from an edi xml file
 * this is a subclass of the  SAX2 handler
 * <br>Class contains a main method to allow it to be invoked as an application.
 * <br>format: java com.americancoders.edi.TransactionSetFactory xmlfilename,
 * <br>where xmlfilename is a xml file based on transactionSetRules.dtd.
 *
 *<br>OBOE - Open Business Objects for EDI
 *<br>An EDI and XML Translator Written In Java
 *<br>Copyright 1998-2007 - American Coders, LTD  - Raleigh NC USA
 *<brp>All rights reserved
 *<br>American Coders, Ltd
 *<br>P. O. Box 97462
 *<br>Raleigh, NC  27624  USA
 *<br>1-919-846-2014
 *<br>http://www.americancoders.com
@author Joe McVerry - American Coders, Ltd.
  @version   3.5.3
 */

public class TransactionSetFactory
	extends DefaultHandler
	implements EntityResolver, LexicalHandler, ContentHandler {

	/** current element number
	 */
	protected int _iElement = 0;
	/** current line number
	 */
	protected int _iLine = 0;
	/** current transaction set
	 */
	protected TemplateTransactionSet currentTransactionSet = null;
	/** current Table
	 */
	protected TemplateTable currentTable = null;
	/** current container for segments either a table or segments
	 */
	protected TemplateLoopContainer currentLoopContainer = null;
	/** current segment
	 */
	protected TemplateSegment currentSegment = null;
	/** current composite
	 */
	protected TemplateComposite currentCompositeDE = null;
	/** current element
	 */
	protected TemplateDE currentDataElement = null;
	/** loop for loop control
	 */
	protected TemplateLoop currentLoop = null;
	/** id list processor
	 */
	protected IDListProcessor currentIDListProcessor = null;

	/** current id string
	 */
	protected String currentID = "";

	/** last node parsed
	 */
	protected String nodeName = "no set yet";
	protected String nameOrID = "no set yet";

	/**     simple string processor    */
	protected CharArrayWriter contents = new CharArrayWriter();

	/** current idListFile name
	 */
	protected String idListFile = null;

	

       public static int typeSet=-101;

	/** current idCode string
	    code comes before value so save it
	 */
	protected String idCode = null;

	/** current IDList parser object
	 */
	protected IDListParser idListParser;
	/** list of IDs
	 */
	protected Hashtable idLists;
	
	/** current list of ids
	 */
	protected IDList currentIDList;

	/** current Vector for IDList processing
	 */

	protected Vector currentVector = null;

	/** directory path for xml file as specified in OBOE.properties
	 */
	protected String xmlDirectoryPath;
	/** directory path for found xml file
	 */
	protected String xmlFoundDirectoryPath;

	/** stack, since segments can be held by table and segments and
	 * datalements by segments and composites we keep track of container depth through a stack
	 */
	protected Stack currentLoopContainerStack;

	/** parser object
	 */
	SAXParser parser;
	
	/** log4j object */
	static Logger logr = Logger.getLogger(TransactionSetFactory.class);
	static 	{Util.isLog4JNotConfigured();}
	


	/** construct the factory with a xml parser
	 * @throws Exception an xml parser exception */

	public TransactionSetFactory() throws Exception {
		SAXParserFactory spf = SAXParserFactory.newInstance();
		xmlDirectoryPath = Util.getOBOEProperty("xmlPath");
		xmlFoundDirectoryPath = Util.getOBOEProperty("xmlPath");

		spf.setNamespaceAware(true);
		spf.setValidating(true);
		
		parser = spf.newSAXParser();
		parser.getXMLReader().setProperty("http://xml.org/sax/properties/lexical-handler", this);

		idLists = new Hashtable();
		
		idListParser = new IDListParser();

	}
	
	   private Locator locator = null;
	    
	    public void setDocumentLocator(Locator locator) {
	    	this.locator = locator;
	    	}
	    
	    private void reportPosition() {

	    	if (locator != null) {

	    	_iLine=  locator.getLineNumber();
	    	}
	    	 

	    	}

	  

	/**
	 * method to call parser with an InputSource argument
	 * @param is InputSource
	 * @throws IOException an i/o exception
	 * @throws SAXException an xml parser exception
	*/

	public void parse(InputSource is) throws SAXException, IOException {
		try {
			is.setSystemId("");
			parser.parse(is, this);
		} catch (SAXException e1) {
			logr.error("Caught exception: " + e1.getMessage());
			logr.error("Near element #: " + _iElement+"     line: " + _iLine+"     nodeName: " + nodeName+"     name or id: " + nameOrID);
			logr.error(e1.getMessage(), e1);
			throw e1;
		}

	}

	/**
	 * method to call parser with a String argument
	 * @param is String of xml data
	 * @throws IOException an i/o exception
	 * @throws SAXException an xml parser exception
	*/

	public void parse(String is) throws SAXException, IOException {
		try {
			parser.parse(is, this);
		} catch (SAXException e1) {
			logr.error("Caught exception: " + e1.getMessage());
			logr.error("Near element #: " + _iElement+"     line: " + _iLine+"     nodeName: " + nodeName+"     name or id: " + nameOrID);
			logr.error(e1.getMessage(), e1);
			throw e1;
		}

	}


	/** resolves the DTD file name for the xerces parser
	 * @param publicId -  String name of xml public id
	 * @param systemId - String name of xml system id
	 * @return InputSource the dtd
	 * @throws SAXException an xml parser exception
	 */

	public InputSource resolveEntity(
		java.lang.String publicId,
		java.lang.String systemId)
		throws SAXException {

		InputSource inpSrc = null;

		try {
			if (publicId != null) {
				if (publicId.indexOf("://") < 1) {
					return new InputSource(
						new FileInputStream(xmlDirectoryPath + File.separator + publicId));
				}
				File f = new File(publicId);
				if (f.exists())
					return null;
				String sf = f.getName();
				inpSrc =  new InputSource(
					new FileInputStream(xmlDirectoryPath + File.separator + sf));
			}
			else
			if (systemId != null) {
				if (systemId.indexOf("://") < 1) {
					inpSrc = new InputSource(
						new FileInputStream(xmlDirectoryPath + File.separator + systemId));
				}
				else  {
				File f = new File(systemId);
				if (f.exists())
					return null;
				String sf = f.getName();
				inpSrc =  new InputSource(
					new FileInputStream(xmlDirectoryPath + File.separator + sf));
				}

			}
		} catch (Exception e) {
			throw new SAXException(e);
		}
		if (inpSrc != null)
		{

		}
		return inpSrc;
	}

	/**
	* method called for each xml element found.
	* <br> process logic
	* <ul>
	* <li> test each name found for edi type: transactionSet, table, segment, dataelement
	* <li> for each type pull appropriate attributes and construct object
	* <li> for transaction set build transaction set
	* <li> for table build a table
	* <li> for segments build a template segment
	* <li> for data element build a template datalement
	* </li>
	*
	* @param uri URI of incoming file
	* @param localName String of element's local name
	* @param rawName String of element's raw name
	* @param attributes Vector of the elements attributes
	* @throws SAXException many possible exceptions
	*/
	public void startElement(
		java.lang.String uri,
		java.lang.String localName,
		java.lang.String rawName,
		Attributes attributes)
		throws SAXException {
			int i;
			reportPosition();
			nodeName = rawName;
			_iElement++;
			contents.reset();
			
			

			if (nodeName.compareTo("transactionSet") == 0) {
				String id = "",
					tsName = "",
					revision = "",
					functionalGroup = "",
					description = "",
					xmlTag = null;
				for (i = 0; i < attributes.getLength(); i++) {

					if (attributes.getQName(i).compareTo("id") == 0)
						id = attributes.getValue(i);
					if (attributes.getQName(i).compareTo("name") == 0)
						tsName = attributes.getValue(i);
					if (attributes.getQName(i).compareTo("revision") == 0)
						revision = attributes.getValue(i);
					if (attributes.getQName(i).compareTo("functionalGroup")
						== 0)
						functionalGroup = attributes.getValue(i);
					if (attributes.getQName(i).compareTo("description") == 0) {
						description = attributes.getValue(i);
					}
					if (attributes.getQName(i).compareTo("xmlTag") == 0)
						xmlTag = attributes.getValue(i);
				}

				nameOrID = tsName;
				if (xmlTag == null)
					xmlTag = nameOrID;

				int format;
				if (Character.isDigit(id.charAt(0)))
					format = Envelope.X12_FORMAT;
				else
					format = Envelope.EDIFACT_FORMAT;

				if (currentTransactionSet == null) {
					currentTransactionSet =
						new TemplateTransactionSet(
							format,
							id,
							tsName,
							revision,
							functionalGroup,
							description,
							xmlTag,
							null);
				} else
					/*throw new SAXException(
						"Transaction set already defined, see element "
							+ _iElement);*/
					currentTransactionSet.setFormat(format);


				return;
			}
			if (nodeName.compareTo("table") == 0) {
				String xmlTag = null;
				currentLoopContainerStack = new Stack();
				for (i = 0; i < attributes.getLength(); i++) {
					if (attributes.getQName(i).compareTo("xmlTag") == 0) {
						xmlTag = attributes.getValue(i);
						break;
					}
				}
				for (i = 0; i < attributes.getLength(); i++) {
					if (attributes.getQName(i).compareTo("section") == 0)
						break;
				}
				if (i >= attributes.getLength()) {
					throw new SAXException(
						"Table section name missing, see element " + _iElement);
				}
				if (attributes.getValue(i).compareTo("header") == 0) {
					if (currentTransactionSet.getHeaderTemplateTable()
						== null) {
						currentTable =
							new TemplateTable(
								attributes.getValue(i),
								currentTransactionSet);
						currentTransactionSet.setHeaderTemplateTable(
							currentTable);
					} else
						throw new SAXException(
							"Header table already defined, see element "
								+ _iElement);
				}
				if (attributes.getValue(i).compareTo("detail") == 0) {
					if (currentTransactionSet.getDetailTemplateTable()
						== null) {
						currentTable =
							new TemplateTable(
								attributes.getValue(i),
								currentTransactionSet);
						currentTransactionSet.setDetailTemplateTable(
							currentTable);
					} else
						throw new SAXException(
							"Detail table already defined, see element "
								+ _iElement);
				}
				if (attributes.getValue(i).compareTo("summary") == 0) {
					if (currentTransactionSet.getSummaryTemplateTable()
						== null) {
						currentTable =
							new TemplateTable(
								attributes.getValue(i),
								currentTransactionSet);
						currentTransactionSet.setSummaryTemplateTable(
							currentTable);
					} else
						throw new SAXException(
							"Summary table already defined, see element "
								+ _iElement);
				}

				nameOrID = attributes.getValue(i);
				if (xmlTag == null)
				  xmlTag = nameOrID;

				for (i = 0; i < attributes.getLength(); i++) {
				}
				currentLoopContainer = currentTable;
				currentLoopContainerStack.push(currentTable);

				return;
			}
			if (nodeName.compareTo("loop") == 0) {
				String currentID = "";
				String currentName = "";
				int occurs = 1;
				char required = 'O';
				boolean used = true;
				String xmlTag = null;
				for (i = 0; i < attributes.getLength(); i++) {
					if (attributes.getQName(i).compareTo("id") == 0)
						currentID = attributes.getValue(i);
					if (attributes.getQName(i).compareTo("name") == 0)
						currentName = attributes.getValue(i);
					if (attributes.getQName(i).compareTo("required") == 0)
						required = attributes.getValue(i).charAt(0);
					if (attributes.getQName(i).compareTo("occurs") == 0) {
						String sOccurs = attributes.getValue(i).trim();
						if (sOccurs.length() > 0)
							// let a numeric parsing exception occur on its own
							occurs = Integer.parseInt(sOccurs);
					}

					if (attributes.getQName(i).compareTo("xmlTag") == 0)
						xmlTag = attributes.getValue(i);
					
					if (attributes.getQName(i).compareTo("used") == 0) {
						used = attributes.getValue(i).trim().charAt(0) == 'Y'; 
					}


				}

                if (xmlTag == null)
                  xmlTag = currentID;
				currentLoop =
					new TemplateLoop(
						currentID,
						currentName,
						occurs,
						required,
						xmlTag, used,
						currentLoopContainer);
				currentLoopContainer.addTemplateLoop(currentLoop);
				currentLoopContainerStack.push(currentLoop);
				currentLoopContainer = currentLoop;

				return;
			}
			
			if (nodeName.compareTo("copyLoop") == 0) {
				
			  /* save attributes because deepCopy will wipe em out */	
				String currentID = currentLoop.getID();
				String currentName = currentLoop.getName();
				int occurs = currentLoop.getOccurs();
				char required = currentLoop.getRequired();
				boolean used = currentLoop.isUsed();
				String xmlTag = currentLoop.getXMLTag();
				String path = attributes.getValue("refid");
				if (path == null)
					throw new SAXException("missing refid attribute on copyLoop element");
			    Util.deepCopy(findLoop(path), currentLoop);
			    
			    currentLoop.setID(currentID);
			    currentLoop.setName(currentName);
			    currentLoop.setOccurs(occurs);
			    currentLoop.setRequired(required);
			    currentLoop.setUsed(used);
			    currentLoop.setXMLTag(xmlTag);
			    
			    
			    return;
			}

			if (nodeName.compareTo("segment") == 0) {
				String xmlTag = null;
				currentCompositeDE = null;
				int sequence = 0;
				String description = "";
				String currentName = "";
				char required = 'O';
				int occurs = 1;
				boolean used = true;
				for (i = 0; i < attributes.getLength(); i++) {
					if (attributes.getQName(i).compareTo("id") == 0)
						currentID = attributes.getValue(i);
					if (attributes.getQName(i).compareTo("sequence") == 0)
						sequence = Integer.parseInt(attributes.getValue(i));
					if (attributes.getQName(i).compareTo("description") == 0) {
						description = attributes.getValue(i);
					}
					if (attributes.getQName(i).compareTo("name") == 0)
						currentName = attributes.getValue(i);
					if (attributes.getQName(i).compareTo("xmlTag") == 0)
						xmlTag = attributes.getValue(i);
					if (attributes.getQName(i).compareTo("occurs") == 0) {
						String sOccurs = attributes.getValue(i).trim();
						if (sOccurs.length() > 0)
							// let a numeric parsing exception occur on its own
							occurs = Integer.parseInt(sOccurs);
					}
					if (attributes.getQName(i).compareTo("required") == 0)
						required = attributes.getValue(i).charAt(0);
					if (attributes.getQName(i).compareTo("used") == 0) {
						used = attributes.getValue(i).trim().charAt(0) == 'Y'; 
					}

				}

				if (xmlTag == null)
					xmlTag = currentID;

				nameOrID =
					currentID
						+ " name:"
						+ currentName
						+ " sequence: "
						+ sequence
						+ " xmlTag: "
						+ xmlTag;
				currentSegment =
					new TemplateSegment(
						currentID,
						currentName,
						sequence,
						description,
						occurs,
						required,
						xmlTag, used,
						currentLoopContainer);

				try {
					currentLoopContainer.addTemplateSegment(
						currentSegment);
				} catch (Exception e1) {
					logr.error(e1.getMessage(), e1);
					throw new SAXException(e1.getMessage());
				}

				return;
			}
			
			if (nodeName.compareTo("copySegment") == 0) {
				  /* save attributes because deepCopy will wipe em out */	
				String currentID = currentSegment.getID();
				String currentName = currentSegment.getName();
				int occurs = currentSegment.getOccurs();
				char required = currentSegment.getRequired();
				boolean used = currentSegment.isUsed();
				String xmlTag = currentSegment.getXMLTag();
				int sequence = currentSegment.getSequence();
				String description = currentSegment.getDescription();

				
				String path = attributes.getValue("refid");
				if (path == null)
					throw new SAXException("missing refid attribute on copySegment element");
			    Util.deepCopy(findSegment(path), currentSegment);
			    
			    currentSegment.setID(currentID);
			    currentSegment.setName(currentName);
			    currentSegment.setOccurs(occurs);
			    currentSegment.setRequired(required);
			    currentSegment.setUsed(used);
			    currentSegment.setXMLTag(xmlTag);
			    currentSegment.setSequence(sequence);
			    currentSegment.setDescription(description);
			    
			    
			    return;
			}

			if (nodeName.compareTo("compositeDE") == 0) {
				currentCompositeDE =
					setTemplateComposite(
						currentSegment.getTemplateDESize(),
						attributes);
				nameOrID = currentCompositeDE.getID();
				try {
					currentSegment.addTemplateComposite(
						currentCompositeDE);
				} catch (OBOEException oe) {
					logr.error(oe.getMessage(), oe);
					throw new SAXException(oe.getMessage());
				}
				return;
			}

			if (nodeName.compareTo("dataElement") == 0) {
				int pos;
				if (currentCompositeDE != null)
					pos = currentCompositeDE.getTemplateDESize();
				else
					pos = currentSegment.getTemplateDESize();

				currentDataElement = setDataElement(pos, attributes);
				nameOrID = currentDataElement.getID();

				try {
					if (currentCompositeDE != null)
						currentCompositeDE.addTemplateDE(currentDataElement);
					else
						currentSegment.addTemplateDE(
							currentDataElement);
				} catch (OBOEException oe) {
					logr.error(oe.getMessage(), oe);
					throw new SAXException(oe.getMessage());
				}

				currentIDListProcessor = null;
				return;
			}

			if (nodeName.compareTo("idListClass") == 0) {
				
				if (currentDataElement.getType().compareTo("AN")==0) {
					currentDataElement.setType("ID");
					logr.info("changed dataelement id =\""+currentDataElement.getID()+"\" from type AN to ID because of idListClass node");
				}
				
				if (currentDataElement.getType().compareTo("ID")!=0) {
					logr.error("cannot use idListClass node with dataelement id =\""+currentDataElement.getID()+"\"");
				}

				try {
					currentIDListProcessor =
						(IDListProcessor) Class.forName(attributes.getValue("className")).newInstance();
				} catch (java.lang.ClassNotFoundException cfne) {
					logr.error(cfne.getMessage(), cfne);
					throw new SAXException(
						"Class not found for idListClass="
							+ attributes.getValue("className"));
				} catch (java.lang.InstantiationException ie) {
					logr.error(ie.getMessage(), ie);
					throw new SAXException(
						"Instantiation Exception for idListClass="
							+ attributes.getValue("className"));
				} catch (java.lang.IllegalAccessException iae) {
					logr.error(iae.getMessage(), iae);
					throw new SAXException(
						"Illegal Access Excpetion for idListClass="
							+ attributes.getValue("className"));
				}
				currentDataElement.setIDList(currentIDListProcessor);
				return;

			}
			if (nodeName.compareTo("idListFile") == 0) {
				if (currentDataElement.getType().compareTo("A")==0 || currentDataElement.getType().compareTo("AN")==0) {
					currentDataElement.setType("ID");
					logr.info("changed dataelement id =\""+currentDataElement.getID()+"\" from type AN to ID because of idListFile node");
				}
				
				if (currentDataElement.getType().compareTo("ID")!=0) {
					logr.error("cannot use idListFile node with dataelement id =\""+currentDataElement.getID()+"\"");
				}

				currentIDList =
					(IDList) idLists.get(
						xmlFoundDirectoryPath
							+ attributes.getValue("fileName"));
				if (currentIDList == null) {
					currentIDList =
						new IDList(
							xmlFoundDirectoryPath
								+ attributes.getValue("fileName"),
							xmlDirectoryPath,
							idListParser);
					idLists.put(
						xmlFoundDirectoryPath + attributes.getValue("fileName"),
						currentIDList);
					currentTransactionSet.addIDListFile(new File(xmlFoundDirectoryPath + attributes.getValue("fileName")));
				}
				for (i = 0; i < attributes.getLength(); i++) {
					if (attributes.getQName(i).compareTo("fileName") == 0)
					    continue;
					if (attributes.getQName(i).compareTo("include") == 0)
					{
					    currentIDList=currentIDList.idListWork('i', attributes.getValue(i));
					    currentIDList.setFilterList("include=\""+attributes.getValue(i)+"\"");
					}
					if (attributes.getQName(i).compareTo("exclude") == 0)
					{
					    currentIDList=currentIDList.idListWork('x', attributes.getValue(i));
					    currentIDList.setFilterList("exclude=\""+attributes.getValue(i)+"\"");
					}
				}	
				
				currentIDListProcessor = currentIDList;
				currentDataElement.setIDList(currentIDListProcessor);
				
				return;
			}
			if (nodeName.compareTo("idList") == 0) {
				if (currentDataElement.getType().compareTo("AN")==0) {
					currentDataElement.setType("ID");
					logr.info("changed dataelement id =\""+currentDataElement.getID()+"\" from type AN to ID because of idList node");
				}
				
				if (currentDataElement.getType().compareTo("ID")!=0) {
					logr.error("cannot use idList node with dataelement id =\""+currentDataElement.getID()+"\"");
				}


				currentIDList = new IDList();
				currentIDListProcessor = currentIDList;
				currentDataElement.setIDList(currentIDListProcessor);
				return;
			}

			if (rawName.compareTo("idCode") == 0) {
				return;
			}

			if (rawName.compareTo("idValue") == 0) {
				return;
			}

			throw new SAXException(
				"logic error: unknown type "
					+ nodeName
					+ " "
					+ currentID
					+ " for element: "
					+ _iElement);
		

	}


    /**
	 * @param path
	 * @return Externalizable segment
	 */
	private Externalizable findSegment(String path) {
		logr.debug("Inpath is "+path);
		TemplateLoop tl = null;
		TemplateLoopContainer tlc = currentTable;
		TemplateSegment ts = null;
		StringTokenizer st = new StringTokenizer(path, "/");
		int stCount = st.countTokens();
		String nm = st.nextToken();
		TemplateTable tbl;
		if (nm.compareToIgnoreCase("header")==0)
		{
			tbl= this.currentTransactionSet.getHeaderTemplateTable();
			if (tbl == null)
			{
				logr.error("header table not defined yet");
			}
		}
		else if (nm.compareToIgnoreCase("detail")==0)
		{
			tbl= this.currentTransactionSet.getDetailTemplateTable();
			if (tbl == null)
			{
				logr.error("detail table not defined yet");
			}
			
		}
		else if (nm.compareToIgnoreCase("summary")==0)
		{
			tbl= this.currentTransactionSet.getSummaryTemplateTable();
			if (tbl == null)
			{
				logr.error("summary table not defined yet");
			}
			
		}
		else
		{
			logr.error("invalid table id in refPath; use hdr|dtl|trl  found=\""+nm+"\"");
			return null;
		}
		tlc = tbl;
		stCount--;
	    while(stCount > 1)
	    {
	    	nm = st.nextToken();
	    	logr.debug("search "+tlc.getID()+" for "+nm);
	    	tl = tlc.getTemplateLoop(nm);
	    	if (tl == null)
	    	{
	    		logr.error("can't find loop from path call "+path);
	    		return null;
	    	}
	    		
	    	tlc = tl;
	    	stCount--;
	    }
    	nm = st.nextToken();
    	logr.debug("last search for segment "+nm+" in "+tlc.getID());
    	ts = tlc.getTemplateSegment(nm);
		
	    if (ts == null)
	    	logr.error("can't find segment from path call "+path);
		return ts;
	}

	/**
	 * @param path
	 * @return TemplateLoop 
	 */
	private TemplateLoop findLoop(String path) {
		logr.debug("Inpath is "+path);
		TemplateLoop tl = null;
		TemplateLoopContainer tlc;
		StringTokenizer st = new StringTokenizer(path, "/");
		String nm = st.nextToken();
		TemplateTable tbl;
		if (nm.compareToIgnoreCase("header")==0)
		{
			tbl= this.currentTransactionSet.getHeaderTemplateTable();
			if (tbl == null)
			{
				logr.error("header table not defined yet");
			}
		}
		else if (nm.compareToIgnoreCase("detail")==0)
		{
			tbl= this.currentTransactionSet.getDetailTemplateTable();
			if (tbl == null)
			{
				logr.error("detail table not defined yet");
			}
			
		}
		else if (nm.compareToIgnoreCase("summary")==0)
		{
			tbl= this.currentTransactionSet.getSummaryTemplateTable();
			if (tbl == null)
			{
				logr.error("summary table not defined yet");
			}
			
		}
		else
		{
			logr.error("invalid table id in refPath; use hdr|dtl|trl  found=\""+nm+"\"");
			return null;
		}
		tlc = tbl;
	    while(st.hasMoreElements())
	    {
	    	nm = st.nextToken();
	    	logr.debug("search "+tlc.getID()+" for "+nm);
	    	tl = tlc.getTemplateLoop(nm);
	    	if (tl == null)
	    		break;
	    	tlc = tl;
	    }
	    if (tl == null)
	    	logr.error("can't find loop from path call "+path);
		return tl;
	}

	/**
	 * Method called by the SAX parser at the </
	 * @param uri URI of incoming file
	 * @param localName String of element's local name
	 * @param rawName String of element's raw name
	 * @throws SAXException many possible  *
	 */
	public void endElement(
		java.lang.String uri,
		java.lang.String localName,
		java.lang.String rawName)
		throws SAXException {
		
		reportPosition();

		String name = rawName;
		if (name.compareTo("transactionSet") == 0) {
			return;
		}
		if (name.compareTo("table") == 0) {
			return;
		}
		if (name.compareTo("loop") == 0) {
			currentLoopContainerStack.pop();
			currentLoopContainer =
				(TemplateLoopContainer) currentLoopContainerStack.peek();
			return;
		}
		
		if (name.compareTo("copyLoop") == 0) {
			return;
		}
		
		if (name.compareTo("copySegment") == 0) {
			return;
		}
		
		
		if (name.compareTo("segment") == 0) {
		}
		if (name.compareTo("compositeDE") == 0) {
			currentCompositeDE = null;

			return;
		}
		if (name.compareTo("dataElement") == 0) {
			currentDataElement = null;
			return;
		}

		if (nodeName.compareTo("idListProcess") == 0) {
			return;
		}
		if (nodeName.compareTo("idListFile") == 0) {
			return;
		}
		if (rawName.compareTo("idList") == 0) {
			currentDataElement.setIDList(currentIDList);
			return;
		}

		if (rawName.compareTo("idCode") == 0) {
			idCode = contents.toString(); // code comes before value so save it
			return;
		}

		if (rawName.compareTo("idValue") == 0) {
			currentIDList.add(idCode, contents.toString());
			return;
		}


		//throw new SAXException("logic error: unknown type " + name + " for element: " + _iElement);
	}

	/**
	 * Method handles #PCDATA
	 * @param ch array
	 * @param start position in array where next has been placed
	 * @param length int
	 *
	 *
	 */
	public void characters(char ch[], int start, int length) {
		reportPosition();

		contents.write(ch, start, length);
		for (int i = start; i < start + length; i++)
			if (ch[i] == '\n')
				_iLine++;
	
	}

	/** help method to build a template composite
	 * @return TemplateComposite template composite
	 * @param pos int position within segment
	 * @param attributes SAX2 attributes
	 * @throws SAXException SAX errors
	 */
	public TemplateComposite setTemplateComposite(
		int pos,
		Attributes attributes)
		throws SAXException {
		int i;
		String id = "", thisName = "", description = "";
		int occurs = 1;
		int sequence = pos + 1;
		String xmlTag = null;
		char required = 'O';
		boolean used = true;
		for (i = 0; i < attributes.getLength(); i++) {
			if (attributes.getQName(i).compareTo("id") == 0)
				id = attributes.getValue(i);
			if (attributes.getQName(i).compareTo("description") == 0) {
				description = attributes.getValue(i);
			}
			if (attributes.getQName(i).compareTo("name") == 0)
				thisName = attributes.getValue(i);
			if (attributes.getQName(i).compareTo("required") == 0)
				required = attributes.getValue(i).charAt(0);
			if (attributes.getQName(i).compareTo("sequence") == 0) {
				try {
					sequence = Integer.parseInt(attributes.getValue(i));
				} catch (NumberFormatException nfe) {
					throw new OBOEException(
						"sequence not numeric. "
							+ " look for sequence=\""
							+ attributes.getValue(i)
							+ "\""
							+ " nodeName: compositeDE"
							+ " name: "
							+ thisName
							+ " id:"
							+ id);
				}
			}
			if (attributes.getQName(i).compareTo("xmlTag") == 0)
				xmlTag = attributes.getValue(i);
			if (attributes.getQName(i).compareTo("occurs") == 0) {
				String sOccurs = attributes.getValue(i).trim();
				if (sOccurs.length() > 0)
				try {
					occurs = Integer.parseInt(sOccurs);
					if (occurs < 1)
					  throw new OBOEException(
					   "occurs less than 1. "
						+ " look for occurs=\""
						+ attributes.getValue(i)
						+ "\""
						+ " nodeName: compositeDE"
						+ " name: "
						+ thisName
						+ " id:"
						+ id);
				} catch (NumberFormatException nfe) {
					throw new OBOEException(
						"occurs not numeric. "
							+ " look for occurs=\""
							+ attributes.getValue(i)
							+ "\""
							+ " nodeName: compositeDE"
							+ " name: "
							+ thisName
							+ " id:"
							+ id);
				}
			}
			if (attributes.getQName(i).compareTo("used") == 0) {
				used = attributes.getValue(i).trim().charAt(0) == 'Y'; 
			}

		}
		if (xmlTag == null)
			xmlTag = id;
		TemplateComposite currentComposite =
			new TemplateComposite(
				id,
				thisName,
				required,
				sequence,
				description,
				xmlTag,
				currentSegment, occurs, used);
		return currentComposite;
	}

	/** help method to build a template data element
	 * @return TemplateDE template data element
	 * @param pos position within segment or composite
	 * @param attributes SAX2 attributes
	 * @throws SAXException SAX errors
	 */
	public TemplateDE setDataElement(int pos, Attributes attributes)
		throws SAXException {
		int i;

		idListFile = null;

		String id = "", thisName = "", type = "", description = "";
		int minLength = 0, maxLength = 0;
		String xmlTag = null, required = "O";
		int sequence = pos + 1;
		int occurs = 1;
		boolean used = true;
		for (i = 0; i < attributes.getLength(); i++) {
			if (attributes.getQName(i).compareTo("type") == 0)
				type = attributes.getValue(i);
			if (attributes.getQName(i).compareTo("required") == 0)
				required = attributes.getValue(i);
			if (attributes.getQName(i).compareTo("id") == 0)
				id = attributes.getValue(i);
			if (attributes.getQName(i).compareTo("name") == 0)
				thisName = attributes.getValue(i);
			if (attributes.getQName(i).compareTo("description") == 0) {
				description = attributes.getValue(i);
			}
			if (attributes.getQName(i).compareTo("sequence") == 0) {
				try {
					sequence = Integer.parseInt(attributes.getValue(i));
				} catch (NumberFormatException nfe) {
					throw new OBOEException(
						"sequence not numeric. "
							+ " look for sequence=\""
							+ attributes.getValue(i)
							+ "\""
							+ " nodeName: dataElement"
							+ " name: "
							+ thisName
							+ " id:"
							+ id);
				}
			}
			if (attributes.getQName(i).compareTo("minLength") == 0) {
				try {
					minLength = Integer.parseInt(attributes.getValue(i));
				} catch (NumberFormatException nfe) {
					throw new OBOEException(
						"minLength not numeric. "
							+ " look for minLength=\""
							+ attributes.getValue(i)
							+ "\""
							+ " nodeName: dataElement"
							+ " name: "
							+ thisName
							+ " id:"
							+ id);
				}
			}
			if (attributes.getQName(i).compareTo("maxLength") == 0) {
				try {
					maxLength = Integer.parseInt(attributes.getValue(i));
				} catch (NumberFormatException nfe) {
					throw new OBOEException(
						"maxLength not numeric. "
							+ " look for maxLength=\""
							+ attributes.getValue(i)
							+ "\""
							+ " nodeName: dataElement"
							+ " name: "
							+ thisName
							+ " id:"
							+ id);
				}
			}
			if (attributes.getQName(i).compareTo("xmlTag") == 0) {
				xmlTag = attributes.getValue(i);
			}
			
			if (attributes.getQName(i).compareTo("used") == 0) {
				used = attributes.getValue(i).trim().charAt(0) == 'Y'; 
			}


			if (attributes.getQName(i).compareTo("occurs") == 0) {
				String sOccurs = attributes.getValue(i).trim();
				if (sOccurs.length() > 0)
				try {
					occurs = Integer.parseInt(sOccurs);
					if (occurs < 1)
					  throw new OBOEException(
					   "occurs less than 1. "
						+ " look for occurs=\""
						+ attributes.getValue(i)
						+ "\""
						+ " nodeName: dataElement"
						+ " name: "
						+ thisName
						+ " id:"
						+ id);
				} catch (NumberFormatException nfe) {
					throw new OBOEException(
						"occurs not numeric. "
							+ " look for occurs=\""
							+ attributes.getValue(i)
							+ "\""
							+ " nodeName: dataElement"
							+ " name: "
							+ thisName
							+ " id:"
							+ id);
				}
			}

		}

		if (xmlTag == null)
			xmlTag = id;
		
		TemplateDE currentDE =
			new TemplateDE(
				id,
				thisName,
				sequence,
				type,
				required.charAt(0),
				description,
				minLength,
				maxLength,
				xmlTag, null, null, occurs, used);
		return currentDE;
	}


	/** I use this to keep track of line #s
	 * @param ch char array of found whitespaces
	 * @param start int start position in array
	 * @param length int length of what's been found
	 */
	public void ignorableWhitespace(char[] ch, int start, int length) {
		reportPosition();

		for (int i = start; i < start + length; i++)
			if (ch[i] == '\n')
				_iLine++;
	}
	/** catches warning SAXParseExceptions
	 * this code sends exception to stdio and allows public classto continue
	 * @param e SaxException object
	 * @throws SAXException exception
	 */
	public void warning(SAXParseException e) throws SAXException {
		logr.error("SAX Warning at (file "
				+ e.getSystemId()
				+ ", line "
				+ e.getLineNumber()
				+ ", char "
				+ e.getColumnNumber()
				+ "): "
				+ e.getMessage());
	}

	/** catches error SAXParseExceptions
	 * this code causes exception to continue
	 * @param e SaxException object
	 * @throws SAXException thrown
	 */
	public void error(SAXParseException e) throws SAXException {
		throw new SAXException(
			"Error at (file "
				+ e.getSystemId()
				+ ", line "
				+ e.getLineNumber()
				+ ", char "
				+ e.getColumnNumber()
				+ "): "
				+ e.getMessage());
	}

	/** catches fatal SAXParseExceptions
	 * this code causes exception to continue
	 * @param e SAXException object
	 * @throws SAXException thrown
	 */
	public void fatalError(SAXParseException e) throws SAXException {
		throw new SAXException(
			"SAX Fatal Error at (file "
				+ e.getSystemId()
				+ ", line "
				+ e.getLineNumber()
				+ ", char "
				+ e.getColumnNumber()
				+ "): "
				+ e.getMessage());
	}
	
	/* (non-Javadoc)
	 * @see org.xml.sax.ext.LexicalHandler#startDTD(java.lang.String, java.lang.String, java.lang.String)
	 */
	public void startDTD(String arg0, String arg1, String arg2) throws SAXException {
		// 
		
	}

	/* (non-Javadoc)
	 * @see org.xml.sax.ext.LexicalHandler#endDTD()
	 */
	public void endDTD() throws SAXException {
		// 
		
	}

	/* (non-Javadoc)
	 * @see org.xml.sax.ext.LexicalHandler#startEntity(java.lang.String)
	 */
	public void startEntity(String arg0) throws SAXException {
		// 
		
	}

	/* (non-Javadoc)
	 * @see org.xml.sax.ext.LexicalHandler#endEntity(java.lang.String)
	 */
	public void endEntity(String arg0) throws SAXException {
		// 
		
	}

	/* (non-Javadoc)
	 * @see org.xml.sax.ext.LexicalHandler#startCDATA()
	 */
	public void startCDATA() throws SAXException {
		// 
		
	}

	/* (non-Javadoc)
	 * @see org.xml.sax.ext.LexicalHandler#endCDATA()
	 */
	public void endCDATA() throws SAXException {
		// 
		
	}

	/* (non-Javadoc)
	 * @see org.xml.sax.ext.LexicalHandler#comment(char[], int, int)
	 */
	public void comment(char[] chars, int start, int length) throws SAXException {
		reportPosition();

		for (int i = start; i < start+length; i++)
			if (chars[i]=='\n')
				_iLine++;
		
	}

	private void setDirectoryPaths(String inPath, String inFoundPath) {
		xmlDirectoryPath = inPath;
		xmlFoundDirectoryPath = inFoundPath;
	}

	/** look in OBOE.properties file for the namespace variable
	 *  @return boolean true if useNamepace = true
	 *  any other value return false
	 */

	public static boolean getNamespaceOption() {
		try {
			String getName = "useNamespace";
			String path = Util.getOBOEProperty(getName);
			if (path == null)
				return false;
			return (path.compareTo("true") == 0);
		} catch (FileNotFoundException fnfe) {
			logr.fatal(fnfe.getMessage(), fnfe);
			System.exit(0);
		} catch (IOException ioe) {
			logr.error(ioe.getMessage(),ioe);
			System.exit(0);
		}

		return false;
	}

	/** store read template ts in a hash table for quick look up */
	static private Hashtable tsBuilt = new Hashtable();

	/** static method to clear built hash table, created for test purposes */
	static public void clearTable() {
		tsBuilt = new Hashtable();
	}

	/** static class method will build a transaction set based on input string and OBOE.properties defintion
	 * see OBOE.properties file to define the directory path
	 * @return TransactionSet
	 * @param inTSID String trransaction set id
	 * @throws OBOEException io error most likely
	 */
	public static TransactionSet buildTransactionSet(String inTSID)
		throws OBOEException {
		return buildTransactionSet(inTSID, null, null, null, null, null, true);

	}

	/** static class method will build a transaction set based on input string, the searchDirective,
	the four search directories
	and OBOE.properties definition
	 * @return TransactionSet
	 * @param inTSID String TransactionSet id
	 * @param inSearchDirective String - any combination of V, S, R, T.  These provide
	 the search path for the rules files through a directory structure as specified by the next
	 four parameters.   See full method for more details about this and the other parameters.
	 * @param inVersionDirectory - specify directory as defined by the Version value.
	 * @param inReceiverIDDirectory - specify directory as defined by
	 * @param inSenderIDDirectory - specify directory as defined by
	 * @param inTestOrProductionDirectory  - specify directory as defined by
	 * @throws OBOEException io  exception
	 */
	public static TransactionSet buildTransactionSet(
		String inTSID,
		String inSearchDirective,
		String inVersionDirectory,
		String inReceiverIDDirectory,
		String inSenderIDDirectory,
		String inTestOrProductionDirectory)
		throws OBOEException {
	 

		return buildTransactionSet(
			inTSID,
			inSearchDirective,
			inVersionDirectory,
			inReceiverIDDirectory,
			inSenderIDDirectory,
			inTestOrProductionDirectory,
			true);
	}

	/** static class method will build a transaction set based on input string, the searchDirective,
	the four search directories
	and OBOE.properties definition
	 * see OBOE.properties file to define the directory path and optional searchDirective.
	 * At the very least the rules file must reside in the directory specified by the xmlPath.
	 * The rules file name is appended with ".xml"
	 * <br> example #1 no search directive
	 * <br> OBOE.properties file contains: xmlPath = c:/xmlDefinitions/
	 * <br> input String is 840
	 * <br> method will read file named: c:/xmlDefinitions/840.xml
	 * <br> example #2 full search directive
	 * <br> OBOE.properties file contains: xmlPath = c:/xmlDefinitions/
	 * <br> input String is 840
	 * <br> searchDirective is VTRS
	 * <br> inVersion is 004010
	 * <br> inTestProduction is P
	 * <br> inReceiverID is 000001
	 * <br> inSenderID is AAAAA
	 * <br> method will search for file named: c:/xmlDefinitions/004010/P/000001/AAAAA/840.xml
	 * <br> if not found then it will search for file named: c:/xmlDefinitions/004010/P/000001/840.xml
	 * <br> if not found then it will search for file named: c:/xmlDefinitions/004010/P/840.xml
	 * <br> if not found then it will search for file named: c:/xmlDefinitions/004010/840.xml
	 * <br> if not found then it  will search for file named: c:/xmlDefinitions/840.xml
	 * <br> if not found then it will throw OBOEException
	 * <br> example #2 partial search directive
	 * <br> OBOE.properties file contains: xmlPath = c:/xmlDefinitions/
	 * <br> input String is 840
	 * <br> searchDirective is RV
	 * <br> inVersion is 004010
	 * <br> inTestProduction is P
	 * <br> inReceiverID is 000001
	 * <br> inSenderID is AAAAA
	 * <br> method will search for file named: c:/xmlDefinitions/000001/004010/840.xml
	 * <br> if not found then it will search for file named: c:/xmlDefinitions/000001/840.xml
	 * <br> if not found then it  will search for file named: c:/xmlDefinitions/840.xml
	 * <br> if not found then it will throw OBOEException
	 * <br><i>Note</i>If any directory parameter is null or zero length that directory
	 is ignored even if the searchDirective specifies its usage.
	 * <br><i>Note</i>Name the directories with the values a possible specified by your
	 standard.  This will be the only way the incoming document parser can find them.  For instance
	 in X12 specify a Version directory with the possible values of GS 480 value such as
	 "004010" or "003031". In EDIFact concatenate the UNH 0052 and 0054 fields such as "D93A" or "D99B".
	 * @return TransactionSet
	 * @param inTSID String TransactionSet id
	 * @param inSearchDirective String - any combination of V, S, R, T.  These provide
	 the search path for the rules files through a directory structure as specified by the next
	 four parameters.   The base directory is defined by the xmlPath property in OBOE.properties.
	 Any combination is possible to provide for the search directive.  The directive value of
	 "STV" - indicates to search using the SendId paramter value as a directory, Test Indicator as
	 as Directory, and Version parameter value as a directory.  While "VR" indicates to use the Version
	 number as a directory and Receiver id.  The package starts at the lowest directory with its
	 search.  If the xml rules files is not found there it will go up to the  next directory and repeat this
	 process until the final directory as specified by the xmlPath property.
	 <br><i><b>Note</b></i>If a null is passed, the method will look in the OBOE.properties file
	 for a property named <i>searchDirective</i>using the same values.  Use this property for
	 incoming documents.
	 * @param inVersionDirectory - specify directory as defined by the Version value.
	 For this and the other directory parameters do not specify a directory seperator. If
	 used specify the names as the same as the the incoming process.
	     <ul>For incoming processing the directory name will be passed from
	       <li>X12: "480 - Version Release Industry Identifier Code"  from GS - Functional Group Header segment
	       <li>EDIFact: the concatenation of "0052 - Message type version" and "0054 Message type release"  from UNH - Message Header
	     </ul>
	 * @param inReceiverIDDirectory - specify directory as defined by
	 For this and the other directory parameters do not specify a directory seperator. If
	 used specify the names as the same as the the incoming process.
	     <ul>For incoming processing the directory name will be passed from
	        <li>X12: "I07 - Interchange Receiver ID"
	        <li>EDIFact: "0010 - Recipient Identification"
	     </ul>
	 * @param inSenderIDDirectory - specify directory as defined by
	 For this and the other directory parameters do not specify a directory seperator. If
	 used specify the names as the same as the the incoming process.
	     <ul>For incoming processing the directory name will be passed from
	        <li>X12:   "I06 - Interchange Sender ID"
	        <li>EDIFact:  "0004 - Sender identification",
	     </ul>
	 * @param inTestOrProductionDirectory  - specify directory as defined by
	 For this and the other directory parameters do not specify a directory seperator. If
	 used specify the names as the same as the the incoming process.
	     <ul>For incoming processing the directory name will be passed from
	       <li>X12: "I14 - Test Indicator"  values of P or T.
	       <li>EDIFact: "0035 - TEST INDICATOR"
	     </ul>
	 * @param inSaveInVectorIndicator boolean to save EDI object in the tsBuilt
	 * vector
	 * @throws OBOEException io  exception
	 */
	public static TransactionSet buildTransactionSet(
		String inTSID,
		String inSearchDirective,
		String inVersionDirectory,
		String inReceiverIDDirectory,
		String inSenderIDDirectory,
		String inTestOrProductionDirectory,
		boolean inSaveInVectorIndicator)
		throws OBOEException {
		// xmlPath - OBOE.properties value
		// xmlSearchPath - directory path to found xml rules file
		// xmlFilePath - full path name to xml rules file
		//objectPath - full path name to object rules file
	    
	String xmlPath = "",
			xmlSearchPath = "",
			xmlFilePath = "",
			objectPath = "";

		TemplateTransactionSet currentTransactionSet;

		File xmlFile = null, objectFile = null;
		boolean useXML = false;
		boolean useObject =  com.americancoders.util.Util.propertyFileIndicatesUseObject();
		
		int i;

		String searchDirective = inSearchDirective;
		String basePath = null;

		try {
			xmlPath = Util.getOBOEProperty("xmlPath");

			
			if (xmlPath == null)
				xmlPath = "";
			if (searchDirective == null)
				searchDirective = Util.getOBOEProperty("searchDirective");
			basePath = Util.getOBOEProperty("baseDirectory");
			// used by RICE application
		} catch (Exception ex) {
			logr.error(ex.getMessage(), ex);
			throw new OBOEException(ex.getMessage());
		}

		String searchPaths[] = null;
		

		if (searchDirective != null) {
			if (searchDirective.compareTo("base") == 0)
				// for the RICE application
				{
				xmlFilePath = basePath + inTSID + ".xml";
				xmlSearchPath = basePath;
				objectPath = basePath + inTSID + ".object";
				xmlFile = new File(xmlFilePath);
				
				objectFile = new File(objectPath);
			} else {
				searchPaths = new String[searchDirective.length() + 1];
				StringBuffer searchPath = new StringBuffer(xmlPath);
				searchPaths[0] = xmlPath;

				for (i = 0; i < searchDirective.length(); i++) {
					switch (searchDirective.charAt(i)) {
						case 'V' :
							if (inVersionDirectory != null
								&& inVersionDirectory.length() > 0) {
								searchPath.append(inVersionDirectory.trim());
								searchPath.append(File.separatorChar);
							}

							break;
						case 'R' :
							if (inReceiverIDDirectory != null
								&& inReceiverIDDirectory.length() > 0) {
								searchPath.append(inReceiverIDDirectory.trim());
								searchPath.append(File.separatorChar);
							}

							break;
						case 'S' :
							if (inSenderIDDirectory != null
								&& inSenderIDDirectory.length() > 0) {
								searchPath.append(inSenderIDDirectory.trim());
								searchPath.append(File.separatorChar);
							}

							break;
						case 'T' :
							if (inTestOrProductionDirectory != null
								&& inTestOrProductionDirectory.length() > 0) {
								searchPath.append(
									inTestOrProductionDirectory.trim());
								searchPath.append(File.separatorChar);
							}

							break;

						default :
							throw new OBOEException(
								"searchDirective ("
									+ searchDirective
									+ ") contains illegal character");
					} // switch
					searchPaths[i + 1] = new String(searchPath);
				} // for int i
				for (i = searchDirective.length();
					i > -1;
					i--) // there's at least one
					{
					xmlFilePath = searchPaths[i] + inTSID + ".xml";
					objectPath = searchPaths[i] + inTSID + ".object";
					xmlFile = new File(xmlFilePath);
					objectFile = new File(objectPath);
					logr.debug("looking for "+xmlFilePath+" and "+objectPath);
					if (xmlFile.exists() || objectFile.exists()) {
						xmlSearchPath = searchPaths[i];
						break;
					}
				}
			} // not for RICE
		} // searchDirective not null
		else {
			xmlFilePath = xmlPath + inTSID + ".xml";
			logr.debug("looking for "+xmlFilePath);
			xmlSearchPath = xmlPath;
			objectPath = xmlPath + inTSID + ".object";
			xmlFile = new File(xmlFilePath);
			objectFile = new File(objectPath);
		}

		if (inSaveInVectorIndicator) {
			TemplateTransactionSet tts =
				(TemplateTransactionSet) tsBuilt.get(xmlFilePath);
			if (tts != null) {
				return new TransactionSet(tts, null);
			}
		}
		


		if (xmlFile.exists() == false && objectFile.exists() == false)
			throw new OBOEException("XML Rules File not found " + xmlFilePath);


		try {
			if (useObject == true) {

				objectFile = new File(objectPath);

				if (objectFile.exists() == false)
					useXML = true;
				else if (xmlFile.exists() == false);
				else if (xmlFile.lastModified() > objectFile.lastModified())
					useXML = true;
			} else
				useXML = true;

			try {
				if (useXML == false) {

					FileInputStream fis = new FileInputStream(objectFile);
					ObjectInputStream ios = new ObjectInputStream(fis);
					currentTransactionSet =
						(TemplateTransactionSet) ios.readObject();
					fis.close();
					if (currentTransactionSet.checkIDListFiles() == true) {
					if (inSaveInVectorIndicator)
						tsBuilt.put(xmlFilePath, currentTransactionSet);
					return new TransactionSet(currentTransactionSet, null);
					}
					else
					{
						logr.debug("rebuild because id list file is outdated");
					}
				}
			} catch (IOException ioe) {
				logr.debug("not using object file because "+ioe.getMessage());
				useXML = true;
			} catch (Exception ex) {
				logr.debug("not using object file because "+ex.getMessage());
				useXML = true;
			}

			synchronized (tsBuilt) {

				TransactionSetFactory tsf = new TransactionSetFactory();

				tsf.setDirectoryPaths(xmlPath, xmlSearchPath);

				InputSource is = new InputSource(new FileReader(xmlFilePath));
				tsf.parse(is);
				currentTransactionSet = tsf.currentTransactionSet;
				if (useObject) {
					FileOutputStream fos = new FileOutputStream(objectPath);
					ObjectOutputStream oos = new ObjectOutputStream(fos);
					oos.writeObject(currentTransactionSet);
					oos.close();
				}
			tsBuilt.put(xmlFilePath, currentTransactionSet);
			}

			return new TransactionSet(currentTransactionSet, null);

		} catch (Exception ex) {
			logr.error(ex.getMessage(), ex);
			
			throw new OBOEException(ex.getMessage());
		}

	}

	
	public static TransactionSet buildTransactionSet(File inFile)
	{
     try{
		InputSource is = new InputSource(new FileReader(inFile));
		TransactionSetFactory tsf = new TransactionSetFactory();
		String pth = inFile.getAbsolutePath();
		int i = pth.lastIndexOf(File.separatorChar);
		pth=pth.substring(0,i+1);
		tsf.setDirectoryPaths(Util.getOBOEProperty("xmlPath"), pth);
		tsf.parse(is);
		TemplateTransactionSet currentTransactionSet = tsf.currentTransactionSet;
		return new TransactionSet(currentTransactionSet, null);
	} catch (Exception ex) {
		logr.error(ex.getMessage(), ex);
		throw new OBOEException(ex.getMessage());
	}
	
	}
			
	public static TransactionSet buildTransactionSetFromString(String inTS)
	{
	     try{
			InputSource is = new InputSource(new StringReader(inTS));
			TransactionSetFactory tsf = new TransactionSetFactory();
			tsf.parse(is);
			TemplateTransactionSet currentTransactionSet = tsf.currentTransactionSet;
			return new TransactionSet(currentTransactionSet, null);
		} catch (Exception ex) {
			logr.error(ex.getMessage(), ex);
			throw new OBOEException(ex.getMessage());
		}
		
	}
			
	/** static main class used for testing
	 * <br>Class contains a main method to allow it to invoked as an application.
	 * <br>format: java com.americancoders.edi.TransactionSetFactory xmlfilename idlistpath
	 * <br>where   xmlfilename is a xml file based on transactionSet.dtd.
	 * <br>        idlistpath is directory name where idlist files reside.
	 * @param args String array
	 */

	public static void main(String args[]) {
		if (args.length != 2 && args.length != 5 && args.length != 6) {
			System.out.println("java TransactionSetFactory xxx yyy");
			System.out.println(
				"                           xxx - rules filename");
			System.out.println(
				"                           yyy - directory path");
			System.out.println(" -OR- ");
			System.out.println(
				"java TransactionSetFactory tsid [search] p1 p2 p3 p4");

			System.exit(0);
		}

		logr.debug("start");
			try {
				if (args.length == 5) {
					TransactionSetFactory.buildTransactionSet(
						args[0],
						null,
						args[1],
						args[2],
						args[3],
						args[4],
						true);
				} else if (args.length == 6) {
					TransactionSetFactory.buildTransactionSet(
						args[0],
						args[1],
						args[2],
						args[3],
						args[4],
						args[5],
						true);
				} else {
					TransactionSetFactory tsf = new TransactionSetFactory();
					tsf.setDirectoryPaths(args[1], args[1]);
					tsf.parse(args[1] + args[0]);
					new TransactionSet(
							tsf.currentTransactionSet,
							null).writeFormattedText(new PrintWriter(System.out),0);		
				}

			} catch (Exception ex) {
				logr.error(ex.getMessage(), ex);
				ex.printStackTrace();
			}
		
			logr.debug("stop");

	}
	
	public TemplateTransactionSet getTemplateTransactionSet() { return currentTransactionSet; }

	
}
