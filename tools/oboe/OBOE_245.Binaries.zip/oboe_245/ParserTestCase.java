import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

import com.americancoders.edi.*;
import com.americancoders.edi.x12.*;
import com.americancoders.edi.EDIFact.*;

import java.io.*;

import org.xml.sax.*;


public class ParserTestCase extends TestCase
{

public ParserTestCase(String name) {super(name);}

protected void setUp()
{

}


public static Test suite()
 {
	 return new TestSuite(ParserTestCase.class);
 }

protected void tearDown()
{

}


public void testX12() throws IOException
{
    FileInputStream fis = new FileInputStream("sample.output.840.1");
    BufferedReader br = new BufferedReader(new InputStreamReader(fis));
    StringBuffer sb = new StringBuffer();
    String s;
    try {
      while(true) {
        s = br.readLine();
        if (s == null)
          break;
		sb.append(s+X12Envelope.SEGMENT_DELIMITER);
	  }
	}
	catch (EOFException e) {;}
    fis.close();
    s = new String(sb);

    com.americancoders.edi.x12.Parser p1 =
                  new com.americancoders.edi.x12.Parser(s);
    Envelope x = p1.getEnvelope();
    String t = new String(x.getFormattedText(Envelope.X12_FORMAT).getBytes());
    assertEquals(s, t);

}

public void testX12ToXMLToX12() throws IOException
{
    FileInputStream fis = new FileInputStream("sample.output.840.1");
    DataInputStream dis = new DataInputStream(fis);
    BufferedReader br = new BufferedReader(new InputStreamReader(fis));
    StringBuffer sb = new StringBuffer();
    String s;
    try {
      while(true) {
        s = br.readLine();
        if (s == null)
          break;
		sb.append(s+X12Envelope.SEGMENT_DELIMITER);
	  }
	}
	catch (EOFException e) {;}
    fis.close();
    s = new String(sb);

    com.americancoders.edi.x12.Parser p1 =
                  new com.americancoders.edi.x12.Parser(s);
    Envelope x = p1.getEnvelope();
    String t = new String(x.getFormattedText(Envelope.VALID_XML_FORMAT).getBytes());

    DataOutputStream dos = new DataOutputStream(new FileOutputStream("c:/xml/test.X12.xml"));
    dos.writeBytes(t);
    dos.close();
    ValidXMLEDIParser xmp = new ValidXMLEDIParser();

    try {
       xmp.parseFile("c:/xml/test.X12.xml");
   }
   catch(SAXException se)
     {
		 se.printStackTrace();
		 fail(se.getMessage());
	 }
   catch(FileNotFoundException fe)
     {
		 fe.printStackTrace();
		 fail(fe.getMessage());
	 }
   catch(IOException ie)

     {
		 ie.printStackTrace();
		 fail(ie.getMessage());
	 }

    x = xmp.getEnvelope();

    t = new String(x.getFormattedText(Envelope.X12_FORMAT).getBytes());


    assertEquals(s, t);

}

public void testX12ToWellFormedXMLToX12() throws IOException
{
    FileInputStream fis = new FileInputStream("sample.output.840.1");
    DataInputStream dis = new DataInputStream(fis);
    BufferedReader br = new BufferedReader(new InputStreamReader(fis));
    StringBuffer sb = new StringBuffer();
    String s;
    try {
      while(true) {
        s = br.readLine();
        if (s == null)
          break;
		sb.append(s+X12Envelope.SEGMENT_DELIMITER);
	  }
	}
	catch (EOFException e) {;}
    fis.close();
    s = new String(sb);

    com.americancoders.edi.x12.Parser p1 =
                  new com.americancoders.edi.x12.Parser(s);
    Envelope x = p1.getEnvelope();
    String t = new String(x.getFormattedText(Envelope.XML_FORMAT).getBytes());

    DataOutputStream dos = new DataOutputStream(new FileOutputStream("c:/xml/test.X12.wf.xml"));
    dos.writeBytes(t);
    dos.close();
    EDIXMLParser xmp = new EDIXMLParser();

    try {
       xmp.parseFile("c:/xml/test.X12.wf.xml");
   }
   catch(SAXException se)
     {
		 se.printStackTrace();
		 fail(se.getMessage());
	 }
   catch(FileNotFoundException fe)
     {
		 fe.printStackTrace();
		 fail(fe.getMessage());
	 }
   catch(IOException ie)

     {
		 ie.printStackTrace();
		 fail(ie.getMessage());
	 }

    x = xmp.getEnvelope();

    t = new String(x.getFormattedText(Envelope.X12_FORMAT).getBytes());


    assertEquals(s, t);

}

public void testX12810() throws IOException
{
    FileInputStream fis = new FileInputStream("/temp/x12810v4010");
    DataInputStream dis = new DataInputStream(fis);
    BufferedReader br = new BufferedReader(new InputStreamReader(fis));
    StringBuffer sb = new StringBuffer();
    String s;
    try {
      while(true) {
        s = br.readLine();
        if (s == null)
          break;
		sb.append(s+X12Envelope.SEGMENT_DELIMITER);
	  }
	}
	catch (EOFException e) {;}
    fis.close();
    s = new String(sb);

    com.americancoders.edi.x12.Parser p1 =
                  new com.americancoders.edi.x12.Parser(s);
    Envelope x = p1.getEnvelope();

    assertEquals(12, x.getFunctionalGroup(0).getTransactionSetCount());
    for (int i=0; i < 12; i++)
      {
	   int j = Integer.parseInt(x.getFunctionalGroup(0).getTransactionSet(i).getSummaryTable().getSegment("SE").getDataElement("96").get());
       assertEquals(j, x.getFunctionalGroup(0).getTransactionSet(i).getSegmentCount());
   }

}

public void testValidXMLParser() throws IOException
{



   try {
      ValidXMLEDIParser xmp = new ValidXMLEDIParser();
      xmp.parseFile("c:/xml/sample.850.microbits.xml");
      String t = xmp.getEnvelope().getFormattedText(Envelope.X12_FORMAT);

      com.americancoders.edi.x12.Parser p1 =
                   new com.americancoders.edi.x12.Parser(t);

      String s = p1.getEnvelope().getFormattedText(Envelope.X12_FORMAT);


      assertEquals(s, t);
   }
   catch(SAXException se)
     {
		 se.printStackTrace();
		 fail(se.getMessage());
	 }
   catch(FileNotFoundException fe)
     {
		 fe.printStackTrace();
		 fail(fe.getMessage());
	 }
   catch(IOException ie)

     {
		 ie.printStackTrace();
		 fail(ie.getMessage());
	 }


}

public void testX12ValidXMLParser() throws IOException
{
    FileInputStream fis = new FileInputStream("sample.output.840.1");
    DataInputStream dis = new DataInputStream(fis);
    BufferedReader br = new BufferedReader(new InputStreamReader(fis));
    StringBuffer sb = new StringBuffer();
    String s;
    try {
      while(true) {
        s = br.readLine();
        if (s == null)
          break;
		sb.append(s+X12Envelope.SEGMENT_DELIMITER);
	  }
	}
	catch (EOFException e) {;}
    fis.close();
    s = new String(sb);

    com.americancoders.edi.x12.Parser p1 =
                  new com.americancoders.edi.x12.Parser(s);

    TransactionSet x = p1.getEnvelope().getFunctionalGroup(0).getTransactionSet(0);
    s = new String(x.getFormattedText(Envelope.VALID_XML_FORMAT).getBytes());

    DataOutputStream dos = new DataOutputStream(new FileOutputStream("c:/xml/test.X12.ts.xml"));
    dos.writeBytes(s);
    dos.close();
    ValidXMLEDIParser xmp = new ValidXMLEDIParser();

    try {
       xmp.parseFile("c:/xml/test.X12.ts.xml");
   }
   catch(SAXException se)
     {
		 se.printStackTrace();
		 fail(se.getMessage());
	 }
   catch(FileNotFoundException fe)
     {
		 fe.printStackTrace();
		 fail(fe.getMessage());
	 }
   catch(IOException ie)

     {
		 ie.printStackTrace();
		 fail(ie.getMessage());
	 }

    x = xmp.getTransactionSet();

    String t = new String(x.getFormattedText(Envelope.VALID_XML_FORMAT).getBytes());


    assertEquals(s, t);

}

public void testX12WellFormedXMLParser() throws IOException
{
    FileInputStream fis = new FileInputStream("sample.output.840.1");
    DataInputStream dis = new DataInputStream(fis);
    BufferedReader br = new BufferedReader(new InputStreamReader(fis));
    StringBuffer sb = new StringBuffer();
    String s;
    try {
      while(true) {
        s = br.readLine();
        if (s == null)
          break;
		sb.append(s+X12Envelope.SEGMENT_DELIMITER);
	  }
	}
	catch (EOFException e) {;}
    fis.close();
    s = new String(sb);

    com.americancoders.edi.x12.Parser p1 =
                  new com.americancoders.edi.x12.Parser(s);

    Envelope x = p1.getEnvelope();
    s = new String(x.getFormattedText(Envelope.XML_FORMAT).getBytes());

    DataOutputStream dos = new DataOutputStream(new FileOutputStream("c:/xml/test.X12.tswf.xml"));
    dos.writeBytes(s);
    dos.close();

    try {
       EDIXMLParser exmp = new EDIXMLParser();
       exmp.parseFile("c:/xml/test.X12.tswf.xml");
       x = exmp.getEnvelope();
   }
   catch(SAXException se)
     {
		 se.printStackTrace();
		 fail(se.getMessage());
	 }
   catch(FileNotFoundException fe)
     {
		 fe.printStackTrace();
		 fail(fe.getMessage());
	 }
   catch(IOException ie)

     {
		 ie.printStackTrace();
		 fail(ie.getMessage());
	 }


    String t = new String(x.getFormattedText(Envelope.XML_FORMAT).getBytes());
    dos = new DataOutputStream(new FileOutputStream("c:/xml/test.X12.tswfII.xml"));
    dos.writeBytes(t);
    dos.close();

    assertEquals(s, t);

}

public void testEDIFact() throws IOException
{
    FileInputStream fis = new FileInputStream("D:/OpenBusinessObjects/Current/docs/orders");
    DataInputStream dis = new DataInputStream(fis);
    BufferedReader br = new BufferedReader(new InputStreamReader(fis));
    StringBuffer sb = new StringBuffer();
    String s;
    try {
      while(true) {
        s = br.readLine();
        if (s == null)
          break;
		sb.append(s);//+EDIFactEnvelope.SEGMENT_DELIMITER);
	  }
	}
	catch (EOFException e) {;}
    fis.close();
    s = new String(sb);


    com.americancoders.edi.EDIFact.Parser p1 =
                  new com.americancoders.edi.EDIFact.Parser(s);
    Envelope x = p1.getEnvelope();
    String t = new String(x.getFormattedText(Envelope.EDIFACT_FORMAT).getBytes());
    assertEquals(s, t);

}

public void testEDIFactToXMLToEDIFact() throws IOException
{
    FileInputStream fis = new FileInputStream("orders");
    DataInputStream dis = new DataInputStream(fis);
    BufferedReader br = new BufferedReader(new InputStreamReader(fis));
    StringBuffer sb = new StringBuffer();
    String s;
    try {
      while(true) {
        s = br.readLine();
        if (s == null)
          break;
		sb.append(s);//+EDIFactEnvelope.SEGMENT_DELIMITER);
	  }
	}
	catch (EOFException e) {;}
    fis.close();
    s = new String(sb);


    com.americancoders.edi.EDIFact.Parser p1 =
                  new com.americancoders.edi.EDIFact.Parser(s);
    Envelope x = p1.getEnvelope();

    String t = new String(x.getFormattedText(Envelope.VALID_XML_FORMAT).getBytes());

    DataOutputStream dos = new DataOutputStream(new FileOutputStream("c:/xml/test.EDIFact.xml"));
    dos.writeBytes(t);
    dos.close();
    ValidXMLEDIParser xmp = new ValidXMLEDIParser();

    try {
       xmp.parseFile("c:/xml/test.EDIFact.xml");
   }
   catch(SAXException se)
     {
		 se.printStackTrace();
		 fail(se.getMessage());
	 }
   catch(FileNotFoundException fe)
     {
		 fe.printStackTrace();
		 fail(fe.getMessage());
	 }
   catch(IOException ie)

     {
		 ie.printStackTrace();
		 fail(ie.getMessage());
	 }

    x = xmp.getEnvelope();

    t = new String(x.getFormattedText(Envelope.EDIFACT_FORMAT).getBytes());


    assertEquals(s, t);

}

public void testEDIFactToWellFormedXMLToEDIFact() throws IOException
{
    FileInputStream fis = new FileInputStream("orders");
    DataInputStream dis = new DataInputStream(fis);
    BufferedReader br = new BufferedReader(new InputStreamReader(fis));
    StringBuffer sb = new StringBuffer();
    String s;
    try {
      while(true) {
        s = br.readLine();
        if (s == null)
          break;
		sb.append(s);//+EDIFactEnvelope.SEGMENT_DELIMITER);
	  }
	}
	catch (EOFException e) {;}
    fis.close();
    s = new String(sb);


    com.americancoders.edi.EDIFact.Parser p1 =
                  new com.americancoders.edi.EDIFact.Parser(s);
    Envelope x = p1.getEnvelope();

    String t = new String(x.getFormattedText(Envelope.XML_FORMAT).getBytes());

    DataOutputStream dos = new DataOutputStream(new FileOutputStream("c:/xml/test.EDIFact.wf.xml"));
    dos.writeBytes(t);
    dos.close();
    EDIXMLParser xmp = new EDIXMLParser();

    try {
       xmp.parseFile("c:/xml/test.EDIFact.wf.xml");
   }
   catch(SAXException se)
     {
		 se.printStackTrace();
		 fail(se.getMessage());
	 }
   catch(FileNotFoundException fe)
     {
		 fe.printStackTrace();
		 fail(fe.getMessage());
	 }
   catch(IOException ie)

     {
		 ie.printStackTrace();
		 fail(ie.getMessage());
	 }

    x = xmp.getEnvelope();

    t = new String(x.getFormattedText(Envelope.EDIFACT_FORMAT).getBytes());


    assertEquals(s, t);

}

public void testEscapeEDIFactToXMLToEscapeEDIFact() throws IOException
{
    FileInputStream fis = new FileInputStream("orders.escape");
    DataInputStream dis = new DataInputStream(fis);
    BufferedReader br = new BufferedReader(new InputStreamReader(fis));
    StringBuffer sb = new StringBuffer();
    String s;
    try {
      while(true) {
        s = br.readLine();
        if (s == null)
          break;
		sb.append(s);//+EDIFactEnvelope.SEGMENT_DELIMITER);
	  }
	}
	catch (EOFException e) {;}
    fis.close();
    s = new String(sb);


    com.americancoders.edi.EDIFact.Parser p1 =
                  new com.americancoders.edi.EDIFact.Parser(s);
    Envelope x = p1.getEnvelope();

    String t = new String(x.getFormattedText(Envelope.VALID_XML_FORMAT).getBytes());

    DataOutputStream dos = new DataOutputStream(new FileOutputStream("c:/xml/test.EDIFact.xml"));
    dos.writeBytes(t);
    dos.close();
    ValidXMLEDIParser xmp = new ValidXMLEDIParser();

    try {
       xmp.parseFile("c:/xml/test.EDIFact.xml");
   }
   catch(SAXException se)
     {
		 se.printStackTrace();
		 fail(se.getMessage());
	 }
   catch(FileNotFoundException fe)
     {
		 fe.printStackTrace();
		 fail(fe.getMessage());
	 }
   catch(IOException ie)

     {
		 ie.printStackTrace();
		 fail(ie.getMessage());
	 }

    x = xmp.getEnvelope();

    t = new String(x.getFormattedText(Envelope.EDIFACT_FORMAT).getBytes());


    assertEquals(s, t);

}


public void testX12Build()
  throws OBOEException
{

    StringBuffer sb = new StringBuffer();
    sb.append("ISA*Y1*AUTH      *Y3*SEC       *Y5*SENDERID       *Y7*RECEIVERID     *010101*1300*Y*Y12  *000000001*x*z*<\n");
    sb.append("GS*fg0*fg1*fg2*010203\n");
    sb.append("ST*840*000000001\n");
    sb.append("BQT*363*586*20010103*200\n");
    sb.append("PO1*PO1350*1*12*1232\n");
    sb.append("LIN*LIN350*2 *2-350\n");
    sb.append("G53*875\n");
    sb.append("CTT*1*1\n");
    sb.append("SE*1*000000001\n");
    sb.append("GE*1*000000001\n");
    sb.append("IEA*1*000000001\n");

	String s = new String(sb);
	String t = new String(b840().getFormattedText(Envelope.X12_FORMAT).getBytes());
    assertEquals(s, t);
}

public Envelope b840()
  throws OBOEException
{
  X12Envelope env = new X12Envelope();

  /** add code here to work with the headers and other envelope control segments */
  Segment interchange_Control_Header = Interchange_Control_Header.getInstance();
  env.setInterchange_Header(interchange_Control_Header);
  interchange_Control_Header.getDataElement(0).set("Y1");//auth. info. qual 2-2
  interchange_Control_Header.getDataElement(1).set("AUTH");//auth info 10-10
  interchange_Control_Header.getDataElement(2).set("Y3");//sec info qual 2-2
  interchange_Control_Header.getDataElement(3).set("SEC");//sec info 10-10
  interchange_Control_Header.getDataElement(4).set("Y5");//int sender info qual 2-2
  interchange_Control_Header.getDataElement(5).set("SENDERID");//int sender info 15-15
  interchange_Control_Header.getDataElement(6).set("Y7");//int id qual 2-2
  interchange_Control_Header.getDataElement(7).set("RECEIVERID");//int id 15-15
  interchange_Control_Header.getDataElement(8).set("010101");// int dt 6-6
  interchange_Control_Header.getDataElement(9).set("1300");//int tm 4-4
  interchange_Control_Header.getDataElement(10).set("Y");//int cntr std id 1-1
  interchange_Control_Header.getDataElement(11).set("Y12");//int cntrl ver 5-5
  interchange_Control_Header.getDataElement(12).set("000000001");// int cntrl number 9-9
  interchange_Control_Header.getDataElement(13).set("x");//ack req 1-1
  interchange_Control_Header.getDataElement(14).set("z");//test ind 1-1

  env.setDelimitersInHeader();

  TransactionSet ts = TransactionSetFactory.buildTransactionSet("840");
  FunctionalGroup fg = new X12FunctionalGroup();

  /** add code here to work with the fg header and trailer segments */
  Segment fgHeader = com.americancoders.edi.x12.Functional_Group_Header.getInstance();

  fgHeader.getDataElement(0).set("fg0");
  fgHeader.getDataElement(1).set("fg1");
  fgHeader.getDataElement(2).set("fg2");
  fgHeader.getDataElement(3).set("010203");

  fg.setHeader(fgHeader);

  env.addFunctionalGroup(fg);
  fg.addTransactionSet(ts);

  Table table;
  table = ts.getHeaderTable();
  buildHeaderST(table);
  buildHeaderBQT(table);
  table = ts.getDetailTable();
  buildDetailPO1(table);
  table = ts.getSummaryTable();
  buildSummaryCTT(table);
  buildSummarySE(table);

  Segment fgTrailer =  com.americancoders.edi.x12.Functional_Group_Trailer.getInstance();
  fg.setTrailer(fgTrailer);
  fg.setCountInTrailer();
  fgTrailer.getDataElement(1).set("000000001");

  Segment interchange_Control_Trailer = Interchange_Control_Trailer.getInstance();
  env.setInterchange_Trailer(interchange_Control_Trailer);
  env.setFGCountInTrailer() ;
  interchange_Control_Trailer.getDataElement(1).set("000000001");

  return env;

}

public void buildHeaderST(Table inTable)
  throws OBOEException
{
  Segment segment = inTable.createSegment("ST");
  inTable.addSegment(segment);  DataElement de;
  de = (DataElement) segment.buildDE(0);  // 143 Transaction Set Identifier Code
  de.set("840");
  de = (DataElement) segment.buildDE(1);  // 329 Transaction Set Control Number
  de.set("000000001");
  }

/** builds segment BQT that is part of the Header
*<br>Beginning Segment for Request for Quotation used
*<br>To indicate the beginning of a Request for Quotation Transaction Set and transmit identifying numbers and dates
*param inTable table containing this segment
*throws OBOEException - most likely segment not found
*/
public void buildHeaderBQT(Table inTable)
  throws OBOEException
{
  Segment segment = inTable.createSegment("BQT");
  inTable.addSegment(segment);  DataElement de;
  de = (DataElement) segment.buildDE(0);  // 353 Transaction Set Purpose Code
  de.set("363");
  de = (DataElement) segment.buildDE(1);  // 586 Request for Quote Reference Number
  de.set("586");
  de = (DataElement) segment.buildDE(2);  // 373 Date
  de.set("010103");
  de = (DataElement) segment.buildDE(3);  // 374 Date/Time Qualifier
  de.set("200");
  }

public void buildDetailPO1(Table inTable)
  throws OBOEException
{
  Segment segment = inTable.createSegment("PO1");
  inTable.addSegment(segment);
  buildDetailPO1LIN(segment);
  buildDetailPO1G53(segment);
  DataElement de;
  de = (DataElement) segment.buildDE(0);  // 350 Assigned Identification
  de.set("PO1350");
  de = (DataElement) segment.buildDE(1);  // 330 Quantity Ordered
  de.set("1");
  de = (DataElement) segment.buildDE(2);  // 355 Unit or Basis for Measurement Code
  de.set("12");
  de = (DataElement) segment.buildDE(3);  // 212 Unit Price
  de.set("1232");
  }
public void buildDetailPO1LIN(Segment inSegment)  throws OBOEException
{
  Segment segment = inSegment.createSegment("LIN");
  inSegment.addSegment(segment);  DataElement de;
  de = (DataElement) segment.buildDE(0);  // 350 Assigned Identification
  de.set("LIN350");
  de = (DataElement) segment.buildDE(1);  // 235 Product/Service ID Qualifier
  de.set("2");
  de = (DataElement) segment.buildDE(2);  // 234 Product/Service ID
  de.set("2-350");
  }

/** builds segment G53 that is part of the DetailPO1
*<br>Maintenance Type used
*<br>To identify the specific type of item maintenance
*param inSegment segment containing this subsegment
*throws OBOEException - most likely segment not found
*/
public void buildDetailPO1G53(Segment inSegment)  throws OBOEException
{
  Segment segment = inSegment.createSegment("G53");
  inSegment.addSegment(segment);  DataElement de;
  de = (DataElement) segment.buildDE(0);  // 875 Maintenance Type Code
  de.set("875");
  }

public void buildSummaryCTT(Table inTable)
  throws OBOEException
{
  Segment segment = inTable.createSegment("CTT");
  inTable.addSegment(segment);  DataElement de;
  de = (DataElement) segment.buildDE(0);  // 354 Number of Line Items
  de.set("1");
  de = (DataElement) segment.buildDE(1);  // 347 Hash Total
  de.set("1");
  }

/** builds segment SE that is part of the Summary
*<br>Transaction Set Trailer used
*<br>To indicate the end of the transaction set and provide the count of the transmitted segments (including the beginning (ST) and ending (SE) segments)
*param inTable table containing this segment
*throws OBOEException - most likely segment not found
*/
public void buildSummarySE(Table inTable)
  throws OBOEException
{
  Segment segment = inTable.createSegment("SE");
  inTable.addSegment(segment);  DataElement de;
  de = (DataElement) segment.buildDE(0);  // 96 Number of Included Segments
  de.set("1");
  de = (DataElement) segment.buildDE(1);  // 329 Transaction Set Control Number
  de.set("000000001");
  }



public static void main(String arg[])
{
	String[] testCaseName = {ParserTestCase.class.getName()};
	junit.swingui.TestRunner.main(testCaseName);
}

}