package com.americancoders.edi;

import com.americancoders.util.Util;

/**
 * class for all Data Elements defined as character and alphanumeric
 *
 *<P>OBOE - Open Business Objects for EDI
 *<p>Part of the OBOE Basic Extended Package
 *<br>An EDI and XML Translator Written In Java
 *<br>Copyright 1998-2007 - American Coders, LTD  - Raleigh NC USA
 *<br>All rights reserved
 *<br>American Coders, Ltd
 *<br>P. O. Box 97462
 *<br>Raleigh, NC  27624  USA
 *<br>1-919-846-2014
 *<br>http://www.americancoders.com
@author Joe McVerry - American Coders, Ltd.
  @version   3.5.3
 */

public class CharDE extends DataElement
{


    protected String value[];

    protected int cursor = -1;

    /** constructs from its template
     * @param inTDE TemplateDE
     * @param inParent owning Object
     */
    public CharDE(TemplateDE inTDE, IContainedObject inParent)
    {
        super(inTDE, inParent);
        value = new String[inTDE.getOccurs()];
     }


    /**
     * gets the current length for the Data Element
     * @return int retuns length of set value,  can have a null exception if value is not set.
     *
     */
    public int getLength()    {
        if (value == null)
          return 0;
        int len = 0;
        for (int i = 0; i < getOccurs(); i++)
         {
          if (value[i] != null)
          		len += value[i].length();
         }
        return len;
        }



	/** sets the fields contents, cursor set to zero
	 * @param inValue String contents
	 * @throws OBOEException
	 */
	public void set(String inValue) {
		
		cursor = 0;
		value[cursor] = inValue;
	}

	/** sets the next field contents by moving cursor, cursor will wrap around
	 * @param inValue String contents
	 * @throws OBOEException
	 */
	public void setNext(String inValue) {
		cursor++;
		if (cursor >= getOccurs())
		   cursor = 0;
		if (this.getRequired()=='M')
			for (int i = inValue.length(); i  < getMinLength();i++)
				inValue+=' ';
		value[cursor] = inValue;
		}

    /** sets the fields contents, not formatted
     * @param inValue byte array, converted to string and set(String) is called
     * @exception OBOEException
     *   inValue contains format characters if field defined with type of N#
     *
     */
   public void set(byte inValue[]) throws OBOEException
     { set(new String(inValue));}



	/**
	 * returns the value for the Data Element
	 * @return String
	 */

	public String get() {
		return get(0);
	}

	/**
	 * returns the value for the Data Element
	 * @param inPos int position in array
	 * @return String
	 */

	public String get(int inPos) {

	if (value[inPos] == null)
	  return null;
	if (value[inPos].length() == 0)
	  return value[inPos];
	StringBuffer sb = new StringBuffer(value[inPos]);
	for (int i = value[inPos].length(); i < getMinLength(); i++)
	   sb.append(' ');
	value[inPos] = new String(sb);
	return value[inPos];
	}


	/** formats text of data element
	* <br> Description of DataElement is defined in the class
	* <br> value is the current value set in the object
	* @param formatType int format type x12, edifact...
	* @return String of formatted  text
	*/

   public String getFormattedText(int formatType)
   {

	  StringBuffer sb = new StringBuffer();
	  String got;
	  int repeatCnt = -1;
	  for (repeatCnt = value.length-1; repeatCnt > -1 && value[repeatCnt] == null; repeatCnt--);
      for (int ii = 0; ii < value.length; ii++) {
      	if (value[ii] == null)
      	   break;
      	got = get(ii);
		if (got == null)
			   got = new String();

	  switch (formatType)
	  {
		  case Envelope.CSV_FORMAT:
		  sb.append("DE,"+getID()+",\""+getName()+"\",\""+got+"\""+com.americancoders.util.Util.lineFeed);            break;
		  case Envelope.XML_FORMAT:
		  sb.append("<" +getXMLTag() + ">" + Util.normalize(got) + "</" + getXMLTag() + ">"+com.americancoders.util.Util.lineFeed);
		  break;
		  case Envelope.VALID_XML_FORMAT:
   	 	  case Envelope.VALID_XML_FORMAT_WITH_POSITION:
 		  if (got == null)
			 got = new String();
		  sb.append("<element code=\"" + getID() + "\"");
  		  sb.append(" name=\"" + getName() + "\"");
		  if (formatType == Envelope.VALID_XML_FORMAT_WITH_POSITION)
			sb.append(" docPosition=\""+this.getSequence() + "\"");
		  sb.append(">");
		  sb.append(" <value>" +  Util.normalize(got) + "</value></element>"+com.americancoders.util.Util.lineFeed);
		  break;
   	 	  case Envelope.PIXES_FORMAT :
   	 	  	if (got.length() == 0)
   	 	  		break;
			sb.append("<set name=\""+parent.getID()+getSequence()+"\">"+Util.normalize(got)+
					"</set>"+com.americancoders.util.Util.lineFeed);
   	 	    sb.append("<element position=\"" + this.getSequence() + "\"");
			sb.append(">$");
            sb.append(parent.getID()+getSequence() + "$</element>"+com.americancoders.util.Util.lineFeed);

  		  break;
		  case Envelope.X12_FORMAT:
			 sb.append(got);
			 if (getOccurs() > 1 && ii < repeatCnt)
			    sb.append(getDelimiter(Envelope.X12_REPEAT_DELIMITER.charAt(0)));
			 break;

		case Envelope.EDIFACT_FORMAT:
		   for (int i = 0; i < got.length(); i++)
			 {
				if (got.charAt(i) == getDelimiter(Envelope.EDIFact_FIELD_DELIMITER.charAt(0))
				|| got.charAt(i) == getDelimiter(Envelope.EDIFact_GROUP_DELIMITER.charAt(0))
				|| got.charAt(i) == getDelimiter(Envelope.EDIFact_SEGMENT_DELIMITER.charAt(0))
				|| got.charAt(i) == getDelimiter(Envelope.EDIFact_ESCAPE_CHARACTER.charAt(0))
				|| got.charAt(i) == getDelimiter(Envelope.EDIFact_REPEAT_DELIMITER.charAt(0)))
				  sb.append(getDelimiter(Envelope.EDIFact_ESCAPE_CHARACTER.charAt(0)));
				sb.append(got.charAt(i));
			 }
		  if (getOccurs() > 1 && ii < repeatCnt)
			 sb.append(getDelimiter(Envelope.EDIFact_REPEAT_DELIMITER.charAt(0)));
		  break;

		case Envelope.TRADACOMS_FORMAT:
		   for (int i = 0; i < got.length(); i++)
			 {
				if (got.charAt(i) == getDelimiter(Envelope.TRADACOMS_FIELD_DELIMITER.charAt(0))
				|| got.charAt(i) == getDelimiter(Envelope.TRADACOMS_GROUP_DELIMITER.charAt(0))
				|| got.charAt(i) == getDelimiter(Envelope.TRADACOMS_SEGMENT_DELIMITER.charAt(0))
				|| got.charAt(i) == getDelimiter(Envelope.TRADACOMS_ESCAPE_CHARACTER.charAt(0))
				|| got.charAt(i) == getDelimiter(Envelope.TRADACOMS_REPEAT_DELIMITER.charAt(0)))
				  sb.append(getDelimiter(Envelope.TRADACOMS_ESCAPE_CHARACTER.charAt(0))+got.charAt(i));
				else sb.append(got.charAt(i));
			 }
		  if (getOccurs() > 1 && ii < repeatCnt)
			 sb.append(getDelimiter(Envelope.EDIFact_REPEAT_DELIMITER.charAt(0)));
		  break;

		  default:
		  sb.append("\t" + getName() + ": " + value[0] + com.americancoders.util.Util.lineFeed);
		  break;
	  }
      }
	  return new String(sb);
  }

    /** returns error responses of contents
     * @param inText String text
     * @return String, null if no error
     */
    public String validate(String inText)
    {

        String returnMessage = myTemplate.validate(inText);
        return returnMessage;

    }

        /** sets  error  in DocumentErrors
	     * @param inDErr DocumentErrors object
	     * @return boolean false = error.
	     */
	    public boolean validate(DocumentErrors inDErr)
	    {
	    	if (isUsed() == false) {
	            if (value[0] != null && value[0].length() > 0)
	            {
	                inDErr.addError(0, getID(), "field is not used, see " +getName() + " at position " + getSequence(),  getParent(), "10", this, 2);
	                return false;
	               }
	            else return true;
	    	}

	        if (getRequired() == 'M'){
	            if (value[0] == null || value[0].length() == 0)
	             {
	              inDErr.addError(0, getID(), "Value Required, see " +getName() + " at position " + getSequence(),  getParent(), "1", this, 1);
	              return false;
	             }
	        }
	        else  // not required
	          if (value[0] == null || value[0].length() == 0)
	            return true;

	        if (value[0].length() < getMinLength())
	          {
	            inDErr.addError(getSequence(), getID(), "Data element value ("+value[0]+") Too Short, see " +getName() + " at position " + getSequence(),  getParent(), "4", this, 1);
	            return false;
	          }

	        if (value[0].length() > getMaxLength())
	          {
	            inDErr.addError(getSequence(), getID(), "Data element value ("+value[0]+") Too Long, see " +getName() + " at position " + getSequence(),  getParent(), "5", this, 1);
	            return false;
	          }



	        return true;
	    }



}
