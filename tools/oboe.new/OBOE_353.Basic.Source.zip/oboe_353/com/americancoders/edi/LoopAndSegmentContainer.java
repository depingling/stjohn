package com.americancoders.edi;


import java.io.IOException;
import java.io.PushbackInputStream;
import java.util.Vector;

import org.apache.log4j.Logger;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.americancoders.util.Util;

/**
 * Segment Container
 *
 *<P>OBOE - Open Business Objects for EDI
 *<p>Part of the OBOE Basic Extended Package
 *<br>An EDI and XML Translator Written In Java
 *<br>Copyright 1998-2007 - American Coders, LTD  - Raleigh NC USA
 *<br>All rights reserved
 *<br>American Coders, Ltd
 *<br>P. O. Box 97462
 *<br>Raleigh, NC  27624  USA
 *<br>1-919-846-2014
 *<br>http://www.americancoders.com
@author Joe McVerry - American Coders, Ltd.
  @version   3.5.3
 */

public abstract class LoopAndSegmentContainer extends SegmentContainer
{

    private TemplateLoopContainer myTemplateLoopContainer;
    
	/** log4j object */
	static Logger logr = Logger.getLogger(LoopAndSegmentContainer.class);
	static 	{Util.isLog4JNotConfigured();}


    /** tests if the seg id  is part of this container
     * @return boolean true it is part of this container
     * @param inID String seg id
     * @exception OBOEException thrown when an unknown segment id string is found
     */
    public boolean doYouWantThisSegment(String inID)
    throws OBOEException
    {

        for (int i=0; i < myTemplateLoopContainer.getCount(); i++)
        {
            if (myTemplateLoopContainer.isSegment(i))
             {
              if (inID.compareTo(myTemplateLoopContainer.getTemplateSegment(i).getID()) == 0)
                return true;
             }
            else if (inID.compareTo(myTemplateLoopContainer.getTemplateLoop(i).getTemplateSegment(0).getID()) == 0)
               return true;
        }

        return false;
    }

    /** parses the segment portion of an EDI Document,
     * adds to segment vector
     * @param TransactionTokenizedString incoming tokenized string
     * @return boolean - true if tts was used
     * @throws OBOEException as thrown, can't process subsegment maybe
     */

  public boolean parse(ITokenizer TransactionTokenizedString)
    throws OBOEException
    {

        boolean inUsed = false;

        int i = 0;
        TemplateSegment tseg;
        TemplateLoop tloop;
        Segment currentSegment = null;
        Loop currentLoop;

        boolean lookback = false;
		boolean foundButNotQuiteRight = false;

        while (i < myTemplateLoopContainer.getCount())
        {
            if (myTemplateLoopContainer.isLoop(i))
            {
                tloop = myTemplateLoopContainer.getTemplateLoop(i);
                if (TransactionTokenizedString.getCurrentDataElement().compareTo(tloop.getTemplateSegment(0).getID()) == 0)
                {
                
                if (tloop.canYouPrevalidate())
                  {
                    if (tloop.isThisYou(TransactionTokenizedString) == false)
                      {
                        i++;
                        continue;
                      }
                  }
                  
                  currentLoop = new Loop(tloop, this);
                  addLoop(currentLoop);
                  currentLoop.parse(TransactionTokenizedString);
                  inUsed = true;
                  if (currentLoop.getOccurs() == 1)
                     i++;
                }
                else i++;
            }
            else if (myTemplateLoopContainer.isSegment(i))
            {
            tseg = myTemplateLoopContainer.getTemplateSegment(i);
            String nextToken = TransactionTokenizedString.getCurrentDataElement(); 
			if (nextToken == null) // error, but we should be able to continue
			  return false;
            if (nextToken.compareTo(tseg.getID()) == 0)
            {
				foundButNotQuiteRight = true;
                if (tseg.canYouPrevalidate())
                  {
                    if (tseg.isThisYou(TransactionTokenizedString) == false)
                      {
                    	logr.debug("can't validate this one " + TransactionTokenizedString.getCurrentDataElement());
                        i++;
                        inUsed = false;
                        continue;
                      }
                  }
				 if (tseg.getOccurs() == this.getCount(i)) {//hipaa equivalent segments
				   if (this.isSegment(i)) {
					   this.dupSegment=true;
					   return false;
				   }
				 }
				foundButNotQuiteRight = false; 
				this.dupSegment=false;

                 currentSegment = new Segment(tseg, this);
                 currentSegment.setByteOffsetPositionInIncomingDocument(TransactionTokenizedString.getInputByteCount());
                 addSegment(currentSegment, new Integer(i));
                 currentSegment.parse(TransactionTokenizedString);
				 if (currentSegment.getOccurs() == 1){
					// first test for hipaa equivalent segments
					if (equivalentSegments(i))
					  i = resetToFirstEquivalentSegment(i);
					else
					  i++; // don't look back
				}
				else // more than one, still test for equivalence
				if (equivalentSegments(i))
				  i = resetToFirstEquivalentSegment(i);
				inUsed = true;
            }
            else i++; // next
            }
            else i++; // next
            if (i == myTemplateLoopContainer.getCount() && lookback == true)
            {
                lookback = false;
                i = 0;
            }
        }

	   if (foundButNotQuiteRight)
	      {
			TransactionTokenizedString.reportError("Unidentifiable data element value", this, "8", null, 1);
			// eat up the token
			inUsed = true;
	      }
	   
	   
	   

        return inUsed;


    }


    /** parses a XML EDI Document
     * adds to datalement vector or compositeDE
     * and adds to secondary Segment vector
     * @param node Incoming DOM node
     * @throws OBOEException as thrown
     */

    public void parse(Node node)
    throws OBOEException
    {
        int i=0, n;

        NodeList nl = node.getChildNodes();
        Segment currentSegment;
        Loop currentLoop;
        Node currentNode = node;


        nodeLoop: for (n = 0; n < nl.getLength(); n++)
        {

         currentNode = nl.item(n);

         if (currentNode.getNodeType() != Node.ELEMENT_NODE)
             continue nodeLoop;

         for (i=0; i < myTemplateLoopContainer.getContainerSize(); i++)
           {
            if (myTemplateLoopContainer.isLoop(i) )
            {
             if (currentNode.getNodeName().compareTo(myTemplateLoopContainer.getTemplateLoop(i).getXMLTag()) == 0)
             {
              currentLoop = new Loop(myTemplateLoopContainer.getTemplateLoop(i), this);
              addLoop(currentLoop);
              currentLoop.parse(currentNode);
              continue nodeLoop;
             }
            }
            else if (myTemplateContainer.isSegment(i))
             {
             if (currentNode.getNodeName().compareTo(myTemplateContainer.getTemplateSegment(i).getXMLTag()) == 0)
              {
                currentSegment = new Segment(myTemplateContainer.getTemplateSegment(i), this);
                addSegment(currentSegment, new Integer(i));
                currentSegment.parse(currentNode);
                continue nodeLoop; // done with this subSegment node
              }
             }
            }
          throw new OBOEException("Unknown node found " +  currentNode.getNodeName() + " in container "+ getID());
        }
    return;
    }

    /** parses a Fixed Length EDI Document
     * @param pis PushbackInputStream
     * @exception OBOEException thrown when the transaction id string is incorrect
     * @exception OBOEException thrown when an unknown segment id string is foundi
     */
    public void parse(PushbackInputStream pis)
    throws OBOEException, IOException
    {

        int i=0;
        Segment currentSegment=null;
        Loop currentLoop=null;
        int idLen = 0;



        while (i < myTemplateContainer.getCount())
        {
			if (myTemplateLoopContainer.isLoop(i))
			   idLen = myTemplateLoopContainer.getTemplateLoop(i).getID().length();
			else
				idLen = myTemplateLoopContainer.getTemplateSegment(i).getID().length();
			byte me[] = new byte[idLen];
			if (pis.read(me) != idLen)
				throw new OBOEException("expected data not read");
			String id = Util.rightTrim(new String(me));
			pis.unread(me);
            if (myTemplateLoopContainer.isLoop(i) && id.compareTo(myTemplateLoopContainer.getTemplateLoop(i).getTemplateSegment(0).getID()) == 0)
             {
              currentLoop = new Loop(myTemplateLoopContainer.getTemplateLoop(i), this);
              addLoop(currentLoop);
              currentLoop.parse(pis);
            }
            else if (myTemplateContainer.isSegment(i))
             {
             if (id.compareTo((myTemplateContainer.getTemplateSegment(i)).getID()) == 0)
               {
             	if (pis.read(me) != idLen)
    				throw new OBOEException("expected data not read");
    			currentSegment = new Segment(myTemplateContainer.getTemplateSegment(i), this);
                addSegment(currentSegment);
                if (currentSegment.getOccurs() == 1)
                    i++; // don't look back
                currentSegment.parse(pis);
               }
                else i++;
            }
           else i++;
        }



    }

   /** asks the container why it didn't use the current token
    * @param  et Tokenizer object to get TransactionTokenizedString incoming tokenized string
    */

   public void whyNotUsed(Tokenizer et)
   {
		if (this.dupSegment)
		  {
			et.reportError("Duplicate Segment", "2");
			return;
		  }
        int i;
        i = 0;
        TemplateSegment tseg;
        TemplateLoop tloop;


        while (i < myTemplateContainer.getCount())
        {

            if (myTemplateLoopContainer.isLoop(i))
            {
                tloop = myTemplateLoopContainer.getTemplateLoop(i);
                if (et.getCurrentDataElement().compareTo(tloop.getTemplateSegment(0).getID()) == 0)
                {
                if (tloop.canYouPrevalidate())
                  {
                    if (tloop.isThisYou(et) == false)
                      {
                        i++;
                        continue;
                      }
                  }
                tloop.whyNotYou(et);
                return;
                }
              i++;
            }

            else {

	        tseg = myTemplateContainer.getTemplateSegment(i);
            if (et.getCurrentDataElement().compareTo(tseg.getID()) == 0)
            {
                if (tseg.canYouPrevalidate())
                  {
                        tseg.whyNotYou(et, this);
                        return;
                  }
            }
            i++;
            }
        }
		et.reportError("Unknown or out of place segment ("+et.getCurrentDataElement()+") at byte offset("+et.getInputByteCount()+")", "2");
        return;
   }




    /** returns the size of the segment array
     * <br> -1 if array is undefined
     @return int
     */
    public int getContainerSize() {
        if (container == null)
          return -1;
        return container.length;
        }

    /** simple routine to build the array based on the number of entries in the template segment vector
     */
    public void defineContainer()
    {
        TemplateSegment ts;
        TemplateLoop tloop;

        container = new Object[myTemplateLoopContainer.getCount()];
        for (int i = 0; i < myTemplateLoopContainer.getCount(); i++)
        {
            if (myTemplateLoopContainer.isLoop(i))
            {
              tloop = myTemplateLoopContainer.getTemplateLoop(i);
              if (tloop.getOccurs() != 1)
                 container[i] = new Vector();
            }
            else if (myTemplateLoopContainer.isSegment(i))
            {
              ts = myTemplateLoopContainer.getTemplateSegment(i);
              if (ts.getOccurs() != 1)
                 container[i] = new Vector();
            }
        }

    }


    /** add a Loop to the array
     * @param inLoop Segmemt to add to vector
     * @throws OBOEException Loop doesn't belong
     */
    public void addLoop(Loop inLoop)
    throws OBOEException
    { int i;
        
        if (container == null) defineContainer();



        for (i=0; i < myTemplateLoopContainer.getContainerSize(); i++)
        {   if (myTemplateLoopContainer.isLoop(i)) {
                TemplateLoop tl = (TemplateLoop) myTemplateLoopContainer.getTemplateLoop(i);
                if (inLoop.getID().compareTo(tl.getID()) != 0)
                   continue;

                if (tl.getOccurs() == 1)
                   container[i] = inLoop;
                else
                {Vector v = (Vector) container[i];
                    if (v == null)
                    {
                        v = new Vector();
                        container[i] = v;
                    }
                    v.addElement(inLoop);
                }
                return;
            }

        }
        throw new OBOEException("SubLoop " + inLoop.getID() + " not defined in " + getID());
    }


    /** adds a Loop to a vectorized Loop in the container at a predefined sequence
     * @param inLoop Loop
     * @param inPosition int position
     * @exception OBOEException Loop postion not vectorized
     */


    public void addLoopToVector(Loop inLoop, int inPosition)
    throws OBOEException
    { int i;
        TemplateLoop tempSeg;
        if (container == null) defineContainer();

        for (i=0; i < myTemplateLoopContainer.getContainerSize(); i++)
        {
            tempSeg = (TemplateLoop) myTemplateLoopContainer.getTemplateLoop(i);
            if (inLoop.getID().compareTo(tempSeg.getID()) == 0)
            { if (tempSeg.getOccurs() == 1)
                throw new OBOEException("Position not held by Vectorized SubLoop");
                else
                {Vector v = (Vector) container[i];
                    if (v == null)
                    {
                        v = new Vector();
                        container[i] = v;
                    }
                    v.insertElementAt(inLoop, inPosition);
                }
                return;
            }
        }
        throw new OBOEException("SubLoop " + inLoop.getID() + " not defined in " + getID());
    }



    /** sets a Loop to the container at position in the array,
     * if the Loop is part of the vectorized Loop throw exception
     * @param inLoop Loop
     * @param inPosition int position
     * @exception OBOEException out of range
     *               SubLoop vectorized
     *               SubLoop not defined at sequence
     */


    public void setLoopAt(Loop inLoop, int inPosition)
    throws OBOEException
    {
        TemplateLoop tempSeg;

        if (inPosition < 0 || inPosition > myTemplateLoopContainer.getContainerSize())
        throw new OBOEException("Input sequence number out of range for array");

        if (isVector(inPosition))
        throw new OBOEException("Position held by Vectorized SubLoop");

        tempSeg = (TemplateLoop) myTemplateLoopContainer.getTemplateLoop(inPosition);
        if (tempSeg.getID().compareTo(inLoop.getID()) !=0)
        throw new OBOEException("Loop not defined at position");

        container[inPosition] = inLoop;
    }

    /** sets a Loop to the vector at a position container
     * @param inLoop Loop
     * @param inPosition int position in array
     * @param inVectorPosition int position with vector at inPosition
     * @exception OBOEException out of range
     *               SubLoop not vectorized
     *               SubLoop not defined at sequence
     */


    public void setLoopAt(Loop inLoop, int inPosition, int inVectorPosition)
    throws OBOEException
    {
        TemplateLoop tempSeg;
        if (inPosition < 0 || inPosition > myTemplateLoopContainer.getContainerSize())
        throw new OBOEException("Input sequence number out of range for array");

        if (isLoop(inPosition))
        throw new OBOEException("Position not held by Vectorized SubLoop");

        tempSeg = (TemplateLoop) myTemplateLoopContainer.getTemplateLoop(inPosition);
        if (tempSeg.getID().compareTo(inLoop.getID()) !=0)
        throw new OBOEException("Loop not defined at position");

        Vector v = (Vector) container[inPosition];
        v.setElementAt(inLoop, inVectorPosition);
    }

    /** removes a Loop from the container by id, does this by setting array entry to null
     * can be used to remove all Loops with same id at a vectorized position
     * @param inID String id
     * @exception OBOEException unknown Loop id
     */


    public void removeLoop(String inID)
    throws OBOEException
    { int i;
        TemplateLoop tempSeg;
        for (i=0; i < myTemplateLoopContainer.getContainerSize(); i++)
        {
            tempSeg = (TemplateLoop)myTemplateLoopContainer.getTemplateLoop(i);
            if (tempSeg.getID().compareTo(inID) == 0)
            {
                container[i] = null;
                return;
            }
        }
        throw new OBOEException("SubLoop " + inID + " not defined in " + getID());
    }
    /** removes a Loop from the container by its ID from the subLoop Vector
     * @param inID String ID
     * @param inPosition int position in array
     * @exception OBOEException SubLoop not vectorized
     *               unknown Loop id
     */


    public void removeLoop(String inID, int inPosition)
    throws OBOEException
    { int i;
        TemplateLoop tempSeg;
        for (i=0; i < myTemplateLoopContainer.getContainerSize(); i++)
        {
            tempSeg = (TemplateLoop)myTemplateLoopContainer.getTemplateLoop(i);
            if (tempSeg.getID().compareTo(inID) == 0)
            {
                if (tempSeg.getOccurs() == 1)
                throw new OBOEException("Position not held by Vectorized SubLoop");
                else
                {Vector v = (Vector) container[i];
                    v.remove(inPosition);
                }
                return;
            }
        }
        throw new OBOEException("SubLoop " + inID + " not defined in " + getID());
    }


    /** removes a Loop from the container at a particular position
     * can be used to remove all Loops with same id at a vectorized position
     * @param inPosition int position in array
     * @exception OBOEException position number out of range
     */


    public void removeLoop(int inPosition)
    throws OBOEException
    {
        if (inPosition < 0 || inPosition > myTemplateLoopContainer.getContainerSize())
        throw new OBOEException("Input sequence number out of range for array");
        container[inPosition] = null;
    }


    /** removes a Loop from the container at a particular position in the subLoop Vector
     * @param inPosition int position in array
     * @param inVectorPosition int position in Vector at inPosition in array
     * @exception OBOEException position number out of range
     *               SubLoop not vectorized
     *               SubLoop sequence not defined
     */


    public void removeLoop(int inPosition, int inVectorPosition)
    throws OBOEException
    {
        if (inPosition < 0 || inPosition > myTemplateLoopContainer.getContainerSize())
        throw new OBOEException("Input sequence number out of range for array");

        TemplateLoop tempSeg = (TemplateLoop)myTemplateLoopContainer.getTemplateLoop(inPosition);
        if (tempSeg.getOccurs() == 1)
        throw new OBOEException("Position not held by Vectorized SubLoop");

        Vector v = (Vector) container[inPosition];
        v.remove(inVectorPosition);

    }

    /** returns a Loop by its position
     * @return Loop objects - will return null if Loop  not defined
     * @param inPosition int  position in array
     * @exception OBOException "No Loop at this position" - it is a Vector of Loops
     */

    public Loop getLoop(int inPosition)
      throws OBOEException
    {
        if (container[inPosition] == null) return null;
        if (!isLoop(inPosition))
        	throw new OBOEException("No Loop at this position");
        return (Loop) container[inPosition];
    }


    /** returns the Loop inside the subLoop Vector by its position
     * @return Vector of Loop objects - null indicates Loop not set
     * @param inPosition int position in array
     * @param inVectorPosition int position in Vector at inPosition in array
     * @throws OBOEException bad position specified, position is negative, larger than Vector or
     * object at position specified by first parameter is a Loop.
     */

    public Loop getLoop(int inPosition, int inVectorPosition)
    throws OBOEException
    {
        if (isLoop(inPosition, inVectorPosition)==false)
        	throw new OBOEException("Position not held by Vectorized SubLoop");
        if (inVectorPosition >= ((Vector) container[inPosition]).size())
        	return null;

        return (Loop) ((Vector) container[inPosition]).elementAt(inVectorPosition);
    }
    /** returns a Loop by its ID
     * @return Loop objects - null indicates Loop not set
     * @param ID String id of Loop to get
     * @throws OBOEException "ID is unknown to Loop "
     */

    public Loop getLoop(String ID)
    throws OBOEException
    {
        int i;
        for (i=0; i < getContainerSize(); i++)
        {
        	if (this.myTemplateLoopContainer.isLoop(i) == false)
        		continue;
        	
       		if (this.myTemplateLoopContainer.getTemplateLoop(i).getID().compareTo(ID)!=0)
        			continue;
        	
        	if (isVector(i))
        		throw new OBOEException("loop inside a vector, use getLoop(String, int)");
        	
            
            return getLoop(i);
        }
        if (myTemplateLoopContainer.getTemplateLoop(ID) == null)
           throw new OBOEException ("Loop with ID " + ID + " is unknown to Loop container " + getID());
        else return null;
    }
    /** returns a Loop by its ID and its position in the vector
     * <br>You must use this method call to get to floating Loops
     * @return Loop objects - null indicates position of Loop not set
     * @param ID String id of Loop to get
     * @param inVectorPosition int position in Vector at position in array identified by id
     * @throws OBOEException Loop with ID not within a Vector.
     */

    public Loop getLoop(String ID, int inVectorPosition)
    throws OBOEException
    {
        int i;
        Loop loop;
        Vector v;
        for (i=0; i < getContainerSize(); i++)
        {
           	if (this.myTemplateLoopContainer.isLoop(i) == false)
        		continue;
        	
       		if (this.myTemplateLoopContainer.getTemplateLoop(i).getID().compareTo(ID)!=0)
        			continue;
       		
              if (isLoop(i))
              {
                loop = (Loop) container[i];
                if (loop.getID().compareTo(ID) == 0)
                  throw new OBOEException("Loop with ID "+ ID +" not within a Vector.");
                else
                continue;
              }
            if (container[i] instanceof Vector){
				v = (Vector) container[i];
				if (v.size() == 0)
				  continue;
				if (!isLoop(i,0))
				  continue;
				loop = (Loop) v.elementAt(0);
				if (loop.getID().compareTo(ID) == 0)
   				   if (v.size() <= inVectorPosition)
                       return null;
   				   else
				      return (Loop) v.elementAt(inVectorPosition);
		  }
        }

        return null;
    }


    /** returns a Loop by its id and the contents of a data field
     * <br>Used for Loops that repeat, useful with IDDE type fields.
     * <br>Will NOT work for Composite DE fields.
     * @return Loop objects - null not found
     * @param ID String id of loop
     * @param inSequence int DataElement sequence number relative to 1
     * @param inValue String value to test
     * @throws OBOEException Loop with ID not within a Vector.
     */

    public Loop getLoopByDataElementValue(String ID, int inSequence, String inValue)
    throws OBOEException
    {
        int i;
        Loop Loop;
        Vector v;
        DataElement de;
        for (i=0; i < getContainerSize(); i++)
        {
            if (isLoop(i))
              {
                Loop = (Loop) container[i];
                if (Loop.getSegment(0).isCompositeDE(i))
                  {
                      return null;
                  }
                if (Loop.getID().compareTo(ID) == 0)
                  {
                    de = Loop.getSegment(0).getDataElement(inSequence);
                    if (de == null)
                      continue;
                    if (de.get().compareTo(inValue) == 0)
                      return Loop;
                  }
              }
            if (container[i] instanceof Vector){
				v = (Vector) container[i];
				if (v.size() == 0)
				  continue;
				if (!isLoop(i,0))
				  continue;
				Loop = (Loop) v.elementAt(0);
                if (Loop.getSegment(0).isCompositeDE(i))
                  {
                      return null;
                  }
                if (Loop.getID().compareTo(ID) == 0)
                  {
                    de = Loop.getSegment(0).getDataElement(inSequence);
                    if (de == null)
                      continue;
                    if (de.get().compareTo(inValue) == 0)
                      return Loop;
                  }
		  }
        }


        return null;
    }

/**
 * returns the vector in the container
 * @param inPosition
 * @return Vector
 */
    public Vector getVector(int inPosition)
    {
    	return (Vector) container[inPosition];
    }

	/** returns the number of sub componenets (loops and segments)
	 * @return int a count - zero if position is not held by a vector
	 * @throws java.lang.ArrayOutOfBounds is possible.
	 */

	public int getLoopAndSegmentCount()
	{
	  int count=0;
	  for (int i = 0; i < getContainerSize(); i++)
		{
			if (isLoop(i))
			  count+= getLoop(i).getLoopAndSegmentCount();
			else
			if (isSegment(i))
			  count+=1;
			else
			if (container[i] instanceof Vector){
				Vector v = (Vector) container[i];
				if (v.size() == 0)
				  continue;
				for (int j = 0; j < v.size(); j++)
				  {
					if (isLoop(i,j))
					  count+= getLoop(i, j).getLoopAndSegmentCount();
					else if (isSegment(i,j))
					  count++;
				  }
			}
		}
	  return count;
	}

	/** returns the number of subsegments
	 * @return int a count - zero if position is not held by a vector
	 * @throws java.lang.ArrayOutOfBounds is possibl
	 */

	public int getSegmentCount()
	{
	  int count=0;
	  for (int i = 0; i < getContainerSize(); i++)
		{
			if (isSegment(i))
			  count+=1;
			else
			if (container[i] instanceof Vector){
				Vector v = (Vector) container[i];
				if (v.size() == 0)
				  continue;
				if (!isSegment(i,0))
				  continue;
				for (int j = 0; j < v.size(); j++)
				  {
					if (isSegment(i,j))
					  count++;
				  }
			}
		}
	  return count;
	}


	/** returns the number of subloops
	 * @return int a count - zero if position is not held by a vector
	 * @throws java.lang.ArrayOutOfBounds is possibl
	 */

	public int getLoopCount()
	{
	  int count=0;
	  for (int i = 0; i < getContainerSize(); i++)
		{
			if (isLoop(i))
			  count+=1;
			else
			if (container[i] instanceof Vector){
				Vector v = (Vector) container[i];
				if (v.size() == 0)
				  continue;
				if (!isLoop(i,0))
				   continue;
				for (int j = 0; j < v.size(); j++)
				  {
					if (isLoop(i,j))
					  count++;
				  }
			}
		}
	  return count;
	}


    /** returns the number of subLoops in a vector position
     * @return int a count - zero if position is not held by a vector
     * @param inPosition int position in array
     * @throws java.lang.ArrayOutOfBounds is possible.
     */

    public int getSegmentCount(int inPosition)
    { if (!isVector(inPosition)) return 0;
      return ((Vector) container[inPosition]).size();
    }

    /** returns the number of subLoops by Loop id
     * @return int
     * @param ID String id of Loop to count
     * @throws OBOEException Loop with ID unknown.
     */

    public int getLoopCount(String ID)
    {
        int i;
        Loop loop;
        Vector v;
        for (i=0; i < getContainerSize(); i++)
        {
            if (isLoop(i))
              {
                loop = (Loop) container[i];
                if (loop.getID().compareTo(ID) == 0)
                  return loop.getSegmentCount();
                else
                continue;
              }
            if (container[i] instanceof Vector){
				v = (Vector) container[i];
				if (v.size() == 0)
				  continue;
				if (!isLoop(i,0))
				  continue;
				loop = (Loop) v.elementAt(0);
				if (loop.getID().compareTo(ID) == 0)
				   return v.size();
		  }
        }
        if (myTemplateLoopContainer.getTemplateLoop(ID) == null)
           throw new OBOEException ("Loop with ID " + ID + " is unknown to Loop container " + getID());
        else return 0;


    }

	/** returns the number of elements in a vector position
	 * @return int a count - zero if position is not held by a vector
	 * @param inPosition int position in array
	 * @throws java.lang.ArrayOutOfBounds is possible.
	 */

	public int getCount(int inPosition)
	{ if (!isVector(inPosition)) return 0;
	  return ((Vector) container[inPosition]).size();
	}

	/** returns the number of elements by id
	 * @return int
	 * @param ID String id  to count
	 * @throws OBOEException ID unknown.
	 */

	public int getCount(String ID) {
		int i;
		Segment segment;
		Loop l;
		for (i = 0; i < getContainerSize(); i++) {
			if (isSegment(i)) {
				segment = (Segment) container[i];
				if (segment.getID().compareTo(ID) == 0)
					return 1;
				else
					continue;
			}
			if (isSegment(i, 0)) {
				if (getSegment(i, 0).getID().compareTo(ID) == 0)
					return getCount(i);
			}
			if (isLoop(i)) {
				l = (Loop) container[i];
				if (l.getID().compareTo(ID) == 0)
					return 1;
				else
					continue;
			}
			if (isLoop(i, 0)) {
				if (getLoop(i, 0).getID().compareTo(ID) == 0)
					return getCount(i);
			}
		}
		if ((myTemplateContainer.getTemplateSegment(ID) == null)
		  && (myTemplateLoopContainer.getTemplateLoop(ID) == null))
			throw new OBOEException(
				"Loop or Segment with ID "
					+ ID
					+ " is unknown to segment container "
					+ getID());
		else
			return 0;

	}


    /** returns true if object in container is a Loop at reqqeusted position
     * if false the subLoop is a vector or position specified is outside range of array
     * @return boolean
     * @param inPosition int position inarray
     */
    public boolean isLoop(int inPosition)
    {
        if (container == null) return false;
        if (inPosition < 0 || inPosition >= getContainerSize()) return false;
        if (container[inPosition] == null) return false;
        if (container[inPosition] instanceof Loop) return true;
        return false;

    }
    /** returns true if object in container is a Loop at reqqeusted position
     * if false the subLoop is a vector or position specified is outside range of array
     * @return boolean
     * @param inPosition int position inarray
     */
    public boolean isLoop(int inPosition, int inVectorPosition)
    {
        if (container == null) return false;
        if (inPosition < 0 || inPosition >= getContainerSize()) return false;
        if (container[inPosition] == null) return false;
        if (container[inPosition] instanceof Vector)
          {
            Vector v = (Vector) container[inPosition];
			if (inVectorPosition >= v.size())
			   return false;
            if (v.elementAt(inVectorPosition) instanceof Loop)
              return true;
            else
              return false;
          }
        return false;

    }
    /** returns true if object in container is a vector  at reqqeusted position
     * if true the subLoop is a Loop or position specified is outside range of array
     * @return boolean
     * @param inPosition int position in array
     */
    public boolean isVector(int inPosition)
    {
        if (container == null) return false;
        if (inPosition < 0 || inPosition >= getContainerSize()) return false;
        if (container[inPosition] == null) return false;
        if (container[inPosition] instanceof Vector) return true;
        return false;

    }

    /** returns true if there is no object in container at reqqeusted position
     * @return boolean
     * @param inPosition int position in array
     */
    public boolean isNull(int inPosition)
    {
        if (container == null) return true;
        if (container[inPosition] == null) return true;
        return false;

    }
	/** creates a Loop by ID
	 * @return Loop based on this Template
	 * @param id String id of subLoop to create
	 * @throws OBOEException unknown id
	 */

	public Loop createLoop(String id) throws OBOEException {
		if (myTemplateLoopContainer.getTemplateLoop(id) == null)
			throw new OBOEException(
				"Unknown loop id "
					+ id
					+ " for container "
					+ this
					+ " "
					+ this.getID());
		Loop seg = new Loop(myTemplateLoopContainer.getTemplateLoop(id), this);
		return seg;
	}

   /** tests if the node is part of this container
     * @return boolean true it is part
     * @param node DOM node of transaction data
     * @exception OBOEException thrown when the transaction id string is incorrect
     * @exception OBOEException thrown when an unknown segment id string is foundi
     */
    public boolean doYouWantThisNode(Node node)
    throws OBOEException
    {


        for (int i=0; i < myTemplateContainer.getCount(); i++)
        {
            if (myTemplateContainer.isSegment(i))
             {
              if (node.getNodeName().compareTo(myTemplateContainer.getTemplateSegment(i).getXMLTag()) == 0)
                return true;
             }
            else
            if (node.getNodeName().compareTo(myTemplateLoopContainer.getTemplateLoop(i).getXMLTag()) == 0)
                return true;
        }

        return false;
    }

    /** removes unused Loops and return the number of subLoops in container
     * @return int
     */

    public int trim()
    {
        int i, vi;
        Loop loop;
        Segment segment;
        Vector v;
        int count = 0;
        for (i=0; i < getContainerSize(); i++)
        {
            if (isSegment(i))
              {
                segment = (Segment) container[i];
                if (segment.trim()  > 0)
                  count++;
                else
                  container[i] = null;
              }
            if (isLoop(i))
              {
                loop = (Loop) container[i];
                if (loop.trim()  > 0)
                  count++;
                else
                  container[i] = null;
              }
            if (container[i] instanceof Vector)
              {
    		    v = (Vector) container[i];
	   	        if (v.size() == 0)
				   continue;
                for (vi=v.size()-1; vi>-1; vi--)
                  {
  				    if (isLoop(i,vi))
  				     {
	     			    loop = (Loop) v.elementAt(vi);
	    	    		if (loop.trim() == 0)
 		      	    	   v.removeElementAt(vi);
 		      	     }
				    else if (isSegment(i,vi))
				     {
	     			    segment = (Segment) v.elementAt(vi);
	    	    		if (segment.trim() == 0)
 		      	    	   v.removeElementAt(vi);
				     }
 		      	  }
 		      	if (v.size() == 0)
 		      	  container[i] = null;
 		      	else
 		      	   count += v.size();
 		      }
		  }
        return count;


    }


    /**
     * continues to parse an EDI Document after an error.
     * Searches through the containers until last one container to make a good
     * request is found.  If it is this container then we know we can restart parsing
     *
     * @param inContainer last container used.
     *
     * @param TransactionSetTokenizer  tokenizer hold transaction strings
     *
     * @return boolean - reparse started
     *
     * @exception OBOEException
     *                         thrown when the transaction id string is incorrect
     * @exception OBOEException
     *                         thrown when an unknown Segment id string is foundi
     */
    public boolean continueParse(SegmentContainer inContainer, ITokenizer TransactionSetTokenizer)
    throws OBOEException
    {

        if (inContainer == this)
          {
           if (parse(TransactionSetTokenizer) == true)
              return true;
          }
        boolean restartSucessful = false;

        for (int i = 0; i < getContainerSize(); i++)
        {
            if (isVector(i))
              {

                for (int j = 0; j < this.getSegmentCount(i); j++)
                  {
                    if (this.isLoop(i,j))
                      restartSucessful = getLoop(i, j).continueParse(inContainer, TransactionSetTokenizer);
                    if (restartSucessful)
                       {
                        //TransactionSetTokenizer.getNextDataElement();
                        parse(TransactionSetTokenizer);
                        return true;
                    }
                  }
              }
            else if (isLoop(i))
                          {
                restartSucessful = getLoop(i).continueParse(inContainer, TransactionSetTokenizer);
                if (restartSucessful)
                   {
                    parse(TransactionSetTokenizer);
                    return true;
                   }
              }

//            else if (isSegment(i))  ;
        }

        if (inContainer != this && restartSucessful == true)
          {
            return parse(TransactionSetTokenizer);
          }

        return  restartSucessful;
    }


    /**
     * validates if the contianer is defined correctly
     * @return boolean true if built correctly
     *  <br>Basic Edition always returns true
     *
     */

    public  boolean validate()
    {
        boolean validateResponse = true;
        return validateResponse;
    }

    /**
     * validates if the container is defined correctly
     * <br> doesn't throw exception, places error messages in DocumentErrors object
     * @return boolean true if built correctly
     *
     */

    public  boolean validate(DocumentErrors inDErr)
    {
        boolean validateResponse = true;
        Segment currentSegment;
        Loop currentLoop;
        for (int i=0; container != null && i < getContainerSize(); i++)
        {
            if (container[i] == null)
             {
              if (myTemplateLoopContainer.isSegment(i) && myTemplateLoopContainer.getTemplateSegment(i).getRequired() == 'M')
                 inDErr.addError(0, myTemplateLoopContainer.getTemplateSegment(i).getID(), "Required segment ("+myTemplateLoopContainer.getTemplateSegment(i).getName()+") missing", this, "3", this, 3);
              else if (myTemplateLoopContainer.isLoop(i) && myTemplateLoopContainer.getTemplateLoop(i).getRequired() == 'M')
                 inDErr.addError(0, myTemplateLoopContainer.getTemplateLoop(i).getID(), "Required segment/loop ("+myTemplateLoopContainer.getTemplateLoop(i).getName()+") missing", this, "3", this, 3);
              continue;
              }

            if (isSegment(i)) {
                currentSegment = (Segment) container[i];
                if (currentSegment.validate(inDErr) == false)
                validateResponse = false;
            }
            else if (isLoop(i)) {
                currentLoop = (Loop) container[i];
                if (currentLoop.validate(inDErr) == false)
                validateResponse = false;
            }
            else {
                Vector v = (Vector) container[i];
                if (myTemplateLoopContainer.isLoop(i))
                {
                    for (int j=0; j<v.size(); j++)
                       {
                        currentLoop = getLoop(i,j);
                        if (currentLoop.validate(inDErr) == false)
                          validateResponse = false;
                       }
                    continue;
                }
                else
                if (myTemplateLoopContainer.getTemplateSegment(i).getRequired() == 'M' &&
                   v.size() == 0)
                 {
                  inDErr.addError(0, myTemplateLoopContainer.getTemplateSegment(i).getID(), "Required segment missing", this, "3", this, 3);
                  continue;
                 }

                  for (int j=0; j<v.size(); j++) {
                      currentSegment = getSegment(i,j);
                      if (currentSegment.validate(inDErr) == false)
                      validateResponse = false;
                  }
              }
        }


        return validateResponse;
    }

    /**
     * sets the template loop container
     * @param inTLC
     */
    public void setTemplateLoopContainer(TemplateLoopContainer inTLC) {myTemplateLoopContainer = inTLC;
    }

/**
 * returns the template loop container
 * @return TemplateLoopContainer
 */
    public TemplateLoopContainer getTemplateLoopContainer() { return myTemplateLoopContainer; }

   

}
