/*
 * Copyright (C) 2006-2007 by Joseph McVerry - American Coders, Ltd.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

package org.pixes;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.StringTokenizer;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.xml.sax.Attributes;


/**
 * @author Joe McVerry - American Coders, Ltd.
 *
 * executor object to do a database select
 *
 */
public class Selecter  extends Executable  {

    static {Util.isLog4JNotConfigured();}
    /** string of unbounded field names */
     String fldnames;
     /** array of field names */
     String fields[];
     /** SQL table*/
     String table;
     /** SQL where clause */
     String where;
     /** SQL order by clause */
     String orderBy=null;
     /** the real executor of the code */
     SelectExecute sexec;

     /** debugging level*/
     Level dbgLvl;
     /** jdbc connecter */
     Connecter connecter;
     /** jdbc results */
     ResultSet rs;

	/**
	 * @param line - int xml line number
	 * @param attr - Attributes
	 * @param dbConnectObject - Connecter
	 * @param parser - Parser
	 * @throws PIXESException
	 */
	public Selecter(int line, Attributes attr, Connecter dbConnectObject, Parser parser)
			throws PIXESException {

	    super(parser);

        logr = Logger.getLogger(Selecter.class);
        setLogger();
		dbgLvl = prsr.logr.getLevel();
        logr.setLevel(dbgLvl);
		logr.debug("Selecter constructor "+line);
		setMyXMLLine(line);
		if (dbConnectObject == null)
		{
			throw new PIXESException("a connector must be defined before this select "+line);
		}
		connecter = dbConnectObject;
		fldnames = attr.getValue("fields");
		if (fldnames == null) {
			throw new PIXESException("no fields specified at line " + line);
		}
		StringTokenizer st = new StringTokenizer(fldnames, ",");
		fields = new String[st.countTokens()];
		for (int i = 0; i < fields.length; i++) {
			fields[i] = st.nextToken();
			logr.debug("created field element " + fields[i]);
		}
		table = attr.getValue("table");
		if (table == null) {
			throw new PIXESException("no table specified at line " + line);

		}

		logr.debug("table specified as " + table);
		where = attr.getValue("where");
		logr.debug("where specfied as " + where);
		orderBy = attr.getValue("orderBy");
		logr.debug("orderBy specfied as " + orderBy);


		sexec = new SelectExecute(this, prsr);

	}



	public int execute(Executor inExec) {
		exec = inExec;
		exec.logr.setLevel(dbgLvl);
		logr.setLevel(dbgLvl);
		logr.debug("executing");

		String sql;
		if (where == null)
		  sql = "select "+fldnames+" from "+table;
		else
			try {
				sql = "select "+fldnames+" from "+table+" where "+  exec.getVarStack().replaceString(where);
			} catch (Exception e1) {

				logr.error(e1.getMessage());
				return -1;
			}

		if (orderBy != null && orderBy.length() > 0)
				sql += " order by "+orderBy;

		logr.debug("executing "+sql);
		try {
		Statement stmt = connecter.getConnection().createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);;
		rs = stmt.executeQuery(sql);
		//PreparedStatement pst = connecter.getConnection().prepareStatement(sql);

		//rs = pst.executeQuery();
		if (fldnames.compareTo("*") == 0){
            rs.getMetaData().getColumnCount();
            fields = new String[rs.getMetaData().getColumnCount()];
            for (int i = 0; i < rs.getMetaData().getColumnCount(); i++){
            	fields[i]=rs.getMetaData().getColumnName(i+1);
            }
		}
		}
		catch (SQLException e){
			logr.error(e.getMessage(), e);
			return -1;
		}

		return this.getNextStep();

	}
	/**used to test the code outside the scope of the parsexecutor
	 * @param string
	 * @param string2
	 * @param string3
	 * @throws PIXESException
	 */
	public Selecter(String string, Connecter connecter,  String string2, String string3, String string4, Parser pr) throws PIXESException {

		super(null);
		prsr = pr;
		dbgLvl = Level.DEBUG;
		logr.debug("Selecter test constructor");
		fldnames = string;
		if (connecter == null)
		{
			throw new PIXESException("a connector must be defined before this select " );
		}
		this.connecter = connecter;
		if (fldnames == null)
		{
			throw new PIXESException("no fields specified at line ");
		}
		StringTokenizer st = new StringTokenizer(fldnames, ",");
		fields = new String[st.countTokens()];
		for (int i=0;i<fields.length;i++){
			fields[i] = st.nextToken();
			logr.debug("created field element "+fields[i]);
		}
		table = string2;
		if (table == null)
		{
			throw new PIXESException("no table specified at line ");


		}
		//vars = new Hashtable();
		logr.debug("table specified as "+table);
		where = string3;
		logr.debug("where specfied as "+where);
		orderBy = string3;
		logr.debug("orderBy specfied as "+orderBy);



		sexec = new SelectExecute(this, null);

	}


	/**
	 * returns the array of fields
	 * @return a string array
	 */
	public String[] getFields() {
		return fields;
	}
	/**
	 * get the object doing the real work
	 * @return SelectExecute
	 */
	public SelectExecute getSexec() {
		return sexec;
	}
	/** return the sql table name
	 *
	 * @return String
	 */
	public String getTable() {
		return table;
	}


	/** return the jdbc result set
	 *
	 * @return Result set
	 */
	public ResultSet getRs() {
		return rs;
	}

	/** at end where do we go
	 *
	 * @return the next step to continue at
	 */
	public int getContinueStep() {
		return sexec.getContinueStep();
	}


	/**
	 * class that does the real work
	 * this step logic is added right after the select step and is
	 * called for loop processing so the selection jdbc code is not reexecuted
	 * @author joseph mcverry
	 *
	 */
	public static class SelectExecute extends Executable implements IContinuable{
	    Logger logr;
	    Selecter mySelecter;

	    int continueStep = -1;
	    Parser prsr;

	    public SelectExecute(Selecter selecter, Parser parser) {
	    	super(parser);
	     	logr = Logger.getLogger(Selecter.class);
	    	Util.isLog4JNotConfigured();
	        logr.debug("selecter constructor");
	        mySelecter = selecter;
	        prsr = parser;
	        setMyXMLLine(selecter.getMyXMLLine());
	    }



		public int getContinueStep() {
			return continueStep;
		}
		public void setContinueStep(int continueStep) {
			this.continueStep = continueStep;
		}
		public int execute(Executor inExec) {

			ResultSet rs = mySelecter.getRs();
			String flds[] = mySelecter.getFields();
			String data;


			try {

				if (rs == null) // no rows to get
				{
					logr.info("no rows to get");
					return getNextStep();
				}

				if (rs.next())
				{

					for (int i = 0; i < flds.length; i++) {
					  data=	rs.getString(i+1);
					  if (data==null)
						  inExec.getVarStack().put(flds[i], "null");
					  else
						  inExec.getVarStack().put(flds[i], data);
					}
					return continueStep;
				}
			} catch (SQLException e) {

				logr.error(e.getMessage(),
						         e);
				return -1;
			}


			return getNextStep();


		}

	}



}