/*
 * Copyright (C) 2006-2007 by Joseph McVerry - American Coders, Ltd.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */



package org.pixes;
import java.io.CharArrayWriter;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintStream;
import java.util.Hashtable;
import java.util.Stack;
import java.util.Vector;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.xml.sax.Attributes;
import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import org.xml.sax.ext.LexicalHandler;
import org.xml.sax.helpers.DefaultHandler;

/**
 * @author Joe McVerry - American Coders, Ltd.
 *
 * the main class of pixes, contains a static main to call from command line. uses one
 * required argument which is the xml file to parse and execute. and an optional argument
 * -P which you use to specify a secondary properties file, which allows the pixes process
 * to access the properties in the file.
 *
 */


public class Parser extends DefaultHandler implements  LexicalHandler, XMLParsexecutor, ContentHandler
 {

	
    Logger logr = Logger.getLogger(Parser.class);
    {
        Util.isLog4JNotConfigured();
    }

    AtEndLogic atEndObject;

    Computer computerObject;
    
    org.pixes.BufferedFile fileObject;

    For forObject;

    IfLogic ifObject;

    Connecter dbConnectObject;

    Selecter selectObject;

    Inserter insertObject;

    Deleter deleteObject;

    Updater updateObject;

    Setter setObject;

    TestLogic testObject;

    XMLObjectExecutor xmlObject;

    Subroutine subroutineObject = null;
    
    Reader readObject = null;
    Writer writeObject = null;

 
    /** last step in array */
    int executorMax = 25;

    /** xml file line number */
    int _iLine = 1;

    /** array of executable objects */
    Executable executorArray[] =	new Executable[executorMax];

    /** did any object find something wrong with their attributes or position in file */
    Boolean parsingErrors = Boolean.valueOf(false);

    /** xml parser */
    SAXParser parser;

    protected CharArrayWriter contents = new CharArrayWriter();

    
    /** repeatable objects must be stacked */
    Stack continueObjects = new Stack();

    Stack logLevelStack = new Stack();

    Stack selectStack = new Stack();

    Stack forStack = new Stack();
    
    Stack fileStack = new Stack();
    
    Stack ifStack = new Stack();

    Hashtable xmlObjTable = new Hashtable();
    
    Stack xmlObjStack = new Stack();
    
    
    /** level of xmlness */
    int level = 0;
    
    /** start here*/
    String rootElement="";

 

    /** default output to System.out unless otherwise told to put it somewhere else */
    private PrintStream processOut = System.out;

    
    /** list of addons */
    Vector xmlProcessors = new Vector();

 
    /** add-ons must track this */
    boolean thisIsASubroutine = false;

    /** are we just testing the xml file, does it pass the parse test? */
    boolean testToo = false;

    /** set up varStack */
    VarStack vstack;

    public static void main(String[] args) {
    	if (args.length < 1) {
        System.out.println("PIXES version 1.0.7,\n"+
        "Copyright � 2006-2007 Joseph McVerry - American Coders Ltd Raleigh NC (USA) \n"+
        "PIXES comes with ABSOLUTELY NO WARRANTY; This is free software, and you are welcome to redistribute it under certain conditions;\n" +
        "\nPackages require one argument - the xml file to execute");
        return;
    	}
        Logger logr = Logger.getLogger(Parser.class);
        
        Parser p;
        try {
            p = new Parser();
        } catch (IOException e) {
            logr.error(e.getMessage(), e);
            return;
        }
        

        try {
            p.parse(new InputSource(new FileReader(args[0])));
            
        } catch (FileNotFoundException e1) {
            logr.error(e1.getMessage(), e1);
            return;
        } catch (SAXException e1) {
            logr.error(e1.getMessage(), e1);
            return;
        } catch (IOException e1) {
            logr.error(e1.getMessage(), e1);
            return;
        }
        
    }

    
    /** locators are for remembering line numbers */
    private Locator locator = null;

    
    /** locators are for remembering line numbers 
     * @param locator
     */
	public void setDocumentLocator(Locator locator) {
		this.locator = locator;
	}

	
	/** store the xml file line number */
	private void reportPosition() {

		if (locator != null) 
			_iLine = locator.getLineNumber();
		

	}
   
    
    /**
     * @throws IOException
     *
     */
    public Parser() throws IOException {
    	
        SAXParserFactory spf = SAXParserFactory.newInstance();

        setDocumentLocator(locator);

        try {
            parser = spf.newSAXParser();

            parser.getXMLReader().setProperty(
                    "http://xml.org/sax/properties/lexical-handler", this);

        } catch (ParserConfigurationException e) {

            logr.error(e.getMessage(), e);
        } catch (SAXException e) {

            logr.error(e.getMessage(), e);
        }
       
        vstack = new VarStack();

        vstack.loadProperties("PIXES.properties");

    }

 
    /**
     * sax code
     * @param is
     * @throws SAXException
     * @throws IOException
     */
    public void parse(InputSource is) throws SAXException, IOException {
         parser.parse(is, this);
    }
    /**
     * sax code
     */
    public boolean start(String arg0, String arg1, String name,
            Attributes attributes) throws SAXException {reportPosition();return false;}

    
    int executorCnt = -1;
    /**
     * sax code
     * 
     */
    public void startElement(String arg0, String arg1, String name,
            Attributes attributes) throws SAXException {

    	reportPosition();
        logr.debug("line " + _iLine + " name = " + name +" arg0 = " + arg0 + " arg1= " + arg1 + " arg2= "
                + name + " 3= " +attributes);
        
        if (executorCnt == -1) {
            if (name.compareTo("process") == 0)
                executorCnt = 0;
            else if (name.compareTo("subroutine") == 0) {
                executorCnt = 0;
                thisIsASubroutine = true;
            } else {
                logr.error("first valid processing tag must be process");
                parsingErrors = Boolean.valueOf(true);
            }

        } else if (name.compareTo("process") == 0) {
            logr.error("process tag required to be first tag ");
            parsingErrors = Boolean.valueOf(true);
        }


        if (nextMustBeIFClose) {
            logr.error("closing else tag must be followed by a closing if tag see line "+_iLine);
            parsingErrors = Boolean.valueOf(true);
            nextMustBeIFClose = false;
        }

        displayContents();

        int i;
        for (i=0; i<xmlProcessors.size();i++){
            XMLParsexecutor xp = (XMLParsexecutor) xmlProcessors.get(i);
            if (xp.start( arg0,  arg1,  name, attributes) == true)
                return;
        }


        if (name.compareTo("atEnd") == 0) {
            if (continueObjects.isEmpty()) {
                logr.error("atEnd statement is not within a looping structure. see line "
                                + _iLine);
                return;

            }

            IContinuable ic = (IContinuable)continueObjects.peek();
        	GoTo gt = new GoTo(_iLine, "");
        	addToExecuteArray(gt);
        	gt.setNextStep(ic.getNextStep()-1);

            ic.setContinueStep(executorCnt);

            atEndObject = new AtEndLogic(_iLine, this,
                    (IContinuable) continueObjects.peek());
            addToExecuteArray(atEndObject);


        } else if (name.compareTo("break") == 0) {
            if (continueObjects.isEmpty()) {
                parsingErrors = Boolean.valueOf(true);
                logr.error("break statement is not within a looping structure see line "
                                + _iLine);
                return;
            }
            ChangeStep csObject = new ChangeStep(_iLine,
                    (IContinuable) continueObjects.peek(), true);
            addToExecuteArray(csObject);
        } else if (name.compareTo("commit") == 0) {
            Commit commitObject = new Commit(_iLine, dbConnectObject, this);
            addToExecuteArray(commitObject);
        } else if (name.compareTo("compute") == 0) {
            try {
                computerObject = new Computer(_iLine,attributes, this);
            } catch (Exception e) {

                logr.error(e.getMessage());
                parsingErrors = Boolean.valueOf(true);
            }
            addToExecuteArray(computerObject);

        } else if (name.compareTo("connect") == 0) {
            dbConnectObject = new Connecter(_iLine,attributes, this);
            addToExecuteArray(dbConnectObject);
        } else if (name.compareTo("continue") == 0) {
            if (continueObjects.isEmpty()) {
                parsingErrors = Boolean.valueOf(true);
                logr.error("continue statement is not within a looping structure. see line "
                                + _iLine);
                return;
            }
            ChangeStep csObject = new ChangeStep(_iLine,
                    (IContinuable) continueObjects.peek(), false);
            addToExecuteArray(csObject);
            csObject.setErrorStep(-1);
        } else if (name.compareTo("delete") == 0) {
            try {
                deleteObject = new Deleter(_iLine,attributes, dbConnectObject, this);
            } catch (Exception e) {
                parsingErrors = Boolean.valueOf(true);
                logr.error(e.getMessage());
                return;
            }

            addToExecuteArray(deleteObject);

        } else if (name.compareTo("dumpVariables") == 0) {
            DumpVariables dv = new DumpVariables(_iLine, this);
            addToExecuteArray(dv);
        } else if (name.compareTo("else") == 0) {
        	
            if (ifObject == null){
            	logr.error("else tag not associated with an if tag see line "+_iLine);
            	parsingErrors = Boolean.valueOf(true);
            	return;
            }
            
            GoTo gt = new GoTo(_iLine, "else");
            addToExecuteArray(gt);
            ifObject.setElse(gt);
            ifObject.setNextStep(executorCnt);
            
            
        } else if (name.compareTo("exit") == 0) {
            GoTo gotoObject = new GoTo(_iLine, name);
            addToExecuteArray(gotoObject);
            gotoObject.setNextStep(-100);
        } else if (name.compareTo("file") == 0) {
			try {
				fileObject = new org.pixes.BufferedFile(_iLine, attributes, this);
			} catch (Exception e) {
				parsingErrors = Boolean.valueOf(true);
				logr.error(e.getMessage());
				return;
			}
            addToExecuteArray(fileObject);
            fileStack.push(fileObject);
        } else if (name.compareTo("for") == 0) {
            try {
                forObject = new For(_iLine, attributes, this);

                addToExecuteArray(forObject);
                forObject.setWithinLine(executorCnt);

                addToExecuteArray(forObject.getFexec());
                forObject.getFexec().setContinueStep(executorCnt);
                continueObjects.push(forObject.getFexec());
                forStack.push(forObject);
            } catch (Exception e) {
                parsingErrors = Boolean.valueOf(true);
                logr.error(e.getMessage());
                return;
            }
        } else if (name.compareTo("if") == 0) {
            try {
                ifObject = new IfLogic(_iLine,attributes, this);
                addToExecuteArray(ifObject);
                ifObject.setNextStep(-1);// reset, it will be set again by else or /if terminator
                ifObject.setWithinLine(executorCnt);
                ifStack.push(ifObject);
                nextMustBeIFClose = false;
            } catch (Exception e) {
                parsingErrors = Boolean.valueOf(true);
                logr.error(e.getMessage());
                return;
            }
        } else if (name.compareTo("insert") == 0) {
            try {
                insertObject = new Inserter(_iLine,attributes, dbConnectObject, this);
            } catch (Exception e) {
                parsingErrors = Boolean.valueOf(true);
                logr.error(e.getMessage());
                return;
            }

            addToExecuteArray(insertObject);

        } else if (name.compareTo("log") == 0) {

            String lvl =attributes.getValue("level");
            if (lvl == null) {
                logr.error("log attribute level not set");
                parsingErrors = Boolean.valueOf(true);

            } else if (lvl.compareTo("ERROR") == 0)
                logr.setLevel(Level.ERROR);
            else if (lvl.compareTo("ALL") == 0)
                logr.setLevel(Level.ALL);
            else if (lvl.compareTo("FATAL") == 0)
                logr.setLevel(Level.FATAL);
            else if (lvl.compareTo("INFO") == 0)
                logr.setLevel(Level.INFO);
            else if (lvl.compareTo("OFF") == 0)
                logr.setLevel(Level.OFF);
            else if (lvl.compareTo("WARN") == 0)
                logr.setLevel(Level.WARN);
            else if (lvl.compareTo("DEBUG") == 0)
                logr.setLevel(Level.DEBUG);
            else {
                logr.error("log attribute level not set correctly");
                logr.error("use ERROR | ALL | FATAL | INFO | OFF| WARN | DEBUG");
                parsingErrors = Boolean.valueOf(true);

            }

            logLevelStack.add(logr.getLevel());

        } else if (name.compareTo("process") == 0) {

        	if (thisIsASubroutine)
        	{
        		if (attributes.getLength() > 0)
        		{
        			logr.error("subroutine process tag uses no arguments");
        			parsingErrors = Boolean.valueOf(true);
        			return;
        		}
        		return;
        	}

            String processFile = attributes.getValue("outfile");
            if (processFile != null)
			try {
	            PrintStream ps;
				ps = new PrintStream(new FileOutputStream(processFile));
	            processOut = ps;
			} catch (FileNotFoundException e) {
				logr.error(e.getMessage(), e);
				e.printStackTrace();
			}

        } else if (name.compareTo("read") == 0) {
            try {
                readObject = new Reader(_iLine,attributes, this);
            } catch (Exception e) {
                parsingErrors = Boolean.valueOf(true);
                logr.error(e.getMessage());
                return;
            }

            addToExecuteArray(readObject);
            continueObjects.push(readObject);

        } else if (name.compareTo("rollback") == 0) {
            Rollback rollbackObject = new Rollback(_iLine, dbConnectObject);
            addToExecuteArray(rollbackObject);
        }else if (name.compareTo("select") == 0) {
            try {
                selectObject = new Selecter(_iLine,attributes, dbConnectObject, this);
                addToExecuteArray(selectObject);

                addToExecuteArray(selectObject.getSexec());
                selectObject.getSexec().setContinueStep(executorCnt);
                continueObjects.push(selectObject.getSexec());
                selectStack.push(selectObject);
            } catch (Exception e) {
                parsingErrors = Boolean.valueOf(true);
                logr.error(e.getMessage());
                return;
            }
        } else if (name.compareTo("set") == 0) {
            
            try {
                setObject = new Setter(_iLine, attributes, this);
            } catch (Exception e) {
                logr.debug(e.getMessage(), e);
                parsingErrors = Boolean.valueOf(true);
                return;
            }

            addToExecuteArray(setObject);

        } else if (name.compareTo("subroutine") == 0) {
        	try {
        	subroutineObject = new Subroutine(_iLine, attributes, this);
            } catch (Exception e) {
                logr.error(e.getMessage(), e);
                parsingErrors = Boolean.valueOf(true);
                return;
            }
            addToExecuteArray(subroutineObject);

        } else if (name.compareTo("test") == 0) {
        	if (testToo == false)
        	{
        		logr.debug("testing not turned on, so test object not used");
        		return;
        	}
        	try {
        	testObject = new TestLogic(_iLine, attributes, this);
            } catch (Exception e) {
                logr.error(e.getMessage(), e);
                parsingErrors = Boolean.valueOf(true);
                return;
            }
            addToExecuteArray(testObject);

        } else if (name.compareTo("update") == 0) {
            try {
                updateObject = new Updater(_iLine,attributes, dbConnectObject, this);
            } catch (Exception e) {
                parsingErrors = Boolean.valueOf(true);
                logr.error(e.getMessage());
                return;
            }

            addToExecuteArray(updateObject);

        } else if (name.compareTo("write") == 0) {
            try {
                writeObject = new Writer(_iLine,attributes, this);
            } catch (Exception e) {
                parsingErrors = Boolean.valueOf(true);
                logr.error(e.getMessage());
                return;
            }

            addToExecuteArray(writeObject);

        } else if (name.compareTo("xmlProcessor") == 0) {
            
            

               String cn =attributes.getValue("className");
               try {
                XMLParsexecutor px = (XMLParsexecutor)Class.forName(cn).newInstance();
                xmlProcessors.add(px);
                px.setParsexecutor(this);
                px.setAttributes(attributes);

            } catch (ClassNotFoundException e) {
                parsingErrors = Boolean.valueOf(true);
                logr.error(e.getMessage(),e);
                return;
            } catch (InstantiationException e) {
                parsingErrors = Boolean.valueOf(true);
                logr.error(e.getMessage(),e);
            } catch (IllegalAccessException e) {
                parsingErrors = Boolean.valueOf(true);
                logr.error(e.getMessage(),e);
            }


        } else {

            if (rootElement.length()>0 &&level == 0){
                logr.error("no element defined as \""+rootElement+"\" \nThe markup in the document following the root element must be well-formed. see line "
                        + get_iLine());
                setParsingErrors(Boolean.valueOf(true));
                }
            logr.warn("xml node \""+name+"\" not found to execute, it will be added as an output type.");
            rootElement = name;
            int xi;
            StringBuffer sb = new StringBuffer();
            for (xi =0; xi<xmlObjStack.size();xi++)
              sb.append(((XMLObjectExecutor) (xmlObjStack.get(xi))).name+'_');

            sb.append(name);
            xmlObject = new XMLObjectExecutor(name, sb.toString(), level, attributes, this);
            level++;
            xmlObjTable.put(sb.toString(), xmlObject);
            xmlObjStack.push(xmlObject);
            addToExecuteArray(xmlObject);

            getContinueObjects().push(xmlObject);

            xmlObject.setContinueStep(getExecutorCnt());


        }



    }

    
    /**
     * sax code
     */
    public void characters(char[] chars, int start, int length)
            throws SAXException {
    	reportPosition();
        contents.write(chars, start, length);
        if (displayLine == -1)
        	displayLine = _iLine;
        for (int i = start; i < start + length; i++) {

            if (chars[i] == '\n')
                _iLine++;
        }

    }

    /**
     * sax code
     */
    
    public void ignorableWhitespace(char[] chars, int start, int length)
            throws SAXException {
    	reportPosition();
        for (int i = start; i < start + length; i++) {
            if (chars[i] == '\n')
                _iLine++;
        }
    }
    

    /**
     * sax code
     */
    public boolean end(String arg0, String name, String arg2)
    throws SAXException {
    	reportPosition();
        return false;
        }

    int displayLine = -1;
    
    /** 
     * sax code
     *
     */
    public void displayContents()
    {

    
    	String str = contents.toString().trim();
        if (str.length() > 0) {
            Display d = new Display(displayLine, str, this);
            addToExecuteArray(d);

        }
        displayLine = -1;    
        contents.reset();



    }
    
    /**
     * can't add an else if there is no if
     */
    boolean nextMustBeIFClose = false;
    
    
    /**
     * sax code
     */
    public void endElement(String arg0, String name, String arg2)
            throws SAXException {
    	
        logr.debug("end 0= " + arg0 + " 1= " + name + " 2= " + arg2);
        
 
        int i;
        for (i=0; i<xmlProcessors.size();i++){
            XMLParsexecutor xp = (XMLParsexecutor) xmlProcessors.get(i);
            if (xp.end( arg0,  name,  arg2) == true)
                return;
        }
        
        
        if (arg2.compareTo("atEnd") == 0) {
        	
            displayContents();
          atEndObject.setOutsideStep(executorCnt);
        }    
        else if (arg2.compareTo("break") == 0) {
            displayContents();
        	
        } else if (arg2.compareTo("commit") == 0) {
            displayContents();
        	
        } else if (arg2.compareTo("connect") == 0) {
            displayContents();
        	
        } else if (arg2.compareTo("compute") == 0) {

            try {
            	String s = contents.toString();
            	contents.reset();
                computerObject.setContents(s);
            } catch (Exception e) {
                logr.error(e.getMessage());
                parsingErrors = Boolean.valueOf(true);
            }

        } else if (arg2.compareTo("continue") == 0) {
            displayContents();
        	
        } else if (arg2.compareTo("delete") == 0) {
            displayContents();
        	
        } else if (arg2.compareTo("dumpVariables") == 0) {
            displayContents();
        	
        } else if (arg2.compareTo("else") == 0) {
            displayContents();
        	
        	ifObject.getElse().setNextStep(executorCnt);
        	nextMustBeIFClose = true;
        } else if (arg2.compareTo("exit") == 0) {
            displayContents();
        	
        } else if (arg2.compareTo("file") == 0) {
            displayContents();
        	
        	fileStack.pop();
        	if (fileStack.isEmpty())
        		fileObject = null;
        	else fileObject = (org.pixes.BufferedFile) fileStack.peek();
 
        } else if (arg2.compareTo("for") == 0) {
            displayContents();
        	
            GoTo goTo = new GoTo(_iLine-1, "for");
            addToExecuteArray(goTo);
            goTo.setNextStep(forObject.getNextStep());
            forObject.getFexec().setNextStep(executorCnt);
            continueObjects.pop();
            forStack.pop();
            if (forStack.isEmpty())
            	forObject = null;
            else
                forObject = (For) forStack.peek();
        } else if (arg2.compareTo("if") == 0) {
            displayContents();
            if (parsingErrors.booleanValue() == false)
             if (ifObject.getNextStep() == -1)
                ifObject.setNextStep(executorCnt);
        	
           	ifStack.pop();
        	if (ifStack.isEmpty())
        		ifObject = null;
        	else
        		ifObject = (IfLogic) ifStack.peek();
        	nextMustBeIFClose = false;
        } else if (arg2.compareTo("insert") == 0) {
            displayContents();
        	
        } else if (arg2.compareTo("leave") == 0) {
            displayContents();
        	
        } else if (arg2.compareTo("log") == 0) {
            displayContents();
        	
            logLevelStack.pop();
            if (logLevelStack.isEmpty() == false)
                logr.setLevel((Level) logLevelStack.peek());
        } else if (arg2.compareTo("process") == 0) {
            displayContents();
        	
        } else if (arg2.compareTo("read") == 0) {
            displayContents();
        	if (readObject.getContinueStep() == -1) {
        		GoTo gt = new GoTo(_iLine-1, "read");
        		addToExecuteArray(gt);
        		gt.setNextStep(readObject.getNextStep()-1);
        	}

        	readObject.setContinueStep(executorCnt);
        	continueObjects.pop();
        	

        } else if (arg2.compareTo("rollback") == 0) {
            displayContents();
            
        } else if (arg2.compareTo("select") == 0) {
        	
            displayContents();
            GoTo goTo = new GoTo(_iLine-1, "select");
            addToExecuteArray(goTo);
            goTo.setNextStep(selectObject.getNextStep());
            selectObject.getSexec().setNextStep(executorCnt);
            continueObjects.pop();
            selectStack.pop();
            if (selectStack.isEmpty())
            	selectObject = null;
            else
                selectObject = (Selecter) selectStack.peek();
        } else if (arg2.compareTo("set") == 0) {

            try {
            	String s = contents.toString();
            	contents.reset();
                setObject.setContents(s);
            } catch (Exception e) {
                logr.error(e.getMessage());
                parsingErrors = Boolean.valueOf(true);
            }

            

        } else if (arg2.compareTo("subroutine") == 0) {

        	
            displayContents();

        } else if (arg2.compareTo("test") == 0) {

            displayContents();
        	

        } else if (arg2.compareTo("update") == 0) {
            displayContents();
        	
        } else if (arg2.compareTo("write") == 0) {
            displayContents();
        	
        } else if (arg2.compareTo("xmlProcessor") == 0) {
            displayContents();
        	

        }
        else {
        	String s = contents.toString();
        	contents.reset();

          xmlObject.setContents(s);
          level--;
          getContinueObjects().pop();

          GoTo goTo = new GoTo(_iLine-1, "an xml tag is here");
          addToExecuteArray(goTo);

          goTo.setNextStep(xmlObject.getNextStep()-1);

          xmlObject.setContinueStep(getExecutorCnt());

          xmlObjStack.pop();
          if (xmlObjStack.isEmpty())
              xmlObject = null;
          else
              xmlObject = (XMLObjectExecutor)xmlObjStack.peek();


        }

    }

    /** add the
     * execturor object to the array, if array is too small make it bigger
     */
    public void addToExecuteArray(Executable e) {
        executorCnt++;
        if (executorCnt == executorMax) {
            logr.debug("increasing size of array ");
            Executable temp[] = new Executable[executorMax * 2];
            System.arraycopy(this.executorArray, 0, temp, 0, executorMax);
            executorMax *= 2;
            executorArray = temp;

        }
        e.setNextStep(executorCnt);
        executorArray[executorCnt - 1] = e;

    }



    /** 
     * sax code
     */
    public void error(SAXParseException arg0) throws SAXException {
        super.error(arg0);
    }

    /** 
     * sax code
     */
    public void warning(SAXParseException arg0) throws SAXException {
        super.warning(arg0);
    }

    /** 
     * sax code
     */
    public void fatalError(SAXParseException arg0) throws SAXException {
        super.fatalError(arg0);
    }



    /* (non-Javadoc)
     * @see org.xml.sax.ext.LexicalHandler#startDTD(java.lang.String, java.lang.String, java.lang.String)
     */
    public void startDTD(String arg0, String name, String arg2)
            throws SAXException {
        //

    }

    /* (non-Javadoc)
     * @see org.xml.sax.ext.LexicalHandler#endDTD()
     */
    public void endDTD() throws SAXException {
        //

    }

    /* (non-Javadoc)
     * @see org.xml.sax.ext.LexicalHandler#startEntity(java.lang.String)
     */
    public void startEntity(String arg0) throws SAXException {
        //

    }

    /* (non-Javadoc)
     * @see org.xml.sax.ext.LexicalHandler#endEntity(java.lang.String)
     */
    public void endEntity(String arg0) throws SAXException {
        //

    }

    /* (non-Javadoc)
     * @see org.xml.sax.ext.LexicalHandler#startCDATA()
     */
    public void startCDATA() throws SAXException {
        //

    }

    /* (non-Javadoc)
     * @see org.xml.sax.ext.LexicalHandler#endCDATA()
     */
    public void endCDATA() throws SAXException {
        //

    }

    /* (non-Javadoc)
     * @see org.xml.sax.ext.LexicalHandler#comment(char[], int, int)
     */
    public void comment(char[] chars, int start, int length)
            throws SAXException {

        for (int i = start; i < start + length; i++)
            if (chars[i] == '\n')
                _iLine++;
    }


    public int get_iLine() {
        return _iLine;
    }
    public void set_iLine(int line) {
        _iLine = line;
    }
    public Connecter getDbConnectObject() {
        return dbConnectObject;
    }
    public void setDbConnectObject(Connecter dbConnectObject) {
        this.dbConnectObject = dbConnectObject;
    }

    public Stack getLogLevelStack() {
        return logLevelStack;
    }
    public void setLogLevelStack(Stack logLevelStack) {
        this.logLevelStack = logLevelStack;
    }
    public Logger getLogger() {
        return logr;
    }
    public void setLogger(Logger logr) {
        this.logr = logr;
    }
    public Boolean getParsingErrors() {
        return parsingErrors;
    }
    public void setParsingErrors(Boolean parsingErrors) {
        this.parsingErrors = parsingErrors;
    }
    public CharArrayWriter getContents() {
        return contents;
    }
    public void setContents(CharArrayWriter contents) {
        this.contents = contents;
    }
    public int getExecutorCnt() {
        return executorCnt;
    }
    public void setExecutorCnt(int executorCnt) {
        this.executorCnt = executorCnt;
    }
    public Stack getContinueObjects() {
        return continueObjects;
    }
 
    /* (non-Javadoc)
     * @see org.pixes.XMLParsexecutor#setParsexecutor(org.pixes.Parser)
     */
    public void setParsexecutor(Parser inPx) {
        logr.error("don't use this method with this class");
        System.exit(0);


    }


    /** 
     * where is output going
     * @return print stream, could be System.out if it wasn't changed
     */
    public PrintStream getOutProcessFile() {
        return processOut;
    }



	public PrintStream getProcessOutStream() {

		return processOut;
	}


	protected void setThisIsASubroutine(boolean thisIsASubroutine) {
		this.thisIsASubroutine = thisIsASubroutine;
	}

	public void setAttributes(Attributes arg3) {
		// the main parsexecutor doesn't need this method 
		
	}

	
    public org.pixes.BufferedFile getFile(String refid){
    	if (refid == null || refid.length() == 0)
    		return fileObject;
    	
    	
    	for (int i=0; i < fileStack.size(); i++)
    	{
    	   org.pixes.BufferedFile f = (org.pixes.BufferedFile) fileStack.get(i);
    	   if (f.getID().compareTo(refid) == 0)
    		   return f;
    	}
    	
    	return null;
    }


	/* (non-Javadoc)
	 * @see org.pixes.XMLParsexecutor#setup()
	 */
	public void setup() {
		// TODO Auto-generated method stub
		
	}


	/* (non-Javadoc)
	 * @see org.pixes.XMLParsexecutor#shutdown()
	 */
	public void shutdown() {
		// TODO Auto-generated method stub
		
	}


	public Executable[] getExecutorArray() {
		return executorArray;
	}


	public VarStack getVarStack() {
		return vstack;
	}



}
