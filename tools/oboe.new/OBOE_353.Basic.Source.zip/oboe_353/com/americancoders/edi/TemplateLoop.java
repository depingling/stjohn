package com.americancoders.edi;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.lang.reflect.Method;
import java.util.Vector;

import org.apache.log4j.Logger;

import com.americancoders.util.Util;


/**
 * class for Template Loops
 * a general class for the segment loops.
 *
 *<p>OBOE - Open Business Objects for EDI
 *<p>Part of the OBOE Basic Extended Package
 *<br>An EDI and XML Translator Written In Java
 *<br>Copyright 1998-2007 - American Coders, LTD  - Raleigh NC USA
 *<br>All rights reserved
 *<br>American Coders, Ltd
 *<br>P. O. Box 97462
 *<br>Raleigh, NC  27624  USA
 *<br>1-919-846-2014
 *<br>http://www.americancoders.com
@author Joe McVerry - American Coders, Ltd.
  @version   3.5.3
 */
public class TemplateLoop
	extends TemplateLoopContainer
	implements IContainedObject, Externalizable {
	

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/** String id
	 */
	protected String id = "";
	/** String name
	 */
	protected String name = "";
	/** how many times it can occur
	 */
	protected int occurs;
	/** required indicator
	 */
	protected char required;
	/** String XML tag
	 */
	protected String xmlTag = "";
	
	
	
	static  Logger logr = Logger.getLogger(TemplateLoop.class);
	static 	{Util.isLog4JNotConfigured();}


	
	public boolean isUsed() {
		return used;
	}
	public void setUsed(boolean used) {
		this.used = used;
	}
    protected boolean used = true;
    
	/** constructor takes no parameters
	 */
	public TemplateLoop() {
		setID("");
		setXMLTag("Unknown");
	}

	/** Constructor
	 * @param inID loop id
	 * @param inName loop name
	 * @param inOccurs int occursance count
	 * @param inRequired char required indicator
	 * @param xmlTag String XML tag
	 * @param inUsed boolean
	 * @param inParent IContainedObject parent container
	 */
	public TemplateLoop(String inID, String inName, int inOccurs,
			char inRequired, String xmlTag, boolean inUsed,
			IContainedObject inParent) {
		setID(inID);
		setName(inName);
		setOccurs(inOccurs);
		setRequired(inRequired);
		setXMLTag(xmlTag);
		used = inUsed;
		this.setParent(inParent);
	}

	/**
	 * sets the id
	 * 
	 * @param inID
	 *            String id
	 */

	public void setID(String inID) {
		id = inID;
	}

	/** returns the Loop id
	 * @return String
	 */
	public String getID() {
		return id;
	}

	/** sets the name
	 * @param inName String name
	 */

	public void setName(String inName) {
		name = inName;
	}

	/** returns the Loop name
	 * @return String
	 */
	public String getName() {
		return name;
	}

	/** sets occurance value
	 * @param inOccurs int
	 */
	public void setOccurs(int inOccurs) {
		occurs = inOccurs;
	}

	/**
	 * gets occurance value
	 * @return int occurs
	 */
	public int getOccurs() {
		return occurs;
	}
	/** sets required value
	 * @param inRequired char
	 */
	public void setRequired(char inRequired) {
		required = inRequired;
	}

	/**
	 * gets required flag
	 * @return char required
	 */
	public char getRequired() {
		return required;
	}

	/** sets the xml tag field
	 * @param inXMLTag String tag
	 */

	public void setXMLTag(String inXMLTag) {
		xmlTag = inXMLTag;
	}

	/**
	 * returns the xml tag field
	 * @return String tag value
	 */

	public String getXMLTag() {
		return xmlTag;
	}

	/** used by externalize methods
	 * @param in ObjectInput stream
	 * @exception IOException - most likely class changed since written
	 * @exception ClassNotFoundException - only when dummy constructro not found
	 */

	public void readExternal(ObjectInput in)
		throws IOException, ClassNotFoundException {
		id = in.readUTF();
		name = in.readUTF();
		setOccurs(in.readInt());
		setRequired(in.readChar());
		used = in.readBoolean();
		xmlTag = in.readUTF();
		templateContainer = (Vector) in.readObject();
		for (int i = 0; i < getCount(); i++)
			((IContainedObject) templateContainer.elementAt(i)).setParent(this);
	}

	/** used by externalize methods
	 * @param out ObjectOutput stream
	 * @exception IOException java.io error
	 */
	public void writeExternal(ObjectOutput out) throws IOException {
		out.writeUTF(id);
		out.writeUTF(name);
		out.writeInt(getOccurs());
		out.writeChar(getRequired());
		out.writeBoolean(used);
		out.writeUTF(xmlTag);
		out.writeObject(templateContainer);

	}

	protected IContainedObject parent = null;
	/** sets parent attribute
	 * @param inParent TemplateSegmentContainer
	 */
	public void setParent(IContainedObject inParent) {
		parent = inParent;
	}

	/** gets parent attribute
	 * @return TemplateSegmentContainer
	 */
	public IContainedObject getParent() {
		return parent;
	}

	/** returns true if the template loop can prevalidate an incoming
	    edi transaction segment.  If yes then this segment is the
	    first segment for this loop. It actually defines the loop.
	    <br> implemented for HIPAA
	    <ul> prevalidation requirement
	      <li> the first segment contains at least one mandatory ID field
	    </ul>
	    @return boolean
	    */

	public boolean canYouPrevalidate() {
    	if (Util.propertyFileIndicatesDoPrevalidate() == false)
    		return false;

		return getTemplateSegment(0).canYouPrevalidate();
	}

	/**
	 * looking into the tokenized string we ask the first segment's first
	 * idde field if the data in the same position is one of its codes
	 * @return boolean
	 */

	public boolean isThisYou(ITokenizer inToken) {

		return getTemplateSegment(0).isThisYou(inToken);
	}

	/**
	 * asking template what parsing id field it doesn't like so that it would
	 * create a prevalidated segment.
	 * @return string
	 */

	public void whyNotYou(Tokenizer et) {
		this.getTemplateSegment(0).whyNotYou(et, null);
	}
	/* (non-Javadoc)
	 * @see com.americancoders.edi.IContainedObject#getDelimiter(char)
	 */

		public char getDelimiter(char inOriginal) {
			
			return parent.getDelimiter(inOriginal);
		}

}
