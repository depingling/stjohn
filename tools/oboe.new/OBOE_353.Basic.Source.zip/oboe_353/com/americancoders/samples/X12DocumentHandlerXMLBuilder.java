package com.americancoders.samples;


/**
 *OBOE - Open Business Objects for EDI
 *<P>java access to EDI
 *<p>Copyright 1998-2007 - American Coders, LTD  - Raleigh NC USA
 *<p>All rights reserved
 *<p>American Coders, Ltd
 *<br>P. O. Box 97462
 *<br>Raleigh, NC  27624  USA
 *<br>1-919-846-2014
 *<br>http://www.americancoders.com
@author Joe McVerry - American Coders, Ltd.
@version buildNotToBeReleased
 */

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;

import com.americancoders.edi.DocumentErrors;
import com.americancoders.edi.EDIDocumentHandler;
import com.americancoders.edi.Envelope;
import com.americancoders.edi.FunctionalGroup;
import com.americancoders.edi.OBOEException;
import com.americancoders.edi.Segment;
import com.americancoders.edi.TransactionSet;
import com.americancoders.edi.x12.X12DocumentParser;
import com.americancoders.edi.x12.X12Envelope;


/**
 * class to parse input string for all defined OBOE Transaction Sets
 * <br> x12 dependent
 *
 */

public class X12DocumentHandlerXMLBuilder implements EDIDocumentHandler {
	X12DocumentParser parser;
	X12Envelope envelope = null;
	FunctionalGroup functionalGroup = null;

	FileWriter fw = null;

	/**
	 * create a parser for transaction set and parser what is coming from Reader object
	 */

	public X12DocumentHandlerXMLBuilder(FileWriter inFW) {
		parser = new X12DocumentParser();
		parser.registerHandler(this);
		fw = inFW;
	}

	/**
	 * create a parser for transaction set and parser what is coming from Reader object
	 * <br>if you use this constructor and there are document errors the method
	 * will not make the envelope object available
	 * @param inReader the edi document in a java io reader object
	 * @exception OBOEException
	 *                      - unknown transaction set, this transaction set is undefined to OBOE
	 *                      - parsing erros
	 */

	public X12DocumentHandlerXMLBuilder(Reader inReader) throws OBOEException {
		parser = new X12DocumentParser();
		parser.registerHandler(this);
		parser.parseDocument(inReader, false);
		envelope.validate(parser.getDocumentErrors());
	}

	/** starts the parser with the passed Reader object
	 *
	 * @param inReader the edi document in a java io reader object
	 * @exception OBOEException
	 *                      - unknown transaction set, this transaction set is undefined to OBOE
	 *                      - parsing erros
	 */

	public void startParsing(Reader inReader) throws OBOEException {
		parser.parseDocument(inReader, false);
		
		envelope.validate(parser.getDocumentErrors());
		}

	/** called when an Envelope object is created
	 * @param inEnv Envelope found
	 */
	public void startEnvelope(Envelope inEnv) {
		envelope = (X12Envelope) inEnv;
		try {
			
			fw.write("\n<?xml version=\"1.0\"?>");
			fw.write("\n<!-- OBOE release -->");
			fw.write("\n<!DOCTYPE envelope SYSTEM \"envelope.dtd\">");
			fw.write("\n<envelope>");
		} catch (IOException e) {
			
			e.printStackTrace();
		}
	}

	/** called when an FunctionalGroup object is created
	 * @param inFG FunctionalGroup found
	 */
	public void startFunctionalGroup(FunctionalGroup inFG) {
		try {
			fw.write("\n<functionalgroup>");
		} catch (IOException e) {
			
			e.printStackTrace();
		}
	}

	/** called when an TransactionSet object is created
	 * @param inTS TransactionSet found
	 */
	public void startTransactionSet(TransactionSet inTS) {
		;
	}

	/** called when an Segment object is created
	 * <br>only called for segments at the Envelope and functionalGroup level
	 * does not get called for segments within TransactionSet
	 * @param inSeg  Segment found
	 */
	public void startSegment(Segment inSeg) {

		;
	}

	/** called when an Evelope is finished
	 * @param inEnv envelope found
	 */
	public void endEnvelope(Envelope inEnv) {
		try {
			fw.write("\n</envelope>");
		} catch (IOException e) {
			
			e.printStackTrace();
		}
	}

	/** called when an FunctionalGroup object is finished
	 * @param inFG FunctionalGroup found
	 */
	public void endFunctionalGroup(FunctionalGroup inFG) {
		try {
			fw.write("\n<functionalgroup>");
		} catch (IOException e) {
			
			e.printStackTrace();
		}
	}

	/** called when an TransactionSet object is finished
	 * @param inTS TransactionSet found
	 */
	public void endTransactionSet(TransactionSet inTS) {
		try {
			fw.write('\n');
			inTS.writeFormattedText(fw, Envelope.VALID_XML_FORMAT);
			System.out.println("wrote a ts");
		} catch (IOException e) {
			
			e.printStackTrace();
		}
	}

	/** called when an Segment object is finished
	 * <br>only called for segments at the Envelope and functionalGroup level
	 * does not get called for segments within TransactionSet
	 * @param inSeg  Segment found
	 */
	public void endSegment(Segment inSeg) {
		  try {
			fw.write("\n"+inSeg.getFormattedText(Envelope.VALID_XML_FORMAT));
		} catch (IOException e) {
			
			e.printStackTrace();
		}
	}


	public DocumentErrors getDocumentErrors() {
		
		return parser.getDocumentErrors();
	}

	/**
	 * main to test in application mode
	 * @param args String[] -  uses 2 arguments, input file name and output file name
	 * input file must contain an x12 edi document, output file will be valid xml oboe format
	 * @throws IOException
	 */

	public static void main(String args[]) throws IOException {
		
		FileReader fr = null;
		FileWriter fw = null;
		try {
			fr = new FileReader(args[0]);
			fw = new FileWriter(args[1]);
			X12DocumentHandlerXMLBuilder dh = new X12DocumentHandlerXMLBuilder(fw);
			dh.startParsing(fr);


		} catch (OBOEException oe1) {
			if (oe1.getDocumentErrors() == null)
				oe1.printStackTrace();
			else {
			   DocumentErrors de = oe1.getDocumentErrors();
			   for (int i = 0; i < de.getErrorCount(); i++) {
				System.out.print(de.getErrorID(i) + " ");
				System.out.print(de.getErrorCode(i) + " ");
				System.out.print(de.getErrorPosition(i) + " ");
				System.out.print(de.getErrorDescription(i) + " ");
				if (de.getContainer(i) instanceof Segment) {
					System.out.print(
						((Segment) de.getContainer(i)).getID()
							+ " "
							+ ((Segment) de.getContainer(i)).getName()
							+ com.americancoders.util.Util.lineFeed);
				} else {
					System.out.print(
						de.getContainer(i)
							+ com.americancoders.util.Util.lineFeed);
				}
			   }

			}
						
		} catch (Exception e1) {
			e1.printStackTrace();
		}
		finally {
			if (fr != null)
			  fr.close();
			if (fw != null) {
			 fw.flush();
			 fw.close();
			}
		
		}
	}



}