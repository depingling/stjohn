package com.americancoders.edi;


/**
 * interface for DataTokenizers
 *
 *<P>OBOE - Open Business Objects for EDI
 *<p>Part of the OBOE Basic Extended Package
 *<br>An EDI and XML Translator Written In Java
 *<br>Copyright 1998-2007 - American Coders, LTD  - Raleigh NC USA
 *<br>All rights reserved
 *<br>American Coders, Ltd
 *<br>P. O. Box 97462
 *<br>Raleigh, NC  27624  USA
 *<br>1-919-846-2014
 *<br>http://www.americancoders.com
@author Joe McVerry - American Coders, Ltd.
  @version   3.5.3
 */


public interface IDataTokenizer
{
    /** gets the next token in tokenized string
     * @return String
     */
  public String nextToken();
    /** gets the token in tokenized string at a specifiec position
     * @param pos int position, if < 0 or > the total returns null
     * @return String
     */
  public String getTokenAt(int pos);
    /** tests if more tokens are available
     * @return true or false
     */
  public boolean hasMoreElements();
    /** returns the number of tokens left to process
     * @return  int*/
  public int countTokens();

  
  /** returns the byte offset position of the token in the overall input stream
   * 
   * @return int
   */
   public int getPositionInStream();

   /** sets the byte offset position of the token in the input stream
    * 
    * @param positioninStream int
    */
   public void setPositionInStream(int positionInStream);
	

}
