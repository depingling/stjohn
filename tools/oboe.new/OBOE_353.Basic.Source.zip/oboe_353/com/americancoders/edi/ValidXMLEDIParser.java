package com.americancoders.edi;

import java.io.CharArrayReader;
import java.io.CharArrayWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Stack;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.apache.log4j.Logger;
import org.xml.sax.Attributes;
import org.xml.sax.EntityResolver;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import org.xml.sax.ext.LexicalHandler;
import org.xml.sax.helpers.DefaultHandler;

import com.americancoders.edi.EDIFact.EDIFactEnvelope;
import com.americancoders.edi.TRADACOMS.TradacomsEnvelope;
import com.americancoders.edi.x12.X12Envelope;
import com.americancoders.edi.x12.X12FunctionalGroup;
import com.americancoders.util.Util;

/**
 * class builds OBOE objects by parsing input string in valid xml edi format
 *
 *<P>OBOE - Open Business Objects for EDI
 *<p>Part of the OBOE Basic Extended Package
 *<br>An EDI and XML Translator Written In Java
 *<br>Copyright 1998-2007 - American Coders, LTD  - Raleigh NC USA
 *<br>All rights reserved
 *<br>American Coders, Ltd
 *<br>P. O. Box 97462
 *<br>Raleigh, NC  27624  USA
 *<br>1-919-846-2014
 *<br>http://www.americancoders.com
@author Joe McVerry - American Coders, Ltd.
  @version   3.5.3
 *
 */

public class ValidXMLEDIParser
	extends DefaultHandler
	implements EntityResolver, LexicalHandler {
	/**     envelope    */
	protected Envelope parsedEnvelope;
	/**     functionalGroup    */
	protected FunctionalGroup parsedFunctionalGroup;
	/**     transactionset    */
	protected TransactionSet parsedTransactionSet;
	/**     templatetransactionset    */
	protected TemplateTransactionSet parsedTemplateTransactionSet;
	/**     current element position    */
	protected int _iElement = 0;
	/**     current line number    */
	protected int _iLine = 0;
	/**     current table    */
	protected Table table = null;
	/**     current template table */
	protected TemplateTable templateTable = null;
	/**     current header tbl */
	protected Table headerTable = null;
	/**     current detail tlb */
	protected Table detailTable = null;
	/**     current sum table */
	protected Table summaryTable = null;
	/**     current loop      */
	protected Loop loop = null;
	/**     current seg      */
	protected Segment segment = null;
	/**     cucurrent comp   */
	protected CompositeDE composite = null;
	/**     current element    */
	protected DataElement element = null;
	/**     current loop container, either table or loop    */
	protected LoopAndSegmentContainer loopAndSegmentContainer = null;
	/**     current seg container, either table or loop    */
	protected SegmentContainer segmentContainer = null;
	/**     current composite container    */
	protected ICompositeDEContainer compositeContainer = null;
	/**     current de container    */
	protected IDataElementContainer elementContainer = null;
	/**     stack to handle recursive nature of file    */
	protected Stack loopAndSegmentStack = new Stack();
	/**     # of elements found    */
	protected int elementCount = -1;
	/**     simple string processor    */
	protected CharArrayWriter contents = new CharArrayWriter();
	/**     parser object    */
	protected SAXParser parser;

	protected TemplateSegment templateSegment = null;
	protected TemplateComposite templateComposite = null;

	protected String xmlDirectoryPath = "." + File.separator + ".";
	
	static Logger logr = Logger.getLogger(ValidXMLEDIParser.class);
	  
	static 	{Util.isLog4JNotConfigured();}


	/** create a XML EDI parser for valid xml files
	 *
	 */

	public ValidXMLEDIParser() {
		
		
		logr.debug("start validxmlediparser");
		
		SAXParserFactory spf = SAXParserFactory.newInstance();
		spf.setNamespaceAware(TransactionSetFactory.getNamespaceOption() == true);
		spf.setValidating(true);
		
		try {
			parser = spf.newSAXParser();
			parser.getXMLReader().setProperty("http://xml.org/sax/properties/lexical-handler", this);
			xmlDirectoryPath = Util.getOBOEProperty("xmlPath");
		} catch (ParserConfigurationException pce)
		{
			pce.printStackTrace();
			System.exit(0);
		} catch (SAXException saxe)
		{
			saxe.printStackTrace();
			System.exit(0);
		}catch (FileNotFoundException fnfe) {
			fnfe.printStackTrace();
			System.exit(0);
		} catch (IOException ioe) {
			ioe.printStackTrace();
			System.exit(0);
		}
	}

	/** parse an xml document coming in as a String
	 * @param text String xml data
	 * @exception SAXException
	 * @exception FileNotFoundException
	 * @exception IOException
	 */
	public void parse(String text)
		throws SAXException, FileNotFoundException, IOException {
		CharArrayReader car = new CharArrayReader(text.toCharArray());
		InputSource is = new InputSource(car);
		is.setSystemId("");
		parser.parse(is, this);
	}

	/** parse an xml
	 * @param filename String xml file name
	 * @exception SAXException
	 * @exception FileNotFoundException
	 * @exception IOException
	 */
	public void parseFile(String filename)
		throws SAXException, FileNotFoundException, IOException {
		InputSource is = new InputSource(new FileReader(filename));
		is.setSystemId("");
		parser.parse(is, this);
	}

	/** resolves the DTD file name for the xml parser
	 * @param publicId -  String name of xml public id
	 * @param systemId - String name of xml system id
	 * @return InputSource the dtd
	 */

	public InputSource resolveEntity(
		java.lang.String publicId,
		java.lang.String systemId)
		throws SAXException
	//java.io.IOException
	{
		try {
			if (publicId != null) {
				if (publicId.indexOf("://") < 1) {
					return new InputSource(
						new FileInputStream(
							xmlDirectoryPath + File.separator + publicId));
				}
				File f = new File(publicId);
				if (f.exists())
					return null;
				String sf = f.getName();
				return new InputSource(
					new FileInputStream(
						xmlDirectoryPath + File.separator + sf));
			}
			if (systemId != null) {
				if (systemId.indexOf("://") < 1) {
					return new InputSource(
						new FileInputStream(
							xmlDirectoryPath + File.separator + systemId));
				}
				File f = new File(systemId);
				if (f.exists())
					return null;
				String sf = f.getName();
				return new InputSource(
					new FileInputStream(
						xmlDirectoryPath + File.separator + sf));

			}
		} catch (Exception e) {
			throw new SAXException(e);
		}
		return null;
	}

	/**
	 * method called for each xml element found.
	 * <br> process logic
	 * <ul>
	 * <li> based on the name of the element found
	 * <li> for each pull appropriate attributes and construct object
	 * <li> if owned by another class, and all are except for Standard, add it to its parents object
	 * </ul>
	 * @param uri URI of incoming file
	 * @param localName String of element's local name
	 * @param rawName String of element's raw name
	 * @param attributes Vector of the elements attributes
	 * @throws SAXException many possible exceptions
	 *
	 */
	public void startElement(
		java.lang.String uri,
		java.lang.String localName,
		java.lang.String rawName,
		Attributes attributes)
		throws SAXException {


		_iElement++;
		contents.reset();

		String name = rawName;
		// Standard
		
        //logr.debug("starting " + name);		


			if (name.compareTo("") == 0) {
				return;
			} else if (name.compareTo("envelope") == 0) {
				String format = attributes.getValue("format");
				if (format.compareTo("X12") == 0) {
					parsedEnvelope =
						new X12Envelope(
							EnvelopeFactory.buildEnvelope("x12.envelope","notSetYet"));
				} else if (format.compareTo("EDIFact") == 0)
					parsedEnvelope =
						new EDIFactEnvelope(
							EnvelopeFactory.buildEnvelope("EDIFact.envelope","notSetYet"));
				else if (format.compareTo("Tradacoms") == 0)
								   parsedEnvelope =
									   new TradacomsEnvelope(
										   EnvelopeFactory.buildEnvelope("Tradacoms.envelope","notSetYet"));
				else
					throw new SAXException(
						"Envelope format " + format + " is unknown");
				segmentContainer = parsedEnvelope;
			} else if (name.compareTo("functionalgroup") == 0) {
				loopAndSegmentStack.push(segmentContainer);
				parsedFunctionalGroup = parsedEnvelope.createFunctionalGroup();
				parsedEnvelope.addFunctionalGroup(parsedFunctionalGroup);
				segmentContainer = parsedFunctionalGroup;
			} else if (name.compareTo("transactionset") == 0) {
				String tsID = attributes.getValue("code");
				String version = attributes.getValue("version"); // for edifact only
				if (version != null && version.length() == 0)
					version = null;
				if (parsedEnvelope instanceof X12Envelope)
						parsedTransactionSet =
							TransactionSetFactory.buildTransactionSet(tsID, null,
					  		  parsedFunctionalGroup.getSegment(X12FunctionalGroup.idHeader).getDataElement("480").get(),
							  parsedEnvelope.getSegment(X12Envelope.idInterchangeHeader).getDataElement("I07").get(),
							  parsedEnvelope.getSegment(X12Envelope.idInterchangeHeader).getDataElement("I06").get(),
					    	  parsedEnvelope.getSegment(X12Envelope.idInterchangeHeader).getDataElement("I14").get());
				else if (parsedEnvelope instanceof EDIFactEnvelope) {
					String testProduction = "";
					DataElement tde = parsedEnvelope.getSegment("UNB").getDataElement("0035");  // do this becuase 0035 is not required
					if (tde != null)
						testProduction = tde.get();
						parsedTransactionSet =
							TransactionSetFactory.buildTransactionSet(tsID, null,	version,
							  parsedEnvelope.getSegment("UNB").getCompositeDE("S003").getDataElement("0010").get(),
							  parsedEnvelope.getSegment("UNB").getCompositeDE("S002").getDataElement("0004").get(),
							  testProduction);
				}
				else if (parsedEnvelope instanceof TradacomsEnvelope) {
					DataElement de = parsedEnvelope.getSegment("STX").getCompositeDE("FROM").getDataElement(1);
					String from = "";
					if (de != null)  from = de.get();
					de = parsedEnvelope.getSegment("STX").getCompositeDE("UNTO").getDataElement(1);
					String unto = "";
					if (de != null)  unto = de.get();
					parsedTransactionSet =
							TransactionSetFactory.buildTransactionSet(tsID, null,
							  parsedEnvelope.getSegment("STX").getCompositeDE("STDS").getDataElement(2).get(),
							  from,
							  unto,
							  ""); //no test/production
				}
				else throw new SAXException("unknown envelope type");
				parsedTemplateTransactionSet =
					parsedTransactionSet.getTemplateTransactionSet();
				parsedTransactionSet.setFormat(Envelope.VALID_XML_FORMAT);
				parsedTransactionSet.setParent(parsedFunctionalGroup);
				if (parsedFunctionalGroup != null)
					parsedFunctionalGroup.addTransactionSet(
						parsedTransactionSet);
				headerTable = null;
				detailTable = null;
				summaryTable = null;
			} else if (name.compareTo("table") == 0) {
				loopAndSegmentStack.push(segmentContainer);
				String section = attributes.getValue("section");
				if (section.compareTo("header") == 0) {
					if (headerTable != null)
						throw new SAXException("header table already defined");
					headerTable = table = parsedTransactionSet.getHeaderTable();
					templateTable =
						parsedTemplateTransactionSet.getHeaderTemplateTable();
					segmentContainer = table;
					loopAndSegmentContainer = table;
				} else if (section.compareTo("detail") == 0) {
					if (detailTable != null)
						throw new SAXException("detail table already defined");
					detailTable = table = parsedTransactionSet.getDetailTable();
					templateTable =
						parsedTemplateTransactionSet.getDetailTemplateTable();
					segmentContainer = table;
					loopAndSegmentContainer = table;
				} else if (section.compareTo("summary") == 0) {
					if (summaryTable != null)
						throw new SAXException("summary table already defined");
					summaryTable =
						table = parsedTransactionSet.getSummaryTable();
					templateTable =
						parsedTemplateTransactionSet.getSummaryTemplateTable();
					segmentContainer = table;
					loopAndSegmentContainer = table;
				} else
					throw new SAXException(
						"table section=" + section + " unknown");
			} else if (name.compareTo("loop") == 0) {
				String code = attributes.getValue("code");
				templateSegment = null;
				loop = loopAndSegmentContainer.createLoop(code);
				loopAndSegmentStack.push(loopAndSegmentContainer);
				loopAndSegmentContainer.addLoop(loop);
				loopAndSegmentContainer = loop;
				segmentContainer = loop;
			} else if (name.compareTo("segment") == 0) {
				String code = attributes.getValue("code");
				/* envelopes return templateSegments as null
				 * so ask the envelope to create the segment
				 */
				templateSegment = null;
				if (segmentContainer.myTemplateContainer.getTemplateSegment(code) == null)
 					throw new SAXException("segment " + code + " unknown to " + segmentContainer + " " +
				   segmentContainer.getID());
				segment = segmentContainer.createSegment(code);
				elementCount = -1;

				compositeContainer = segment;
				elementContainer = segment;
				composite = null;

			} else if (name.compareTo("composite") == 0) {
				String code = attributes.getValue("code");

				templateSegment = segment.getTemplate();

				if (templateSegment != null) {
					elementCount =
						templateSegment.doYouUseThisElement(code, elementCount);
					if (elementCount == -1)
						throw new SAXException(
							"element "
								+ code
								+ " not in correct position for segment: "
								+ segment.getID());
					templateComposite =
						templateSegment.getTemplateComposite(elementCount + 1);
				    if (templateComposite.getOccurs() > 1 && composite!=null &&
				          composite.getID().compareTo(templateComposite.getID())== 0) //already built one
				        composite.createNewGroup();
				    else
					    composite = (CompositeDE) segment.buildDE(elementCount + 1);
					loopAndSegmentStack.push(new Integer(elementCount));
					elementCount = -1;
				} else {
					composite = segment.getCompositeDE(code);
					elementCount = segment.getObjectPosition(composite);
					loopAndSegmentStack.push(new Integer(elementCount));
					elementCount = -1;
				}
				elementContainer = composite;
			} else if (name.compareTo("element") == 0) {
				String code = attributes.getValue("code");
				if (elementContainer instanceof CompositeDE) {
					if (templateComposite != null) {
						elementCount =
							templateComposite.doYouUseThisElement(
								code,
								elementCount);
						if (elementCount == -1)
							throw new SAXException(
								"element "
									+ code
									+ " not in correct position for composite: "
									+ composite.getID());
						composite.buildDE(elementCount + 1);
					} else {
						if (composite
							.getDataElement(elementCount)
							.getID()
							.compareTo(code)
							!= 0)
							throw new SAXException(
								"element "
									+ code
									+ " not in correct position for composite: "
									+ composite.getID());
					}
					element = composite.getDataElement(elementCount + 1);
				} else {
					templateSegment = segment.getTemplate();
					if (templateSegment != null) {
						elementCount =
							templateSegment.doYouUseThisElement(
								code,
								elementCount);
						if (elementCount == -1)
							throw new SAXException(
								"element id="
									+ code
									+ " not in correct position for segment: "
									+ segment.getID());
						segment.buildDE(elementCount + 1);
						element = segment.getDataElement(elementCount + 1);
					} else {
						element =
							segment.getDataElement(code, elementCount + 1);
						if ( element == null) {
							String nm = attributes.getValue("name");
							logr.error("element code=" + code + " not found in segment: "+segment.getID()+ " will look by name " + nm);
							if (nm == null)
									throw new SAXException("element code=" + code + " not in correct position  for segment: "+segment.getID());
							element =  segment.getDataElementByName(nm, elementCount+1);
							if (element == null)
									throw new SAXException("element code=" + code + " not in correct position  for segment: "+segment.getID());
							}
					}
					elementCount = segment.getObjectPosition(element);
					if (element.getOccurs() > 1)
					  elementCount--;
				}
				//element.set("");

			} else if (name.compareTo("value") == 0) {

			} else
				logr.error(
					"Logic error: Unknown element name \""
						+ name
						+ "\" found at element position "
						+ _iElement
						+ " line: "
						+ _iLine);


	}

	/**
	 * Method called by the SAX parser at the </
	 * @param uri URI of incoming file
	 * @param localName String of element's local name
	 * @param rawName String of element's raw name
	 * @throws SAXException many possible  *
	 */
	public void endElement(
		java.lang.String uri,
		java.lang.String localName,
		java.lang.String rawName)
		throws SAXException {
		String name = rawName;
		Integer intObject;
		Object obj;

		//logr.debug("ending " + name);
		if (name.compareTo("dataelement") == 0) {
			//if (element instanceof NumericDE)
			//   ((NumericDE) element).setFormatted(contents.toString());
			//else
			//   element.set(contents.toString());
		} else if (name.compareTo("value") == 0) {
			if (segment.getID().compareTo("ISA")==0) // may have to rebuild envelope object
			{ 
				if (element.getID().compareTo("I11") == 0) {
					X12Envelope newParsedEnvelope =
						new X12Envelope(EnvelopeFactory.buildEnvelope("x12.envelope",contents.toString()));
					parsedEnvelope = newParsedEnvelope;
					segmentContainer = parsedEnvelope;
					segment.setParent(parsedEnvelope);
					
				}
				
			}
			if (element instanceof NumericDE)
				 ((NumericDE) element).setFormatted(contents.toString());
			else
				element.setNext(contents.toString());
		} else if (name.compareTo("composite") == 0) {
			intObject = (Integer) loopAndSegmentStack.pop();
			elementCount = intObject.intValue();
			elementContainer = segment;
			if (composite.getOccurs() > 1)
			  elementCount--;

		} else if (name.compareTo("segment") == 0) {
			if (loopAndSegmentContainer == null)
				segmentContainer.addSegment(segment);
			else
				loopAndSegmentContainer.addSegment(segment);

		} else if (name.compareTo("loop") == 0) {
			obj = loopAndSegmentStack.pop();
			segmentContainer = (SegmentContainer) obj;
			loopAndSegmentContainer = (LoopAndSegmentContainer) obj;
		} else if (name.compareTo("table") == 0) {
			obj = loopAndSegmentStack.pop();
			segmentContainer = (SegmentContainer) obj;
			loopAndSegmentContainer = null;
		} else if (name.compareTo("functionalgroup") == 0) {
			obj = loopAndSegmentStack.pop();
			segmentContainer = (SegmentContainer) obj;
		}
	}

	/**
	 * Method handles #PCDATA
	 * @param ch array
	 * @param start position in array where next has been placed
	 * @param length int
	 *
	 *
	 */
	public void characters(char ch[], int start, int length) {
		contents.write(ch, start, length);
		for (int i = start; i < start + length; i++)
			if (ch[i] == '\n')
				_iLine++;
	}

	/** I use this to keep track of line #s
	 * @param ch char array of found whitespaces
	 * @param start int start position in array
	 * @param length int length of what's been found
	 */
	public void ignorableWhitespace(char[] ch, int start, int length) {
		for (int i = start; i < start + length; i++)
			if (ch[i] == '\n')
				_iLine++;
	}

	/** catches warning SAXParseExceptions
	 * this code sends exception to stdio and allows public classto continue
	 * @param e SaxException object
	 * @throws SAXException exception
	 */
	public void warning(SAXParseException e) throws SAXException {
		logr.error(
			"Warning at (file "
				+ e.getSystemId()
				+ ", line "
				+ e.getLineNumber()
				+ ", char "
				+ e.getColumnNumber()
				+ "): "
				+ e.getMessage());
	}

	/** catches error SAXParseExceptions
	 * this code causes exception to continue
	 * @param e SaxException object
	 * @throws SAXException thrown
	 */
	public void error(SAXParseException e) throws SAXException {
		throw new SAXException(
			"Error at (file "
				+ e.getSystemId()
				+ ", line "
				+ e.getLineNumber()
				+ ", char "
				+ e.getColumnNumber()
				+ "): "
				+ e.getMessage());
	}

	/** catches fatal SAXParseExceptions
	 * this code causes exception to continue
	 * @param e SAXException object
	 * @throws SAXException thrown
	 */
	public void fatalError(SAXParseException e) throws SAXException {
		throw new SAXException(
			"Fatal Error at (file "
				+ e.getSystemId()
				+ ", line "
				+ e.getLineNumber()
				+ ", char "
				+ e.getColumnNumber()
				+ "): "
				+ e.getMessage());
	}
	/* (non-Javadoc)
	 * @see org.xml.sax.ext.LexicalHandler#startDTD(java.lang.String, java.lang.String, java.lang.String)
	 */
	public void startDTD(String arg0, String arg1, String arg2) throws SAXException {
		// 
		
	}

	/* (non-Javadoc)
	 * @see org.xml.sax.ext.LexicalHandler#endDTD()
	 */
	public void endDTD() throws SAXException {
		// 
		
	}

	/* (non-Javadoc)
	 * @see org.xml.sax.ext.LexicalHandler#startEntity(java.lang.String)
	 */
	public void startEntity(String arg0) throws SAXException {
		// 
		
	}

	/* (non-Javadoc)
	 * @see org.xml.sax.ext.LexicalHandler#endEntity(java.lang.String)
	 */
	public void endEntity(String arg0) throws SAXException {
		// 
		
	}

	/* (non-Javadoc)
	 * @see org.xml.sax.ext.LexicalHandler#startCDATA()
	 */
	public void startCDATA() throws SAXException {
		// 
		
	}

	/* (non-Javadoc)
	 * @see org.xml.sax.ext.LexicalHandler#endCDATA()
	 */
	public void endCDATA() throws SAXException {
		// 
		
	}

	/* (non-Javadoc)
	 * @see org.xml.sax.ext.LexicalHandler#comment(char[], int, int)
	 */
	public void comment(char[] chars, int start, int length) throws SAXException {
		for (int i = start; i < start+length; i++)
			if (chars[i]=='\n')
				_iLine++;
		
	}
	/** static main method to test xmlparser class
	 * @param args String array
	 */
	public static void main(String args[]) {
		try {

			ValidXMLEDIParser xmlp = new ValidXMLEDIParser();
			xmlp.parseFile(args[0]);
			xmlp.getEnvelope().writeFormattedText(new PrintWriter(System.out),Envelope.X12_FORMAT); 
			//System.out.println(xmlp.getEnvelope().getFormattedText(Envelope.X12_FORMAT));
		} catch (Exception e1) {
			e1.printStackTrace();
		}
	}

	/**
	 * returns the envelope that was parsed
	 * @return Envelope - the envelope parsed when parse method was called
	 */
	public Envelope getEnvelope() {
		return parsedEnvelope;
	}

	/**
	 * returns the last transaction set that was parsed
	 * @return TransactionSet - the transaction set parsed when parse method was called
	 */
	public TransactionSet getTransactionSet() {
		return parsedTransactionSet;
	}

}
