/*
 * Copyright (C) 2006-2007 by Joseph McVerry - American Coders, Ltd.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

package org.pixes;

import java.sql.SQLException;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;


/**
 * @author Joe McVerry - American Coders, Ltd.
 *
 * executor object to do a database rollback
 *
 */
public class Rollback extends Executable {
	    static {Util.isLog4JNotConfigured();}
	    /**
	     * jdbc connector
	     */
	Connecter connectObject;
	/**
	 * debugging level
	 */
	Level dbgLvl;
	/**
	 * @param line - xml line number
	 * @param dbConnectObject
	 *
	 */
	public Rollback(int line, Connecter dbConnectObject) {

		super(null);
        logr = Logger.getLogger(Rollback.class);
		dbgLvl = dbConnectObject.prsr.logr.getLevel();
		logr.setLevel(dbgLvl);
        logr.setLevel(dbgLvl);
		logr.debug("rollback constructor "+line);
		setMyXMLLine(line);
		connectObject = dbConnectObject;

	}
	public int execute(Executor inExec) {
		connectObject.exec.logr.setLevel(dbgLvl);
		logr.setLevel(dbgLvl);
		try {
			connectObject.getConnection().rollback();
		} catch (SQLException e) {

			logr.error(e.getMessage(),
					         e);
			return -1;
		}
		return getNextStep();
	}

}
