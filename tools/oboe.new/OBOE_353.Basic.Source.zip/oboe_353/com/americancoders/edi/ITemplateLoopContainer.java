package com.americancoders.edi;

/** interface for Loop Container
 * <br> used by tables and Loops
 *
 * <P>OBOE - Open Business Objects for EDI
 * <br>An EDI and XML Translator Written In Java
 * <br>Copyright 1998-2007 - American Coders, LTD  - Raleigh NC USA
 * <br>All rights reserved
 * <br>American Coders, Ltd
 * <br>P. O. Box 97462
 * <br>Raleigh, NC  27624  USA
 * <br>1-919-846-2014
 * <br>http://www.americancoders.com
 * @author Joe McVerry - American Coders, Ltd.
  @version   3.5.3
 */

public interface ITemplateLoopContainer {

	/** returns a new Loop
	 * @return Loop objects - null indicates Loop not set
	 * @param ID String id of Loop to create
	 * @exception OBOEException ID is unknown to this Loop
	 */

	public Loop createLoop(String ID) throws OBOEException;

	/** returns a Loop
	 * @return Loop objects - null indicates Loop not set
	 * @param ID String ID of TemplateLoop to look for
	 * @exception OBOEException ID is unknown to this Loop
	 */

	public TemplateLoop getTemplateLoop(String ID) throws OBOEException;

	/** returns a Loop
	 * @return Loop objects - null indicates Loop not set
	 * @param pos int pos TemplateLoop to look for
	 * @exception OBOEException ID is unknown to this Loop
	 */

	public TemplateLoop getTemplateLoop(int pos) throws OBOEException;

	/** sets a Loop
	 * <UL>
	 * <li> may be used to add a new Loop
	 * <li> may be used to change an existing Loop
	 * <li> may be used to remove an Loop, this is done by passing a null object
	 * </ul>
	 * @param templateLoopObject TemplateLoop to be added
	 * @exception OBOEException Loop is unknown
	 */

	public void addTemplateLoop(TemplateLoop templateLoopObject)
		throws OBOEException;

	/** implemented for interface
	 * @return int
	 */
	public int getTemplateLoopSize();

}
