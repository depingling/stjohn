/*
 * Copyright (C) 2006-2007 by Joseph McVerry - American Coders, Ltd.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

package org.pixes;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.log4j.Logger;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

/**
 * @author Joe McVerry - American Coders, Ltd.
 *
 * the main class of pixes, contains a static main to call from command line. uses one
 * required argument which is the xml file to parse and execute. and an optional argument
 * -P which you use to specify a secondary properties file, which allows the pixes process
 * to access the properties in the file.
 *
 */

public class Parsexecutor {

	/** the current version,  i seem to always forget to update this when new releases come out */
	static String version = "1.1.0";

	Logger logr = Logger.getLogger(Parsexecutor.class);
	{
		Util.isLog4JNotConfigured();
	}

	public static void main(String[] args) {
		if (args.length < 1) {
			System.out.println("PIXES version 1.1.0,\n"
							+ "Copyright � 2006-2007 Joseph McVerry - American Coders Ltd Raleigh NC (USA) \n"
							+ "PIXES comes with ABSOLUTELY NO WARRANTY; This is free software, and you are welcome to redistribute it under certain conditions;\n"
							+ "\nPackages requires one argument - the xml file to execute"
							+ "\na optional argument specifies an properties file to load (eg. -P=vars.prop)"
							+ "\na optional argument specifies to only parse the xml file (eg. -parseOnly)"
							+ "\na optional argument specifies to only test test code within the xml file (eg. -test)");
			return;
		}
		Logger logr = Logger.getLogger(Parser.class);
		Parser prsr;
		try {
			logr.info("building parser");
			prsr = new Parser();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return;
		}
		int argI = 0;
		for (argI = 0; argI < args.length && args[argI].charAt(0) == '-'; argI++) {
			if (args[argI].compareTo("-test") == 0) {
				prsr.testToo = true;
			} else if (args[argI].startsWith("-P="))
				try {
					prsr.getVarStack().loadProperties(args[argI].substring(3));
				} catch (IOException e1) {
					logr.error(e1.getMessage(), e1);
					return;
				}
			else {
				logr.error("don't understand argument at " + argI
						+ " with a value of " + args[argI]);
				return;

			}
		}
		logr.info("parsing file " + args[argI]);
		try {
			logr.info("calling parser");
			prsr.parse(new InputSource(new FileInputStream(args[argI])));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return;
		} catch (SAXException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return;
		}

		try {
			logr.info("building executor");
			Executor exec = new Executor(prsr.executorArray);
			logr.info("call executor");
			exec.start();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
