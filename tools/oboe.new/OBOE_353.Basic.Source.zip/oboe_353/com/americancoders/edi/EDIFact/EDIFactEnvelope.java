package com.americancoders.edi.EDIFact;

/**
 *OBOE - Open Business Objects for EDI
 *<P>java access to EDI
 *<p>Copyright 1998-2007 - American Coders, LTD  - Raleigh NC USA
 *<p>All rights reserved
 *<p>American Coders, Ltd
 *<br>P. O. Box 97462
 *<br>Raleigh, NC  27624  USA
 *<br>1-919-846-2014
 *<br>http://www.americancoders.com
@author Joe McVerry - American Coders, Ltd.
  @version   3.5.3
 */

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PushbackInputStream;
import java.io.Writer;
import java.util.Vector;

import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.americancoders.edi.DataElement;
import com.americancoders.edi.DocumentErrors;
import com.americancoders.edi.Envelope;
import com.americancoders.edi.FunctionalGroup;
import com.americancoders.edi.OBOEException;
import com.americancoders.edi.Segment;
import com.americancoders.edi.TemplateEnvelope;
import com.americancoders.edi.TemplateSegment;
import com.americancoders.edi.TransactionSet;
import com.americancoders.edi.TransactionSetFactory;
import com.americancoders.util.Util;


/**
 * class for wrapping a EDI transaction set within an EDI Envelope
 *
 */

public class EDIFactEnvelope extends Envelope 
{



  /** constants for segments */

 /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
/** segment constants */
  public static final String  idServiceString = "UNA";
  public static final String  idInterchangeHeader = "UNB";
  public static final String  idInterchangeTrailer = "UNZ";
  /**
   * instantiates the class from all related OBOE classes
   */

  public EDIFactEnvelope()
  {
    super();
    setFormat(Envelope.EDIFACT_FORMAT);
    segmentDelimiter = Envelope.EDIFact_SEGMENT_DELIMITER;
    fieldDelimiter = Envelope.EDIFact_FIELD_DELIMITER;
    groupDelimiter = Envelope.EDIFact_GROUP_DELIMITER;
    repeatDelimiter = Envelope.EDIFact_REPEAT_DELIMITER;
    escapeCharacter= Envelope.EDIFact_ESCAPE_CHARACTER;
    

  }

  /**
   * instantiates the class from a TemplateEnvelope,
   * creates mandatory segments UNB and UNZ and creates one emtpy functional group
   * @param inTempEnv TemplateEnvelope to build this class with
   * @exception OBOEException missing segment definition in envelope xml.
   */

  public EDIFactEnvelope(TemplateEnvelope inTempEnv)
    throws OBOEException
  {
    super();
    setFormat(Envelope.EDIFACT_FORMAT);
    segmentDelimiter = Envelope.EDIFact_SEGMENT_DELIMITER;
    fieldDelimiter = Envelope.EDIFact_FIELD_DELIMITER;
    groupDelimiter = Envelope.EDIFact_GROUP_DELIMITER;
    repeatDelimiter = Envelope.EDIFact_REPEAT_DELIMITER;
    escapeCharacter= Envelope.EDIFact_ESCAPE_CHARACTER;
    myTemplate = inTempEnv;
	myTemplateContainer = myTemplate;
    //createInterchange_Header();
    //createFunctionalGroup();
    //createInterchange_Trailer();

  }




 /* method for parsing well formed edi xml files
  * @param node a DOM node object
  * @throws OBOException...
  * @throws FileNotFoundException...
  * @throws IOException...
  */


  public void parse(Node node)
   throws OBOEException, FileNotFoundException, IOException
   {
        Node cnode = null;
        NodeList nl = node.getChildNodes();
        Segment seg;
        int i;
        for (i = 0; i < nl.getLength(); i++)
        {
           cnode = nl.item(i);
           if (cnode.getNodeType() == Node.ELEMENT_NODE)
              break;
        }


        if (i == nl.getLength())
          throw new OBOEException("No element nodes found");

        if (cnode.getNodeName().compareTo("Service_String") == 0)
        {
	        seg = new Segment(myTemplate.getTemplateSegment(idServiceString), this);
	        addSegment(seg);
	        seg.parse(cnode);

	        for (i++; i < nl.getLength(); i++)
	        {
	           cnode = nl.item(i);
	           if (cnode.getNodeType() == Node.ELEMENT_NODE)
	              break;
	        }


	        if (i == nl.getLength())
	          throw new OBOEException("Envelope terminated too soon");
		}

        if (cnode.getNodeName().compareTo(myTemplate.getTemplateSegment(idInterchangeHeader).getXMLTag()) != 0)
          throw new OBOEException("Expected "+ myTemplate.getTemplateSegment(idInterchangeHeader).getXMLTag()+ " got " +cnode.getNodeName());


        seg = new Segment(myTemplate.getTemplateSegment(idInterchangeHeader), this);
        addSegment(seg);
        seg.parse(cnode);

        for (i++; i < nl.getLength(); i++)
        {
           cnode = nl.item(i);
           if (cnode.getNodeType() == Node.ELEMENT_NODE)
              break;
        }


        if (i == nl.getLength())
          throw new OBOEException("Envelope terminated too soon");

        if  (cnode.getNodeName().compareTo(myTemplate.getTemplateFunctionalGroup().getTemplateSegment(EDIFactFunctionalGroup.idHeader).getXMLTag()) != 0)
          {

                   FunctionalGroup functionalGroup = new EDIFactFunctionalGroup(myTemplate.getTemplateFunctionalGroup(), this);
                   addFunctionalGroup(functionalGroup);
                   do
                     {

                      String tsID = Util.getOBOEProperty(cnode.getNodeName());
                      if (tsID == null)
                        throw new OBOEException(cnode.getNodeName() + " not defined in OBOE.properties.");

                     String testProduction = "";
  					 DataElement tde = getSegment("UNB").getDataElement("0035");  // do this becuase 0035 is not required
  					 if (tde != null)
  						testProduction = tde.get();
  					 
  					 String version = "";
  					 tde = null;
  					 
  					 if (getSegment("UNB").getCompositeDE("S008") !=null)
  					   tde = getSegment("UNB").getCompositeDE("S008").getDataElement("0054");
  					 
  					 if (tde != null)
  					    version = tde.get().trim();
     	  			    
                      TransactionSet parsedTransactionSet =
							TransactionSetFactory.buildTransactionSet(tsID, null,	version,
							  getSegment("UNB").getCompositeDE("S003").getDataElement("0010").get(),
							  getSegment("UNB").getCompositeDE("S002").getDataElement("0004").get(),
							  testProduction);

                      parsedTransactionSet.setFormat(Envelope.EDIFACT_FORMAT);
                      parsedTransactionSet.parse(nl.item(i));
                      functionalGroup.addTransactionSet(parsedTransactionSet);
                      parsedTransactionSet.setParent(functionalGroup);

                      for (i++; i < nl.getLength(); i++)
                       {
                        cnode = nl.item(i);
                        if (cnode.getNodeType() == Node.ELEMENT_NODE)
                        break;
                       }

                      if (i == nl.getLength())
                         throw new OBOEException("Envelope terminated too soon");
                     } while (cnode.getNodeName().compareTo(myTemplate.getTemplateSegment(idInterchangeTrailer).getXMLTag()) != 0);

          }
        else
         while  (cnode.getNodeName().compareTo(myTemplate.getTemplateFunctionalGroup().getTemplateSegment(EDIFactFunctionalGroup.idHeader).getXMLTag()) == 0)
            {
                   FunctionalGroup functionalGroup = new EDIFactFunctionalGroup(myTemplate.getTemplateFunctionalGroup(), this);
                   addFunctionalGroup(functionalGroup);
                   seg = functionalGroup.createSegment(EDIFactFunctionalGroup.idHeader);
                   seg.parse(cnode);
                   functionalGroup.addSegment(seg);
                   for (i++; i < nl.getLength(); i++)
                    {
                        cnode = nl.item(i);
                        if (cnode.getNodeType() == Node.ELEMENT_NODE)
                        break;
                    }

                   if (i == nl.getLength())
                      throw new OBOEException("Envelope terminated too soon");

                   while (cnode.getNodeName().compareTo(myTemplate.getTemplateFunctionalGroup().getTemplateSegment(EDIFactFunctionalGroup.idTrailer).getXMLTag()) != 0)
                    {

                      String tsID = Util.getOBOEProperty(cnode.getNodeName());
                      if (tsID == null)
                        throw new OBOEException(cnode.getNodeName() + " not defined in OBOE.properties.");


                      TransactionSet parsedTransactionSet = TransactionSetFactory.buildTransactionSet(tsID);
                      parsedTransactionSet.setFormat(Envelope.EDIFACT_FORMAT);
                      parsedTransactionSet.parse(nl.item(i));
                      functionalGroup.addTransactionSet(parsedTransactionSet);
                      parsedTransactionSet.setParent(functionalGroup);

                      for (i++; i < nl.getLength(); i++)
                       {
                        cnode = nl.item(i);
                        if (cnode.getNodeType() == Node.ELEMENT_NODE)
                        break;
                       }

                      if (i == nl.getLength())
                         throw new OBOEException("Envelope terminated too soon");
                    }
                   seg = functionalGroup.createSegment(EDIFactFunctionalGroup.idTrailer);
                   seg.parse(cnode);
                   functionalGroup.addSegment(seg);
                   for (i++; i < nl.getLength(); i++)
                    {
                        cnode = nl.item(i);
                        if (cnode.getNodeType() == Node.ELEMENT_NODE)
                        break;
                    }

                   if (i == nl.getLength())
                      throw new OBOEException("Envelope terminated too soon");

            }

    if (cnode.getNodeName().compareTo(myTemplate.getTemplateSegment(idInterchangeTrailer).getXMLTag()) != 0)
          throw new OBOEException("Expecting " + myTemplate.getTemplateSegment(idInterchangeTrailer).getXMLTag());


    seg = new Segment(myTemplate.getTemplateSegment(idInterchangeTrailer), this);
    seg.parse(cnode);
    addSegment(seg);


   }
 /* method for parsing fixed format edi files
  * @param DataInputStream
  * @throws OBOException...
  * @throws FileNotFoundException...
  * @throws IOException...
  */

  public boolean parse(PushbackInputStream pis)
      throws OBOEException, FileNotFoundException, IOException
      {
        Segment seg;
  

        StringBuffer sb=new StringBuffer(); // first char was already read by parser class
        byte me[] = new byte[4];
        if (pis.read(me) != 4)
           	throw new OBOEException("expected data not read");

        sb.append(me);
        String id = Util.rightTrim(new String(sb));

        if (id.compareTo("Service_String") == 0)
        {
	        seg = new Segment(myTemplate.getTemplateSegment(idServiceString), this);
	        addSegment(seg);
	        seg.parse(pis);

            if (pis.read(me) != 4)
               	throw new OBOEException("expected data not read");
            id = Util.rightTrim(new String(me));
		}

        if (id.compareTo(myTemplate.getTemplateSegment(idInterchangeHeader).getID()) != 0)
          throw new OBOEException("Expected "+ myTemplate.getTemplateSegment(idInterchangeHeader).getID()+ " got " +id);


        seg = new Segment(myTemplate.getTemplateSegment(idInterchangeHeader), this);
        addSegment(seg);
        seg.parse(pis);

        if  (id.compareTo(myTemplate.getTemplateFunctionalGroup().getTemplateSegment(EDIFactFunctionalGroup.idHeader).getID()) != 0)
          {

                   FunctionalGroup functionalGroup = new EDIFactFunctionalGroup(myTemplate.getTemplateFunctionalGroup(), this);
                   addFunctionalGroup(functionalGroup);
                   String tsID = Util.getOBOEProperty(id);
                   if (tsID == null)
                        throw new OBOEException(id + " not defined in OBOE.properties file");


                   TransactionSet parsedTransactionSet = TransactionSetFactory.buildTransactionSet(tsID);
                   parsedTransactionSet.setFormat(Envelope.EDIFACT_FORMAT);
                   parsedTransactionSet.parse(pis);
                   functionalGroup.addTransactionSet(parsedTransactionSet);
                   parsedTransactionSet.setParent(functionalGroup);

                   if (pis.read(me) != 4)
                   	throw new OBOEException("expected data not read");
                  id = Util.rightTrim(new String(me));

          }
        else
         while  (id.compareTo(myTemplate.getTemplateSegment(EDIFactFunctionalGroup.idHeader).getID()) == 0)
            {
                   FunctionalGroup functionalGroup = new EDIFactFunctionalGroup(myTemplate.getTemplateFunctionalGroup(), this);
                   addFunctionalGroup(functionalGroup);
                   seg = new Segment(myTemplate.getTemplateFunctionalGroup().getTemplateSegment(EDIFactFunctionalGroup.idHeader), functionalGroup);
                   seg.parse(pis);
                   if (pis.read(me) != 4)
                   	throw new OBOEException("expected data not read");
                   id = Util.rightTrim(new String(me));

                   while (id.compareTo(myTemplate.getTemplateSegment(EDIFactFunctionalGroup.idTrailer).getID()) != 0)
                    {

                      String tsID = Util.getOBOEProperty(id);
                      if (tsID == null)
                        throw new OBOEException(id + " not defined in OBOE.properties file");


                      TransactionSet parsedTransactionSet = TransactionSetFactory.buildTransactionSet(tsID);
                      parsedTransactionSet.setFormat(Envelope.EDIFACT_FORMAT);
                      parsedTransactionSet.parse(pis);
                      functionalGroup.addTransactionSet(parsedTransactionSet);
                      parsedTransactionSet.setParent(functionalGroup);

                      if (pis.read(me) != 4)
                       	throw new OBOEException("expected data not read");
                      id = Util.rightTrim(new String(me));
                    }
   				   seg = new Segment(myTemplate.getTemplateFunctionalGroup().getTemplateSegment(EDIFactFunctionalGroup.idTrailer), functionalGroup);
                   seg.parse(pis);
                   if (pis.read(me) != 4)
                   	throw new OBOEException("expected data not read");
                   id = Util.rightTrim(new String(me));
            }

    if (id.compareTo(myTemplate.getTemplateSegment(idInterchangeTrailer).getID()) != 0)
          throw new OBOEException("Expecting " + myTemplate.getTemplateSegment(idInterchangeTrailer).getID());


    seg = new Segment(myTemplate.getTemplateSegment(idInterchangeTrailer), this);
    seg.parse(pis);
    addSegment(seg);

    return true;

   }

    /** creates a basic functionalgroup object
     * @return EDIFactFunctionalGroup
     */
  public FunctionalGroup createFunctionalGroup()
    {
         return new EDIFactFunctionalGroup(myTemplate.getTemplateFunctionalGroup(), this);
    }




  /** gets the Interchange_Header
   * @return Interchange_Header segment
   */
public Segment getInterchange_Header()  {return getSegment(idInterchangeHeader); }


  /** gets the count of Functional Group object in the vector (container);
   * @return int count
   */
public int getFunctionalGroupCount(){return functionalGroups.size();}

  /** gets a Functional Group object from the vector (container);
   *  <br>check for runtime array out of bounds exception
   * @return a FunctionalGroup object
   */
public FunctionalGroup getFunctionalGroup(int pos){return (FunctionalGroup) functionalGroups.elementAt(pos);}

  /** gets the Vector of Functional Group objects
   * @return a Vector of FunctionalGroup objects
   */
public Vector getFunctionalGroups(){return functionalGroups;}

  /** returns the Service String Advice Segment
   *  @return Segment
   */

public Segment getService_String() {return getSegment(idServiceString);}

  /** returns the Interchange Control Trailer built for the envelope
   *  @return Segment
   */

public Segment getInterchange_Trailer() {return getSegment(idInterchangeTrailer);}

  /** sets the functional group count in the trailer */

/** sets the Delimter fields in the header */

public void setDelimitersInHeader()
    throws OBOEException
  {

    if (getInterchange_Header() == null)
       throw new OBOEException("header not set yet");

  }



public void setFGCountInTrailer()
  {

    getInterchange_Trailer().getDataElement(1).set(Integer.toString(getFunctionalGroupCount()));
  }

  /**
   * returns the EDI (EDIFact) formatted document in a String
   * @param format int - format type see TransactionSet
   * @return String the formatted document
   */

public String getFormattedText(int format)
  {
    StringBuffer sb = new StringBuffer();
    if (format == Envelope.VALID_XML_FORMAT) {
            sb.append("<?xml version=\"1.0\"?>"+com.americancoders.util.Util.lineFeed);
            sb.append("<!-- OBOE release " +
//++$$textRelease            build.not.to.be.released
            "-->"+com.americancoders.util.Util.lineFeed);
            sb.append("<!DOCTYPE envelope SYSTEM \"envelope.dtd\">"+com.americancoders.util.Util.lineFeed);
            sb.append("<envelope format=\"EDIFact\">"+com.americancoders.util.Util.lineFeed);
      }
    if  (format == Envelope.XML_FORMAT)
      {
            sb.append("<?xml version=\"1.0\"?>"+com.americancoders.util.Util.lineFeed);
            sb.append("<!-- OBOE release " +
//++$$textRelease            build.not.to.be.released
            "-->"+com.americancoders.util.Util.lineFeed);
            sb.append("<Envelope>"+com.americancoders.util.Util.lineFeed);
      }

    if (format == Envelope.CSV_FORMAT)
       sb.append("Envelope"+com.americancoders.util.Util.lineFeed);

    Segment seg = getSegment(idServiceString);
    if (seg != null) {// not required
       sb.append(seg.getFormattedText(format));

    }

    seg = getSegment(idInterchangeHeader);
    sb.append(seg.getFormattedText(format));

    FunctionalGroup fg;
    for (int i=0; i < getFunctionalGroupCount(); i++)
      {
       fg = (FunctionalGroup)getFunctionalGroup(i);
       sb.append(fg.getFormattedText(format));
      }

    seg = getSegment(idInterchangeTrailer);
    sb.append(seg.getFormattedText(format));
    if  (format == Envelope.XML_FORMAT)
      {
            sb.append("</Envelope>"+com.americancoders.util.Util.lineFeed);
      }
    if (format == Envelope.VALID_XML_FORMAT) {
            sb.append("</envelope>"+com.americancoders.util.Util.lineFeed);
    }

    return new String(sb);
  }




  /**
	 * @see com.americancoders.edi.Envelope#writeFormattedText(Writer, int)
	 */

	public void writeFormattedText(Writer inWriter, int format)
			throws OBOEException, IOException {

		Writer writer = inWriter;


		if (format == Envelope.VALID_XML_FORMAT) {
			writer.write("<?xml version=\"1.0\"?>"
					+ com.americancoders.util.Util.lineFeed);
			writer.write("<!-- OBOE release " +
//++$$textRelease            build.not.to.be.released
					"-->" + com.americancoders.util.Util.lineFeed);
			writer.write("<!DOCTYPE envelope SYSTEM \"envelope.dtd\">"
					+ com.americancoders.util.Util.lineFeed);
			writer.write("<envelope format=\"EDIFact\">"
					+ com.americancoders.util.Util.lineFeed);
		}
		if (format == Envelope.XML_FORMAT) {
			writer.write("<?xml version=\"1.0\"?>"
					+ com.americancoders.util.Util.lineFeed);
			writer.write("<!-- OBOE release " +
//++$$textRelease            build.not.to.be.released
					"-->" + com.americancoders.util.Util.lineFeed);
			writer.write("<Envelope>" + com.americancoders.util.Util.lineFeed);
		}

		if (format == Envelope.CSV_FORMAT)
			writer.write("Envelope" + com.americancoders.util.Util.lineFeed);
		Segment seg = getSegment(idServiceString);
		if (seg != null) // not required
			writer.write(seg.getFormattedText(format));

		seg = getSegment(idInterchangeHeader);
		writer.write(seg.getFormattedText(format));

		FunctionalGroup fg;
		for (int i = 0; i < getFunctionalGroupCount(); i++) {
			fg = (FunctionalGroup) getFunctionalGroup(i);
			fg.writeFormattedText(writer, format);
		}

		seg = getSegment(idInterchangeTrailer);
		writer.write(seg.getFormattedText(format));
		if (format == Envelope.XML_FORMAT) {
			writer.write("</Envelope>" + com.americancoders.util.Util.lineFeed);
		}
		if (format == Envelope.VALID_XML_FORMAT) {
			writer.write("</envelope>" + com.americancoders.util.Util.lineFeed);
		}

		writer.flush();
		writer.close();

	}

  /**
	 * validates
	 * 
	 * @exception OBOEException
	 *                indicates why envelope is invalid
	 */

   public void validate()
    throws OBOEException
    {
   	Segment seg;
   	seg = getSegment(idServiceString);
    if (seg != null) // not required
       seg.validate();

   	seg = getSegment(idInterchangeHeader);
    if (seg == null)
        throw new OBOEException("Missing "+idInterchangeHeader+" Segment");
      else
        seg.validate();
    
	seg.validate();

    FunctionalGroup fg;
    for (int i=0; i < getFunctionalGroupCount(); i++)
      {
       fg = (FunctionalGroup)getFunctionalGroup(i);
       fg.validate();
      }

   	seg = getSegment(idInterchangeTrailer);	
    if (seg == null)
        throw new OBOEException("Missing "+idInterchangeTrailer+" Segment");
      else
   	seg.validate();
    }

  /**
   * validates and places errors in DocumentErrors object
   * @param inDErr DocumentErrors
   */

   public void validate(DocumentErrors inDErr)
    throws OBOEException
    {
   	Segment seg;
   	seg = getSegment(idServiceString);
    if (seg != null) // not required
       seg.validate();
    
   	seg = getSegment(idInterchangeHeader);
    
    if (seg == null)
        inDErr.addError(0, "Envelope", "Missing "+idInterchangeHeader+"  Segment", this, "1", this, 1);
      else
        seg.validate(inDErr);
    
    
    FunctionalGroup fg;
    for (int i=0; i < getFunctionalGroupCount(); i++)
      {
       fg = (FunctionalGroup)getFunctionalGroup(i);
       fg.validate(inDErr);
      }
   	seg = getSegment(idInterchangeTrailer);	
    if (seg == null)
        inDErr.addError(0, "Envelope", "Missing "+idInterchangeTrailer+"  Segment", this, "1", this, 1);
      else
        seg.validate(inDErr);
    }

  /** creates, sets and returns the Service String built for the envelope
   *  @return Segment - can return null if templateenvelope is null or segment not defined in envelope xml rules file
   */

  public Segment createService_String () {
    if (myTemplate == null) return null;
    TemplateSegment tsg = myTemplate.getTemplateSegment(EDIFactEnvelope.idServiceString);
    if (tsg == null) return null;
    Segment seg = new Segment(tsg, this);
    addSegment(seg);
    return seg;
  }


  /** creates, sets and returns the Interchange Control Header built for the envelope
   *  @return Segment - can return null if templateenvelope is null or segment not defined in envelope xml rules file
   */

  public Segment createInterchange_Header() {

    if (myTemplate == null) return null;
    TemplateSegment tsg = myTemplate.getTemplateSegment(EDIFactEnvelope.idInterchangeHeader);

    if (tsg == null) return null;
    Segment seg = new Segment(tsg, this);
    addSegment(seg);
    return seg;
    }

  /** creates, sets and returns the Interchange Control Trailer built for the envelope
   *  @return Segment - can return null if templateenvelope is null or segment not defined in envelope xml rules file
   */

 public Segment createInterchange_Trailer()
   {
    if (myTemplate == null) return null;
    TemplateSegment tsg = myTemplate.getTemplateSegment(EDIFactEnvelope.idInterchangeTrailer);
    if (tsg == null) return null;
    Segment seg = new Segment(tsg, this);
    addSegment(seg);
    return seg;
    }


 /* (non-Javadoc)
  * @see com.americancoders.edi.IContainedObject#getDelimiter(char)
  */

 	public char getDelimiter(char inOriginal) {
 		
 		 
		 if (inOriginal == Envelope.EDIFact_SEGMENT_DELIMITER.charAt(0))
				return segmentDelimiter.charAt(0);

		 if (inOriginal ==  Envelope.EDIFact_GROUP_DELIMITER.charAt(0))
				 return groupDelimiter.charAt(0);
			     
		 if (inOriginal == Envelope.EDIFact_FIELD_DELIMITER.charAt(0))
				 return fieldDelimiter.charAt(0);
			     
		 if (inOriginal == Envelope.EDIFact_REPEAT_DELIMITER.charAt(0)) 
		     return repeatDelimiter.charAt(0);
		 
		 if (inOriginal ==  Envelope.EDIFact_ESCAPE_CHARACTER.charAt(0))
			 return escapeCharacter.charAt(0);


		return inOriginal;
	}
 	
    
}
