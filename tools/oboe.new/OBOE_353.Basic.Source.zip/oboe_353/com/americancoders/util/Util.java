package com.americancoders.util;

/**
 *OBOE - Open Business Objects for EDI
 *<p>Copyright 1998-2007 - American Coders, LTD  - Raleigh NC USA
 *<p>All rights reserved
 *<p>American Coders, Ltd
 *<br>P. O. Box 97462
 *<br>Raleigh, NC  27624  USA
 *<br>1-919-846-2014
 *<br>http://www.americancoders.com
@author Joe McVerry - American Coders, Ltd.
  @version   3.5.3
 */

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Reader;
import java.text.DecimalFormat;
import java.util.Calendar;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.StringTokenizer;

import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.americancoders.edi.Envelope;
import com.americancoders.edi.OBOEException;


/**
 * class of utility routines
 *
 */
public class Util {

	

	
   static Logger logr = Logger.getLogger(Util.class);
   
   static boolean log4JConfigured = false;
   
	static java.util.Properties props = new java.util.Properties();
	static File propFile = null;
	static InputStream propIS = null;
	static long lastUpdate = -1;
	
	static boolean recheckProperties;
	    
	
	static {
		if (log4JConfigured == false) {
            
			Enumeration enumeration = Logger.getRootLogger().getAllAppenders();
			if ((enumeration != null)
					&& (!(enumeration instanceof org.apache.log4j.helpers.NullEnumeration))) {
				log4JConfigured = true;
			} else {
				Enumeration loggers = LogManager.getCurrentLoggers();
				while (loggers.hasMoreElements()) {
					Logger c = (Logger) loggers.nextElement();
					if (!(c.getAllAppenders() instanceof org.apache.log4j.helpers.NullEnumeration))
						log4JConfigured = true;
				}
			}
			if (log4JConfigured == false) {
				if (Util.isLog4JNotConfigured())   
				if (new File("log4j.properties").exists())
					PropertyConfigurator.configure("log4j.properties");
				else
					BasicConfigurator.configure();
				log4JConfigured = true;
			}
                logr.info("Running - OBOE version  3.5.3 ");
		}
		
		
		try {
			String test = getOBOEProperty("checkPropertyFileForChanges");
			if (test != null)
			   recheckProperties = (test.compareToIgnoreCase("true")==0 || test.compareToIgnoreCase("yes")==0);
			}
			catch (Exception e)
			{
				logr.error(e.getMessage(), e);
			}
			finally {
				logr.debug("recheckProperties is " + recheckProperties);
				
			}
			
		
	   
	}
	
	

	/** line separator character used by local operating system.
	 */

	public static final String lineFeed = System.getProperty("line.separator");
	
	static HashSet hs = new HashSet();

	private static String servletContextPath = null;

	public static void setServletContextPath(String inPath) {
		servletContextPath = inPath;
	}

	/**
	 * @return String date in format CCYYMMDD
	 */
	public static String currentDate() {
		Calendar currentDateTime = Calendar.getInstance();
		DecimalFormat df = new DecimalFormat("00000000");

		return (
			df.format(
				currentDateTime.get(Calendar.YEAR) * 10000
					+
					+ ((currentDateTime.get(Calendar.MONTH)) + 1) * 100
					+
					+ (currentDateTime.get(Calendar.DAY_OF_MONTH))));

	}

	/**
	 *
	 * @return String time in format HHMM  24hour
	 */
	public static String currentTime() {
		Calendar currentDateTime = Calendar.getInstance();
		DecimalFormat df = new DecimalFormat("0000");

		return (
			df.format(
				currentDateTime.get(Calendar.HOUR_OF_DAY) * 100
					+
					+ currentDateTime.get(Calendar.MINUTE)));
	}

	/**
	 * normlizes the string to remove XML characters.
	 * @param inString to be normalized
	 * @return String normalized
	 */
	public static String normalize(String inString) {
		int i;
		StringBuffer sb = new StringBuffer();
		for (i = 0; i < inString.length(); i++)
			switch (inString.charAt(i)) {
				case '&' :
					sb.append("&amp;");
					break;
				case '<' :
					sb.append("&lt;");
					break;
				case '>' :
					sb.append("&gt;");
					break;
				case '"' :
					sb.append("&quot;");
					break;
				case '\'' :
					sb.append("&apos;");
					break;
				default :
					if (inString.charAt(i) < ' ')
						// what to do with control codes
						sb.append(inString.charAt(i) + '\uee00');
					else
						sb.append(inString.charAt(i));
			}

		return new String(sb);
	}

	/**
	 * normlizes the string to remove NonUnicode characters.
	 * @param inString to be normalized
	 * @return String normalized
	 */
	public static String normalizeNonUnicode(String inString) {
		int i;
		StringBuffer sb = new StringBuffer();
		byte bytes[] = inString.getBytes();
		for (i = 0; i < inString.length(); i++) {
			//sb.append("#"+java.lang.Character.digit(inString.charAt(i),10));
			sb.append(bytes[i] + "#");
		}

		return new String(sb);
	}
	/**
	 * normlizes the string to replace NonUnicode characters.
	 * @param inString to be normalized
	 * @return String normalized
	 */
	public static String denormalizeNonUnicode(String inString) {
		int i = -1;

		StringTokenizer st = new StringTokenizer(inString, "#");
		String token;

		byte b[] = new byte[st.countTokens()];
		while (st.hasMoreTokens()) {
			token = st.nextToken();
			i++;
			b[i] = (byte) Integer.parseInt(token);
		}

		return new String(b);
	}
	/** removes escape characters
	 * @param inString
	 * @param inEscString
	 * @return String
	 */
	public static String unEscape(String inString, String inEscString) {

        if (inString == null) return "";
        if (inEscString == null) return inString;
		StringBuffer sb = new StringBuffer();
		
		for (int i = 0; i < inString.length(); i++) {
			if (inEscString.indexOf(inString.charAt(i)) == -1)
				sb.append(inString.charAt(i));
			else {
				i++;
				sb.append(inString.charAt(i));
			}

		}
		return new String(sb);
	}

	/**
	 * starting with the full file name search down the specified absolute path
	 * to find the file
	 * @param inFilename - String, full path name for file
	 * @param inStopAtDir - String, stop looking after  reaching this directory.
	 * @return String the file name found
	 * @throws OBOEException - file not found
	 */

	public static String searchForFile(String inFilename, String inStopAtDir) {
		String theName = inFilename;
		String endDir = " ";
		// we go through the loop at least once, so set this at the end of loop
		String name;
		String stopDir = (inStopAtDir == null ? "" : inStopAtDir);
		//if no stopdir sent set to zero-length string.
		File f;
		int pos, nextpos;
		while (true) {
			f = new File(theName);
			name = f.getName();
			if (f.exists())
				if (f.isDirectory() == false)
					return theName;
			if (stopDir.compareTo(endDir) == 0)
				break;
			pos = f.getAbsolutePath().lastIndexOf(File.separator);
			if (pos < 0)
				break;
			nextpos =
				f.getAbsolutePath().substring(0, pos).lastIndexOf(
					File.separator);
			if (nextpos < 0)
				break;
			endDir = f.getAbsolutePath().substring(0, nextpos) + File.separator;
			theName = endDir + name;
		}
		throw new OBOEException("File " + inFilename + " not found.");
	}

	/** routine to test to see if parsers should throw exceptions or
    based on property in OBOE.properties file "throwParsingException"
    @return boolean
 */
public static boolean propertyFileIndicatesThrowParsingException() {
	
	boolean throwException = true;
	try {
		String throwPE = getOBOEProperty("throwParsingException");
		if (throwPE != null)
			throwException = throwPE.toLowerCase().compareTo("false") != 0;
		// anything but false assumes true
	} catch (java.io.IOException ioe) {
		;
	} // ignore and assume true
	

	return throwException;

}
/** routine to test to see if we want to do the prevalidation logic
 * <br>prevalidation is the function of segments to check to see if there valid by the first id code field in the container
@return boolean
*/
public static boolean propertyFileIndicatesDoPrevalidate() {

	boolean doPrevalidate = false;
	try {
		String doPrevalid = getOBOEProperty("doPrevalidate");
		if (doPrevalid != null)
			doPrevalidate = doPrevalid.toLowerCase().compareTo("true") == 0;
		// anything but "true" assumes false
	} catch (java.io.IOException ioe) {
		;
	} // ignore and assume false


return doPrevalidate;

}


	/** copy file using string file name
	 *
	 * @param inputFile
	 * @param outputFile
	 * @throws IOException
	 */

	public static void copyFile(String inputFile, String outputFile)
		throws IOException {
		FileInputStream fis = new FileInputStream(inputFile);
		FileOutputStream fos = new FileOutputStream(outputFile);
		for (int b = fis.read(); b != -1; b = fis.read())
			fos.write(b);
		fos.close();
		fis.close();

	}

	/** routine to test to see if parsers allows try to use object files
	    based on property in OBOE.properties file "useObject"
	    @return boolean, default value is false
	 */
	public static boolean propertyFileIndicatesUseObject() {
		boolean useObject = false;
		try {
			String testObject = getOBOEProperty("useObject");
			if (testObject != null)
				useObject = (testObject.toLowerCase().compareTo("true") == 0);
			// anything but true assumes false
			//          useObject = Boolean.valueOf(testObject.toLowerCase().compareTo("true") == 0);  // anything but true assumes false
		} catch (java.io.IOException ioe) {
			;
		} 

		return useObject;
		

	}

	/** removes trailing spaces
	 * @param inString
	 * @return String
	 */
	public static String rightTrim(String inString) {
		int len = inString.length();
		int i = 0;
		for (i = len - 1; i > -1; i--)
			if (inString.charAt(i) != ' ')
				break;
		return inString.substring(0, i + 1);
	}


	/*
	 * sets a value in the OBOE.properties
	 * @param inName
	 * @param inValue
	 * @throws IOException
	 */
	public static void setOBOEProperty(String inName, String inValue) 
	{
		synchronized (props) {
			props.setProperty(inName, inValue);
		}
	}

	/*
	 * returns a value of a name in the OBOE.properties file.  will
	 * return null if property not found
	 * @param String name
	 * @return String value of name
	 * @throws IOException
	 */
	public static String getOBOEProperty(String inString) throws  IOException
	{
		synchronized (props) {
			
		if (props == null)
			props = new java.util.Properties();
		

		if (propFile == null && propIS == null) {
			propIS = getPropertiesFile();
			if (propFile != null) {
				lastUpdate = propFile.lastModified();
			}
			logr.debug("loading properties");
			props.load(propIS);
			propIS.close();
		}
			
		if (propFile != null && recheckProperties == true) {
			//propFile = new File(propFile.getAbsolutePath());
    		if (lastUpdate < propFile.lastModified())
    		{
    			//props = new java.util.Properties();

    			propIS = new FileInputStream(propFile);
    			lastUpdate = propFile.lastModified();
    			logr.debug("loading properties, because modified");
    			props.load(propIS);
    			propIS.close();
    		}
		}
		String rets = props.getProperty(inString);
		if (rets != null)
			rets = rets.trim();
		return rets;
		}
	}
	/** use this if you need to reset the property file which is usually left open
	 * 
	 *
	 */
	public static void closeOBOEProperty() {
		synchronized (props) {
			
			propFile = null;
			if (propIS != null) {
				try {
					propIS.close();
				} catch (IOException e) {
					logr.fatal(e.getMessage(), e);
				}
				propIS = null;
			}
			props = new java.util.Properties();
			

		}
	}

	/**
	 * static class method to build the properties file input stream see
	 * OBOE.properties file
	 * <ul>search for OBOE.properties files
	 * <li>as specified by system property OBOE.properties
	 * <li>local directory
	 * <li>user.home directory
	 * <li>java.home directory
	 * <li>classpath environment variable
	 * </ul>
	 * 
	 * @return InputStream OBOE.properties file
	 * @throws OBOEException
	 *             io error most likely
	 */
	private static InputStream getPropertiesFile() throws OBOEException {
		String OBOEPropertiesFileName = "OBOE.properties";
		
		String _fileName = System.getProperty(OBOEPropertiesFileName);
		if (_fileName != null)
		    OBOEPropertiesFileName = _fileName;
		File f3, f2, f1 = new File(OBOEPropertiesFileName);
		if (f1.exists())
			try {
				propFile = f1;
				logr.info("properties file loaded from "+f1.getAbsolutePath());
				return new FileInputStream(f1);
			} catch (FileNotFoundException fnfe) {
				fnfe.printStackTrace();
				throw new OBOEException(fnfe.getMessage());
			} else {
			OBOEPropertiesFileName =
				System.getProperty("user.home") + "/OBOE.properties";
			f2 = new File(OBOEPropertiesFileName);
			if (f2.exists())
				try {
					propFile = f2;
					logr.info("properties file loaded from "+f2.getAbsolutePath());
					return new FileInputStream(f2);
				} catch (FileNotFoundException fnfe) {
					fnfe.printStackTrace();
					throw new OBOEException(fnfe.getMessage());
				} else {
				OBOEPropertiesFileName =
					System.getProperty("java.home") + "/OBOE.properties";
				f3 = new File(OBOEPropertiesFileName);
				if (f3.exists()) {
					try {
						propFile = f3;
						logr.info("properties file loaded from "+f3.getAbsolutePath());
						return new FileInputStream(f3);
					} catch (FileNotFoundException fnfe) {
						fnfe.printStackTrace();
						throw new OBOEException(fnfe.getMessage());
					}
				}
				else {
                    
					InputStream is = (new Util()).getClass().getResourceAsStream("OBOE.properties");
					if (is == null) {
					 if (servletContextPath == null) // try it again 
						is = ClassLoader.getSystemClassLoader().getResourceAsStream("OBOE.properties");
					 else { // context is not null 	
					   try {
						is = new FileInputStream(servletContextPath + "/OBOE.properties");
						logr.info("properties file loaded from servlet context path "+servletContextPath + "/OBOE.properties");
						propFile = new File(servletContextPath + "/OBOE.properties");

					   }
					   catch (IOException ioe){
					 	logr.error("Searched for OBOE.properties as " + servletContextPath + "/OBOE.properties");
					     }
					  }
					}
					if (is != null) {
						logr.info("properties file loaded from classpath");
						return is;
					} else {
						logr.error(
							"Searched for OBOE.properties as "
								+ f1.getAbsolutePath());
						logr.error(
							"Searched for OBOE.properties as "
								+ f2.getAbsolutePath());
						logr.error(
							"Searched for OBOE.properties as "
								+ f3.getAbsolutePath());
						logr.error(
							"Searched for OBOE.properties in classpath environment variable");
						throw new OBOEException("OBOE.properties file not found");
					}
				}
			}

	}

}

/** gets and returns the x12 composite element seperator character */
public static String getCES() {
	return Envelope.X12_GROUP_DELIMITER;
}

/**
 * input  blocked data.  returns it as a stream. data blocked by cr/lf.
 * @param inIS InputStream object
 * @return InputStream object
 * @throws IOException
 */
public static InputStream removeCRLFFromStream(InputStream inIS) throws IOException
{

	BufferedReader br = new BufferedReader(new InputStreamReader(inIS));
	ByteArrayOutputStream baos = new ByteArrayOutputStream();
	


	String readString = br.readLine();

	do {
		
		baos.write(readString.getBytes());
		baos.flush();
		readString = br.readLine();

	} 	while (readString != null) ;


    baos.flush();
    baos.close();
	return new ByteArrayInputStream(baos.toByteArray());

}

/**
 * input  blocked data.  returns it as a stream. data blocked by cr/lf.
 * @param inReader Reader object
 * @return Reader object
 * @throws IOException
 */
    public static Reader removeCRLFFromReader(final Reader inReader)
            throws IOException {

        BufferedReader br = new BufferedReader(inReader);
        File f = File.createTempFile("oboe", "tmp");
        FileWriter fw = new FileWriter(f);

        try {
            String readString = br.readLine();

            do {
                fw.write(readString);
                fw.flush();
                readString = br.readLine();

            } while (readString != null);

        } catch (IOException e) {
            logr.error(e.getMessage(), e);
        }

        fw.flush();
        fw.close();

        return new FileReader(f);

    }

public static void main(String args[]){
    try{
    Reader r = removeCRLFFromReader(new FileReader("c:/eclipse/workspace/oboe/source/com/americancoders/util/util.java"));
    int b;
    while (( b = r.read()) > -1)
    System.out.print((char) b);
    }
    catch(Exception e){e.printStackTrace();}
}


/** 
Returns true if it appears that log4j have been previously configured. This code 
checks to see if there are any appenders defined for log4j which is the 
definitive way to tell if log4j is already initialized */ 
public static boolean isLog4JNotConfigured() {
	return !log4JConfigured;
} 


/** returns a deep copy of an object
 *  <br>JavaWorld Javatip 76 by Dave Miller
 *  <br>http://www.javaworld.com/javaworld/javatips/jw-javatip76.html
 * @param fromObj
 * @param toObj
 */
static public void deepCopy(java.io.Externalizable fromObj, java.io.Externalizable toObj) 
{
  
   if (fromObj == toObj)
       throw new OBOEException("fromObject is the same as toObj");
   ObjectOutputStream oos = null;
   ObjectInputStream ois = null;
   ByteArrayOutputStream bos = new ByteArrayOutputStream(); // A
      try {
	      oos = new ObjectOutputStream(bos); // B
	      // serialize and pass the object
	      fromObj.writeExternal(oos);
	      oos.flush();               // D
	      ByteArrayInputStream bin =
	            new ByteArrayInputStream(bos.toByteArray()); // E
	      ois = new ObjectInputStream(bin);                  // F
	      toObj.readExternal(ois);
	      oos.close();
	      ois.close();
	      return; // G
	} catch (IOException e) {
		logr.error(e.getMessage(),e);
		return;
	} catch (ClassNotFoundException e) {
		logr.error(e.getMessage(),e);
	}
	finally {
		try {
			oos.close();
		}
		catch (IOException ioe)
		{
			logr.error(ioe.getMessage());
		}
		finally {}
		
		try {
			ois.close();
		}
		catch (IOException ioe)
		{
			logr.error(ioe.getMessage());
		}
	}
	
	
}


public static boolean isInteger(String arg)
{
	if (arg.length() == 0)
		return false;
	for (int len=0; len < arg.length(); len++)
		if (arg.charAt(len)<'0' || arg.charAt(len)>'9')
				return false;
	
	return true;
	
}





}
