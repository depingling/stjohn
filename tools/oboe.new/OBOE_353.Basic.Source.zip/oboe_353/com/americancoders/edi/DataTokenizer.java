package com.americancoders.edi;

import java.util.Vector;

/**
 *  class to assist in tokenizing input transaction sets
 * <br> similar to the java.lang.StringTokenizer.
 * It seemed that StringTokenizer couldn't return a zero-length
 * element between 2 tokens - such as token(*) and string in is (***) it would not find 2
 * zero-length tokens.
 * <br>
 *<p>OBOE - Open Business Objects for EDI
 *<p>Part of the OBOE Basic Extended Package
 *<br>An EDI and XML Translator Written In Java
 *<br>Copyright 1998-2007 - American Coders, LTD  - Raleigh NC USA
 *<br>All rights reserved
 *<br>American Coders, Ltd
 *<br>P. O. Box 97462
 *<br>Raleigh, NC  27624  USA
 *<br>1-919-846-2014
 *<br>http://www.americancoders.com
@author Joe McVerry - American Coders, Ltd.
  @version   3.5.3
 */

public class DataTokenizer implements IDataTokenizer {
	/**
	 * current position within tokenized string
	 */
	protected int currentPos;
	/**
	 * length of field
	 */
	protected int stringLength;
	/**
	 * current tokenized string
	 */
	protected String tokenString;
	/**
	 * what breaks up fields
	 */
	protected String tokens;
	/**
	 * escape characters to allow tokens in the text
	 */
	protected String escapeCharacters = "";

	/**
	 * where all the substrings are stored
	 */
	protected Vector allTokens = new Vector();
	
	protected int positionInStream;
	

	/**
	 *  constructor
	 *  @param inString - string to be tokenized
	 *  @param inTokens - list of tokens
	 *  @param  inEscapeCharacters - list of characters to escape and allow
	 * tokens in the text.      pass an empty string or null if no escape
	 * characters used
	 */
	public DataTokenizer(
		String inString,
		String inTokens,
		String inEscapeCharacters) {
		int startPos = 0;
		tokenString = inString;
		stringLength = tokenString.length();
		tokens = inTokens;
		if (inEscapeCharacters != null)
			escapeCharacters = inEscapeCharacters;

		StringBuffer sb = new StringBuffer();

		currentPos = 0;
	

		while (currentPos < stringLength) {
			if (escapeCharacters.indexOf(tokenString.charAt(currentPos))
				> -1) {
				//if ((tokens.indexOf(tokenString.charAt(currentPos + 1)) > -1)
				//	|| (escapeCharacters
				//		.indexOf(tokenString.charAt(currentPos + 1))
				//		> -1)) {
				    sb.append(tokenString.charAt(currentPos));
					currentPos++;
					sb.append(tokenString.charAt(currentPos));
					currentPos++;
					continue;
				//}
			}
			if (tokens.indexOf(tokenString.charAt(currentPos)) > -1) {
				allTokens.addElement(new String(sb));
				sb = new StringBuffer();
				currentPos++;
				startPos = currentPos;
				continue;
			}
			sb.append(tokenString.charAt(currentPos));
			currentPos++;
		}
		if (currentPos != startPos)
			allTokens.addElement(new String(sb));
		currentPos = -1;
	}

	/**
	 *  to get next token
	 *  @return String - the next token
	 *
	 */
	public String nextToken() {

		currentPos++;
		if (currentPos < allTokens.size())
			return (String) allTokens.elementAt(currentPos);

		return null;

	}

	/** gets the token in tokenized string at a specifiec position
	 * @param pos int position, if < 0 or > the total returns null
	 * @return String
	 */
	public String getTokenAt(int pos) {
		if (pos < 0)
			return null;
		if (pos < allTokens.size())
			return (String) allTokens.elementAt(pos);
		return null;

	}

	/**
	 *  indicates if there are more data elements to parse
	 *  @return boolean  more to parse?
	 *
	 */
	public boolean hasMoreElements() {
		return (currentPos < allTokens.size());
	}

	/**
	 *  how many tokens in list
	 *  @return int - a count
	 *
	 */
	public int countTokens() {

		return allTokens.size();
	}

	/**
	 */
	public String getTokenString() {
		return tokenString;
	}

	public int getPositionInStream() {
		return positionInStream;
	}

	public void setPositionInStream(int positionInStream) {
		this.positionInStream = positionInStream;
	}
	
	
}
