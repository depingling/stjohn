package com.americancoders.edi;

import java.io.CharArrayWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.util.Vector;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.apache.log4j.Logger;
import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import org.xml.sax.ext.LexicalHandler;
import org.xml.sax.helpers.DefaultHandler;

import com.americancoders.util.Util;

/** SAX2 parser handler for IDList xml files
 *<P>OBOE - Open Business Objects for EDI
 *<p>Part of the OBOE Basic Extended Package
 *<br>An EDI and XML Translator Written In Java
 *<br>Copyright 1998-2007 - American Coders, LTD  - Raleigh NC USA
 *<br>All rights reserved
 *<br>American Coders, Ltd
 *<br>P. O. Box 97462
 *<br>Raleigh, NC  27624  USA
 *<br>1-919-846-2014
 *<br>http://www.americancoders.com
@author Joe McVerry - American Coders, Ltd.
  @version   3.5.3
 */

public class IDListParser extends DefaultHandler
  implements LexicalHandler
{
    /** current element count
     */
    protected int		  _iElement = 0;
    /** current line number
     */
    protected int		  _iLine = 0;
    /** vectors of idlist codes and values
     */
    protected Vector	  codes, values;
    /** currently working vector and last vector processsed
     */
    protected Vector      currentVector, lastVector = null;
    //protected org.xml.sax.Parser parser;
    /** SAX parser
     */
    protected SAXParser parser;
    // Buffer for collecting data from
    // the "characters" SAX event.
    private CharArrayWriter contents = new CharArrayWriter();

	/** directory path for xml file
	 */
	protected String xmlDirectoryPath = "." + File.pathSeparator + ".";

	static Logger logr = Logger.getLogger(IDListParser.class);
	static 	{Util.isLog4JNotConfigured();}

    /**
     * constructor, sets up SAX parser,
     * turns off validation, turns on namespaces,
     * sets up content handler and error handler as this object.
     * sax exceptions go to System.err
     */
    public IDListParser() throws OBOEException{
    	
        try {
        	SAXParserFactory spf = SAXParserFactory.newInstance();
			spf.setNamespaceAware(TransactionSetFactory.getNamespaceOption() == true);
			spf.setValidating(true);
            parser = spf.newSAXParser();
			parser.getXMLReader().setProperty("http://xml.org/sax/properties/lexical-handler", this);

             }
         catch (Exception e1)  {e1.printStackTrace();}
		try {
			xmlDirectoryPath =Util.getOBOEProperty("xmlPath");
			if (xmlDirectoryPath == null)
			xmlDirectoryPath = "";
			// used by RICE application
		} catch (Exception ex) {
			logr.error("message" + ex.getMessage());
			ex.printStackTrace();
			throw new OBOEException(ex.getMessage());
		}
    }

    private String xmlFile = null;
    /** makes the SAX2 parser call
     * @param inXMLFile String of filename to parse
     * @param inLastDirectoryToLook - name of the top directory where the IDList file could reside
     * @param vCodes vector of codes
     * @param vValues vector of code descriptive values
     */
    public void parse(String inXMLFile, String inLastDirectoryToLook, Vector vCodes, Vector vValues)
    {
        xmlFile = Util.searchForFile(inXMLFile, inLastDirectoryToLook);
        try {
            codes = vCodes;
            values = vValues;

            InputSource is = new InputSource(new FileReader(xmlFile));
			is.setSystemId("");
            parser.parse(is, this);
        } /* endtry */
        catch ( Exception e1 ) {
        	logr.error("message" + e1.getMessage());
            e1.printStackTrace();

        } /* endcatch */


    }

    /** method called for each xml element found.
     * <br> process logic
     * <ul>
     * <li> based on the name of the element found
     * <li> for each pull appropriate attributes and construct object
     * <li> if owned by another class, and all are except for Standard, add it to its parents object
     * </ul>
     * @param uri URI of incoming file
     * @param localName String of element's local name
     * @param rawName String of element's raw name
     * @param attributes Vector of the elements attributes
     * @throws SAXException many possible exceptions
     */
    public void startElement(java.lang.String uri,
    java.lang.String localName,
    java.lang.String rawName,
    Attributes attributes)
    throws SAXException
    {

        _iElement++;

        contents.reset();


        // Standard

        if (rawName.compareTo("") == 0) {
            return;
        }

        // MessageDirectory
        if (rawName.compareTo("idList") == 0)
            return;

        if (rawName.compareTo("idCode") == 0)
            currentVector = codes;
        else if (rawName.compareTo("idValue") == 0)
            currentVector = values;
        else logr.error("Logic error: Unknown element name \"" + rawName
            + "\" found at element position " + _iElement + " line: " + _iLine);
    }


    /** catches the element's value
     * @param ch char array of the current element value contents
     * @param start int start position within the array
     * @param length int of characters found so far
     * @throws SAXException many possible
     */
    public void characters(char ch[], int start, int length)
    throws SAXException {
        contents.write( ch, start, length );
		for (int i = start; i < start + length; i++)
			if (ch[i] == '\n')
				_iLine++;
	
    }

    /** Method called by the SAX parser at the </
     * @param uri URI of incoming file
     * @param localName String of element's local name
     * @param rawName String of element's raw name
     * @throws SAXException many possible
     */
    public void endElement(java.lang.String uri,
    java.lang.String localName,
    java.lang.String rawName)
    throws SAXException{

        if (rawName.compareTo("idCode") == 0
          || rawName.compareTo("idValue") == 0)
        currentVector.addElement(contents.toString());

    }

    /** I use this to keep track of line #s
     * @param ch char array of found whitespaces
     * @param start int start position in array
     * @param length int length of what's been found
     */
    public void ignorableWhitespace(char[] ch, int start, int length)
    {
        for (int i=start; i < start+length; i++)
        if (ch[i] == '\n') _iLine++;
    }

    /** catches warning SAXParseExceptions
     * this code sends exception to stdio and allows public classto continue
     * @param e SaxException object
     * @throws SAXException exception
     */
    public void warning(SAXParseException e) throws SAXException {
        logr.error("Warning at (file " + xmlFile + ", line "
        + e.getLineNumber() + ", char "
        + e.getColumnNumber() + "): " + e.getMessage());
    }

    /** catches error SAXParseExceptions
     * this code causes exception to continue
     * @param e SaxException object
     * @throws SAXException thrown
     */
    public void error(SAXParseException e) throws SAXException {
        throw new SAXException("Error at (file " + xmlFile
        + ", line " + e.getLineNumber() + ", char "
        + e.getColumnNumber() + "): "
        + e.getMessage());
    }

    /** catches fatal SAXParseExceptions
     * this code causes exception to continue
     * @param e SAXException object
     * @throws SAXException thrown
     */
    public void fatalError(SAXParseException e) throws SAXException {
        throw new SAXException("Fatal Error at (file " + xmlFile
        + ", line " + e.getLineNumber() + ", char "
        + e.getColumnNumber() + "): "
        + e.getMessage());
    }

	/* (non-Javadoc)
	 * @see org.xml.sax.ext.LexicalHandler#startDTD(java.lang.String, java.lang.String, java.lang.String)
	 */
	public void startDTD(String arg0, String arg1, String arg2) throws SAXException {
		// 
		
	}

	/* (non-Javadoc)
	 * @see org.xml.sax.ext.LexicalHandler#endDTD()
	 */
	public void endDTD() throws SAXException {
		// 
		
	}

	/* (non-Javadoc)
	 * @see org.xml.sax.ext.LexicalHandler#startEntity(java.lang.String)
	 */
	public void startEntity(String arg0) throws SAXException {
		// 
		
	}

	/* (non-Javadoc)
	 * @see org.xml.sax.ext.LexicalHandler#endEntity(java.lang.String)
	 */
	public void endEntity(String arg0) throws SAXException {
		// 
		
	}

	/* (non-Javadoc)
	 * @see org.xml.sax.ext.LexicalHandler#startCDATA()
	 */
	public void startCDATA() throws SAXException {
		// 
		
	}

	/* (non-Javadoc)
	 * @see org.xml.sax.ext.LexicalHandler#endCDATA()
	 */
	public void endCDATA() throws SAXException {
		// 
		
	}

	/* (non-Javadoc)
	 * @see org.xml.sax.ext.LexicalHandler#comment(char[], int, int)
	 */
	public void comment(char[] chars, int start, int length) throws SAXException {
		for (int i = start; i < start+length; i++)
			if (chars[i]=='\n')
				_iLine++;
		
	}
    
	/** resolves the DTD file name for the xerces parser
	 * @param publicId -  String name of xml public id
	 * @param systemId - String name of xml system id
	 * @return InputSource the dtd
	 */

	public InputSource resolveEntity(
		java.lang.String publicId,
		java.lang.String systemId)
		throws SAXException
	//java.io.IOException
	{
		try {
			if (publicId != null) {
				if (publicId.indexOf("://") < 1) {
					return new InputSource(
						new FileInputStream(
							xmlDirectoryPath + File.separator + publicId));
				}
				File f = new File(publicId);
				if (f.exists())
					return null;
				String sf = f.getName();
				return new InputSource(
					new FileInputStream(
						xmlDirectoryPath + File.separator + sf));
			}
			if (systemId != null) {
				if (systemId.indexOf("://") < 1) {
					return new InputSource(
						new FileInputStream(
							xmlDirectoryPath + File.separator + systemId));
				}
				File f = new File(systemId);
				if (f.exists())
					return null;
				String sf = f.getName();
				return new InputSource(
					new FileInputStream(
						xmlDirectoryPath + File.separator + sf));

			}
		} catch (Exception e) {
			throw new SAXException(e);
		}
		return null;
	}

    //
    /** get SAX parser
     * @return SAXParser
     */
    public SAXParser getParser()
     {return parser;}

    /** returns number of code/value pairs
     * @return int
     */
public int getCount() {return codes.size();}
/** gets code as specific location
 * @param i int position to look at
 * @return String
 */
public String getCode(int i) {return (String) codes.elementAt(i); }
/** returns descriptive value at position
 * @param i int position to look at
 * @return String
 */
public String getValue(int i) {return (String) values.elementAt(i); }

}

