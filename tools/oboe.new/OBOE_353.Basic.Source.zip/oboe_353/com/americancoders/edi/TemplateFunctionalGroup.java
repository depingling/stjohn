package com.americancoders.edi;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.util.Vector;

/**
 *class for Template FunctionalGroups
 *<p>OBOE - Open Business Objects for EDI
 *<p>Part of the OBOE Basic Extended Package
 *<br>An EDI and XML Translator Written In Java
 *<br>Copyright 1998-2007 - American Coders, LTD  - Raleigh NC USA
 *<br>All rights reserved
 *<br>American Coders, Ltd
 *<br>P. O. Box 97462
 *<br>Raleigh, NC  27624  USA
 *<br>1-919-846-2014
 *<br>http://www.americancoders.com
@author Joe McVerry - American Coders, Ltd.
  @version   3.5.3
 */

public class TemplateFunctionalGroup
	extends TemplateSegmentContainer
	implements Externalizable, IContainedObject {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/** creates a FunctionalGroup object
	 */
	public TemplateFunctionalGroup() {
		templateContainer = new Vector();

	}

	/** creates a FunctionalGroup object
	 * @param inParent owning Object
	 */
	public TemplateFunctionalGroup(IContainedObject inParent) {
		setParent(inParent);
		templateContainer = new Vector();

	}
	/** used by externalize methods
	 * @param in ObjectInput stream
	 * @exception IOException - most likely class changed since written
	 * @exception ClassNotFoundException - only when dummy constructro not found
	 */

	public void readExternal(ObjectInput in)
		throws IOException, ClassNotFoundException {
		templateContainer = (Vector) in.readObject();
	}

	/** used by externalize methods
	 * @param out ObjectOutput stream
	 * @exception IOException Java.io error
	 */

	public void writeExternal(ObjectOutput out) throws IOException {
		out.writeObject(templateContainer);

	}
	protected IContainedObject parent = null;
	/** sets parent attribute
	 * @param inParent TemplateSegmentContainer
	 */
	public void setParent(IContainedObject inParent) {
		parent = inParent;
	}

	/** gets parent attribute
	 * @return TemplateSegmentContainer
	 */
	public IContainedObject getParent() {
		return parent;
	}

	public String getID() {
		return "template fg";
	}
	public String getXMLTag() {
		return "<templateFG>";
	}
	/* (non-Javadoc)
	 * @see com.americancoders.edi.IContainedObject#getDelimiter(char)
	 */

		public char getDelimiter(char inOriginal) {
			
			return parent.getDelimiter(inOriginal);
		}

}
